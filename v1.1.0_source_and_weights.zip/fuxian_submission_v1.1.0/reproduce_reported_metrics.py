"""Independently recompute all 192 Version-27 expanded-domain metric rows.

Only numpy, scipy and scikit-image are required. Verifies cached thresholding and
metric computation, not neural inference or training; rerun those from imagery.
"""
from pathlib import Path
import csv,hashlib,json
import numpy as np
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu
ROOT=Path(__file__).resolve().parent
EXP=ROOT/'preexperiment/results/v27_index_jrc_20261001'
KEYS=('precision','recall','f1','iou','boundary_f1_30m','boundary_f1_60m','mean_symmetric_boundary_distance_m','hd95_m')
def metric(pred,truth,valid,wide):
    p,t=pred[valid],truth[valid];tp=int((p&t).sum());fp=int((p&~t).sum());fn=int((~p&t).sum())
    precision=tp/max(tp+fp,1);recall=tp/max(tp+fn,1)
    out={'precision':precision,'recall':recall,'f1':2*precision*recall/max(precision+recall,1e-12),'iou':tp/max(tp+fp+fn,1)}
    safe=ndi.binary_erosion(valid,iterations=1);query=ndi.binary_erosion(valid&wide,iterations=3)
    a=(pred^ndi.binary_erosion(pred))&safe;b=(truth^ndi.binary_erosion(truth))&safe
    aq=a&query;bq=b&query
    if not aq.any() or not bq.any():raise RuntimeError('Empty boundary in archived cache')
    ab=(ndi.distance_transform_edt(~b)*30)[aq];ba=(ndi.distance_transform_edt(~a)*30)[bq]
    out['mean_symmetric_boundary_distance_m']=float((ab.mean()+ba.mean())/2)
    out['hd95_m']=float(max(np.percentile(ab,95),np.percentile(ba,95)))
    for tol in (30,60):
        bp=float((ab<=tol).mean());br=float((ba<=tol).mean());out[f'boundary_f1_{tol}m']=2*bp*br/(bp+br+1e-12)
    return out
def main():
    rows=list(csv.DictReader((EXP/'per_date_metrics.csv').open(encoding='utf-8-sig',newline='')))
    manifest=json.loads((EXP/'verification_cache/manifest.json').read_text(encoding='utf-8'));count=0;worst=0.
    for r in manifest['records']:
        p=EXP/'verification_cache'/f"{r['tag']}.npz"
        if hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:raise RuntimeError('Cache hash mismatch')
        a=dict(np.load(p));preds={m:a[m] for m in ('jrc_2019','spatial_prior','deep_prewitt','parameter_matched_ordinary_conv')}
        for index in ('ndwi','mndwi'):
            vals=a[index][a['valid']&np.isfinite(a[index])];otsu=float(threshold_otsu(vals,nbins=256))
            if abs(otsu-r['thresholds'][index+'_otsu'])>1e-7:raise RuntimeError('Otsu threshold mismatch')
            for suffix,threshold in (('zero',0.),('otsu',otsu)):preds[index+'_'+suffix]=np.isfinite(a[index])&(a[index]>threshold)
        sub=[x for x in rows if x['lake']==r['lake'] and x['l8_date']==r['l8_date']]
        for x in sub:
            truth=a['manual_truth'] if x['scope']=='manual_full' else a['proxy_truth']
            got=metric(preds[x['model']],truth,a['valid'],a['wide'])
            for k in KEYS:
                difference=abs(got[k]-float(x[k]));worst=max(worst,difference)
                if difference>1e-9:raise RuntimeError(f"Metric mismatch: {r['tag']} {x['model']} {k} {difference}")
            count+=1
    assert count==len(rows)==192
    print(f'PASS: {count} rows; eight metrics per row; maximum absolute difference {worst:.3g}')
if __name__=='__main__':main()
