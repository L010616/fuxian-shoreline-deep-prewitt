"""Insert a fixed 2019 JRC Dianchi main-lake outline into GEE preflight.

The outline comes only from the prediction-blind JRC prior, never from model
predictions. Its 120 m outward buffer allows for polygon simplification.
"""

import json
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize, shapes
from rasterio.warp import transform
from scipy import ndimage as ndi
from skimage.measure import approximate_polygon

ROOT = Path(__file__).resolve().parent.parent
QA = ROOT / "drive-download-20260923T112403Z-1-001" / (
    "Q2_FAST_Dianchi_Waihai_20211019_20211018_QA_JRC.tif"
)
SOURCE = ROOT / "preexperiment" / "gee" / "23_dianchi_wet_auto_export_three.js"
TARGET = ROOT / "preexperiment" / "gee" / "24_dianchi_wet_target_lake_auto_export.js"

with rasterio.open(QA) as ds:
    all_water = ds.read(1) >= 2
    labels, _ = ndi.label(all_water, structure=np.ones((3, 3), np.uint8))
    x, y = transform("EPSG:4326", ds.crs, [102.7049], [24.8379])
    col, row = (~ds.transform) * (x[0], y[0])
    main = labels == labels[round(row), round(col)]
    polygons = [geom for geom, value in shapes(main.astype(np.uint8),
                                                 mask=main, transform=ds.transform)
                if value == 1]
    polygon = max(polygons, key=lambda g: len(g["coordinates"][0]))
    ring_xy = approximate_polygon(np.asarray(polygon["coordinates"][0]), 60)
    ring_xy[-1] = ring_xy[0]
    lon, lat = transform(ds.crs, "EPSG:4326", ring_xy[:, 0].tolist(),
                         ring_xy[:, 1].tolist())
    ring = [[round(a, 6), round(b, 6)] for a, b in zip(lon, lat)]

    coarse = rasterize([({"type": "Polygon",
                         "coordinates": [ring_xy.tolist()]}, 1)],
                       out_shape=main.shape, transform=ds.transform).astype(bool)
    coarse_buffer = ndi.binary_dilation(coarse, iterations=4)
    target_coverage = (coarse_buffer & main).sum() / main.sum()
    selected_water = coarse_buffer & all_water
    extra_water = int((selected_water & ~main).sum())
    print("outline vertices", len(ring), "main lake coverage after buffer",
          round(float(target_coverage), 5), "extra water pixels", extra_water,
          "main water pixels", int(main.sum()))
    if target_coverage < 0.999:
        raise RuntimeError("Outline buffer clips the target lake")

source = SOURCE.read_text(encoding="utf-8")
old = "var water = ee.Image(ee.ImageCollection('JRC/GSW1_4/YearlyHistory')"
new = ("var TARGET_OUTLINE = " + json.dumps(ring, separators=(",", ":")) + ";\n"
       "var TARGET_GEOM = ee.Geometry.Polygon([TARGET_OUTLINE], null, false)"
       ".buffer(120);\n"
       "// Keep the 2019 JRC component containing the fixed lake-center seed.\n"
       "// The polygon was drawn from that component before any model inference.\n"
       "var water = ee.Image(ee.ImageCollection('JRC/GSW1_4/YearlyHistory')")
if source.count(old) != 1:
    raise RuntimeError("Expected one JRC water definition")
source = source.replace(old, new)
old2 = ".select('waterClass').gte(2).unmask(0, false);"
new2 = (".select('waterClass').gte(2)"
        ".updateMask(ee.Image.constant(1).clip(TARGET_GEOM))"
        ".unmask(0, false);")
if source.count(old2) != 1:
    raise RuntimeError("Expected one target mask insertion point")
source = source.replace(old2, new2)
TARGET.write_text(source, encoding="utf-8")
print(TARGET)
