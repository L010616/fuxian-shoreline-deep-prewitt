"""Record the prediction-blind QC state; deliberately does not freeze a test set."""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
INPUTS = [ROOT / "跨湖测试",
          ROOT / "drive-download-20260923T094631Z-1-001",
          ROOT / "drive-download-20260923T095357Z-1-001",
          ROOT / "drive-download-20260923T110142Z-1-001",
          ROOT / "drive-download-20260923T112403Z-1-001",
          ROOT / "drive-download-20260923T124126Z-1-001"]
OUT = ROOT / "preexperiment" / "results" / "q2_external"
QC = OUT / "candidate_qc.csv"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(16 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def find_files(pattern: str) -> list[Path]:
    return [p for source in INPUTS for p in source.rglob(pattern)]


def main() -> None:
    with QC.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if len(rows) < 18:
        raise RuntimeError(f"Expected at least 18 candidate pairs; found {len(rows)}")
    records = []
    for row in rows:
        stem = f"Q2_FAST_{row['lake']}_{row['l8_date']}_{row['s2_date']}"
        files = {}
        for suffix in ("L8", "S2", "QA_JRC"):
            matches = find_files(stem + "_" + suffix + ".tif")
            if not matches and suffix == "L8" and row["l8_reused_from_earlier_pair"] == "True":
                matches = find_files(
                    f"Q2_FAST_{row['lake']}_{row['l8_date']}_*_L8.tif"
                )
            if len(matches) != 1:
                raise RuntimeError(f"Expected one {stem}_{suffix}; found {len(matches)}")
            path = matches[0]
            files[suffix] = {
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        records.append({
            "lake": row["lake"], "l8_date": row["l8_date"],
            "s2_date": row["s2_date"],
            "quality_pass_provisional": row["preliminary_quality_pass"] == "True",
            "l8_foot_lake": float(row["l8_foot_lake"]),
            "s2_foot_lake": float(row["s2_foot_lake"]),
            "l8_valid_shore": float(row["l8_valid_shore"]),
            "s2_valid_shore": float(row["s2_valid_shore"]),
            "joint_valid_shore": float(row["joint_valid_shore"]),
            "jrc_outer_perimeter_km": float(row["jrc_outer_perimeter_km"]),
            "approx_usable_shoreline_km": float(row["approx_usable_shoreline_km"]),
            "sectors_50pct_joint_valid_of_12": int(row["sectors_50pct_joint_valid_of_12"]),
            "files": files,
        })
        print("hashed", row["lake"], row["l8_date"], flush=True)
    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "PROVISIONAL_PREDICTION_BLIND_IMAGE_QC_NOT_FINAL_TEST_FREEZE",
        "model_predictions_opened": False,
        "allow_model_selection": False,
        "allow_target_lake_training": False,
        "allow_test_evaluation": False,
        "quality_rules": {
            "l8_lake_footprint_min": 0.98,
            "s2_lake_footprint_min": 0.98,
            "l8_shore_valid_min": 0.50,
            "s2_shore_valid_min": 0.50,
            "joint_shore_valid_min": 0.40,
            "approx_usable_shoreline_min_km": 30,
            "min_covered_sectors_of_12": 8,
            "shore_zone_radius_m": 300,
            "jrc_year": 2019,
            "jrc_water_classes": [2, 3],
        },
        "method_files_sha256": {
            "qc_script": sha256(ROOT / "preexperiment" / "q2_external_qc.py"),
            "experiment_plan": sha256(ROOT / "论文" / "二区增强实验方案_预注册草案.md"),
        },
        "records": records,
    }
    path = OUT / "provisional_candidate_manifest.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
