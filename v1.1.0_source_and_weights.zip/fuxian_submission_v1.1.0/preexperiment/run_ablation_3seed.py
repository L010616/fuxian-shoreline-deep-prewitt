"""Run the five-variant ablation through the shared three-seed protocol."""
from pathlib import Path

import run_fair_comparison_3seed as protocol
from run_multidate_ablation_pilot import AblationDFANet


ROOT = Path(__file__).resolve().parents[1]
protocol.OUT = ROOT / "preexperiment/results/ablation_3seed_v02_corrected_labels"


def ablation_models():
    return {
        "dfanet": lambda: AblationDFANet(False, None),
        "prior": lambda: AblationDFANet(True, None),
        "log": lambda: AblationDFANet(True, "log"),
        "prewitt": lambda: AblationDFANet(True, "prewitt"),
        "parallel": lambda: AblationDFANet(True, "parallel"),
    }


protocol.build_models = ablation_models

if __name__ == "__main__":
    protocol.main()
