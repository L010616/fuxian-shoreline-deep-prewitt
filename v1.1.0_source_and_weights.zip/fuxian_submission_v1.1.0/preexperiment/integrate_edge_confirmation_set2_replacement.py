"""Validate and integrate the prediction-blind replacement for confirmation set 2."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path

import rasterio


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "drive-download-20260922T074258Z-1-001"
BASE = ROOT / "preexperiment" / "data" / "edge_confirmation_set2"
RAW = BASE / "analysis_ready"
ORIGINAL = BASE / "selection_manifest.json"
FINAL = BASE / "selection_manifest_final.json"
REJECTED_DATE = "2025-09-28"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def signature(path: Path) -> dict:
    with rasterio.open(path) as dataset:
        return {
            "bands": dataset.count,
            "width": dataset.width,
            "height": dataset.height,
            "crs": str(dataset.crs),
            "transform": list(tuple(dataset.transform)[:6]),
            "dtypes": list(dataset.dtypes),
            "nodata": dataset.nodata,
        }


def main() -> None:
    if FINAL.exists():
        raise RuntimeError("Final set-2 selection manifest already exists")
    original = json.loads(ORIGINAL.read_text(encoding="utf-8"))
    csv_path = SOURCE / "Fuxian_edgeconfirm_set2_replacement_manifest.csv"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 1:
        raise RuntimeError(f"Expected one replacement record, found {len(rows)}")
    row = rows[0]
    l8_tag = row["l8_date"].replace("-", "")
    s2_tag = row["s2_date"].replace("-", "")
    names = {
        "l8": f"Fuxian_edgeconfirm_set2_L8_native_{l8_tag}.tif",
        "s2": f"Fuxian_edgeconfirm_set2_S2_{s2_tag}_for_{l8_tag}.tif",
        "mask": f"Fuxian_edgeconfirm_set2_masks_native_{l8_tag}.tif",
    }
    source_paths = {key: SOURCE / name for key, name in names.items()}
    missing = [str(path) for path in source_paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(missing)

    signatures = {key: signature(path) for key, path in source_paths.items()}
    expected = {
        "l8": (7, 542, 1095, "EPSG:32648"),
        "s2": (8, 1623, 3281, "EPSG:32648"),
        "mask": (5, 542, 1095, "EPSG:32648"),
    }
    for key, wanted in expected.items():
        item = signatures[key]
        actual = (item["bands"], item["width"], item["height"], item["crs"])
        if actual != wanted:
            raise RuntimeError(f"Unexpected {key} signature: {item}")

    files = {}
    hashes = {}
    for key, source_path in source_paths.items():
        destination = RAW / source_path.name
        if destination.exists():
            raise RuntimeError(f"Destination already exists: {destination}")
        shutil.copy2(source_path, destination)
        files[key] = str(destination.relative_to(ROOT)).replace("\\", "/")
        hashes[key] = sha256(destination)

    replacement = {
        "l8_date": row["l8_date"],
        "s2_date": row["s2_date"],
        "calendar_gap_days": int(float(row["day_gap"])),
        "window": "quality_replacement_for_20250928",
        "season": "dry",
        "l8_clear_shore": float(row["l8_clear_shore"]),
        "s2_clear_shore": float(row["s2_clear_shore"]),
        "quality_score": float(row["quality_score"]),
        "files": files,
        "sha256": hashes,
        "raster_signature": signatures,
    }
    retained = [record for record in original["records"] if record["l8_date"] != REJECTED_DATE]
    if len(retained) != 5:
        raise RuntimeError("Original manifest does not contain exactly one rejected date")
    retained.append(replacement)
    retained.sort(key=lambda record: record["l8_date"])

    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "EDGE_CONFIRMATION_SET2_FINAL_SIX_INPUTS_VALIDATED_BEFORE_REFERENCE_FREEZE",
        "selection_rule": "Quality-only selection; unusable cloudy date replaced before model predictions",
        "rejected_before_predictions": [{
            "l8_date": REJECTED_DATE,
            "reason": "Only one draft shoreline segment and it was low-confidence because of extensive cloud cover",
        }],
        "date_count": 6,
        "analysis_file_count": 18,
        "allow_training": False,
        "allow_model_selection": False,
        "allow_threshold_tuning": False,
        "model_predictions_opened": False,
        "records": retained,
    }
    FINAL.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": payload["status"],
        "rejected": REJECTED_DATE,
        "replacement": replacement["l8_date"],
        "final_dates": [record["l8_date"] for record in retained],
        "replacement_clear_shore": {
            "l8": replacement["l8_clear_shore"],
            "s2": replacement["s2_clear_shore"],
        },
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
