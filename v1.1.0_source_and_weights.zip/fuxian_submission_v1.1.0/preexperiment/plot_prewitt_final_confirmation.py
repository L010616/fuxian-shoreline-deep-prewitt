"""Publication outputs for the one-time final Prewitt confirmation set."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/prewitt_confirmation_set3/locked_evaluation"
SOURCE = BASE / "prewitt_confirmation_set3_results.json"
MODELS = ["prior_only", "fixed_log_prewitt_deep", "parameter_matched_ordinary_conv", "fixed_prewitt_deep"]
LABELS = {
    "prior_only": "Spatial prior",
    "fixed_log_prewitt_deep": "LoG–Prewitt",
    "parameter_matched_ordinary_conv": "Matched convolution",
    "fixed_prewitt_deep": "Deep Prewitt",
}
COLORS = {
    "prior_only": "#8FA2D6", "fixed_log_prewitt_deep": "#A9C8B8",
    "parameter_matched_ordinary_conv": "#E7A889", "fixed_prewitt_deep": "#6A5C95",
}


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    dates = sorted(data["dates"])
    with (BASE / "prewitt_final_confirmation_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", "IoU_mean", "BF1_30m_mean", "BF1_60m_mean", "ASD_m_mean", "HD95_m_mean"])
        for model in MODELS:
            summary = data["summary"][model]
            writer.writerow([LABELS[model], *[summary[key]["mean"] for key in (
                "iou", "boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m", "hd95_m")]])

    plt.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 10,
        "xtick.labelsize": 8, "ytick.labelsize": 9, "legend.fontsize": 8,
        "axes.linewidth": 0.8, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.55), constrained_layout=False)
    fig.subplots_adjust(left=0.10, right=0.985, bottom=0.24, top=0.76, wspace=0.25)
    x = np.arange(len(dates))
    for model in MODELS:
        values = [data["seed_averaged_per_date"][model][date]["mean_symmetric_boundary_distance_m"] for date in dates]
        axes[0].plot(x, values, marker="o", markersize=4.2, linewidth=1.7,
                     color=COLORS[model], label=LABELS[model])
    axes[0].set_ylabel("ASD (m)")
    axes[0].set_xticks(x, [date[2:] for date in dates], rotation=45, ha="right")
    axes[0].set_xlabel("Independent confirmation date")
    handles_a, labels_a = axes[0].get_legend_handles_labels()

    prior = data["paired_date_level_effects"]["fixed_prewitt_deep_vs_prior_only"]["asd_reduction_m"]["date_level_improvement"]
    matched = data["paired_date_level_effects"]["fixed_prewitt_deep_vs_parameter_matched_ordinary_conv"]["asd_reduction_m"]["date_level_improvement"]
    width = 0.36
    axes[1].bar(x - width / 2, [prior[d] for d in dates], width, color=COLORS["prior_only"], label="vs spatial prior")
    axes[1].bar(x + width / 2, [matched[d] for d in dates], width, color=COLORS["parameter_matched_ordinary_conv"], label="vs matched convolution")
    axes[1].axhline(0, color="#3E3142", linewidth=0.9)
    axes[1].set_ylabel("ASD reduction (m)")
    axes[1].set_xticks(x, [date[2:] for date in dates], rotation=45, ha="right")
    axes[1].set_xlabel("Independent confirmation date")
    handles_b, labels_b = axes[1].get_legend_handles_labels()
    for index, ax in enumerate(axes):
        ax.grid(axis="y", color="#E8E8EC", linewidth=0.7)
        ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
        ax.set_axisbelow(True)
        ax.text(-0.14, 1.13, f"({chr(97 + index)})", transform=ax.transAxes,
                fontweight="bold", fontsize=11, va="bottom")
    fig.legend(handles_a, labels_a, frameon=False, ncol=2, loc="upper center",
               bbox_to_anchor=(0.285, 0.975), columnspacing=1.2, handlelength=2.0)
    fig.legend(handles_b, labels_b, frameon=False, ncol=1, loc="upper center",
               bbox_to_anchor=(0.765, 0.975), labelspacing=0.35, handlelength=1.8)
    fig.savefig(BASE / "prewitt_final_confirmation.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(BASE / "prewitt_final_confirmation.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(BASE)


if __name__ == "__main__":
    main()
