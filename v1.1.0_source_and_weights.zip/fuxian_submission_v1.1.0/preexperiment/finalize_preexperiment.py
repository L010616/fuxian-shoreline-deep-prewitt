"""Audit and hash the corrected v0.2 development-stage preexperiment artifacts."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PRE = ROOT / "preexperiment"
ABL = PRE / "results/ablation_3seed_v02_corrected_labels"
FAIR = PRE / "results/fair_comparison_3seed_corrected_labels_v03"
MANIFEST = PRE / "results/dataset_v0.2/dataset_manifest_v0.2.json"
TEST_SUMMARY = PRE / "results/formal_test_drafts_v02/test_draft_summary.json"
OUTPUT = PRE / "results/preexperiment_completion_audit_v02.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    ablation = json.loads((ABL / "summary_mean_std.json").read_text(encoding="utf-8"))
    fair = json.loads((FAIR / "summary_mean_std.json").read_text(encoding="utf-8"))
    dataset = json.loads(MANIFEST.read_text(encoding="utf-8"))
    test_summary = json.loads(TEST_SUMMARY.read_text(encoding="utf-8"))
    by_seed = json.loads((FAIR / "results_by_seed.json").read_text(encoding="utf-8"))

    metrics = (
        "precision", "recall", "f1", "iou", "boundary_f1_30m",
        "boundary_f1_60m", "mean_symmetric_boundary_distance_m",
    )
    same_proposed = all(
        fair["proposed_parallel"][mode][metric]["values"]
        == ablation["parallel"][mode][metric]["values"]
        for mode in ("raw", "common_constraint") for metric in metrics
    )
    boundary_invariant = all(
        fair[model]["raw"][metric]["values"]
        == fair[model]["common_constraint"][metric]["values"]
        for model in fair
        for metric in ("boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m")
    )
    complete_grid = set(by_seed) == {"20260913", "20260929", "20261017"} and all(
        set(by_seed[seed]) == set(fair) for seed in by_seed
    )
    parallel_best = (
        ablation["parallel"]["raw"]["iou"]["mean"] == max(v["raw"]["iou"]["mean"] for v in ablation.values())
        and ablation["parallel"]["raw"]["boundary_f1_30m"]["mean"] == max(v["raw"]["boundary_f1_30m"]["mean"] for v in ablation.values())
        and ablation["parallel"]["raw"]["boundary_f1_60m"]["mean"] == max(v["raw"]["boundary_f1_60m"]["mean"] for v in ablation.values())
        and ablation["parallel"]["raw"]["mean_symmetric_boundary_distance_m"]["mean"] == min(v["raw"]["mean_symmetric_boundary_distance_m"]["mean"] for v in ablation.values())
    )

    artifacts = [
        MANIFEST,
        ABL / "summary_mean_std.json",
        ABL / "results_by_seed.json",
        ABL / "三随机种子公平对比报告.md",
        ABL / "deterministic_ablation_3seed_corrected_labels.png",
        FAIR / "summary_mean_std.json",
        FAIR / "results_by_seed.json",
        FAIR / "config.json",
        FAIR / "三随机种子公平对比报告.md",
        FAIR / "fair_comparison_3seed.png",
        TEST_SUMMARY,
        PRE / "results/formal_test_drafts_v02/compact_review.html",
        PRE / "results/formal_test_drafts_v02/compact_review_contact_sheet.jpg",
        PRE / "results/formal_test_drafts_v02/ai_triage_24_sites.csv",
        PRE / "results/formal_test_drafts_v02/ai_triage_24_sites.json",
        PRE / "results/formal_test_drafts_v02/ai_triage_summary.md",
        PRE / "results/model_freeze_v02.json",
        PRE / "results/label_issue_v01.md",
        PRE / "三随机种子阶段结论与调整建议.md",
        PRE / "模型冻结与后续实验清单.md",
    ]
    checks = {
        "dataset_version_is_v0.2": dataset.get("version") == "0.2",
        "dataset_has_6_train_2_validation": dataset.get("split", {}).get("train_dates") == 6 and dataset.get("split", {}).get("validation_dates") == 2,
        "test_accuracy_is_unopened": dataset.get("test_accuracy_opened") is False and test_summary.get("allow_test_evaluation") is False,
        "standard_comparison_has_3_seeds_x_4_models": complete_grid,
        "proposed_matches_ablation_exactly": same_proposed,
        "parallel_is_best_on_four_core_metrics": parallel_best,
        "common_constraint_preserves_shore_band_boundary_metrics": boundary_invariant,
        "all_required_artifacts_exist": all(path.is_file() for path in artifacts),
    }
    payload = {
        "audit_time": datetime.now().astimezone().isoformat(timespec="seconds"),
        "stage": "corrected v0.2 modeling preexperiment complete; manual reference review pending",
        "all_checks_passed": all(checks.values()),
        "checks": checks,
        "official_development_outputs": {
            str(path.relative_to(ROOT)): {"bytes": path.stat().st_size, "sha256": sha256(path)}
            for path in artifacts if path.is_file()
        },
        "superseded_outputs": [
            "preexperiment/results/model_freeze_v01.json",
            "preexperiment/results/preexperiment_completion_audit.json",
            "all experiments based on dataset v0.1"
        ],
        "limitations": [
            "Reference shorelines remain prior-anchored automatic drafts requiring manual review.",
            "Only two development-validation dates are used.",
            "Test inputs are available for reference drafting, but test accuracy remains unopened.",
            "Results support model selection only and are not final paper accuracy."
        ],
        "next_required_action": "Manually review and freeze train, validation and test reference shorelines before any test inference."
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if not payload["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
