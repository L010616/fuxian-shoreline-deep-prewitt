"""Create manuscript tables and figures from locked four-date experiments."""
from __future__ import annotations

import csv
import json
from pathlib import Path

from build_publication_figures import draw_chart


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "preexperiment/results"
OUT = ROOT / "preexperiment/manuscript_ready"
FIG = OUT / "figures"
METRICS = ["precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m"]


def write_table(path, summary, names, mode="raw_macro"):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", *sum(([f"{m}_mean", f"{m}_std"] for m in METRICS), [])])
        for key, label in names.items():
            row = [label]
            for metric in METRICS:
                cell = summary[key][mode][metric]; row.extend([cell["mean"], cell["std"]])
            writer.writerow(row)


def chart_data(summary, names, mode="raw_macro"):
    return {key: {"raw": summary[key][mode]} for key in names}


def main():
    FIG.mkdir(parents=True, exist_ok=True)
    comparison = json.loads((RESULTS / "locked_four_date_model_comparison_v01/model_comparison_test_results.json").read_text(encoding="utf-8"))
    ablation = json.loads((RESULTS / "locked_four_date_ablation_v01/ablation_test_results.json").read_text(encoding="utf-8"))
    model_names = {"proposed_parallel": "Proposed", "unet_resnet18": "U-Net", "deeplabv3plus_resnet18": "DeepLabV3+", "segformer_mit_b0": "SegFormer-B0"}
    ablation_names = {"dfanet": "DFANet", "prior": "+ prior", "log": "+ LoG", "prewitt": "+ Prewitt", "parallel": "Parallel"}
    write_table(OUT / "table_locked_test_model_comparison.csv", comparison["summary"], model_names)
    write_table(OUT / "table_locked_test_ablation.csv", ablation["summary"], ablation_names)
    draw_chart(chart_data(comparison["summary"], model_names), list(model_names), ["Proposed", "U-Net", "DeepLabV3+", "SegFormer"],
               "figure_locked_test_model_comparison", ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3"])
    draw_chart(chart_data(ablation["summary"], ablation_names), list(ablation_names), list(ablation_names.values()),
               "figure_locked_test_ablation", ["#bdbdbd", "#80b1d3", "#fdb462", "#b3de69", "#fb8072"])
    p = comparison["summary"]["proposed_parallel"]["raw_macro"]
    lines = [
        "# 封存实验写作口径", "",
        "所有数值均来自四个独立测试日期和三个已冻结随机种子。模型结构、权重、阈值与参考岸线筛查规则均在本次测试前固定。", "",
        f"本文模型：IoU {p['iou']['mean']:.4f} ± {p['iou']['std']:.4f}，Boundary F1 (30 m) {p['boundary_f1_30m']['mean']:.4f} ± {p['boundary_f1_30m']['std']:.4f}，Boundary F1 (60 m) {p['boundary_f1_60m']['mean']:.4f} ± {p['boundary_f1_60m']['std']:.4f}，平均对称岸线距离 {p['mean_symmetric_boundary_distance_m']['mean']:.2f} ± {p['mean_symmetric_boundary_distance_m']['std']:.2f} m。", "",
        "完整模型在四期测试上的 IoU、30 m Boundary F1 和平均岸线距离均优于三个常用对比模型。与原始 DFANet 相比，完整模型的 Boundary F1 提高约 0.0030，平均岸线距离减少约 2.64 m。", "",
        "消融结果显示空间先验是边界改善的主要来源。完整并联模型相对仅空间约束模型的 IoU 更高，并在四个日期中均保持这一方向；但两者的 Boundary F1 和平均岸线距离基本持平，因此不能表述为边缘分支在所有场景中显著改善边界。", "",
        "参考岸线由近同期 Sentinel-2 自动草稿经保守筛查获得，所有低置信度段均被排除。这些参考不能描述为独立测量真值。投稿前仍需第二位审阅者对保留岸段进行抽查确认。", "",
    ]
    (OUT / "封存实验写作口径.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"tables": 2, "figures": 4, "output": str(OUT)}, ensure_ascii=False))


if __name__ == "__main__": main()
