"""Render publication-ready development figures with Pillow only."""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "preexperiment/results"
OUT = ROOT / "preexperiment/manuscript_ready/figures"
FONT_PATH = Path(r"C:\Windows\Fonts\times.ttf")
FONT_BOLD_PATH = Path(r"C:\Windows\Fonts\timesbd.ttf")


def font(size: int, bold: bool = False):
    path = FONT_BOLD_PATH if bold else FONT_PATH
    return ImageFont.truetype(str(path), size) if path.exists() else ImageFont.load_default()


def metric_cell(data, model, metric):
    item = data[model]["raw"][metric]
    return float(item["mean"]), float(item["std"])


def centered(draw, xy, value, fnt, fill="#111111"):
    if "\n" in value:
        box = draw.multiline_textbbox((0, 0), value, font=fnt, align="center", spacing=3)
        draw.multiline_text(
            (xy[0] - (box[2] - box[0]) / 2, xy[1]), value,
            font=fnt, fill=fill, align="center", spacing=3,
        )
    else:
        box = draw.textbbox((0, 0), value, font=fnt)
        draw.text((xy[0] - (box[2] - box[0]) / 2, xy[1]), value, font=fnt, fill=fill)


def draw_chart(data, models, labels, filename, colors):
    width, height = 2400, 820
    canvas = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(canvas)
    panels = [
        ("iou", "IoU", 0.985, 1.0, 3),
        ("boundary_f1_30m", "Boundary F1 (30 m)", 0.89, 1.0, 3),
        ("mean_symmetric_boundary_distance_m", "Mean boundary distance (m)", 0.0, None, 1),
    ]
    margin_x, gap, top, bottom = 115, 95, 70, 180
    panel_w = (width - margin_x * 2 - gap * 2) // 3
    plot_h = height - top - bottom
    axis_font, tick_font, label_font = font(31), font(27), font(21)

    for panel_index, (metric, ylabel, ymin, ymax, decimals) in enumerate(panels):
        left = margin_x + panel_index * (panel_w + gap)
        right = left + panel_w
        plot_left, plot_right = left + 88, right - 20
        plot_top, plot_bottom = top, top + plot_h
        values = [metric_cell(data, m, metric) for m in models]
        if ymax is None:
            ymax = max(mean + std for mean, std in values) * 1.18

        for tick in range(6):
            frac = tick / 5
            y = round(plot_bottom - frac * plot_h)
            val = ymin + frac * (ymax - ymin)
            draw.line((plot_left, y, plot_right, y), fill="#dddddd", width=2)
            tick_text = f"{val:.3f}" if ymax <= 1.01 else f"{val:.0f}"
            box = draw.textbbox((0, 0), tick_text, font=tick_font)
            draw.text((plot_left - 14 - (box[2] - box[0]), y - 15), tick_text, font=tick_font, fill="#222222")

        draw.line((plot_left, plot_top, plot_left, plot_bottom), fill="#111111", width=3)
        draw.line((plot_left, plot_bottom, plot_right, plot_bottom), fill="#111111", width=3)
        n = len(models)
        slot = (plot_right - plot_left) / n
        bar_w = slot * 0.58
        for idx, ((mean, std), label, color) in enumerate(zip(values, labels, colors)):
            cx = plot_left + slot * (idx + 0.5)
            y_mean = plot_bottom - (mean - ymin) / (ymax - ymin) * plot_h
            y_zero = plot_bottom
            draw.rectangle((cx - bar_w / 2, y_mean, cx + bar_w / 2, y_zero), fill=color, outline="#111111", width=2)
            y_hi = plot_bottom - (mean + std - ymin) / (ymax - ymin) * plot_h
            y_lo = plot_bottom - (mean - std - ymin) / (ymax - ymin) * plot_h
            draw.line((cx, y_hi, cx, y_lo), fill="#111111", width=3)
            draw.line((cx - 12, y_hi, cx + 12, y_hi), fill="#111111", width=3)
            draw.line((cx - 12, y_lo, cx + 12, y_lo), fill="#111111", width=3)
            value_text = f"{mean:.{decimals}f}"
            centered(draw, (cx, max(plot_top + 2, y_hi - 39)), value_text, tick_font)
            centered(draw, (cx, plot_bottom + 22), label, label_font)

        centered(draw, ((plot_left + plot_right) / 2, height - 62), ylabel, axis_font, "#111111")

    png_path = OUT / f"{filename}.png"
    pdf_path = OUT / f"{filename}.pdf"
    canvas.save(png_path, dpi=(600, 600), optimize=True)
    canvas.save(pdf_path, "PDF", resolution=600.0)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ablation = json.loads((RESULTS / "ablation_3seed_v02_corrected_labels/summary_mean_std.json").read_text(encoding="utf-8"))
    draw_chart(
        ablation,
        ["dfanet", "prior", "log", "prewitt", "parallel"],
        ["DFANet", "+ prior", "+ LoG", "+ Prewitt", "Parallel"],
        "figure_ablation_development",
        ["#bdbdbd", "#80b1d3", "#fdb462", "#b3de69", "#fb8072"],
    )
    comparison = json.loads((RESULTS / "fair_comparison_3seed_corrected_labels_v03/summary_mean_std.json").read_text(encoding="utf-8"))
    draw_chart(
        comparison,
        ["proposed_parallel", "unet_resnet18", "deeplabv3plus_resnet18", "segformer_mit_b0"],
        ["Proposed", "U-Net", "DeepLabV3+\n(ResNet-18)", "SegFormer"],
        "figure_model_comparison_development",
        ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3"],
    )
    print(json.dumps({"output": str(OUT), "files": 4}, ensure_ascii=False))


if __name__ == "__main__":
    main()
