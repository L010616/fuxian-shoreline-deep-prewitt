"""Build a model-blind human shoreline review pack for six external scenes."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import rasterio
from PIL import Image
from scipy import ndimage as ndi


ROOT = Path(__file__).resolve().parents[1]
PRE = ROOT / "preexperiment"
sys.path.insert(0, str(PRE))
import run_q2_cross_lake_zero_shot as experiment  # noqa: E402

FREEZE = PRE / "results/q2_external/screened_reference_freeze"
OUT = PRE / "results/q2_external/manual_review_core6"
REVIEW_CSV = FREEZE / "reference_review.csv"
LAKES = ("Dianchi_Waihai", "Erhai", "Xingyun")
SEASONS = ("dry", "wet")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def choose_core(records: list[dict]) -> list[dict]:
    quality = {}
    with REVIEW_CSV.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            quality[(row["lake"], row["l8_date"])] = float(row["joint_valid_shore"])
    selected = []
    for lake in LAKES:
        for season in SEASONS:
            candidates = [row for row in records if row["lake"] == lake and row["season"] == season]
            # Selection is model-independent: maximum valid shoreline fraction;
            # if tied, retain the earliest Landsat date.
            chosen = sorted(candidates, key=lambda row: (-quality[(lake, row["l8_date"])], row["l8_date"]))[0]
            chosen = dict(chosen)
            chosen["joint_valid_shore"] = quality[(lake, chosen["l8_date"])]
            selected.append(chosen)
    return selected


def stretch(raw: np.ndarray, valid: np.ndarray) -> np.ndarray:
    channels = []
    for band in raw:
        sample = band[valid & np.isfinite(band) & (band > 0)]
        low, high = np.percentile(sample, [2, 98])
        channels.append(np.clip((band - low) / max(high - low, 1), 0, 1) ** 0.85)
    return np.moveaxis(np.stack(channels), 0, -1)


def crop_bounds(mask: np.ndarray, padding: int = 80) -> tuple[slice, slice]:
    rows, cols = np.where(mask)
    r0 = max(0, int(rows.min()) - padding); r1 = min(mask.shape[0], int(rows.max()) + padding + 1)
    c0 = max(0, int(cols.min()) - padding); c1 = min(mask.shape[1], int(cols.max()) + padding + 1)
    return slice(r0, r1), slice(c0, c1)


def make_panel(record: dict, scene_dir: Path, scene_id: str) -> Path:
    with rasterio.open(record["paths"]["s2"]) as src:
        red, green, blue, nir = src.read([3, 2, 1, 4]).astype("float32")
        s2_valid = src.read(8) > 0
    with rasterio.open(record["paths"]["draft"]) as src:
        draft_raw = src.read(1)
    water = draft_raw == 1
    valid = s2_valid & (draft_raw != 255)
    crop = crop_bounds(water)
    rgb = stretch(np.stack([red, green, blue]), valid)[crop]
    ndwi = np.divide(green - nir, green + nir, out=np.zeros_like(green), where=(green + nir) != 0)[crop]
    water_crop = water[crop]
    valid_crop = valid[crop]
    edge = water_crop ^ ndi.binary_erosion(water_crop)
    edge = ndi.binary_dilation(edge, iterations=1)
    overlay = rgb.copy()
    overlay[edge & valid_crop] = np.array([0.23, 0.82, 0.86])
    overlay[~valid_crop] = 0.65 * overlay[~valid_crop] + 0.35 * np.array([0.90, 0.35, 0.45])

    fig, axes = plt.subplots(1, 3, figsize=(11.4, 4.0), constrained_layout=True)
    axes[0].imshow(rgb); axes[0].set_title("Sentinel-2 RGB")
    image = axes[1].imshow(ndwi, cmap="RdBu", vmin=-0.5, vmax=0.5)
    axes[1].set_title("NDWI (visual aid)")
    fig.colorbar(image, ax=axes[1], fraction=0.045, pad=0.02)
    axes[2].imshow(overlay); axes[2].set_title("Draft (cyan); invalid (red)")
    for label, axis in zip(("(a)", "(b)", "(c)"), axes):
        axis.set_xticks([]); axis.set_yticks([])
        axis.text(0.02, 0.98, label, transform=axis.transAxes, fontweight="bold",
                  ha="left", va="top", color="black",
                  bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 1.5})
        for spine in axis.spines.values():
            spine.set_visible(True); spine.set_linewidth(0.6); spine.set_color("#7D8085")
    fig.suptitle(f"{scene_id} | {record['lake']} | {record['season']} | L8 {record['l8_date']} / S2 {record['s2_date']}",
                 fontsize=11, fontweight="bold")
    path = scene_dir / "model_blind_review_panel.png"
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return path


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records = experiment.selected_records()
    selected = choose_core(records)
    manifest = []
    form_rows = []
    panel_paths = []
    for index, record in enumerate(selected, start=1):
        scene_id = f"HR{index:02d}"
        scene_dir = OUT / scene_id
        scene_dir.mkdir(exist_ok=True)
        source_dir = Path(record["paths"]["draft"]).parent
        for source_name, target_name in (("S2_water_DRAFT_10m.tif", "S2_water_FOR_REVIEW_10m.tif"),
                                         ("shoreline_DRAFT.geojson", "shoreline_FOR_REVIEW.geojson")):
            shutil.copy2(source_dir / source_name, scene_dir / target_name)
        panel = make_panel(record, scene_dir, scene_id)
        panel_paths.append(panel)
        input_files = {
            "sentinel2_multiband": str(record["paths"]["s2"]),
            "initial_water_mask": str(scene_dir / "S2_water_FOR_REVIEW_10m.tif"),
            "initial_shoreline": str(scene_dir / "shoreline_FOR_REVIEW.geojson"),
            "review_panel": str(panel),
        }
        item = {
            "scene_id": scene_id, "lake": record["lake"], "season": record["season"],
            "l8_date": record["l8_date"], "s2_date": record["s2_date"],
            "joint_valid_shore": record["joint_valid_shore"],
            "selection_rule": "maximum joint-valid shoreline fraction within lake x season; earliest date breaks ties",
            "model_outputs_available_to_reviewer": False,
            "inputs": input_files,
            "sha256": {key: sha256(Path(value)) for key, value in input_files.items()},
            "required_output": str(scene_dir / "shoreline_REVIEWED.geojson"),
        }
        (scene_dir / "review_input_manifest.json").write_text(json.dumps(item, ensure_ascii=False, indent=2), encoding="utf-8")
        manifest.append(item)
        form_rows.append({
            "scene_id": scene_id, "lake": record["lake"], "season": record["season"],
            "l8_date": record["l8_date"], "s2_date": record["s2_date"],
            "reviewer_A": "", "reviewer_A_status": "UNREVIEWED", "reviewer_A_notes": "",
            "reviewer_B": "", "reviewer_B_status": "UNREVIEWED", "reviewer_B_notes": "",
            "consensus_status": "UNREVIEWED", "reviewed_file": "",
        })

    with (OUT / "manual_review_form.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(form_rows[0]))
        writer.writeheader(); writer.writerows(form_rows)
    (OUT / "manual_review_manifest.json").write_text(json.dumps({
        "status": "LOCKED_UNREVIEWED_CORE6",
        "selection_frozen_before_manual_editing": True,
        "selection_uses_model_metrics": False,
        "review_scope": "one dry and one wet scene per lake",
        "source_reference_freeze": str(FREEZE / "external_reference_freeze_manifest.json"),
        "scenes": manifest,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    thumbs = []
    for path in panel_paths:
        image = Image.open(path).convert("RGB")
        image.thumbnail((1200, 480), Image.Resampling.LANCZOS)
        thumbs.append(image.copy())
    width = max(image.width for image in thumbs)
    height = max(image.height for image in thumbs)
    sheet = Image.new("RGB", (width * 2 + 120, height * 3 + 120), "white")
    for index, image in enumerate(thumbs):
        x = (index % 2) * (width + 120); y = (index // 2) * (height + 60)
        sheet.paste(image, (x, y))
    sheet.save(OUT / "core6_model_blind_contact_sheet.png", optimize=True)

    readme = """# 六期人工岸线复核核心集

本复核包固定选择每个“湖泊×季节”中共同有效岸线比例最高的一期；并列时选较早日期。选择过程不使用任何模型预测、模型误差或模型间差异。

## 复核步骤

1. 每个HR目录中只打开原始Sentinel-2多波段影像、`shoreline_FOR_REVIEW.geojson`和`S2_water_FOR_REVIEW_10m.tif`，不得加载任何模型输出。
2. 在QGIS中以RGB和NDWI为辅助，沿可判读的水陆界面检查初始岸线。云、阴影、薄云、缺测和无法判定岸段只标记为无效，不凭历史先验臆画。
3. 若初始岸线正确，将其复制为`shoreline_REVIEWED.geojson`；若需修改，在副本中编辑后保存该文件。不得覆盖`shoreline_FOR_REVIEW.geojson`。
4. `manual_review_form.csv`填写复核人、状态（ACCEPTED、MODIFIED或INVALID_SECTOR_ONLY）和修改原因。推荐A、B两名复核者独立检查，再形成共识文件。
5. 六期全部完成且文件哈希冻结后，才允许重新计算人工参考子集指标。未签署前不得在论文中称为人工参考岸线。

## 判读原则

- 目标为命名湖泊外岸线；岛屿和内部孔洞不计入外岸线。
- 岸线取影像时刻可见水陆界面，不沿JRC先验轮廓直接描绘。
- 对混合像元采用水体占优侧的一致规则；不要针对任何模型预测修正。
- 复核结果用于验证自动Sentinel-2岸线代理的可靠性，不用于重新训练、调阈值或选择模型。
"""
    (OUT / "人工岸线复核说明.md").write_text(readme, encoding="utf-8")
    print(json.dumps({"output": str(OUT), "core_scenes": [row["scene_id"] + ":" + row["lake"] + ":" + row["season"] + ":" + row["l8_date"] for row in manifest]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
