"""Audit whether all JRC water in the export box biases preflight shore QA."""

from pathlib import Path

import numpy as np
import rasterio
from rasterio.warp import transform
from scipy import ndimage as ndi

root = Path(__file__).resolve().parent.parent
paths = [
    root / "drive-download-20260923T112403Z-1-001" /
    "Q2_FAST_Dianchi_Waihai_20211019_20211018_QA_JRC.tif",
    root / "drive-download-20260923T110142Z-1-001" /
    "Q2_FAST_Dianchi_Waihai_20230603_20230603_QA_JRC.tif",
]

for path in paths:
    with rasterio.open(path) as ds:
        a = ds.read()
        all_water = a[0] >= 2
        labels, _ = ndi.label(all_water, structure=np.ones((3, 3), np.uint8))
        x, y = transform("EPSG:4326", ds.crs, [102.7049], [24.8379])
        col, row = (~ds.transform) * (x[0], y[0])
        main_water = labels == labels[round(row), round(col)]

        def shore(water):
            return ndi.binary_dilation(water, iterations=10) & ~ndi.binary_erosion(
                water, iterations=10
            )

        print(path.name)
        for name, water in (("main", main_water), ("all", all_water)):
            belt = shore(water)
            print(name, "area_pixels", int(water.sum()), "shore_pixels",
                  int(belt.sum()), "l8_valid", round(float((a[1] > 0)[belt].mean()), 4),
                  "s2_valid", round(float((a[2] > 0)[belt].mean()), 4),
                  "joint_valid", round(float((a[3] > 0)[belt].mean()), 4))
