"""One-time four-date test of all frozen ablation checkpoints."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch

from run_multidate_ablation_pilot import AblationDFANet, predict
from run_quick_model_pilot import metrics
from run_locked_test_model_comparison import load_scenes, normalize_and_exclude


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/ablation_3seed_v02_corrected_labels"
OUT = ROOT / "preexperiment/results/locked_four_date_ablation_v01"
SEEDS = [20260913, 20260929, 20261017]
VARIANTS = {"dfanet": (False, None), "prior": (True, None), "log": (True, "log"), "prewitt": (True, "prewitt"), "parallel": (True, "parallel")}
METRICS = ("precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "ablation_test_results.json"
    if path.exists():
        raise RuntimeError("Locked ablation test already exists; refusing to rerun")
    config = json.loads((MODEL_DIR / "config.json").read_text(encoding="utf-8"))
    scenes = load_scenes(); normalize_and_exclude(scenes, config["normalization"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results = {}
    for name, (has_prior, edge_mode) in VARIANTS.items():
        results[name] = {}
        for seed in SEEDS:
            model = AblationDFANet(has_prior, edge_mode).to(device)
            ckpt = torch.load(MODEL_DIR / f"{name}_seed{seed}_best.pt", map_location=device, weights_only=False)
            model.load_state_dict(ckpt["model"])
            per_date = {}
            for scene in scenes:
                probability = predict(model, scene, device)
                raw = metrics(probability, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
                constrained = probability.copy(); constrained[scene["interior"]] = 1.0
                constrained[scene["roi"] & ~scene["shore"] & ~scene["interior"]] = 0.0; constrained[~scene["roi"]] = 0.0
                common = metrics(constrained, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
                per_date[scene["record"]["l8_date"]] = {"raw": raw, "common_constraint": common}
            results[name][str(seed)] = {
                "checkpoint_epoch": int(ckpt["epoch"]), "per_date": per_date,
                "raw_macro": {m: float(np.mean([r["raw"][m] for r in per_date.values()])) for m in METRICS},
                "common_constraint_macro": {m: float(np.mean([r["common_constraint"][m] for r in per_date.values()])) for m in METRICS},
            }
            del model
            if torch.cuda.is_available(): torch.cuda.empty_cache()
    summary = {}
    for name in VARIANTS:
        summary[name] = {}
        for mode in ("raw_macro", "common_constraint_macro"):
            summary[name][mode] = {}
            for metric in METRICS:
                vals = np.asarray([results[name][str(seed)][mode][metric] for seed in SEEDS])
                summary[name][mode][metric] = {"mean": float(vals.mean()), "std": float(vals.std(ddof=1)), "values": vals.tolist()}
    output = {"status": "LOCKED_FOUR_DATE_ABLATION_OPENED_ONCE", "variants": list(VARIANTS), "seeds": SEEDS,
              "dates": [s["record"]["l8_date"] for s in scenes], "decision_threshold": 0.5,
              "training_or_model_selection_after_test": False,
              "reference_status": "Conservatively screened Sentinel-2 references; not independent surveyed ground truth",
              "device": str(device), "results_by_variant_and_seed": results, "summary": summary}
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({name: summary[name]["raw_macro"] for name in VARIANTS}, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
