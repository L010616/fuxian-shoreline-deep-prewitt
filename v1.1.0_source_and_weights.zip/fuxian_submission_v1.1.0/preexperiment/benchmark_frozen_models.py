"""Benchmark frozen comparison models on a fixed 256x256 input."""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np
import torch

from run_standard_model_comparison_pilot import build_models


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/fair_comparison_3seed_corrected_labels_v03"
OUT = ROOT / "preexperiment/manuscript_ready/table_model_efficiency.csv"
SEED = 20260913
WARMUP = 20
REPEATS = 100


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    x = torch.zeros((1, 6, 256, 256), device=device)
    priors = torch.zeros((1, 2, 256, 256), device=device)
    rows = []
    for name, factory in build_models().items():
        model = factory().to(device).eval()
        checkpoint = torch.load(MODEL_DIR / f"{name}_seed{SEED}_best.pt", map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model"])
        with torch.inference_mode():
            for _ in range(WARMUP): model(x, priors)
            if device.type == "cuda":
                torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
                start = torch.cuda.Event(enable_timing=True); end = torch.cuda.Event(enable_timing=True)
                times = []
                for _ in range(REPEATS):
                    start.record(); model(x, priors); end.record(); torch.cuda.synchronize(); times.append(start.elapsed_time(end))
                peak_mb = torch.cuda.max_memory_allocated() / 1024**2
            else:
                times = []
                for _ in range(REPEATS):
                    t0 = time.perf_counter(); model(x, priors); times.append((time.perf_counter()-t0)*1000)
                peak_mb = None
        arr = np.asarray(times)
        rows.append({"model": name, "parameters": sum(p.numel() for p in model.parameters()),
                     "input": "1x6x256x256", "mean_inference_ms": float(arr.mean()),
                     "std_inference_ms": float(arr.std(ddof=1)), "peak_allocated_mb": peak_mb,
                     "device": torch.cuda.get_device_name(0) if device.type == "cuda" else "CPU",
                     "warmup": WARMUP, "repeats": REPEATS, "checkpoint_seed": SEED})
        del model
        if device.type == "cuda": torch.cuda.empty_cache()
    with OUT.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    (OUT.with_suffix(".json")).write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(rows, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
