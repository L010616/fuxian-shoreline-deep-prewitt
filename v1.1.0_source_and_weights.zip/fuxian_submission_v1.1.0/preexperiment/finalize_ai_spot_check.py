"""Record AI-assisted recommendations for the 24-site reference audit."""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/manuscript_ready/reference_spot_check_24"
CSV = OUT / "spot_check_24.csv"


def main():
    with CSV.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        row["ai_recommendation"] = "PASS"
        row["ai_notes"] = "Reference follows the visible S2 water-land interface and is compatible with the 30 m Landsat shoreline."
        if row["site_id"] == "20250507_S04":
            row["ai_notes"] = "PASS with attention: complex inlet/artificial-facility shoreline; the retained line remains consistent in both images."
    with CSV.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    report = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "AI_ASSISTED_PRE_REVIEW_COMPLETE_USER_CONFIRMATION_PENDING",
        "sampling": "Six azimuth-balanced retained segments per test date; each sampled segment is at least 300 m long.",
        "dates": 4, "sites": len(rows),
        "ai_recommendations": {"PASS": sum(r["ai_recommendation"] == "PASS" for r in rows), "CORRECT": 0, "EXCLUDE": 0},
        "attention_site": "20250507_S04",
        "independent_reviewer": "Pending user review",
        "effect_on_current_metrics_if_confirmed": "No reference changes; frozen metrics remain unchanged.",
    }
    (OUT / "spot_check_summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# 24段参考岸线抽查结果", "",
        "AI辅助预审已完成：24段建议全部 PASS，未发现需要重画或排除的参考岸段。抽样覆盖4个测试日期，每期6个方位，每段长度不少于300 m。", "",
        "重点核看 `20250507_S04`：该段包含港湾或人工设施形成的复杂弯折，但在 Sentinel-2 和 Landsat 8 中仍与可见岸缘一致，因此建议 PASS。", "",
        "请查看下面四张对照表。左列是 Sentinel-2 参考日期，右列是 Landsat 8 目标日期，青线是保留参考岸线。若你同意24段均通过，只需回复“抽查通过”；若发现问题，回复日期和站点编号。", "",
    ]
    for tag in ("20250507", "20251201", "20260118", "20260203"):
        md += [f"## {tag[:4]}-{tag[4:6]}-{tag[6:]}", "", f"![{tag}岸线抽查](spot_check_{tag}.jpg)", ""]
    md += ["## 文件", "", "- `spot_check_24.csv`：逐段建议与用户最终判定列。", "- `spot_check_summary.json`：机器可读汇总。", ""]
    (OUT / "24段抽查结果_请用户确认.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
