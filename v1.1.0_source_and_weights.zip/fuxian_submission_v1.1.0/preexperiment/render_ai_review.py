"""Render exact-coordinate observation crops for AI visual review, not reference labels."""
import json
from pathlib import Path
import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
from affine import Affine
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'preexperiment/results/native_20200102/annotation_workspace'
OUT=BASE/'ai_review'


def main():
    OUT.mkdir(exist_ok=True)
    draft=json.loads((BASE/'initial_draft.json').read_text('utf8'))
    ids=list(range(100,109))+[185,186,187]
    with rasterio.open(ROOT/'Fuxian_S2_20200102.tif') as s:
        s2=s.read([1,2,3,4]).astype('float32')*.0001;st=s.transform;crs=s.crs
    with rasterio.open(ROOT/'Fuxian_L8_native_20200102.tif') as s:
        l8=s.read([1,2,3,4]);lt=s.transform
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17)
    records=[]
    for number in ids:
        seg=next(s for s in draft['segments'] if s['id']==f'S2_DRAFT_{number:03d}')
        coords=np.array(seg['coordinates']);lo=coords.min(0);hi=coords.max(0);center=(lo+hi)/2
        size=max(300,int(np.ceil((hi-lo).max()/10)*10)+200)
        left=np.floor((center[0]-size/2)/10)*10;top=np.ceil((center[1]+size/2)/10)*10
        n=size//10;target=Affine(10,0,left,0,-10,top)
        arrays=[]
        for data,trans in [(s2,st),(l8,lt)]:
            a=np.zeros((4,n,n),'float32')
            for b in range(4):reproject(data[b],a[b],src_transform=trans,src_crs=crs,dst_transform=target,dst_crs=crs,resampling=Resampling.nearest)
            arrays.append(a)
        rgb=lambda a,ids:Image.fromarray((np.clip(a[list(ids)].transpose(1,2,0)/.20,0,1)**.65*255).astype('uint8')).resize((440,440),Image.Resampling.NEAREST)
        panels=[rgb(arrays[0],(2,1,0)),rgb(arrays[0],(3,2,1)),rgb(arrays[0],(2,1,0)),rgb(arrays[1],(2,1,0))]
        pix=[((p[0]-left)/size*440,(top-p[1])/size*440) for p in coords]
        for i in [2,3]:ImageDraw.Draw(panels[i]).line(pix,fill='#ffcf2e',width=2)
        canvas=Image.new('RGB',(1760,520),'white');d=ImageDraw.Draw(canvas)
        for i,(im,title) in enumerate(zip(panels,['S2 RGB (native pixels)','S2 NIR false color','S2 + automatic draft','L8 + automatic draft'])):
            canvas.paste(im,(i*440,35));d.text((i*440+5,8),title,font=font,fill='black')
        d.text((8,484),f'{seg["id"]} | {size} m square | UTM bounds {int(left)}, {int(top-size)}, {int(left+size)}, {int(top)}',font=font,fill='black')
        canvas.save(OUT/f'{seg["id"]}.png')
        records.append(dict(id=seg['id'],bounds_utm=[left,top-size,left+size,top],image=f'{seg["id"]}.png',review_status='PENDING_AI_VISUAL_REVIEW'))
    (OUT/'crops.json').write_text(json.dumps(records,indent=2),encoding='utf8')
    print('Rendered',len(records),'east-shore segments.')


if __name__=='__main__':main()
