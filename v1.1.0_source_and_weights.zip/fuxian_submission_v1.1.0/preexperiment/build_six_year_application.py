"""Create 2020-2025 representative dry-season shoreline application outputs."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import rasterio
import torch
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi
from skimage.measure import find_contours
from rasterio.warp import transform as warp_transform

from run_multidate_ablation_pilot import AblationDFANet, fixed_interior, predict


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/round4_fusion_confirmation"
OUT = ROOT / "preexperiment/manuscript_ready/six_year_application_2020_2025"
SEEDS = [20260913, 20260929, 20261017]
DATES = ["2020-05-09", "2021-02-05", "2022-03-12", "2023-01-26", "2024-02-14", "2025-12-01"]


def read_scene(date):
    tag = date.replace("-", "")
    with rasterio.open(ROOT / f"Fuxian_L8_native_{tag}.tif") as src:
        x_raw = src.read(range(1, 7)).astype("float32"); profile = src.profile.copy(); transform = src.transform; crs = src.crs
    with rasterio.open(ROOT / f"Fuxian_masks_native_{tag}.tif") as src:
        masks = src.read()
    shore, l8_valid, roi = masks[0].astype(bool), masks[1].astype(bool), masks[4].astype(bool)
    interior = fixed_interior(roi, shore)
    finite = np.all(np.isfinite(x_raw) & (x_raw > -9000), axis=0)
    return {"tag": tag, "record": {"l8_date": date}, "x_raw": x_raw, "y": np.zeros(roi.shape, dtype=bool), "shore": shore, "roi": roi,
            "interior": interior, "valid": finite & l8_valid & roi, "profile": profile, "transform": transform, "crs": crs}


def normalize(scene, stats):
    scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
    for b, stat in enumerate(stats):
        scene["x"][b] = (np.clip(scene["x_raw"][b], stat["p01"], stat["p99"]) - stat["mean"]) / stat["std"]
    scene["x"][~np.isfinite(scene["x"])] = 0
    scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")


def postprocess(probability, scene):
    p = probability.copy(); p[scene["interior"]] = 1.0
    p[scene["roi"] & ~scene["shore"] & ~scene["interior"]] = 0.0; p[~scene["roi"]] = 0.0
    mask = p >= 0.5
    labels, _ = ndi.label(mask, structure=np.ones((3, 3)))
    overlap = np.bincount(labels[scene["interior"]].ravel())
    if len(overlap) <= 1: raise RuntimeError(f"No lake component for {scene['record']['l8_date']}")
    overlap[0] = 0; keep = int(np.argmax(overlap))
    return ndi.binary_fill_holes(labels == keep)


def outer_contour(mask, transform_affine):
    contours = find_contours(mask.astype("uint8"), 0.5)
    contour = max(contours, key=len)
    xy = np.asarray([transform_affine * (col + 0.5, row + 0.5) for row, col in contour])
    length = float(np.linalg.norm(np.diff(xy, axis=0), axis=1).sum())
    return xy, length


def rgb(scene):
    arr = scene["x_raw"][[2, 1, 0]].transpose(1, 2, 0).astype("float32"); out = np.zeros_like(arr)
    sample = scene["roi"] & scene["valid"]
    for b in range(3):
        lo, hi = np.percentile(arr[:, :, b][sample], [2, 98]); out[:, :, b] = np.clip((arr[:, :, b] - lo) / max(hi-lo, 1e-6), 0, 1)
    return (out ** 0.75 * 255).astype("uint8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    config = json.loads((MODEL_DIR / "fusion_confirmation_results.json").read_text(encoding="utf-8"))
    scenes = [read_scene(date) for date in DATES]
    for scene in scenes: normalize(scene, config["normalization"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    probabilities = {scene["tag"]: [] for scene in scenes}
    for seed in SEEDS:
        model = AblationDFANet(prior=True, edge_mode=None).to(device).eval()
        checkpoint = torch.load(MODEL_DIR / f"prior_seed{seed}_best.pt", map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model"])
        for scene in scenes: probabilities[scene["tag"]].append(predict(model, scene, device))
        del model
        if device.type == "cuda": torch.cuda.empty_cache()

    rows = []; panels = []
    for scene in scenes:
        date = scene["record"]["l8_date"]; tag = scene["tag"]
        probability = np.mean(probabilities[tag], axis=0); water = postprocess(probability, scene)
        xy, shoreline_length = outer_contour(water, scene["transform"])
        pixel_area = abs(scene["transform"].a * scene["transform"].e)
        area = float(water.sum() * pixel_area / 1e6)
        valid_fraction = float(scene["valid"][scene["shore"]].mean())
        profile = scene["profile"].copy(); profile.update(count=1, dtype="uint8", nodata=255, compress="deflate")
        with rasterio.open(OUT / f"Fuxian_water_{tag}.tif", "w", **profile) as dst:
            dst.write(water.astype("uint8"), 1); dst.set_band_description(1, "ensemble_water_mask_1_water")
        lon, lat = warp_transform(scene["crs"], "EPSG:4326", xy[:, 0].tolist(), xy[:, 1].tolist())
        coordinates = list(map(list, zip(lon, lat)))
        geojson = {"type": "FeatureCollection", "features": [{"type": "Feature",
            "properties": {"date": date, "area_km2": area, "shoreline_length_km": shoreline_length/1000,
                           "model": "three-seed frozen spatial-prior ensemble", "application_only": True},
            "geometry": {"type": "LineString", "coordinates": coordinates}}]}
        (OUT / f"Fuxian_shoreline_{tag}.geojson").write_text(json.dumps(geojson, ensure_ascii=False), encoding="utf-8")
        rows.append({"year": int(date[:4]), "image_date": date, "area_km2": area, "shoreline_length_km": shoreline_length/1000,
                     "l8_valid_fraction_on_shore": valid_fraction, "model_seeds": 3, "role": "representative_application_snapshot"})
        base = rgb(scene); edge = water & ~ndi.binary_erosion(water)
        overlay = base.copy(); thick = ndi.binary_dilation(edge, iterations=2); overlay[thick] = [0, 245, 255]
        overlay[~scene["valid"] & scene["shore"]] = (0.45*overlay[~scene["valid"] & scene["shore"]] + 0.55*np.array([150,40,160])).astype("uint8")
        panels.append((date, area, valid_fraction, Image.fromarray(overlay)))

    with (OUT / "six_year_shoreline_statistics.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    render_six_panel(panels)
    render_area_chart(rows)
    manifest = {"status": "SIX_YEAR_APPLICATION_COMPLETE", "years": [r["year"] for r in rows], "dates": DATES,
                "selection_rule": "One high-validity representative Landsat 8 scene per year; 2020-05-09 replaces the cloudy 2020-01-02 scene for figure quality, while 2021-2025 use dry-season or nearest dry-season scenes.",
                "model": "Mean probability from three frozen spatial-prior DFANet checkpoints; threshold 0.5; fixed spatial constraint and lake-connected component.",
                "interpretation": "Representative annual snapshots, not annual means and not independent accuracy evidence.", "records": rows}
    (OUT / "six_year_application_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    net = rows[-1]["area_km2"] - rows[0]["area_km2"]
    report = [
        "# 2020—2025年代表性湖界应用结果", "",
        "每年选择1期高有效率的代表性Landsat 8影像，采用3个冻结并联模型的概率均值提取湖界。2020年采用无云的2020-05-09影像，其余年份采用旱季或邻近旱季影像。所有日期均使用同一归一化参数、0.5阈值、固定空间约束和湖心连通水体规则。", "",
        "|年份|影像日期|湖泊面积/km²|岸线长度/km|岸带有效率|", "|---:|---|---:|---:|---:|",
    ]
    report += [f"|{r['year']}|{r['image_date']}|{r['area_km2']:.2f}|{r['shoreline_length_km']:.2f}|{r['l8_valid_fraction_on_shore']:.2%}|" for r in rows]
    report += ["", f"六期结果中面积最大值为{max(r['area_km2'] for r in rows):.2f} km²，最小值为{min(r['area_km2'] for r in rows):.2f} km²；2025年相对2020年变化{net:+.2f} km²。", "",
               "这些数值代表所选日期的瞬时湖界，并非年度平均面积。由于月份并不完全一致、Landsat空间分辨率为30 m且2020年影像存在少量残余无效像元，正文应表述为代表性时序应用，不能据此单独断言长期单调变化。", ""]
    (OUT / "六年时序应用结果.md").write_text("\n".join(report), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def render_six_panel(panels):
    cell_w, image_h, header_h, gutter = 410, 720, 96, 8
    canvas = Image.new("RGB", (cell_w*3 + gutter*2, (image_h+header_h)*2 + gutter + 54), "white")
    draw = ImageDraw.Draw(canvas); title = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 29); small = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 23)
    for i, (date, area, valid_fraction, image) in enumerate(panels):
        row, col = divmod(i, 3); x, y = col*(cell_w+gutter), row*(image_h+header_h+gutter)
        fitted = image.resize((round(image.width*image_h/image.height), image_h), Image.Resampling.LANCZOS)
        bg = Image.new("RGB", (cell_w, image_h), "white"); bg.paste(fitted, ((cell_w-fitted.width)//2,0)); canvas.paste(bg,(x,y+header_h))
        draw.text((x+18,y+8),f"{date[:4]}  ({date})",font=title,fill="#111111")
        draw.text((x+18,y+53),f"Area: {area:.2f} km²",font=small,fill="#111111")
    note = "Cyan: ensemble shoreline. Representative snapshots, not annual means."
    draw.text((16,canvas.height-40),note,font=small,fill="#222222")
    canvas.save(OUT / "figure_six_year_shorelines_2x3.png", dpi=(600,600), optimize=True)
    canvas.save(OUT / "figure_six_year_shorelines_2x3.pdf", "PDF", resolution=600)


def render_area_chart(rows):
    width, height = 1500, 820
    image = Image.new("RGB", (width, height), "white"); draw = ImageDraw.Draw(image)
    left, right, top, bottom = 150, 1410, 90, 650
    title = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 42)
    regular = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 31)
    small = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 27)
    areas = np.asarray([r["area_km2"] for r in rows])
    ymin = np.floor((areas.min()-0.15)*2)/2; ymax = np.ceil((areas.max()+0.15)*2)/2
    for tick in range(5):
        frac=tick/4; y=bottom-frac*(bottom-top); value=ymin+frac*(ymax-ymin)
        draw.line((left,y,right,y),fill="#dddddd",width=2)
        label=f"{value:.1f}"; box=draw.textbbox((0,0),label,font=small)
        draw.text((left-18-(box[2]-box[0]),y-16),label,font=small,fill="#222222")
    draw.line((left,top,left,bottom),fill="#111111",width=3); draw.line((left,bottom,right,bottom),fill="#111111",width=3)
    points=[]
    for i,r in enumerate(rows):
        x=left+i*(right-left)/(len(rows)-1); y=bottom-(r["area_km2"]-ymin)/(ymax-ymin)*(bottom-top); points.append((x,y))
    draw.line(points,fill="#0072B2",width=6)
    for (x,y),r in zip(points,rows):
        draw.ellipse((x-10,y-10,x+10,y+10),fill="#D55E00",outline="#111111",width=2)
        label=f"{r['area_km2']:.2f}"; box=draw.textbbox((0,0),label,font=small)
        draw.text((x-(box[2]-box[0])/2,y-48),label,font=small,fill="#111111")
        year=str(r["year"]); box=draw.textbbox((0,0),year,font=regular)
        draw.text((x-(box[2]-box[0])/2,bottom+22),year,font=regular,fill="#111111")
    heading="Fuxian Lake area, 2020–2025"; box=draw.textbbox((0,0),heading,font=title)
    draw.text(((width-(box[2]-box[0]))/2,18),heading,font=title,fill="#111111")
    caption="Representative Landsat 8 snapshots; values are not annual means"
    box=draw.textbbox((0,0),caption,font=regular); draw.text(((width-(box[2]-box[0]))/2,735),caption,font=regular,fill="#333333")
    image.save(OUT / "figure_six_year_area_change.png",dpi=(600,600),optimize=True)
    image.save(OUT / "figure_six_year_area_change.pdf","PDF",resolution=600)


if __name__ == "__main__": main()
