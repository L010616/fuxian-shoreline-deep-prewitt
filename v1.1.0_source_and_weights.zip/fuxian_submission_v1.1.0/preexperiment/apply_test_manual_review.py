"""Apply compact-panel manual review without modifying original test drafts.

The 24 deliberately high-risk sites are classified as PASS or EXCLUDE. Former
REDRAW candidates are conservatively excluded because an independent manual
redraw is unavailable. Outputs remain unsuitable for opening test accuracy.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_geom
from scipy.ndimage import binary_dilation


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/formal_test_drafts_v02"
TRIAGE_PATH = BASE / "ai_triage_24_sites.json"
MANIFEST_PATH = BASE / "compact_review_manifest.json"
OUT = BASE / "manual_review_v01"

GE_EVIDENCE = {
    "20240214_R01": {
        "imagery_date": "2019-08-12",
        "finding": "Stable village/natural shore; supports the paired-image PASS decision only as auxiliary evidence.",
    },
    "20250507_R03": {
        "imagery_date": "2019-08-12",
        "finding": "Historical shore is smooth; the draft loop and lakeward spur are not a stable shoreline.",
    },
    "20251201_R04": {
        "imagery_date": "2019-08-12",
        "finding": "Historical shore is smooth; the draft loop and long lakeward spur are false boundary geometry.",
    },
    "20251201_R06": {
        "imagery_date": "2019-08-12",
        "finding": "Historical imagery is insufficient to resolve the later artificial harbor geometry; conservative exclusion retained.",
    },
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build_exclusion_mask(raster_path: Path, features: list[dict], output: Path) -> dict:
    with rasterio.open(raster_path) as src:
        shapes = []
        for feature in features:
            geom = transform_geom("EPSG:4326", src.crs, feature["geometry"], precision=3)
            shapes.append((geom, 1))
        line_mask = rasterize(
            shapes, out_shape=(src.height, src.width), transform=src.transform,
            fill=0, all_touched=True, dtype="uint8"
        ).astype(bool)
        resolution = abs(src.transform.a)
        mask = binary_dilation(line_mask, iterations=max(1, math.ceil(30 / resolution))).astype("uint8")
        profile = src.profile.copy()
        profile.update(count=1, dtype="uint8", nodata=255, compress="deflate", predictor=2)
        with rasterio.open(output, "w", **profile) as dst:
            dst.write(mask, 1)
            dst.set_band_description(1, "manual_review_exclusion_mask")
            dst.update_tags(
                STATUS="REVIEWED_EXCLUSION_MASK",
                CODE_0="not_excluded_by_compact_review",
                CODE_1="excluded_around_rejected_high_risk_segment",
                BUFFER_M="30",
                TEST_ACCURACY_ALLOWED="false",
            )
    return {
        "path": str(output.relative_to(ROOT)),
        "reference_raster": raster_path.name,
        "resolution_m": resolution,
        "excluded_pixels": int(mask.sum()),
        "sha256": sha256(output),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    triage = json.loads(TRIAGE_PATH.read_text(encoding="utf-8"))
    compact = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    sites = {x["site_id"]: x for x in compact["sites"]}

    decisions = []
    for row in triage["records"]:
        original = row["ai_triage"]
        decision = "PASS" if original == "PASS_CANDIDATE" else "EXCLUDE"
        reason = row["reason"]
        if original == "REDRAW_CANDIDATE":
            reason += " Conservative exclusion used because no independent redraw is available."
        evidence = GE_EVIDENCE.get(row["site_id"])
        decisions.append({
            "site_id": row["site_id"],
            "source_segment": row["source_segment"],
            "decision": decision,
            "review_status": "MANUALLY_INTERPRETED_FROM_PAIRED_PANEL",
            "reason": reason,
            "google_earth_checked": evidence is not None,
            "google_earth_imagery_date": evidence["imagery_date"] if evidence else "",
            "google_earth_finding": evidence["finding"] if evidence else "",
            "reviewer": "Codex-assisted visual interpretation",
            "independent_second_reviewer": False,
            "allow_test_evaluation": False,
        })

    with (OUT / "manual_review_decisions_24.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=decisions[0].keys())
        writer.writeheader()
        writer.writerows(decisions)
    write_json(OUT / "manual_review_decisions_24.json", {
        "status": "COMPACT_HIGH_RISK_SITES_REVIEWED_FULL_REFERENCE_NOT_FINAL",
        "reviewed_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "review_scope": "24 deliberately selected high-risk sites; not all shoreline segments",
        "decision_counts": dict(Counter(x["decision"] for x in decisions)),
        "google_earth_scope": "Four targeted checks; historical imagery is auxiliary and not same-date truth.",
        "independent_second_reviewer": False,
        "test_accuracy_opened": False,
        "records": decisions,
    })

    masks = []
    for date in sorted({x["site_id"].split("_")[0] for x in decisions}):
        scene_out = OUT / date
        scene_out.mkdir(exist_ok=True)
        draft_path = BASE / date / "shoreline_DRAFT.geojson"
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        by_id = {f["properties"]["segment_id"]: f for f in draft["features"]}
        date_rows = [x for x in decisions if x["site_id"].startswith(date)]
        exclude_ids = {x["source_segment"] for x in date_rows if x["decision"] == "EXCLUDE"}
        pass_ids = {x["source_segment"] for x in date_rows if x["decision"] == "PASS"}
        missing = (exclude_ids | pass_ids) - by_id.keys()
        if missing:
            raise KeyError(f"Missing segments for {date}: {sorted(missing)}")

        screened_features = []
        for feature in draft["features"]:
            sid = feature["properties"]["segment_id"]
            if sid in exclude_ids:
                continue
            copy = json.loads(json.dumps(feature))
            if sid in pass_ids:
                copy["properties"].update({
                    "compact_review_status": "PASS",
                    "compact_review_allow_reference_candidate": True,
                })
            else:
                copy["properties"].update({
                    "compact_review_status": "NOT_SELECTED_FOR_COMPACT_REVIEW",
                    "compact_review_allow_reference_candidate": False,
                })
            screened_features.append(copy)
        screened = {
            "type": "FeatureCollection",
            "name": f"shoreline_screened_{date}",
            "status": "PARTIALLY_REVIEWED_NOT_FINAL_REFERENCE",
            "allow_test_evaluation": False,
            "features": screened_features,
        }
        screened_path = scene_out / "shoreline_screened_PARTIAL.geojson"
        write_json(screened_path, screened)

        excluded_features = [by_id[sid] for sid in sorted(exclude_ids)]
        write_json(scene_out / "excluded_segments.geojson", {
            "type": "FeatureCollection", "name": f"excluded_segments_{date}",
            "features": excluded_features,
        })

        s2_tag = {"20240214":"20240215", "20240504":"20240505", "20250507":"20250505", "20251201":"20251201"}[date]
        masks.append(build_exclusion_mask(
            ROOT / f"Fuxian_S2_{s2_tag}.tif", excluded_features,
            scene_out / "compact_review_exclusion_mask_S2_10m.tif"
        ))
        masks.append(build_exclusion_mask(
            ROOT / f"Fuxian_L8_native_{date}.tif", excluded_features,
            scene_out / "compact_review_exclusion_mask_L8_30m.tif"
        ))

    summary = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "HIGH_RISK_COMPACT_REVIEW_COMPLETE_FULL_LABEL_REVIEW_PENDING",
        "reviewed_sites": len(decisions),
        "decision_counts": dict(Counter(x["decision"] for x in decisions)),
        "google_earth_checks": len(GE_EVIDENCE),
        "original_drafts_modified": False,
        "independent_second_reviewer": False,
        "test_accuracy_opened": False,
        "allow_test_evaluation": False,
        "remaining_requirement": "Review or conservatively mask all remaining unreviewed shoreline segments, then freeze final labels and hashes.",
        "mask_outputs": masks,
    }
    write_json(OUT / "manual_review_summary.json", summary)
    (OUT / "README.md").write_text(
        "# 测试集简化人工审核结果\n\n"
        "24 个主动选择的高风险岸段已完成配对影像人工判读，其中 4 处使用 Google Earth Pro 2019-08-12 历史影像辅助检查。"
        "最终判定为 7 处通过、17 处排除。原始草稿未修改；排除段建立了 S2 10 m 与 L8 30 m 网格的 30 m 缓冲掩膜。\n\n"
        "本次仅完成高风险抽样审核，不能称为独立完整真值。剩余岸段完成审核或保守掩膜并冻结哈希前，测试精度继续封存。\n",
        encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
