import json
from pathlib import Path
import numpy as np
from scipy.ndimage import binary_erosion,distance_transform_edt
import run_locked_test_model_comparison as l

OUT=l.ROOT/'preexperiment/results/revision_round2'
scenes=l.load_scenes();l.normalize_and_exclude(scenes,json.loads((l.MODEL_DIR/'config.json').read_text())['normalization'])
scene=next(s for s in scenes if s['tag']=='20251201')
truth=scene['y'];full_tb=truth^binary_erosion(truth)
full_dt,indices=distance_transform_edt(~full_tb,return_indices=True)
core=binary_erosion(scene['valid']&scene['shore'],iterations=3)
cropped_tb=full_tb&core;cropped_dt=distance_transform_edt(~cropped_tb)
rows=[]
for seed in l.SEEDS:
    pred=np.load(OUT/f'probability_20251201_seed{seed}.npz')['probability']>=.5
    pb=(pred^binary_erosion(pred))&core
    severe=pb&(cropped_dt*30>60)
    pts=np.argwhere(severe)
    nr=indices[0][severe];nc=indices[1][severe]
    rows.append(dict(seed=seed,query_count=int(pb.sum()),over60_count=int(severe.sum()),
        fraction_over60_with_unfiltered_reference_within60=float(np.mean(full_dt[severe]*30<=60)),
        fraction_over60_nearest_reference_removed_by_core=float(np.mean(~core[nr,nc])),
        mean_distance_unfiltered_reference_m=float(np.mean(full_dt[severe])*30),
        max_distance_unfiltered_reference_m=float(np.max(full_dt[severe])*30)))
(OUT/'missing_counterpart_audit.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
