"""Exploratory land-texture translation screening, never a control-point accuracy certificate.

No correction is applied. Candidate land comes from a pre-period outline;
independent stable-ground control points remain required before label evaluation.
"""
import json
import argparse
from pathlib import Path
import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_geom
from scipy import ndimage as ndi
from scipy.optimize import minimize
from audit_first_scene import rgb, panel

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'preexperiment/results/baselines_20200102'


def corr(a,b):
    a=a.ravel()-a.mean(); b=b.ravel()-b.mean()
    return float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),1e-12))


def estimate(a,b):
    # Remove slowly varying radiometric differences. Interior scoring excludes warp borders.
    a=ndi.gaussian_filter(a,.6)-ndi.gaussian_filter(a,3)
    b=ndi.gaussian_filter(b,.6)-ndi.gaussian_filter(b,3)
    ref=a[5:-5,5:-5]
    def score(shift):
        return corr(ref,ndi.shift(b,shift,order=1,mode='nearest',prefilter=False)[5:-5,5:-5])
    guesses=[(score((y,x)),(y,x)) for y in range(-2,3) for x in range(-2,3)]
    start=max(guesses)[1]
    fit=minimize(lambda p:-score(p),start,method='Powell',bounds=[(-2,2),(-2,2)],
                 options={'xtol':.01,'ftol':1e-5})
    return dict(shift_row_col_pixels=fit.x.tolist(),ncc_before=score((0,0)),ncc_after=score(fit.x),
                converged=bool(fit.success),at_search_boundary=bool(np.max(np.abs(fit.x))>1.95))


def main():
    global OUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native',action='store_true')
    parser.add_argument('--match-original-windows',action='store_true',help='Reuse the geographic centers of the original eight windows.')
    args=parser.parse_args()
    if args.native: OUT=ROOT/'preexperiment/results/native_20200102'
    l8path=ROOT/('Fuxian_L8_native_20200102.tif' if args.native else 'Fuxian_L8_20200102.tif')
    with rasterio.open(l8path) as src:
        l8=src.read(); trans=src.transform; crs=src.crs
    with rasterio.open(OUT/'s2_30m_diagnostic.tif') as src: s2=src.read()
    with rasterio.open(OUT/'masks_explicit_bands.tif') as src: joint=src.read(4)==1
    geo=json.loads((ROOT/'preexperiment/results/screening_outline_and_bounds.geojson').read_text('utf8'))
    outline=next(f for f in geo['features'] if f['properties']['role']=='screening_outline_2019_not_truth')
    prior=rasterize([(transform_geom('EPSG:4326',crs,outline['geometry']),1)],
                    out_shape=joint.shape,transform=trans).astype(bool)
    candidates_land=ndi.binary_erosion(joint & np.isfinite(s2).all(0),iterations=4) & ~ndi.binary_dilation(prior,iterations=3)
    candidates=[]
    for r in range(6,joint.shape[0]-70,32):
        for c in range(6,joint.shape[1]-70,32):
            sl=np.s_[r:r+64,c:c+64]
            if candidates_land[sl].all():
                texture=float(np.std(l8[3][sl]-ndi.gaussian_filter(l8[3][sl],3)))
                if texture>.01: candidates.append((texture,r,c))
    selected=[]
    for texture,r,c in sorted(candidates,reverse=True):
        if all(abs(r-p[1])>=96 or abs(c-p[2])>=96 for p in selected):
            selected.append((texture,r,c))
        if len(selected)==8: break
    if args.match_original_windows:
        assert args.native,'Matched windows are intended for the native-grid comparison.'
        old=json.loads((ROOT/'preexperiment/results/baselines_20200102/registration_screen.json').read_text())
        with rasterio.open(ROOT/'Fuxian_L8_20200102.tif') as src: original_transform=src.transform
        selected=[]
        for record in old['records']:
            x,y=original_transform*(record['col']+32,record['row']+32)
            center_col,center_row=(~trans)*(x,y)
            r,c=int(np.floor(center_row-32+.5)),int(np.floor(center_col-32+.5))
            assert candidates_land[r:r+64,c:c+64].all(),'Matched window is no longer entirely valid candidate land.'
            selected.append((float(np.std(l8[3,r:r+64,c:c+64])),r,c))
    records=[]
    dest=OUT/'registration_screen';dest.mkdir(exist_ok=True)
    for i,(texture,r,c) in enumerate(selected):
        sl=np.s_[r:r+64,c:c+64]
        bands={name:estimate(l8[idx][sl],s2[idx][sl]) for name,idx in [('NIR',3),('SWIR1',4)]}
        consistent=np.linalg.norm(np.array(bands['NIR']['shift_row_col_pixels'])-bands['SWIR1']['shift_row_col_pixels'])<=.5
        usable=consistent and all(b['converged'] and not b['at_search_boundary'] and b['ncc_after']>=.7 for b in bands.values())
        record=dict(id=i+1,row=r,col=c,size_pixels=64,nir_texture=texture,bands=bands,
                    center_utm=list(trans*(c+32,r+32)),
                    spectral_shift_consistency=bool(consistent),screen_usable=bool(usable))
        records.append(record)
        panel([rgb(l8[:6,r:r+64,c:c+64]),rgb(s2[:,r:r+64,c:c+64])],
              [f'Land {i+1} / L8',f'Land {i+1} / S2 averaged'],dest/f'land_{i+1}.png',
              '1.92 km square | Candidate land texture, not independently surveyed control points.',width=384)
    accepted=[r for r in records if r['screen_usable']]
    shifts=[r['bands'][b]['shift_row_col_pixels'] for r in accepted for b in ['NIR','SWIR1']]
    result=dict(status='EXPLORATORY_ONLY_NO_CORRECTION_APPLIED',candidate_count=len(candidates),
                input=str(l8path),matched_original_windows=args.match_original_windows,
                windows_examined=len(records),usable_windows=len(accepted),records=records,
                convention='Shift applied to S2 array to match L8: positive row=south; positive col=east.',
                optimization='Gaussian high-pass land textures; NCC with bilinear translation within +/-2 pixels.',
                limitation='Fitted shifts depend on PSF, spectral response and interpolation. Not independent geolocation accuracy; stable landmark verification required.')
    if shifts:
        median=np.median(shifts,axis=0)
        result['median_row_col_pixels']=median.tolist()
        result['median_fitted_translation_magnitude_m']=float(np.linalg.norm(median)*30)
    (OUT/'registration_screen.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))


if __name__=='__main__': main()
