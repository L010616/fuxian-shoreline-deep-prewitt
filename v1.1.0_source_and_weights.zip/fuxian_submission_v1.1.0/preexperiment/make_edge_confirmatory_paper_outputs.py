"""Create paper-ready tables and figure from the locked edge evaluation."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "results" / "edge_confirmatory_2018"
LOCKED = BASE / "locked_evaluation" / "edge_confirmatory_results.json"
OUT = BASE / "paper_ready"

COLORS = {
    "prior_only": "#5B608C",
    "shallow_parallel_depth0": "#E7A889",
    "deep_parallel_depth2": "#A9C8B8",
}
LABELS = {
    "prior_only": "Spatial prior",
    "shallow_parallel_depth0": "Prior + shallow edge",
    "deep_parallel_depth2": "Prior + deep edge",
}


def main() -> None:
    data = json.loads(LOCKED.read_text(encoding="utf-8"))
    if data["status"] != "EDGE_CONFIRMATORY_EVALUATION_OPENED_ONCE_AND_LOCKED":
        raise RuntimeError("Locked evaluation result is unavailable")
    OUT.mkdir(parents=True, exist_ok=True)

    models = list(LABELS)
    dates = data["dates"]
    summary = data["summary"]
    per_date = data["seed_averaged_per_date"]
    paired = data["paired_date_level_effects"]

    date_stats = {
        model: {
            key: {
                "mean": float(np.mean([row[key] for row in per_date[model].values()])),
                "std": float(np.std([row[key] for row in per_date[model].values()], ddof=1)),
            }
            for key in ("boundary_f1_30m", "mean_symmetric_boundary_distance_m", "iou")
        }
        for model in models
    }

    with (OUT / "table_edge_confirmatory_summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Model", "Boundary F1 30 m mean", "Boundary F1 30 m SD", "ASD mean (m)", "ASD SD (m)", "IoU mean", "IoU SD"])
        for model in models:
            writer.writerow([
                LABELS[model],
                date_stats[model]["boundary_f1_30m"]["mean"],
                date_stats[model]["boundary_f1_30m"]["std"],
                date_stats[model]["mean_symmetric_boundary_distance_m"]["mean"],
                date_stats[model]["mean_symmetric_boundary_distance_m"]["std"],
                date_stats[model]["iou"]["mean"],
                date_stats[model]["iou"]["std"],
            ])

    plt.rcParams.update({
        "font.family": "Arial",
        "font.size": 9,
        "axes.linewidth": 0.8,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(2, 2, figsize=(8.3, 6.2), constrained_layout=True)
    x = np.arange(len(models))

    for ax, key, ylabel, ylim in [
        (axes[0, 0], "boundary_f1_30m", "Boundary F1 (30 m)", (0.985, 1.001)),
        (axes[0, 1], "mean_symmetric_boundary_distance_m", "ASD (m)", (5.0, 13.0)),
    ]:
        means = [date_stats[m][key]["mean"] for m in models]
        stds = [date_stats[m][key]["std"] for m in models]
        ax.bar(x, means, yerr=stds, width=0.62, color=[COLORS[m] for m in models],
               edgecolor="#3E3142", linewidth=0.65, capsize=3, error_kw={"elinewidth": 0.8})
        ax.set_xticks(x, [LABELS[m].replace(" + ", "\n+ ") for m in models])
        ax.set_ylabel(ylabel)
        ax.set_ylim(*ylim)
        ax.grid(axis="y", color="#D9DDE2", linewidth=0.55, alpha=0.8)
        ax.set_axisbelow(True)
        for i, value in enumerate(means):
            text = f"{value:.4f}" if key == "boundary_f1_30m" else f"{value:.2f}"
            ax.text(i, value + (0.00028 if key == "boundary_f1_30m" else 0.18), text,
                    ha="center", va="bottom", fontsize=8, color="#3E3142")

    deep_prior = paired["deep_minus_prior_only"]
    bf = deep_prior["boundary_f1_30m"]["date_level_effects"]
    asd = deep_prior["asd_reduction_m"]["date_level_effects"]
    labels = [d[5:] for d in dates]
    for ax, values, ylabel, zero_label in [
        (axes[1, 0], [bf[d] for d in dates], "Deep edge − spatial prior\nBoundary F1", "No change"),
        (axes[1, 1], [asd[d] for d in dates], "ASD reduction (m)\nSpatial prior − deep edge", "No reduction"),
    ]:
        values = np.asarray(values)
        colors = ["#A9C8B8" if v >= 0 else "#D99AAE" for v in values]
        ax.axhline(0, color="#3E3142", linewidth=0.8)
        ax.bar(np.arange(len(dates)), values, color=colors, edgecolor="#3E3142", linewidth=0.55, width=0.68)
        ax.set_xticks(np.arange(len(dates)), labels, rotation=35, ha="right")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", color="#D9DDE2", linewidth=0.55, alpha=0.8)
        ax.set_axisbelow(True)

    axes[0, 0].text(-0.16, 1.05, "(a)", transform=axes[0, 0].transAxes, fontweight="bold", fontsize=11)
    axes[0, 1].text(-0.16, 1.05, "(b)", transform=axes[0, 1].transAxes, fontweight="bold", fontsize=11)
    axes[1, 0].text(-0.16, 1.05, "(c)", transform=axes[1, 0].transAxes, fontweight="bold", fontsize=11)
    axes[1, 1].text(-0.16, 1.05, "(d)", transform=axes[1, 1].transAxes, fontweight="bold", fontsize=11)
    for ax in axes.flat:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    fig.savefig(OUT / "figure_edge_confirmatory_evidence.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / "figure_edge_confirmatory_evidence.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    bp = deep_prior["boundary_f1_30m"]
    ap = deep_prior["asd_reduction_m"]
    shallow = paired["deep_minus_shallow_parallel_depth0"]
    report = f"""# 2018 independent confirmation of the edge branch

The six dates and all reference exclusions were frozen before model predictions were opened. All values are averages over three independently trained seeds. Date-level confidence intervals resample the six frozen dates after averaging the seeds.

| Model | Boundary F1 (30 m) | ASD (m) | IoU |
|---|---:|---:|---:|
"""
    for model in models:
        report += (
            f"| {LABELS[model]} | {date_stats[model]['boundary_f1_30m']['mean']:.5f} ± {date_stats[model]['boundary_f1_30m']['std']:.5f} | "
            f"{date_stats[model]['mean_symmetric_boundary_distance_m']['mean']:.2f} ± {date_stats[model]['mean_symmetric_boundary_distance_m']['std']:.2f} | "
            f"{date_stats[model]['iou']['mean']:.5f} ± {date_stats[model]['iou']['std']:.5f} |\n"
        )
    report += f"""

Compared with the spatial-prior-only model, the selected deep edge model increased Boundary F1 by {bp['mean_effect']:.5f} (95% bootstrap CI {bp['bootstrap_95_ci'][0]:.5f} to {bp['bootstrap_95_ci'][1]:.5f}); five of six dates improved. ASD decreased by {ap['mean_effect']:.2f} m (95% bootstrap CI {ap['bootstrap_95_ci'][0]:.2f} to {ap['bootstrap_95_ci'][1]:.2f} m), with improvement on all six dates. This satisfies the predeclared criterion for treating the edge branch as a second formal innovation.

The deep variant was not uniformly better than the shallow edge variant: its mean Boundary F1 was higher by {shallow['boundary_f1_30m']['mean_effect']:.5f}, whereas ASD was higher by {-shallow['asd_reduction_m']['mean_effect']:.2f} m. The manuscript should therefore attribute the confirmed gain to the multiscale LoG–Prewitt edge branch and present added residual depth as the validation-selected implementation, without claiming universal superiority of additional depth.
"""
    (OUT / "edge_confirmatory_report.md").write_text(report, encoding="utf-8")
    print(json.dumps({"figure": str(OUT / 'figure_edge_confirmatory_evidence.png'), "report": str(OUT / 'edge_confirmatory_report.md')}, ensure_ascii=False))


if __name__ == "__main__":
    main()
