"""Validate round-4 train/validation files and freeze the six-date blind test."""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

from validate_formal_downloads import inspect_tif


ROOT = Path(__file__).resolve().parents[1]
PRE = ROOT / "preexperiment"
DATA = PRE / "data/round4_trainval"
PROTOCOL_DIR = PRE / "data/round4_protocol"
BASE = PRE / "results/round4_protocol"


def checksum(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    protocol = json.loads((BASE / "round4_split_protocol.json").read_text(encoding="utf-8"))
    records = protocol["added_export_records"]
    audited = []
    for record in records:
        ld = record["l8_date"].replace("-", "")
        sd = record["s2_date"].replace("-", "")
        paths = {
            "l8": DATA / f"Fuxian_L8_native_{ld}.tif",
            "s2": DATA / f"Fuxian_S2_{sd}.tif",
            "masks": DATA / f"Fuxian_masks_native_{ld}.tif",
        }
        files = {kind: inspect_tif(path, kind) if path.exists() else {"status": "MISSING", "path": str(path)}
                 for kind, path in paths.items()}
        audited.append({
            "l8_date": record["l8_date"], "s2_date": record["s2_date"],
            "split": record["split"], "joint_shore_valid": record["joint_shore_valid"],
            "status": "PASS" if all(f["status"] == "PASS" for f in files.values()) else "FAIL",
            "files": files,
        })
    qc = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "PASS" if all(r["status"] == "PASS" for r in audited) else "FAIL",
        "expected_dates": len(records), "passed_dates": sum(r["status"] == "PASS" for r in audited),
        "records": audited,
    }
    (BASE / "round4_trainval_download_qc.json").write_text(
        json.dumps(qc, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    csv_path = PROTOCOL_DIR / "Fuxian_sealed_final_test_2026_manifest.csv"
    with csv_path.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 3 or any(str(r["imagery_opened"]).lower() != "false" for r in rows):
        raise RuntimeError("2026 sealed-date manifest is incomplete or marked opened")
    fixed = [r for r in protocol["final_blind_test"] if r["l8_date"]]
    added = [{
        "l8_date": r["l8_date"], "s2_date": r["s2_date"],
        "l8_product_id": r["l8_product_id"],
        "l8_clear_shore": float(r["l8_clear_shore"]),
        "s2_clear_shore": float(r["s2_clear_shore"]),
        "joint_clear_score": float(r["joint_clear_score"]),
        "day_gap": int(float(r["day_gap"])),
        "role": "final_blind_test", "status": "SEALED",
    } for r in rows]
    final = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "FINAL_SIX_DATE_TEST_SET_SEALED_BEFORE_FUSION_TRAINING",
        "selection_used_model_outputs": False,
        "imagery_downloaded": False,
        "references_created": False,
        "allow_training": False,
        "allow_model_selection": False,
        "allow_evaluation": False,
        "dates": fixed + added,
        "source_2026_manifest": str(csv_path.relative_to(ROOT)),
        "source_2026_sha256": checksum(csv_path),
    }
    (BASE / "final_blind_six_date_manifest.json").write_text(
        json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "trainval_qc": qc["status"], "passed_dates": qc["passed_dates"],
        "sealed_final_dates": [r["l8_date"] for r in final["dates"]],
    }, ensure_ascii=False, indent=2))
    return 0 if qc["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
