"""Generate consistent automatic reference drafts for all unsealed dates."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/formal_trainval_drafts"
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"


def main():
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]
    selected = [r for r in records if r["split"] in {"train", "validation"}]
    results = [builder.build_one(record) for record in selected]
    summary = {
        "dataset": "Fuxian train-validation automatic shoreline drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_FINAL_REFERENCE_REVIEW",
        "purpose": "multi-date feasibility ablation, not final paper accuracy",
        "allow_final_paper_claims": False,
        "test_dates_opened": False,
        "split_counts": {
            "train": sum(r["split"] == "train" for r in results),
            "validation": sum(r["split"] == "validation" for r in results),
        },
        "records": results,
    }
    (OUT / "trainval_draft_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "dates": len(results), "train": summary["split_counts"]["train"],
        "validation": summary["split_counts"]["validation"],
        "output": str(OUT),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
