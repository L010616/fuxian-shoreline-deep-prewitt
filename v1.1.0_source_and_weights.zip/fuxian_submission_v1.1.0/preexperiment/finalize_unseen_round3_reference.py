"""Conservatively screen and freeze the five newly unseen test references."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import finalize_additional_test_reference as finalizer


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/unseen_test_round3"
DRAFT = BASE / "reference_drafts"
SELECTION = BASE / "selection_manifest.json"


def main() -> int:
    source = json.loads(SELECTION.read_text(encoding="utf-8"))
    pairs = [{
        "l8_date": r["l8_date"],
        "s2_date": r["s2_date"],
        "calendar_gap_days": r["day_gap"],
        "quality_class": r["quality_class"],
    } for r in source["selected"]]
    compatible = BASE / "evaluation_pairs.json"
    compatible.write_text(json.dumps({"selected": pairs}, ensure_ascii=False, indent=2), encoding="utf-8")

    notes = {
        "2024-04-02": "Accepted; extensive clear shoreline with cloud-obscured segments conservatively excluded.",
        "2024-10-27": "Accepted as partial scene; clear central, western and southern shoreline retained.",
        "2025-01-31": "Accepted as partial scene; cloud-obscured northern and local shoreline excluded.",
        "2025-04-21": "Accepted as partial scene; evaluation restricted to joint-valid visible shoreline.",
        "2025-10-14": "Accepted as challenging partial scene; only joint-valid retained shoreline may be evaluated.",
    }
    review = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "DATE_OVERVIEWS_REVIEWED",
        "reviewer": "Codex-assisted full-date visual screening",
        "policy": "Accept a date only for its joint-valid shoreline; exclude all automatically flagged high-priority segments with a 30 m buffer.",
        "records": [{"l8_date": r["l8_date"], "accept": True, "notes": notes[r["l8_date"]]} for r in pairs],
    }
    review_path = DRAFT / "date_level_review.json"
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")

    finalizer.DRAFT_ROOT = DRAFT
    finalizer.REVIEW = review_path
    finalizer.OUT = BASE / "screened_reference"
    finalizer.MANIFEST = compatible
    finalizer.main()

    manifest_path = finalizer.OUT / "screened_reference_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.update({
        "dataset": "Fuxian Lake unseen-date conservative screened references round 3",
        "status": "FROZEN_FOR_ONE_TIME_UNSEEN_EVALUATION",
        "reference_scope": "Only retained shoreline intersecting the exported joint-valid mask is eligible.",
        "previously_opened_dates_excluded": source["previously_opened_dates_excluded"],
    })
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": manifest["status"],
        "dates": len(manifest["records"]),
        "coverage": {r["l8_date"]: {
            "retained_fraction": round(r["retained_length_fraction"], 3),
            "sectors": r["spatial_coverage"]["occupied_12_sectors"],
        } for r in manifest["records"]},
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
