"""Read-only QC for the 18 external-lake candidate triples.

Outputs live beside this script under results/q2_external/. No image is
altered. Raster checks are intentionally independent of model predictions.
"""

from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import rasterio
from rasterio.warp import Resampling, reproject
from rasterio.warp import transform as transform_coords
from scipy import ndimage
from skimage.measure import find_contours


ROOT = Path(__file__).resolve().parent.parent
INPUTS = [
    ROOT / "跨湖测试",
    ROOT / "drive-download-20260923T094631Z-1-001",
    ROOT / "drive-download-20260923T095357Z-1-001",
    ROOT / "drive-download-20260923T110142Z-1-001",
    ROOT / "drive-download-20260923T112403Z-1-001",
    ROOT / "drive-download-20260923T124126Z-1-001",
]
OUTPUT = ROOT / "preexperiment" / "results" / "q2_external"
PATTERN = re.compile(
    r"Q2_FAST_(Dianchi_Waihai|Erhai|Xingyun)_(\d{8})_(\d{8})_(L8|S2|QA_JRC)\.tif$"
)
SEEDS = {
    "Dianchi_Waihai": (102.7049, 24.8379),
    "Erhai": (100.1960, 25.8000),
    "Xingyun": (102.7820, 24.3370),
}


def footprint_on_grid(path: Path, ref: rasterio.DatasetReader) -> np.ndarray:
    with rasterio.open(path) as ds:
        src = ds.read_masks(1)
        dst = np.zeros((ref.height, ref.width), dtype=np.uint8)
        reproject(
            source=src,
            destination=dst,
            src_transform=ds.transform,
            src_crs=ds.crs,
            dst_transform=ref.transform,
            dst_crs=ref.crs,
            resampling=Resampling.nearest,
        )
        return dst > 0


def fraction(mask: np.ndarray, domain: np.ndarray) -> float:
    n = int(domain.sum())
    return float((mask & domain).sum() / n) if n else float("nan")


def main_lake(water: np.ndarray, ds: rasterio.DatasetReader,
              lake: str) -> np.ndarray:
    labels, count = ndimage.label(water, structure=np.ones((3, 3), dtype=np.uint8))
    if not count:
        raise ValueError("no JRC water component")
    lon, lat = SEEDS[lake]
    x, y = transform_coords("EPSG:4326", ds.crs, [lon], [lat])
    col, row = (~ds.transform) * (x[0], y[0])
    rr, cc = round(row), round(col)
    if not (0 <= rr < ds.height and 0 <= cc < ds.width):
        raise ValueError(f"{lake}: seed outside raster")
    label = int(labels[rr, cc])
    if label == 0:
        raise ValueError(f"{lake}: seed not on JRC 2019 water")
    return labels == label


def run() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    groups: dict[tuple[str, str, str], dict[str, Path]] = defaultdict(dict)
    for source in INPUTS:
        for path in source.rglob("*.tif"):
            m = PATTERN.fullmatch(path.name)
            if m:
                key, kind = m.group(1, 2, 3), m.group(4)
                if kind in groups[key]:
                    raise RuntimeError(f"Duplicate raster: {groups[key][kind]} and {path}")
                groups[key][kind] = path
    existing_l8: dict[tuple[str, str], list[Path]] = defaultdict(list)
    for (lake, l8_day, _), files in groups.items():
        if "L8" in files:
            existing_l8[(lake, l8_day)].append(files["L8"])

    rows = []
    for (lake, l8_day, s2_day), files in sorted(groups.items()):
        files = dict(files)
        reused_l8 = False
        if "L8" not in files and "S2" in files and "QA_JRC" in files:
            candidates = existing_l8.get((lake, l8_day), [])
            if len(candidates) == 1:
                files["L8"] = candidates[0]
                reused_l8 = True
        row = {"lake": lake, "l8_date": l8_day, "s2_date": s2_day,
               "file_count": len(files), "missing": "|".join(sorted(
                   {"L8", "S2", "QA_JRC"} - set(files))),
               "l8_reused_from_earlier_pair": reused_l8}
        if len(files) != 3:
            rows.append(row)
            continue
        with rasterio.open(files["QA_JRC"]) as qa:
            a = qa.read()
            if qa.count != 4:
                row["error"] = f"QA has {qa.count} bands, expected 4"
                rows.append(row)
                continue
            water = main_lake(a[0] >= 2, qa, lake)
            shore = ndimage.binary_dilation(water, iterations=10) & ~ndimage.binary_erosion(
                water, iterations=10
            )
            l8_foot = footprint_on_grid(files["L8"], qa)
            s2_foot = footprint_on_grid(files["S2"], qa)
            l8_valid = a[1] > 0
            s2_valid = a[2] > 0
            joint_valid = a[3] > 0
            contours = find_contours(water.astype(np.uint8), 0.5)
            perimeter_km = max(
                (float(np.linalg.norm(np.diff(c, axis=0), axis=1).sum())
                 * abs(qa.res[0]) / 1000 for c in contours), default=0.0
            )
            boundary = water & ~ndimage.binary_erosion(water)
            ys, xs = np.where(boundary)
            cy, cx = np.where(water)[0].mean(), np.where(water)[1].mean()
            angle = np.arctan2(ys - cy, xs - cx)
            sectors = np.floor((angle + np.pi) / (2 * np.pi) * 12).astype(int) % 12
            boundary_valid = joint_valid[ys, xs]
            valid_boundary_fraction = float(boundary_valid.mean())
            covered_sectors = sum(
                bool(boundary_valid[sectors == i].mean() >= 0.5)
                for i in range(12) if np.any(sectors == i)
            )
            with rasterio.open(files["L8"]) as l8_ds, rasterio.open(files["S2"]) as s2_ds:
                l8_bands, s2_bands = l8_ds.count, s2_ds.count
            row.update({
                "crs": str(qa.crs),
                "qa_shape": f"{qa.height}x{qa.width}",
                "jrc_main_km2": round(float(water.sum()) * abs(qa.res[0] * qa.res[1]) / 1e6, 2),
                "jrc_outer_perimeter_km": round(perimeter_km, 2),
                "joint_valid_boundary_fraction": round(valid_boundary_fraction, 4),
                "approx_usable_shoreline_km": round(perimeter_km * valid_boundary_fraction, 2),
                "sectors_50pct_joint_valid_of_12": covered_sectors,
                "l8_foot_lake": round(fraction(l8_foot, water), 4),
                "s2_foot_lake": round(fraction(s2_foot, water), 4),
                "l8_valid_shore": round(fraction(l8_valid, shore), 4),
                "s2_valid_shore": round(fraction(s2_valid, shore), 4),
                "joint_valid_shore": round(fraction(joint_valid, shore), 4),
                "l8_valid_lake": round(fraction(l8_valid, water), 4),
                "s2_valid_lake": round(fraction(s2_valid, water), 4),
                "joint_valid_lake": round(fraction(joint_valid, water), 4),
                "qa_joint_consistent": bool(np.array_equal(
                    joint_valid, l8_valid & s2_valid
                )),
                "l8_bands": l8_bands,
                "s2_bands": s2_bands,
            })
            row["preliminary_quality_pass"] = bool(
                row["l8_foot_lake"] >= 0.98
                and row["s2_foot_lake"] >= 0.98
                and row["l8_valid_shore"] >= 0.50
                and row["s2_valid_shore"] >= 0.50
                and row["joint_valid_shore"] >= 0.40
                and row["approx_usable_shoreline_km"] >= 30
                and row["sectors_50pct_joint_valid_of_12"] >= 8
                and row["qa_joint_consistent"]
            )
        rows.append(row)

    path = OUTPUT / "candidate_qc.csv"
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    (OUTPUT / "candidate_qc.json").write_text(
        json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"groups={len(groups)} triples={sum(r['file_count']==3 for r in rows)} "
          f"preliminary_pass={sum(bool(r.get('preliminary_quality_pass')) for r in rows)}")
    print(path)
    for row in rows:
        print(row["lake"], row["l8_date"], row.get("l8_foot_lake"),
              row.get("s2_foot_lake"), row.get("joint_valid_shore"),
              row.get("preliminary_quality_pass"))


if __name__ == "__main__":
    run()
