"""Create automatic Sentinel-2 shoreline drafts for frozen unseen dates."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "preexperiment/results/unseen_test_round3/selection_manifest.json"
OUT = ROOT / "preexperiment/results/unseen_test_round3/reference_drafts"


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest["status"] != "FROZEN_BEFORE_REFERENCE_CREATION":
        raise RuntimeError("Unseen-date selection is not frozen")
    records = [{
        "l8_date": r["l8_date"],
        "s2_date": r["s2_date"],
        "calendar_gap_days": r["day_gap"],
        "split": "unseen_test",
    } for r in manifest["selected"]]
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    results = [builder.build_one(record) for record in records]
    summary = {
        "dataset": "Fuxian unseen-date reference drafts round 3",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_REVIEW",
        "allow_training": False,
        "allow_model_selection": False,
        "allow_evaluation": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(r["segment_count"] for r in results),
            "high_priority_segments": sum(r["high_priority_segments"] for r in results),
        },
    }
    (OUT / "draft_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary["totals"], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
