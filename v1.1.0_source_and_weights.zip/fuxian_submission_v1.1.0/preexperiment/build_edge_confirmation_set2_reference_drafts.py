"""Build prediction-blind Sentinel-2 shoreline drafts for confirmation set 2."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "data" / "edge_confirmation_set2"
MANIFEST = BASE / "selection_manifest.json"
OUT = ROOT / "preexperiment" / "results" / "edge_confirmation_set2" / "reference_drafts"


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    expected = "EDGE_CONFIRMATION_SET2_INPUTS_VALIDATED_BEFORE_REFERENCE_SCREENING"
    if manifest.get("status") != expected:
        raise RuntimeError("Confirmation set 2 inputs are not validated")

    builder.DATA_ROOT = BASE / "analysis_ready"
    builder.OUT = OUT
    builder.L8_TEMPLATE = "Fuxian_edgeconfirm_set2_L8_native_{l8_tag}.tif"
    builder.S2_TEMPLATE = "Fuxian_edgeconfirm_set2_S2_{s2_tag}_for_{l8_tag}.tif"
    builder.MASK_TEMPLATE = "Fuxian_edgeconfirm_set2_masks_native_{l8_tag}.tif"
    OUT.mkdir(parents=True, exist_ok=True)

    records = [{
        "l8_date": row["l8_date"],
        "s2_date": row["s2_date"],
        "calendar_gap_days": row["calendar_gap_days"],
        "split": "edge_confirmation_set2_prediction_blind_reference",
    } for row in manifest["records"]]
    results = [builder.build_one(record) for record in records]

    payload = {
        "dataset": "Fuxian Lake edge confirmation set 2 reference drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_PREDICTION_BLIND_SCREENING",
        "allow_training": False,
        "allow_model_selection": False,
        "allow_threshold_tuning": False,
        "allow_evaluation": False,
        "model_predictions_opened": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(row["segment_count"] for row in results),
            "high_priority_segments": sum(row["high_priority_segments"] for row in results),
        },
    }
    (OUT / "draft_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "totals": payload["totals"],
        "dates": [{
            "l8_date": row["l8_date"],
            "segment_count": row["segment_count"],
            "high_priority_segments": row["high_priority_segments"],
        } for row in results],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
