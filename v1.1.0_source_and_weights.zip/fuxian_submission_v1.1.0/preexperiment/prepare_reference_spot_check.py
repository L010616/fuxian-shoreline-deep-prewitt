"""Prepare 24 spatially balanced reference-shoreline audit panels."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw, ImageFont
from rasterio.features import rasterize
from rasterio.transform import from_bounds
from rasterio.warp import transform, transform_geom


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/manuscript_ready/reference_spot_check_24"
OLD = ROOT / "preexperiment/results/formal_test_drafts_v02/manual_review_v01/pilot_test_reference_v01/pilot_test_reference_manifest.json"
NEW = ROOT / "preexperiment/results/formal_test_drafts_v03_additional/screened_reference_v01/screened_reference_manifest.json"
TARGET_ANGLES = np.arange(0, 360, 60)
CROP_M = 1800.0


def stretch(arr):
    rgb = arr.transpose(1, 2, 0).astype("float32")
    out = np.zeros_like(rgb)
    for b in range(3):
        valid = np.isfinite(rgb[:, :, b])
        lo, hi = np.percentile(rgb[:, :, b][valid], [2, 98])
        out[:, :, b] = np.clip((rgb[:, :, b] - lo) / max(hi - lo, 1e-6), 0, 1)
    return (out ** 0.75 * 255).astype("uint8")


def feature_midpoint(feature, crs):
    xy = np.asarray(feature["geometry"]["coordinates"], dtype="float64")
    xs, ys = transform("EPSG:4326", crs, xy[:, 0].tolist(), xy[:, 1].tolist())
    return np.array([np.mean(xs), np.mean(ys)])


def choose_six(features, crs):
    eligible = [i for i, f in enumerate(features) if float(f["properties"].get("length_m", 0)) >= 300.0]
    if len(eligible) < 6:
        raise RuntimeError("Fewer than six retained shoreline segments are at least 300 m long")
    mids = np.vstack([feature_midpoint(features[i], crs) for i in eligible])
    center = mids.mean(axis=0)
    angles = (np.degrees(np.arctan2(mids[:, 1] - center[1], mids[:, 0] - center[0])) + 360) % 360
    selected, used = [], set()
    for target in TARGET_ANGLES:
        delta = np.abs((angles - target + 180) % 360 - 180)
        for idx in np.argsort(delta):
            if int(idx) not in used:
                used.add(int(idx)); selected.append((eligible[int(idx)], float(angles[idx]), mids[idx])); break
    return selected


def render_panel(path, center_xy, geometry, label):
    with rasterio.open(path) as src:
        half = CROP_M / 2
        bounds = (center_xy[0] - half, center_xy[1] - half, center_xy[0] + half, center_xy[1] + half)
        window = rasterio.windows.from_bounds(*bounds, transform=src.transform)
        data = src.read([3, 2, 1], window=window, boundless=True, fill_value=0, out_shape=(3, 360, 360), resampling=rasterio.enums.Resampling.bilinear)
        dst_transform = from_bounds(*bounds, 360, 360)
        geom = transform_geom("EPSG:4326", src.crs, geometry)
        line = rasterize([(geom, 1)], out_shape=(360, 360), transform=dst_transform, fill=0, all_touched=True, dtype="uint8")
    image = stretch(data)
    thick = line.astype(bool)
    for _ in range(2):
        thick |= np.roll(thick, 1, 0) | np.roll(thick, -1, 0) | np.roll(thick, 1, 1) | np.roll(thick, -1, 1)
    image[thick] = [0, 245, 255]
    pil = Image.fromarray(image).resize((480, 480), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (480, 526), "white"); canvas.paste(pil, (0, 46))
    draw = ImageDraw.Draw(canvas); fnt = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 23)
    draw.text((12, 9), label, font=fnt, fill="#111111")
    draw.ellipse((234, 280, 246, 292), outline="#ffff00", width=3)
    return canvas


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads(OLD.read_text(encoding="utf-8"))["records"] + json.loads(NEW.read_text(encoding="utf-8"))["records"]
    rows = []
    title = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 28)
    for record in records:
        date = record["l8_date"]; l8_tag = date.replace("-", ""); s2_tag = record["s2_date"].replace("-", "")
        ref_path = ROOT / record["retained_reference"]["path"]
        collection = json.loads(ref_path.read_text(encoding="utf-8")); features = collection["features"]
        s2_path = ROOT / f"Fuxian_S2_{s2_tag}.tif"; l8_path = ROOT / f"Fuxian_L8_native_{l8_tag}.tif"
        with rasterio.open(s2_path) as src: crs = src.crs
        picked = choose_six(features, crs)
        sheet = Image.new("RGB", (1000, 6 * 526 + 70), "white"); draw = ImageDraw.Draw(sheet)
        draw.text((15, 14), f"{date}: Sentinel-2 reference vs Landsat 8 target | cyan=retained reference", font=title, fill="#111111")
        for site_no, (idx, angle, center) in enumerate(picked, 1):
            feature = features[idx]; sid = feature["properties"]["segment_id"]
            s2 = render_panel(s2_path, center, feature["geometry"], f"S2 {record['s2_date']} | site {site_no} | {angle:.0f}°")
            l8 = render_panel(l8_path, center, feature["geometry"], f"L8 {date} | gap {record['calendar_gap_days']} d")
            y = 70 + (site_no - 1) * 526; sheet.paste(s2, (0, y)); sheet.paste(l8, (520, y))
            rows.append({"site_id": f"{l8_tag}_S{site_no:02d}", "l8_date": date, "s2_date": record["s2_date"],
                         "gap_days": record["calendar_gap_days"], "source_segment": sid, "azimuth_sector_deg": round(angle, 1),
                         "ai_recommendation": "PENDING", "ai_notes": "", "user_final_decision": "PENDING"})
        sheet.save(OUT / f"spot_check_{l8_tag}.jpg", quality=94, subsampling=0)
    with (OUT / "spot_check_24.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    protocol = """# 24段参考岸线独立抽查\n\n每个测试日期从六个方位扇区各抽取一个保留岸段。左图为 Sentinel-2 参考日期，右图为 Landsat 8 目标日期；青线为待审参考岸线，黄色圆点为抽查中心。\n\n判定规则：\n\n- PASS：青线沿可见水陆界面，且在 Landsat 尺度下偏差不超过约1个像元。\n- CORRECT：局部边界可明确重画，偏差持续超过1个 Landsat 像元。\n- EXCLUDE：云、阴影、混合像元或日期差使真实岸线无法可靠判断。\n\nAI先填写建议；用户在CSV的 `user_final_decision` 列完成独立确认。\n"""
    (OUT / "审核说明.md").write_text(protocol, encoding="utf-8")
    print(json.dumps({"dates": len(records), "sites": len(rows), "output": str(OUT)}, ensure_ascii=False))


if __name__ == "__main__": main()
