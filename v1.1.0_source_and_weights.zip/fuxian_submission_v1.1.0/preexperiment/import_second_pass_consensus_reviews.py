"""Import the second manual-review pass and build the final consensus files.

The workflow is sequential: reviewer A edited the AI candidate, reviewer B
checked that result and supplied the final revision.  Both geometries are
preserved.  A small endpoint gap may be closed only when <= 60 m and is logged.
"""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import numpy as np
from rasterio.warp import transform
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "人工审核"
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
FORM = PACK / "manual_review_form.csv"
BACKUP = PACK / "manual_review_form_before_second_pass.csv"


def digest(path: Path) -> str:
    h = hashlib.sha256(path.read_bytes())
    return h.hexdigest()


def read_kml(path: Path) -> list[list[float]]:
    root = ET.parse(path).getroot()
    ns = {"k": "http://www.opengis.net/kml/2.2"}
    lines = root.findall(".//k:LineString", ns)
    if len(lines) != 1:
        raise RuntimeError(f"{path}: expected exactly one LineString")
    text = lines[0].findtext("k:coordinates", default="", namespaces=ns)
    coords = [[float(v.split(",")[0]), float(v.split(",")[1])] for v in text.split()]
    if len(coords) < 4:
        raise RuntimeError(f"{path}: too few vertices")
    return coords


def projected(coords: list[list[float]]) -> np.ndarray:
    a = np.asarray(coords)
    zone = int((float(a[:, 0].mean()) + 180) // 6) + 1
    xs, ys = transform("EPSG:4326", f"EPSG:{32600 + zone}", a[:, 0].tolist(), a[:, 1].tolist())
    return np.column_stack([xs, ys])


def densify(points: np.ndarray, step: float = 5.0) -> np.ndarray:
    out = []
    for start, end in zip(points[:-1], points[1:]):
        n = max(1, int(np.ceil(np.linalg.norm(end - start) / step)))
        out.extend(start + (end - start) * i / n for i in range(n))
    out.append(points[-1])
    return np.asarray(out)


def comparison(a: list[list[float]], b: list[list[float]]) -> dict:
    da, db = densify(projected(a)), densify(projected(b))
    distances = np.concatenate([cKDTree(db).query(da)[0], cKDTree(da).query(db)[0]])
    return {
        "median_m": float(np.median(distances)),
        "p95_m": float(np.percentile(distances, 95)),
        "p99_m": float(np.percentile(distances, 99)),
        "max_m": float(np.max(distances)),
        "mean_m": float(np.mean(distances)),
        "fraction_gt_10m": float(np.mean(distances > 10)),
        "fraction_gt_30m": float(np.mean(distances > 30)),
    }


def feature(row: dict, coords: list[list[float]], status: str, source: Path,
            stage: str, closure_repair_m: float = 0.0) -> dict:
    xy = projected(coords)
    length = float(np.linalg.norm(np.diff(xy, axis=0), axis=1).sum())
    return {"type": "Feature", "properties": {
        "scene_id": row["scene_id"], "lake": row["lake"], "season": row["season"],
        "l8_date": row["l8_date"], "s2_date": row["s2_date"], "status": status,
        "review_stage": stage, "source_kml": str(source), "source_kml_sha256": digest(source),
        "endpoint_closure_repair_m": closure_repair_m, "length_m": round(length, 3),
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds")},
        "geometry": {"type": "LineString", "coordinates": coords}}


def write_geojson(path: Path, item: dict) -> None:
    path.write_text(json.dumps({"type": "FeatureCollection", "features": [item]},
                               ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    with FORM.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        rows, fields = list(reader), reader.fieldnames
    if len(rows) != 6:
        raise RuntimeError("Expected six rows")
    if not BACKUP.exists():
        shutil.copy2(FORM, BACKUP)
    records = []
    for row in rows:
        scene = row["scene_id"]
        first_path = SOURCE / f"{scene}_shoreline_REVIEWED.kml"
        second_path = SOURCE / f"{scene}_shoreline_REVIEWED-1.kml"
        first = read_kml(first_path)
        second = read_kml(second_path)
        second_xy = projected(second)
        gap = float(np.linalg.norm(second_xy[0] - second_xy[-1]))
        repaired = 0.0
        if gap > 0.05:
            if gap > 60.0:
                raise RuntimeError(f"{scene}: second-pass endpoint gap {gap:.2f} m exceeds 60 m")
            second.append(list(second[0]))
            repaired = gap
        folder = PACK / scene
        write_geojson(folder / "shoreline_REVIEWER_A.geojson",
                      feature(row, first, "REVIEWER_A_COMPLETED", first_path, "first_manual_pass"))
        write_geojson(folder / "shoreline_REVIEWER_B.geojson",
                      feature(row, second, "REVIEWER_B_COMPLETED", second_path, "second_manual_pass", repaired))
        final_path = folder / "shoreline_REVIEWED.geojson"
        write_geojson(final_path, feature(row, second, "SEQUENTIAL_TWO_REVIEWER_CONSENSUS",
                                          second_path, "final_consensus", repaired))

        candidate = json.loads((folder / "shoreline_AI_ASSISTED_CANDIDATE.geojson").read_text(encoding="utf-8"))
        cand = candidate["features"][0]["geometry"]["coordinates"]
        status_a = "ACCEPTED" if len(first) == len(cand) and np.allclose(first, cand, atol=1e-10) else "MODIFIED"
        status_b = "ACCEPTED" if len(second) == len(first) and np.allclose(second, first, atol=1e-10) else "MODIFIED"
        row.update({
            "reviewer_A": "Reviewer A (anonymized)", "reviewer_A_status": status_a,
            "reviewer_A_notes": "First manual pass in Google Earth Pro",
            "reviewer_B": "Reviewer B (anonymized)", "reviewer_B_status": status_b,
            "reviewer_B_notes": "Second sequential check and final revision in Google Earth Pro",
            "consensus_status": "MODIFIED" if status_a == "MODIFIED" or status_b == "MODIFIED" else "ACCEPTED",
            "reviewed_file": f"{scene}/shoreline_REVIEWED.geojson",
        })
        records.append({"scene_id": scene, "reviewer_a_vertices": len(first),
                        "reviewer_b_vertices": len(second), "endpoint_gap_repaired_m": repaired,
                        **comparison(first, second), "final_sha256": digest(final_path)})

    with FORM.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    with (PACK / "two_pass_consensus_qc.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)
    (PACK / "two_pass_consensus_qc.json").write_text(json.dumps({
        "review_protocol": "sequential_two_reviewer_check",
        "independent_blinded_review": False,
        "final_geometry": "reviewer_B_second_pass",
        "records": records}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
