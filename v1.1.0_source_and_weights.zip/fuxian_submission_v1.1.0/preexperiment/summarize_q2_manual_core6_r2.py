"""Create paper-ready summaries for the from-scratch R2 human review."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "preexperiment/results/q2_manual_core6_evaluation_R2_from_scratch_v2"
SENS = ROOT / "preexperiment/results/q2_manual_core6_R2_manual_uncertainty"
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
FIG = Path(r"D:\Document\Codex资源\Q2_R2_manual_uncertainty_sensitivity.png")
MODELS = {
    "spatial_prior": "Spatial prior",
    "deep_prewitt": "Deep Prewitt",
    "parameter_matched_ordinary_conv": "Matched conv.",
}
METRICS = ["precision", "recall", "f1", "iou", "boundary_f1_30m",
           "boundary_f1_60m", "mean_symmetric_boundary_distance_m", "hd95_m"]


def main() -> None:
    data = json.loads((RESULT / "manual_core6_results.json").read_text(encoding="utf-8"))
    sens = json.loads((SENS / "manual_uncertainty_sensitivity.json").read_text(encoding="utf-8"))
    qc = json.loads((PACK / "manual_review_R2_geometry_qc.json").read_text(encoding="utf-8"))
    rows = []
    for key, label in MODELS.items():
        summary = data["summary"][key]["all_18_dates"]
        row = {"model": label, "n_dates": 6}
        for metric in METRICS:
            row[f"{metric}_mean"] = summary[metric]["mean"]
            row[f"{metric}_date_sd"] = summary[metric]["date_sd"]
        rows.append(row)
    with (RESULT / "Table_R2_from_scratch_model_metrics.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

    offsets = np.asarray(sens["offsets_m"], dtype=float)
    colors = {"boundary_f1_30m": "#6A5C95", "asd_reduction_m": "#D979AA"}
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.45), constrained_layout=True)
    labels = {
        "deep_prewitt_vs_spatial_prior": "vs spatial prior",
        "deep_prewitt_vs_parameter_matched_ordinary_conv": "vs matched conv.",
    }
    styles = {
        "deep_prewitt_vs_spatial_prior": ("o", "-"),
        "deep_prewitt_vs_parameter_matched_ordinary_conv": ("s", "--"),
    }
    for axis, effect, ylabel in zip(
        axes, ("boundary_f1_30m", "asd_reduction_m"),
        ("Boundary F1 gain", "ASD reduction (m)")
    ):
        for comparison in labels:
            row = next(r for r in sens["paired_effect_rows"]
                       if r["comparison"] == comparison and r["effect"] == effect)
            values = [row[f"offset_{int(o):+d}m"] for o in offsets]
            marker, line = styles[comparison]
            axis.plot(offsets, values, marker=marker, ls=line, lw=1.7, ms=5,
                      color=colors[effect] if comparison.endswith("spatial_prior") else "#8FA2D6",
                      label=labels[comparison])
        axis.axhline(0, color="#777A80", ls=":", lw=0.9)
        axis.set_xlabel("Manual shoreline perturbation (m)")
        axis.set_ylabel(ylabel)
        axis.grid(color="#E6E8EC", lw=0.7)
        axis.set_axisbelow(True)
        axis.legend(loc="lower left", frameon=False, fontsize=8)
    axes[0].text(-0.15, 1.04, "(a)", transform=axes[0].transAxes, fontweight="bold")
    axes[1].text(-0.15, 1.04, "(b)", transform=axes[1].transAxes, fontweight="bold")
    FIG.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG, dpi=350, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    deep = next(r for r in rows if r["model"] == "Deep Prewitt")
    p = data["paired_date_effects"]["deep_prewitt_vs_spatial_prior"]
    m = data["paired_date_effects"]["deep_prewitt_vs_parameter_matched_ordinary_conv"]
    sr = {f"{r['comparison']}:{r['effect']}": r for r in sens["paired_effect_rows"]}
    report = f"""# R2从零手绘岸线冻结评估

## 审核与几何质量

- 6期岸线均由同一名人工审核者依据同期Sentinel-2影像从零绘制，审核时未显示模型预测或上一轮人工岸线。
- 6个文件均为单一闭合外环，端点缺口均为0 m。
- 人工线相对修正自动候选线的对称距离中位数为{min(r['candidate_distance_median_m'] for r in qc['records']):.1f}—{max(r['candidate_distance_median_m'] for r in qc['records']):.1f} m，95百分位数为{min(r['candidate_distance_p95_m'] for r in qc['records']):.1f}—{max(r['candidate_distance_p95_m'] for r in qc['records']):.1f} m。这反映复杂湾岸的判读与概化差异，不能解释为现场测量误差。

## 名义岸线结果

- Deep Prewitt：F1={deep['f1_mean']:.4f} ± {deep['f1_date_sd']:.4f}，IoU={deep['iou_mean']:.4f} ± {deep['iou_date_sd']:.4f}，30 m Boundary F1={deep['boundary_f1_30m_mean']:.4f} ± {deep['boundary_f1_30m_date_sd']:.4f}，ASD={deep['mean_symmetric_boundary_distance_m_mean']:.2f} ± {deep['mean_symmetric_boundary_distance_m_date_sd']:.2f} m。
- 相对空间先验：Boundary F1平均提高{p['boundary_f1_30m']['mean_improvement']:.4f}（{p['boundary_f1_30m']['dates_improved']}/6期改善，95%日期自助区间{p['boundary_f1_30m']['bootstrap_95_ci'][0]:.4f}—{p['boundary_f1_30m']['bootstrap_95_ci'][1]:.4f}）；ASD平均降低{p['asd_reduction_m']['mean_improvement']:.2f} m（{p['asd_reduction_m']['dates_improved']}/6期改善）。
- 相对参数量匹配普通卷积：Boundary F1平均提高{m['boundary_f1_30m']['mean_improvement']:.4f}，ASD平均降低{m['asd_reduction_m']['mean_improvement']:.2f} m；名义岸线下均为6/6期改善。

## 人工误差敏感性

将手绘多边形在10 m Sentinel-2网格上分别向内、向外移动10 m和20 m后重复冻结评价：

- 相对空间先验的Boundary F1平均增益始终为{sr['deep_prewitt_vs_spatial_prior:boundary_f1_30m']['minimum_mean_across_perturbations']:.4f}—{sr['deep_prewitt_vs_spatial_prior:boundary_f1_30m']['maximum_mean_across_perturbations']:.4f}，ASD降低量始终为{sr['deep_prewitt_vs_spatial_prior:asd_reduction_m']['minimum_mean_across_perturbations']:.2f}—{sr['deep_prewitt_vs_spatial_prior:asd_reduction_m']['maximum_mean_across_perturbations']:.2f} m，方向在全部扰动下保持一致。
- 相对普通卷积的Boundary F1平均增益为{sr['deep_prewitt_vs_parameter_matched_ordinary_conv:boundary_f1_30m']['minimum_mean_across_perturbations']:.4f}—{sr['deep_prewitt_vs_parameter_matched_ordinary_conv:boundary_f1_30m']['maximum_mean_across_perturbations']:.4f}，ASD降低量为{sr['deep_prewitt_vs_parameter_matched_ordinary_conv:asd_reduction_m']['minimum_mean_across_perturbations']:.2f}—{sr['deep_prewitt_vs_parameter_matched_ordinary_conv:asd_reduction_m']['maximum_mean_across_perturbations']:.2f} m。平均方向稳定，但在向内20 m扰动时仅4/6期改善，显著性不稳定。

## 可写入论文的结论

从零手绘岸线支持Deep Prewitt相对空间先验的边缘改进，而且该平均改进在±20 m参考岸线扰动下保持同方向。相对参数量匹配普通卷积的名义结果更好，但日期一致性和显著性对岸线扰动敏感，因此仍应表述为有利趋势，不能宣称稳定显著优于普通卷积分支。由于只有一名人工审核者，±10/20 m分析只是确定性敏感性包络，并非人工误差的统计置信区间；同步RTK/GNSS岸线或独立第二审核者仍是绝对定位验证所需的更强证据。
"""
    (RESULT / "R2从零手绘岸线分析报告.md").write_text(report, encoding="utf-8")
    print(report)
    print(FIG)


if __name__ == "__main__":
    main()
