"""Build Sentinel-2 shoreline drafts for the frozen round-4 blind test."""
from __future__ import annotations
import json
from pathlib import Path
import build_wave1_reference_drafts as builder
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'preexperiment/results/round4_final_blind'
PAIRS=BASE/'evaluation_pairs.json'
OUT=BASE/'reference_drafts'
def main():
 pairs=json.loads(PAIRS.read_text(encoding='utf-8'))['selected']
 records=[{'l8_date':r['l8_date'],'s2_date':r['s2_date'],'calendar_gap_days':r['calendar_gap_days'],'split':'final_blind_test'} for r in pairs]
 builder.OUT=OUT; OUT.mkdir(parents=True,exist_ok=True)
 results=[builder.build_one(r) for r in records]
 payload={'dataset':'Fuxian Lake round-4 final blind-test reference drafts',
  'status':'AUTOMATIC_DRAFTS_REQUIRE_CONSERVATIVE_SCREENING','allow_training':False,
  'allow_model_selection':False,'allow_evaluation':False,'records':results,
  'totals':{'dates':len(results),'segments':sum(r['segment_count'] for r in results),
            'high_priority_segments':sum(r['high_priority_segments'] for r in results)}}
 (OUT/'draft_summary.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(payload['totals'],ensure_ascii=False,indent=2))
if __name__=='__main__': main()
