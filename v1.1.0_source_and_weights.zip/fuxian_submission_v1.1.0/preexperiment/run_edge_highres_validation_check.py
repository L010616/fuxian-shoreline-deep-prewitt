"""Single validation-only check: add one residual block only at e0/e1."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np, torch
from torch import nn
from torch.utils.data import DataLoader
import run_multidate_ablation_pilot as ablation
import run_round4_fusion_screen as screen
from run_multidate_ablation_pilot import MultiSceneDataset, seed_all, windows_for
from run_quick_model_pilot import ConvBNAct, DSConv
from run_edge_depth_validation_screen import DeeperEdgeDFANet, ResidualRefine

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'preexperiment/results/edge_highres_validation_check'
SEEDS=(20260913,20260929,20261017); MAX_EPOCHS=40; MIN_EPOCHS=20; PATIENCE=8

class HighResEdgeEncoder(nn.Module):
    def __init__(self):
        super().__init__(); w=(12,20,32,48)
        self.stem=ConvBNAct(4,w[0],3,2); self.r0=ResidualRefine(w[0],1)
        self.s1=DSConv(w[0],w[1],2); self.r1=ResidualRefine(w[1],1)
        self.s2=DSConv(w[1],w[2],2); self.s3=DSConv(w[2],w[3],2)
    def forward(self,x):
        a=self.r0(self.stem(x)); b=self.r1(self.s1(a)); c=self.s2(b); d=self.s3(c); return a,b,c,d

def main():
    OUT.mkdir(parents=True,exist_ok=True); path=OUT/'edge_highres_validation_results.json'
    if path.exists(): raise RuntimeError('High-resolution validation check already completed')
    scenes=screen.load_scenes(); train=[s for s in scenes if s['record']['split']=='train']; val=[s for s in scenes if s['record']['split']=='validation']
    norm=ablation.normalize_scenes(scenes); tw=windows_for(train); vw=windows_for(val)
    vl=DataLoader(MultiSceneDataset(val,vw),batch_size=12,shuffle=False,num_workers=0,pin_memory=True)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'); results={}
    for seed in SEEDS:
        seed_all(seed); tl=DataLoader(MultiSceneDataset(train,tw,augment=True),batch_size=12,shuffle=True,num_workers=0,pin_memory=True)
        model=DeeperEdgeDFANet(0); model.edge_encoder=HighResEdgeEncoder(); model=model.to(device)
        opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=1e-4); best=float('inf'); stale=0; hist=[]; ck=OUT/f'edge_highres_seed{seed}_best.pt'
        for epoch in range(1,MAX_EPOCHS+1):
            tr=screen.train_epoch(model,tl,device,opt,0.0); va=screen.validation_loss(model,vl,device,0.0); hist.append({'epoch':epoch,'train_loss':tr,'validation_loss':va})
            if va<best-1e-4: best=va; stale=0; torch.save({'model':model.state_dict(),'epoch':epoch},ck)
            else: stale+=1
            if epoch>=MIN_EPOCHS and stale>=PATIENCE: break
        state=torch.load(ck,map_location=device,weights_only=False); model.load_state_dict(state['model']); per,macro=screen.validate_full_scenes(model,val,device)
        results[str(seed)]={'best_epoch':state['epoch'],'best_validation_loss':best,'parameters':sum(p.numel() for p in model.parameters()),'per_date':per,'validation_macro':macro,'history':hist}
        print(seed,'epoch',state['epoch'],'BF1',round(macro['boundary_f1_30m'],5),'ASD',round(macro['mean_symmetric_boundary_distance_m'],2),flush=True)
        del model
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    keys=('iou','boundary_f1_30m','boundary_f1_60m','mean_symmetric_boundary_distance_m','hd95_m'); summary={'parameters':results[str(SEEDS[0])]['parameters']}
    for k in keys:
        a=np.array([results[str(s)]['validation_macro'][k] for s in SEEDS]); summary[k]={'mean':float(a.mean()),'sd':float(a.std(ddof=1)),'values':a.tolist()}
    payload={'status':'VALIDATION_ONLY_HIGH_RESOLUTION_EDGE_CHECK','final_blind_test_accessed':False,'configuration':'one residual DSConv at e0 and e1 only','seeds':SEEDS,'normalization':norm,'summary':summary,'results':results}
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__': main()
