"""Create publication-ready summaries for the extended convergence experiment."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'preexperiment/results/extended_training_round3'
LABELS={'dfanet':'Compact DFANet','prior':'Prior only','log':'Prior + LoG','prewitt':'Prior + Prewitt',
        'parallel':'Parallel model','unet_resnet18':'U-Net','deeplabv3plus_resnet18':'DeepLabV3+',
        'segformer_mit_b0':'SegFormer-B0'}
COLORS={'dfanet':'#6B7280','prior':'#2A9D8F','log':'#E9C46A','prewitt':'#F4A261','parallel':'#2878B5',
        'unet_resnet18':'#7A5195','deeplabv3plus_resnet18':'#EF5675','segformer_mit_b0':'#FFA600'}
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.linewidth':.8,'pdf.fonttype':42})

rows=[]
with (OUT/'training_log.csv').open(encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        r['seed']=int(r['seed']);r['epoch']=int(r['epoch']);r['val_loss']=float(r['val_loss']);rows.append(r)

fig,axes=plt.subplots(2,4,figsize=(11,5.2),sharex=True)
for ax,(name,label) in zip(axes.flat,LABELS.items()):
    for seed in sorted({r['seed'] for r in rows}):
        z=[r for r in rows if r['model']==name and r['seed']==seed]
        ax.plot([r['epoch'] for r in z],[r['val_loss'] for r in z],lw=1.0,alpha=.75,label=str(seed))
    ax.set_title(label,fontweight='bold');ax.set_yscale('log');ax.grid(alpha=.18,lw=.5)
    ax.spines[['top','right']].set_visible(False)
for ax in axes[-1]:ax.set_xlabel('Epoch')
for ax in axes[:,0]:ax.set_ylabel('Validation loss')
axes[0,0].legend(frameon=False,fontsize=7,ncol=1)
fig.tight_layout();fig.savefig(OUT/'extended_convergence_curves.png',dpi=300,bbox_inches='tight');fig.savefig(OUT/'extended_convergence_curves.pdf',bbox_inches='tight');plt.close(fig)

data=json.loads((OUT/'unified_boundary_support/results.json').read_text(encoding='utf8'))['summary']
names=list(LABELS); x=np.arange(len(names));bf=[data[n]['boundary_f1_30m']['mean'] for n in names];bfs=[data[n]['boundary_f1_30m']['std'] for n in names]
asd=[data[n]['mean_symmetric_boundary_distance_m']['mean'] for n in names];asds=[data[n]['mean_symmetric_boundary_distance_m']['std'] for n in names]
fig,axes=plt.subplots(1,2,figsize=(10.5,3.7)); colors=[COLORS[n] for n in names]
axes[0].bar(x,bf,yerr=bfs,capsize=3,color=colors,edgecolor='white',linewidth=.6);axes[0].set_ylim(.86,1);axes[0].set_ylabel('Boundary F1 at 30 m')
axes[1].bar(x,asd,yerr=asds,capsize=3,color=colors,edgecolor='white',linewidth=.6);axes[1].set_ylabel('ASD (m)')
for ax,letter in zip(axes,['A','B']):
    ax.set_xticks(x,[LABELS[n] for n in names],rotation=32,ha='right');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.18,lw=.5);ax.text(-.12,1.03,letter,transform=ax.transAxes,fontsize=15,fontweight='bold')
fig.tight_layout();fig.savefig(OUT/'extended_unified_boundary_comparison.png',dpi=300,bbox_inches='tight');fig.savefig(OUT/'extended_unified_boundary_comparison.pdf',bbox_inches='tight');plt.close(fig)

conv=json.loads((OUT/'convergence_summary.json').read_text(encoding='utf8'))
old=json.loads((ROOT/'preexperiment/results/revision_round2/convergence_audit.json').read_text(encoding='utf8'))
lines=['# Extended-training robustness report','',
'This analysis was specified after the original test results were known. Checkpoints were selected only by the two validation dates; the four test dates were used as a post-review robustness set.','',
'## Main findings','',
f'- The extended protocol completed {len(conv)} unique model–seed runs (8 architectures/ablations × 3 seeds), compared with 27 original runs because the identical parallel architecture is no longer counted twice.',
f'- Only {sum(r["best_at_epoch_50"] for r in conv)} of {len(conv)} best checkpoints occurred at epoch 50, compared with {sum(r["best_at_budget_end"] for r in old)} of {len(old)} at the original epoch-15 boundary.',
'- Best epochs for the parallel model were 42, 46 and 26.','- The prior-only variant retains the best mean boundary scores; the parallel edge model does not establish a stable advantage over it.','',
'## Unified target-support boundary results','',
'|Model|BF1 at 30 m|ASD (m)|HD95 (m)|','|---|---:|---:|---:|']
for n in names:
    z=data[n];lines.append(f'|{LABELS[n]}|{z["boundary_f1_30m"]["mean"]:.4f} ± {z["boundary_f1_30m"]["std"]:.4f}|{z["mean_symmetric_boundary_distance_m"]["mean"]:.2f} ± {z["mean_symmetric_boundary_distance_m"]["std"]:.2f}|{z["hd95_m"]["mean"]:.2f} ± {z["hd95_m"]["std"]:.2f}|')
lines += ['','The query boundary remains inside the eroded original 300 m shoreline evaluation region. Nearest-neighbour target boundaries may occur anywhere in the eroded valid image, preventing target clipping from creating artificial kilometre-scale distances.','',
'## Interpretation','',
'The extended runs resolve the clearest training-budget criticism, but they do not strengthen the claim that the edge branch consistently improves shoreline positioning. The results support a spatial-prior-centred method with edge responses as a scene-dependent auxiliary component. Because the test set had already been examined before this protocol was specified, these values are robustness evidence rather than a new untouched confirmatory test.']
(OUT/'extended_training_report.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('SUMMARY_COMPLETE')
