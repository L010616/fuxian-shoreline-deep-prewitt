"""Build prediction-blind Sentinel-2 shoreline drafts for the post-2019 set."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "data" / "edge_confirmatory_post2019"
MANIFEST = BASE / "selection_manifest.json"
OUT = ROOT / "preexperiment" / "results" / "edge_confirmatory_post2019" / "reference_drafts"


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest.get("status") != "POST2019_CONFIRMATORY_INPUTS_VALIDATED_AND_FROZEN":
        raise RuntimeError("Post-2019 inputs are not frozen")
    control = json.loads((ROOT / "preexperiment/results/parameter_matched_conv_control/parameter_matched_conv_validation.json").read_text(encoding="utf-8"))
    if control.get("status") != "PARAMETER_MATCHED_CONTROL_FROZEN_BEFORE_CONFIRMATORY_REFERENCE_CREATION":
        raise RuntimeError("Parameter-matched control was not frozen before reference creation")

    builder.DATA_ROOT = BASE / "analysis_ready"
    builder.OUT = OUT
    builder.L8_TEMPLATE = "Fuxian_edgeconfirm_post2019_L8_native_{l8_tag}.tif"
    builder.S2_TEMPLATE = "Fuxian_edgeconfirm_post2019_S2_{s2_tag}_for_{l8_tag}.tif"
    builder.MASK_TEMPLATE = "Fuxian_edgeconfirm_post2019_masks_native_{l8_tag}.tif"
    OUT.mkdir(parents=True, exist_ok=True)
    records = [{
        "l8_date": row["l8_date"], "s2_date": row["s2_date"],
        "calendar_gap_days": row["calendar_gap_days"],
        "split": "post2019_edge_confirmatory_test",
    } for row in manifest["records"]]
    results = [builder.build_one(record) for record in records]
    payload = {
        "dataset": "Fuxian Lake post-2019 edge-branch confirmatory reference drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_PREDICTION_BLIND_SCREENING",
        "allow_training": False, "allow_model_selection": False,
        "allow_threshold_tuning": False, "allow_evaluation": False,
        "model_predictions_opened": False, "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(r["segment_count"] for r in results),
            "high_priority_segments": sum(r["high_priority_segments"] for r in results),
        },
    }
    (OUT / "draft_summary.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload["totals"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
