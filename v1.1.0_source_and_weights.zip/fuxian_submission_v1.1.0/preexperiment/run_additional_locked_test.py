"""Evaluate frozen parallel checkpoints once on the two added dates."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
import torch

import run_multidate_ablation_pilot as ablation
from run_multidate_ablation_pilot import AblationDFANet, predict
from run_quick_model_pilot import metrics


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/ablation_3seed_v02_corrected_labels"
REF_DIR = ROOT / "preexperiment/results/formal_test_drafts_v03_additional/screened_reference_v01"
PAIR_MANIFEST = ROOT / "preexperiment/results/additional_test_pairs_v01.json"
OUT = ROOT / "preexperiment/results/locked_additional_test_v01"
SEEDS = [20260913, 20260929, 20261017]


def normalize(scenes, stats):
    for scene in scenes:
        scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
        for band, stat in enumerate(stats):
            scene["x"][band] = (np.clip(scene["x_raw"][band], stat["p01"], stat["p99"]) - stat["mean"]) / stat["std"]
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        with rasterio.open(REF_DIR / scene["tag"] / "exclusion_mask_L8_30m.tif") as src:
            scene["valid"] &= ~src.read(1).astype(bool)


def macro(rows):
    keys = ("precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m")
    return {key: float(np.mean([row[key] for row in rows.values()])) for key in keys}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    result_path = OUT / "additional_test_results.json"
    if result_path.exists():
        raise RuntimeError("Locked additional test already exists; refusing to rerun")
    manifest = json.loads((REF_DIR / "screened_reference_manifest.json").read_text(encoding="utf-8"))
    if manifest["status"] != "FROZEN_FOR_ONE_TIME_ADDITIONAL_EVALUATION" or not manifest["allow_one_time_evaluation"]:
        raise RuntimeError("Additional reference is not frozen")
    selected = json.loads(PAIR_MANIFEST.read_text(encoding="utf-8"))["selected"]
    dates = [{"l8_date": r["l8_date"], "s2_date": r["s2_date"], "split": "test"} for r in selected]
    ablation.DRAFTS = ROOT / "preexperiment/results/formal_test_drafts_v03_additional"
    scenes = [ablation.read_scene(record) for record in dates]
    config = json.loads((MODEL_DIR / "config.json").read_text(encoding="utf-8"))
    normalize(scenes, config["normalization"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results = {}
    for seed in SEEDS:
        model = AblationDFANet(prior=True, edge_mode="parallel").to(device)
        checkpoint = torch.load(MODEL_DIR / f"parallel_seed{seed}_best.pt", map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model"])
        per_date = {}
        for scene in scenes:
            probability = predict(model, scene, device)
            raw = metrics(probability, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
            constrained = probability.copy()
            constrained[scene["interior"]] = 1.0
            constrained[scene["roi"] & ~scene["shore"] & ~scene["interior"]] = 0.0
            constrained[~scene["roi"]] = 0.0
            common = metrics(constrained, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
            per_date[scene["record"]["l8_date"]] = {"raw": raw, "common_constraint": common}
        results[str(seed)] = {"checkpoint_epoch": int(checkpoint["epoch"]), "per_date": per_date,
                              "raw_macro": macro({d: r["raw"] for d, r in per_date.items()}),
                              "common_constraint_macro": macro({d: r["common_constraint"] for d, r in per_date.items()})}
        del model
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    summary = {}
    for mode in ("raw_macro", "common_constraint_macro"):
        summary[mode] = {}
        for name in results[str(SEEDS[0])][mode]:
            vals = np.asarray([results[str(seed)][mode][name] for seed in SEEDS])
            summary[mode][name] = {"mean": float(vals.mean()), "std": float(vals.std(ddof=1)), "values": vals.tolist()}
    output = {"status": "LOCKED_ADDITIONAL_TEST_OPENED_ONCE", "model": "frozen parallel LoG-Prewitt DFANet v0.2",
              "seeds": SEEDS, "dates": [r["l8_date"] for r in dates], "decision_threshold": 0.5,
              "reference_manifest": str((REF_DIR / "screened_reference_manifest.json").relative_to(ROOT)),
              "training_or_model_selection_after_test": False, "device": str(device),
              "results_by_seed": results, "summary": summary}
    result_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": output["status"], "summary": summary}, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
