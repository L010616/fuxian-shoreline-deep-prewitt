from __future__ import annotations
import csv,json
from pathlib import Path
import numpy as np
from scipy.stats import wilcoxon
import matplotlib.pyplot as plt
ROOT=Path(r'D:\Document\ChatGPT\水色'); BASE=ROOT/'preexperiment/results/round4_final_blind'
EVAL=BASE/'locked_evaluation/round4_final_blind_results.json'; REF=BASE/'screened_reference/screened_reference_manifest.json'; OUT=BASE/'paper_ready'; OUT.mkdir(parents=True,exist_ok=True)
d=json.loads(EVAL.read_text(encoding='utf-8')); refs=json.loads(REF.read_text(encoding='utf-8'))
labels={'dfanet':'DFANet','prior':'Boundary-constrained DFANet','log':'LoG-enhanced DFANet','prewitt':'Prewitt-enhanced DFANet','parallel_concat_ew0p0':'Parallel edge fusion','unet_resnet18':'U-Net','deeplabv3plus_resnet18':'DeepLabV3+','segformer_mit_b0':'SegFormer'}
order=list(labels)
# Model-level summary across seeds
rows=[]
for name in order:
 s=d['summary'][name]
 rows.append({'model':labels[name],'config_key':name,
  'precision_mean':s['precision']['mean'],'recall_mean':s['recall']['mean'],'f1_mean':s['f1']['mean'],
  'iou_mean':s['iou']['mean'],'iou_sd':s['iou']['std'],
  'boundary_f1_30m_mean':s['boundary_f1_30m']['mean'],'boundary_f1_30m_sd':s['boundary_f1_30m']['std'],
  'boundary_f1_60m_mean':s['boundary_f1_60m']['mean'],'boundary_f1_60m_sd':s['boundary_f1_60m']['std'],
  'asd_m_mean':s['mean_symmetric_boundary_distance_m']['mean'],'asd_m_sd':s['mean_symmetric_boundary_distance_m']['std'],
  'hd95_m_mean':s['hd95_m']['mean'],'hd95_m_sd':s['hd95_m']['std']})
with (OUT/'table_final_blind_model_comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# Per date, average and SD across seeds
coverage={r['l8_date']:r for r in refs['records']}; per=[]
for name in order:
 for date in d['dates']:
  vals=[d['results'][name][str(seed)]['per_date'][date] for seed in d['seeds']]
  row={'model':labels[name],'config_key':name,'date':date,
       'retained_reference_fraction':coverage[date]['retained_length_fraction'],
       'retained_reference_km':coverage[date]['retained_length_km'],
       'occupied_12_sectors':coverage[date]['spatial_coverage']['occupied_12_sectors']}
  for key in ['iou','boundary_f1_30m','boundary_f1_60m','mean_symmetric_boundary_distance_m','hd95_m']:
   a=np.array([v[key] for v in vals]); row[key+'_mean']=a.mean();row[key+'_sd']=a.std(ddof=1)
  per.append(row)
with (OUT/'table_final_blind_per_date.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=per[0]);w.writeheader();w.writerows(per)
# Paired date-level tests versus raw DFANet and between the two leading methods.
def date_means(name,key): return np.array([next(r[key+'_mean'] for r in per if r['config_key']==name and r['date']==dt) for dt in d['dates']])
pairs=[]
for cand,base in [('prior','dfanet'),('parallel_concat_ew0p0','dfanet'),('parallel_concat_ew0p0','prior')]:
 for key,direction in [('boundary_f1_30m','higher'),('mean_symmetric_boundary_distance_m','lower')]:
  a,b=date_means(cand,key),date_means(base,key); diff=a-b
  try:p=float(wilcoxon(a,b,alternative='two-sided').pvalue)
  except ValueError:p=1.0
  pairs.append({'candidate':labels[cand],'reference':labels[base],'metric':key,'n_dates':len(a),
                'mean_candidate':a.mean(),'mean_reference':b.mean(),'mean_paired_difference':diff.mean(),
                'improved_dates':int(((diff>0) if direction=='higher' else (diff<0)).sum()),
                'wilcoxon_two_sided_p':p,'interpretation':'descriptive_small_n'})
with (OUT/'paired_date_level_tests.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=pairs[0]);w.writeheader();w.writerows(pairs)
# Journal figure: consistent single-color bars.
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.linewidth':.8})
fig,axs=plt.subplots(1,2,figsize=(10,4.2),dpi=180); y=np.arange(len(rows)); color='#4C78A8'; labs=[r['model'] for r in rows]
axs[0].barh(y,[r['boundary_f1_30m_mean'] for r in rows],xerr=[r['boundary_f1_30m_sd'] for r in rows],color=color,edgecolor='black',linewidth=.45,capsize=2.5,error_kw={'elinewidth':.8});axs[0].set_yticks(y,labs);axs[0].invert_yaxis();axs[0].set_xlim(.78,.92);axs[0].set_xlabel('Boundary F1 (30 m)');axs[0].text(-.12,1.02,'(a)',transform=axs[0].transAxes,fontweight='bold',fontsize=12)
axs[1].barh(y,[r['asd_m_mean'] for r in rows],xerr=[r['asd_m_sd'] for r in rows],color=color,edgecolor='black',linewidth=.45,capsize=2.5,error_kw={'elinewidth':.8});axs[1].set_yticks(y,[]);axs[1].invert_yaxis();axs[1].set_xlabel('Average shoreline distance (m)');axs[1].text(-.12,1.02,'(b)',transform=axs[1].transAxes,fontweight='bold',fontsize=12)
for ax in axs: ax.grid(axis='x',color='#D9D9D9',linewidth=.55);ax.set_axisbelow(True);ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
fig.tight_layout(w_pad=1.1);fig.savefig(OUT/'figure_final_blind_model_comparison.png',dpi=600,bbox_inches='tight');fig.savefig(OUT/'figure_final_blind_model_comparison.tif',dpi=600,bbox_inches='tight',pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
# Concise report
prior=next(r for r in rows if r['config_key']=='prior'); parallel=next(r for r in rows if r['config_key']=='parallel_concat_ew0p0'); base=next(r for r in rows if r['config_key']=='dfanet')
report=f'''# Round-4 final blind-test report\n\nSix dates fixed before model selection were evaluated once after all configurations and checkpoints were frozen. All dates were retained; evaluation was limited to screened, jointly valid shoreline. Sentinel-2 derived references are not surveyed ground truth.\n\n- Parallel edge fusion: Boundary F1 = {parallel['boundary_f1_30m_mean']:.4f} ± {parallel['boundary_f1_30m_sd']:.4f}; ASD = {parallel['asd_m_mean']:.2f} ± {parallel['asd_m_sd']:.2f} m.\n- Boundary-constrained DFANet: Boundary F1 = {prior['boundary_f1_30m_mean']:.4f} ± {prior['boundary_f1_30m_sd']:.4f}; ASD = {prior['asd_m_mean']:.2f} ± {prior['asd_m_sd']:.2f} m.\n- Original DFANet: Boundary F1 = {base['boundary_f1_30m_mean']:.4f} ± {base['boundary_f1_30m_sd']:.4f}; ASD = {base['asd_m_mean']:.2f} ± {base['asd_m_sd']:.2f} m.\n\nThe parallel model improved Boundary F1 by {(parallel['boundary_f1_30m_mean']-base['boundary_f1_30m_mean'])*100:.2f} percentage points and reduced ASD by {base['asd_m_mean']-parallel['asd_m_mean']:.2f} m relative to DFANet. It also achieved the best blind-test boundary metrics, while the validation-selected boundary-constrained model was nearly tied in Boundary F1. Date-level Wilcoxon tests are descriptive because only six independent dates are available. No retraining, threshold tuning, or architecture changes are permitted after these results.\n'''
(OUT/'round4_final_blind_report.md').write_text(report,encoding='utf-8')
print(json.dumps({'outputs':[p.name for p in OUT.iterdir()],'paired_tests':pairs},ensure_ascii=False,indent=2))
