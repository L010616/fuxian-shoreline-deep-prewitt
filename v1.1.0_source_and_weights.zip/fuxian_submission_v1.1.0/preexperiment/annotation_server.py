"""Local-only annotation UI; validated, versioned saves in the current workspace."""
import argparse
import json
import math
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
from rasterio.warp import transform

ROOT=Path(__file__).resolve().parent/'results/native_20200102/annotation_workspace'


def validate(data):
    if not isinstance(data,dict) or data.get('crs')!='EPSG:32648' or data.get('scene_date')!='2020-01-02':
        raise ValueError('坐标系或影像日期不匹配。')
    author=str(data.get('author','')).strip()
    if not author or len(author)>100:raise ValueError('保存前请填写标注人姓名或代号。')
    segments=data.get('segments',[]);controls=data.get('control_points',[])
    if not isinstance(segments,list) or len(segments)>5000 or not isinstance(controls,list) or len(controls)>500:
        raise ValueError('要素数量或格式不正确。')
    def coord(p):
        if not isinstance(p,list) or len(p)!=2 or not all(isinstance(x,(float,int)) and math.isfinite(x) for x in p):
            raise ValueError('存在无效坐标。')
        if not (277000<=p[0]<=296000 and 2690000<=p[1]<=2729000):raise ValueError('坐标超出首景检查范围。')
    ids=set()
    for s in segments:
        sid=s.get('id');kind=s.get('kind');coords=s.get('coordinates',[])
        if not isinstance(sid,str) or sid in ids or kind not in ['shoreline','uncertainty']:raise ValueError('要素标识或类型不正确。')
        ids.add(sid)
        if not isinstance(coords,list) or not (2 if kind=='shoreline' else 4)<=len(coords)<=50000:raise ValueError('线段或多边形顶点数量不正确。')
        for p in coords:coord(p)
        if kind=='uncertainty' and coords[0]!=coords[-1]:raise ValueError('不确定区域多边形未闭合。')
        props=s.setdefault('properties',{})
        if not isinstance(props,dict):raise ValueError('属性格式不正确。')
        status=props.get('review_status','DRAFT')
        if status not in ['DRAFT','REVIEWED']:raise ValueError('审核状态不正确。')
        if status=='REVIEWED' and not str(props.get('reviewer','')).strip():raise ValueError('已复核要素需要填写复核人。')
        props.update(segment_id=sid,scene_date='2020-01-02',reference_date='2020-01-02',last_editor=author)
        props['approx_length_m']=sum(math.dist(a,b) for a,b in zip(coords,coords[1:]))
    for p in controls:
        coord(p.get('s2'));coord(p.get('l8'))
        p['distance_m']=math.dist(p['s2'],p['l8'])
        p['status']='MANUAL_POINT_PAIR_REQUIRES_ASSESSMENT'
    data.update(author=author,review_status='DRAFT_DATASET',allow_training=False,
                saved_utc=datetime.now(timezone.utc).isoformat())
    return data


def as_geojson(data):
    features=[]
    for s in data['segments']:
        x,y=zip(*s['coordinates']);lon,lat=transform('EPSG:32648','EPSG:4326',x,y)
        coords=[list(p) for p in zip(lon,lat)]
        geom=dict(type='LineString',coordinates=coords) if s['kind']=='shoreline' else dict(type='Polygon',coordinates=[coords])
        features.append(dict(type='Feature',properties={**s['properties'],'kind':s['kind']},geometry=geom))
    return dict(type='FeatureCollection',features=features)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
    def reply(self,status,data):
        body=json.dumps(data,ensure_ascii=False).encode('utf8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_GET(self):
        if urlsplit(self.path).path=='/state':
            p=ROOT/'saves/latest.json'
            if not p.exists():p=ROOT/'initial_draft.json'
            return self.reply(200,json.loads(p.read_text('utf8')))
        super().do_GET()
    def do_POST(self):
        if self.path!='/save':return self.reply(404,dict(error='未知操作。'))
        origin=self.headers.get('Origin')
        if origin and origin!=f'http://127.0.0.1:{self.server.server_port}':return self.reply(403,dict(error='只接受本地标注页面保存。'))
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=8_000_000:raise ValueError('保存内容大小不正确。')
            data=validate(json.loads(self.rfile.read(length)))
            output=ROOT/'saves';output.mkdir(exist_ok=True)
            stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
            payload=json.dumps(data,ensure_ascii=False,indent=2)
            (output/f'draft_{stamp}.json').write_text(payload,encoding='utf8')
            (output/f'draft_{stamp}.geojson').write_text(json.dumps(as_geojson(data),ensure_ascii=False),encoding='utf8')
            temp=output/'latest.tmp';temp.write_text(payload,encoding='utf8');temp.replace(output/'latest.json')
            return self.reply(200,dict(saved=str(output/f'draft_{stamp}.geojson'),utc=data['saved_utc'],
                                      reviewed=sum(s['properties'].get('review_status')=='REVIEWED' for s in data['segments']),
                                      allow_training=False))
        except (ValueError,TypeError,KeyError) as e:return self.reply(400,dict(error=str(e)))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=8765);args=parser.parse_args()
    print(f'Annotation workspace: http://127.0.0.1:{args.port}/index.html',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
