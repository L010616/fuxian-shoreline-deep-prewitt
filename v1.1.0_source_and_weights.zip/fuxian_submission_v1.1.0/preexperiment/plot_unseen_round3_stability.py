"""Plot date-wise stability of the frozen parallel model."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/unseen_test_round3"
DATA = BASE / "locked_evaluation/unseen_test_results.json"
OUT = BASE / "paper_ready"


def main() -> None:
    data = json.loads(DATA.read_text(encoding="utf-8"))
    dates = data["dates"]
    seeds = data["seeds"]
    result = data["results"]["parallel"]
    values = {}
    for metric in ("boundary_f1_30m", "mean_symmetric_boundary_distance_m"):
        matrix = np.asarray([[result[str(seed)]["per_date"][date]["raw"][metric]
                              for date in dates] for seed in seeds])
        values[metric] = (matrix.mean(axis=0), matrix.std(axis=0, ddof=1))

    plt.rcParams.update({"font.family": "Arial", "font.size": 10})
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.25))
    blue = "#2E86C1"
    x = np.arange(len(dates))
    panels = [
        ("boundary_f1_30m", "Boundary F1 (30 m)", "A"),
        ("mean_symmetric_boundary_distance_m", "Mean shoreline offset (m)", "B"),
    ]
    for ax, (metric, ylabel, letter) in zip(axes, panels):
        mean, sd = values[metric]
        ax.plot(x, mean, color=blue, marker="o", markersize=5.2, linewidth=2.2)
        ax.fill_between(x, mean - sd, mean + sd, color=blue, alpha=0.16, linewidth=0)
        ax.errorbar(x, mean, yerr=sd, color=blue, fmt="none", capsize=3, linewidth=1.1)
        ax.set_xticks(x, [d[2:] for d in dates], rotation=35, ha="right")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", color="#D9D9D9", linewidth=0.7, alpha=0.8)
        ax.spines[["top", "right"]].set_visible(False)
        ax.text(-0.13, 1.04, letter, transform=ax.transAxes, fontsize=15, fontweight="bold")
    axes[0].set_ylim(min(0.94, values["boundary_f1_30m"][0].min() - 0.015), 1.002)
    axes[1].set_ylim(bottom=0)
    fig.subplots_adjust(left=0.09, right=0.99, top=0.96, bottom=0.30, wspace=0.34)
    fig.supxlabel("Independent test date", y=0.03)
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "figure_unseen_date_stability.png", dpi=600, bbox_inches="tight")
    fig.savefig(OUT / "figure_unseen_date_stability.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
