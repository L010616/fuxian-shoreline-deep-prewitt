import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/standard_model_comparison_pilot"
d = json.loads((OUT / "metrics.json").read_text(encoding="utf-8"))
order = ["proposed_parallel", "unet_resnet18", "deeplabv3plus_resnet18", "segformer_mit_b0"]
labels = ["Proposed", "U-Net", "DeepLabV3+", "SegFormer"]
colors = ["#b14d55", "#3b82a0", "#6f9e4f", "#d49a35"]
panels = [
    ("IoU", [d[k]["macro"]["iou"] for k in order], True),
    ("Boundary F1 (30 m)", [d[k]["macro"]["boundary_f1_30m"] for k in order], True),
    ("Mean boundary distance (m)", [d[k]["macro"]["mean_symmetric_boundary_distance_m"] for k in order], False),
]
im=Image.new("RGB",(1800,650),"white"); draw=ImageDraw.Draw(im)
tf=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",30); f=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",22); sm=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",17)
draw.text((900,20),"Standard architecture comparison pilot (draft labels)",fill="#172738",font=tf,anchor="ma")
for pi,(title,vals,zoom) in enumerate(panels):
    x0=pi*600+62;y0=100;w=490;h=430;draw.text((x0+w/2,66),title,fill="#172738",font=f,anchor="ma")
    lo=min(vals)-.006 if zoom else 0;hi=max(vals)+.002 if zoom else max(vals)*1.15
    for t in range(5):
        y=y0+h-t*h/4;v=lo+t*(hi-lo)/4;draw.line((x0,y,x0+w,y),fill="#d9e0e5");draw.text((x0-8,y),f"{v:.3f}" if zoom else f"{v:.1f}",fill="#52616b",font=sm,anchor="rm")
    bw=82;gap=35
    for i,(lab,v,c) in enumerate(zip(labels,vals,colors)):
        left=x0+12+i*(bw+gap);top=y0+h-(v-lo)/(hi-lo)*h;draw.rectangle((left,top,left+bw,y0+h),fill=c);draw.text((left+bw/2,top-8),f"{v:.4f}" if zoom else f"{v:.2f}",fill="#172738",font=sm,anchor="mb");draw.text((left+bw/2,y0+h+14),lab,fill="#172738",font=sm,anchor="ma")
draw.text((900,625),"Six training dates; two independent validation dates; one seed; training from scratch",fill="#52616b",font=sm,anchor="ms")
im.save(OUT/"standard_model_comparison.png")
