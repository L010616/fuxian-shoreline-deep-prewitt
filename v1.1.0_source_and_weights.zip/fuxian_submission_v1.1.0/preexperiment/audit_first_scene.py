"""Audit actual exported observations and render data-driven pilot diagnostics.

All predictions remain unvalidated. The 2019 outline selects spatial review
windows only. Figures are rendered directly from raster arrays using Pillow.
"""
import hashlib
import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import reproject, transform_geom, Resampling
from rasterio.windows import Window, bounds as window_bounds
from rasterio.enums import ColorInterp
from affine import Affine
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'preexperiment/results/baselines_20200102'
FONT = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', 19)
SMALL = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', 15)


def metadata(path):
    with rasterio.open(path) as src:
        return dict(file=path.name, sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest(),
                    shape=list(src.shape), crs=str(src.crs), transform=list(src.transform)[:6],
                    bounds=list(src.bounds), bands=list(src.descriptions), dtypes=list(src.dtypes),
                    nodata=src.nodata, size_bytes=path.stat().st_size)


def rgb(data):
    # Fixed reflectance stretch shared across sensors; display only, not normalization for training.
    return (np.clip(data[[2, 1, 0]].transpose(1, 2, 0) / .20, 0, 1) ** .65 * 255).astype('uint8')


def boundary(mask, valid):
    return mask & ~ndi.binary_erosion(mask) & ndi.binary_erosion(valid)


def scalar_image(a, low, high, diverging=False):
    x = np.clip((np.nan_to_num(a, nan=low) - low) / (high - low), 0, 1)
    if diverging:
        c = np.stack([np.minimum(1, 2 * (1-x)), 1-abs(2*x-1), np.minimum(1, 2*x)], axis=-1)
    else:
        c = np.stack([x, x**.6, x**.3], axis=-1)
    out = (255*c).astype('uint8')
    out[~np.isfinite(a)] = [90, 90, 90]
    return out


def panel(arrays, titles, path, subtitle, width=430):
    ratio = arrays[0].shape[0] / arrays[0].shape[1]
    height = round(width * ratio)
    canvas = Image.new('RGB', (width*len(arrays), height+100), 'white')
    draw = ImageDraw.Draw(canvas)
    for i, (arr, title) in enumerate(zip(arrays, titles)):
        im = Image.fromarray(arr).resize((width, height), Image.Resampling.NEAREST)
        canvas.paste(im, (i*width, 42))
        draw.text((i*width+8, 10), title, fill='black', font=FONT)
    draw.text((10, height+50), subtitle, fill='black', font=SMALL)
    canvas.save(path)


def main():
    global OUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native',action='store_true',help='Audit the repaired native-grid first scene in a separate output directory.')
    args=parser.parse_args()
    paths = {k: ROOT/f'Fuxian_{k}_20200102.tif' for k in ['L8', 'S2', 'masks']}
    if args.native:
        OUT=ROOT/'preexperiment/results/native_20200102'
        paths.update({k:ROOT/f'Fuxian_{k}_native_20200102.tif' for k in ['L8','masks']})
    OUT.mkdir(parents=True,exist_ok=True)
    with rasterio.open(paths['L8']) as src:
        l8 = src.read(); profile = src.profile.copy(); trans = src.transform; crs = src.crs
    with rasterio.open(paths['masks']) as src:
        masks = src.read()
        mask_profile = src.profile.copy()
        mask_names=src.descriptions
        source_alpha=ColorInterp.alpha in src.colorinterp
        assert src.crs == crs and src.transform == trans and src.shape == l8.shape[1:]
    with rasterio.open(paths['S2']) as src:
        s2 = src.read(); s2trans = src.transform
        assert src.crs == crs
    assert tuple(metadata(paths['L8'])['bands']) == ('B2','B3','B4','B5','B6','B7','valid')
    assert set(np.unique(masks)) <= {0, 1}
    zone, valid, svalid, joint = masks[:4] == 1
    assert np.array_equal(valid, l8[6] == 1)
    assert np.array_equal(joint, valid & svalid)
    # Preserve the original export; remove accidental RGBA interpretation in a working copy.
    mask_profile.update(photometric='MINISBLACK', compress='deflate')
    with rasterio.open(OUT/'masks_explicit_bands.tif','w',**mask_profile) as dst:
        dst.write(masks)
        dst.descriptions=mask_names
        dst.colorinterp=(ColorInterp.gray,)+(ColorInterp.undefined,)*(masks.shape[0]-1)
    shape = valid.shape
    aligned = np.full((6, *shape), np.nan, dtype='float32')
    # Cloud-masked area averaging is for cross-sensor diagnostics only.
    for i in range(6):
        a = np.where(s2[7] == 1, s2[i]*.0001, np.nan).astype('float32')
        reproject(a, aligned[i], src_transform=s2trans, src_crs=crs, src_nodata=np.nan,
                  dst_transform=trans, dst_crs=crs, dst_nodata=np.nan, resampling=Resampling.average)
    target = profile.copy()
    target.update(count=6, dtype='float32', nodata=np.nan, compress='deflate')
    with rasterio.open(OUT/'s2_30m_diagnostic.tif', 'w', **target) as dst:
        dst.write(aligned); dst.descriptions = ('B2','B3','B4','B8','B11','B12')
    svalid_nearest = np.zeros(shape, dtype='uint8')
    reproject(s2[7], svalid_nearest, src_transform=s2trans, src_crs=crs,
              dst_transform=trans, dst_crs=crs, resampling=Resampling.nearest)
    with rasterio.open(OUT/'indices.tif') as src: indices = src.read()
    with rasterio.open(OUT/'mndwi_otsu.tif') as src: mp = src.read(1)
    with rasterio.open(OUT/'awei_zero.tif') as src: ap = src.read(1)
    with rasterio.open(OUT/'edge_responses.tif') as src: edges = src.read()
    data = json.loads((ROOT/'preexperiment/results/screening_outline_and_bounds.geojson').read_text('utf8'))
    outline = next(f for f in data['features'] if f['properties']['role']=='screening_outline_2019_not_truth')
    geom = transform_geom('EPSG:4326', crs, outline['geometry'])
    prior = rasterize([(geom, 1)], out_shape=shape, transform=trans).astype(bool)
    prior_edge = boundary(prior, np.ones(shape, bool))
    sample = indices[0, zone & valid & np.isfinite(indices[0])]
    bounded = sample[(sample >= -1) & (sample <= 1)]
    sensitivity_threshold = float(threshold_otsu(bounded))
    threshold = json.loads((OUT/'processing.json').read_text())['mndwi_threshold']
    common = zone & joint & (mp != 255) & (ap != 255)
    disagreement = common & (mp != ap)
    audit = dict(date='2020-01-02', files={k:metadata(p) for k,p in paths.items()},
        grid_checks=dict(l8_masks_exact_match=True,
                         s2_mask_nearest_mismatches=int(np.count_nonzero(svalid_nearest.astype(bool)!=svalid)),
                         s2_mask_nearest_shore_mismatches=int(np.count_nonzero((svalid_nearest.astype(bool)!=svalid)&zone)),
                         source_masks_alpha_tag=source_alpha,
                         note='S2 export extent differs at outer edges; align by geotransform, never array index.'),
        counts=dict(shore_pixels=int(zone.sum()), shore_area_km2=float(zone.sum()*.0009),
                    l8_valid_shore=int((zone&valid).sum()), s2_valid_shore=int((zone&svalid).sum()),
                    joint_valid_shore=int((zone&joint).sum()), common_baseline_pixels=int(common.sum()),
                    baseline_disagreement_pixels=int(disagreement.sum()),
                    baseline_disagreement_fraction=float(disagreement.sum()/common.sum()),
                    edge_valid_shore=int((zone & np.isfinite(edges).all(axis=0)).sum())),
        qa_fractions=dict(l8=float(valid[zone].mean()),s2=float(svalid[zone].mean()),joint=float(joint[zone].mean())),
        reflectance_percentiles=dict(percentiles=[0,1,50,99,100],
            values=np.percentile(l8[:6, zone&valid], [0,1,50,99,100], axis=1).tolist(),
            note='Rows are percentiles, columns are B2-B7; negative SR retained.'),
        mndwi=dict(percentiles=np.percentile(sample,[0,.1,1,50,99,99.9,100]).tolist(),
                   outside_unit_interval=int(((sample < -1)|(sample > 1)).sum()),
                   primary_otsu_threshold=threshold, bounded_sample_sensitivity_threshold=sensitivity_threshold,
                   sensitivity_changed_shore_pixels=int(((sample>threshold)!=(sample>sensitivity_threshold)).sum()),
                   note='Sensitivity only: original threshold remains primary; no reference accuracy claimed.'),
        label_status='NOT_CREATED', registration='NOT_VERIFIED', allow_training=False)
    (OUT/'audit.json').write_text(json.dumps(audit, indent=2), encoding='utf8')
    lr = rgb(l8[:6]); sr = rgb(s2[:6]*.0001)
    qa = lr.copy(); qa[~valid]=[210,55,180]; qa[zone&~joint]=[255,150,0]
    overlay = lr.copy()
    overlay[boundary(mp==1, valid)]=[0,255,255]
    overlay[boundary(ap==1, valid)]=[255,235,0]
    overlay[~valid]=[90,90,90]
    panel([lr,sr,qa,overlay], ['L8 RGB / 30 m','S2 RGB / 10 m','QA diagnostic','Unvalidated predictions'],
          OUT/'overview.png','2020-01-02 | Orange: shore lacks joint QA; magenta: L8 invalid | Cyan: MNDWI; yellow: AWEI',width=430)
    ep = np.hypot(edges[0],edges[1]); lg = edges[3]
    panel([scalar_image(indices[0],-1,1,True), scalar_image(indices[1],-.3,.3,True),
           scalar_image(ep,0,float(np.nanpercentile(ep[zone],99))),
           scalar_image(lg,-.03,.03,True)],
          ['MNDWI [-1, 1]','AWEI_sh [-0.3, 0.3]','Prewitt NIR magnitude','LoG NIR sigma=2'],
          OUT/'operators.png','Clipped display ranges only; raw signed responses retained in GeoTIFF. Gray: invalid.',width=400)
    # Spatial review windows use the pre-period outline, not model error or future labels.
    rr, cc = np.where(prior_edge); cy,cx = ndi.center_of_mass(prior)
    angles = np.arctan2((rr-cy)/(rr.max()-rr.min()), (cc-cx)/(cc.max()-cc.min()))
    patch_records=[]; features=[]
    review_dir = OUT/'review_windows'; review_dir.mkdir(exist_ok=True)
    for name, angle in [('E',0),('SE',45),('S',90),('SW',135),('W',180),('NW',-135),('N',-90),('NE',-45)]:
        delta=np.abs(np.angle(np.exp(1j*(angles-np.deg2rad(angle)))))
        # One L8-pixel margin keeps windows inside both differently rounded export extents.
        n=int(np.argmin(delta)); r=int(np.clip(rr[n]-64,1,shape[0]-129)); c=int(np.clip(cc[n]-64,1,shape[1]-129))
        win=Window(c,r,128,128); left,bottom,right,top=window_bounds(win,trans)
        # Native L8 edges can be offset 5 m from the 10 m S2 grid. Display on
        # the exact same geographic extent rather than rounding array indices.
        display=np.zeros((3,384,384),dtype='float32')
        for b in range(3):
            reproject(s2[b].astype('float32')*.0001,display[b],src_transform=s2trans,src_crs=crs,
                      dst_transform=Affine(10,0,left,0,-10,top),dst_crs=crs,resampling=Resampling.average)
        lpatch=lr[r:r+128,c:c+128]; spatch=rgb(display)
        Image.fromarray(lpatch).resize((384,384),Image.Resampling.NEAREST).save(review_dir/f'{name}_L8.png')
        Image.fromarray(spatch).save(review_dir/f'{name}_S2.png')
        panel([lpatch,spatch,overlay[r:r+128,c:c+128]],
              [f'{name} / L8',f'{name} / S2',f'{name} / baselines'],review_dir/f'{name}_diagnostic.png',
              '3.84 km square | Cyan: MNDWI; yellow: AWEI | Predictions are not reference labels.',width=384)
        rec=dict(id=name,row=r,col=c,width=128,height=128,bounds_utm=[left,bottom,right,top],
                 joint_qa_fraction=float(joint[r:r+128,c:c+128].mean()),label_status='NOT_CREATED')
        patch_records.append(rec)
        box=dict(type='Polygon',coordinates=[[[left,bottom],[right,bottom],[right,top],[left,top],[left,bottom]]])
        features.append(dict(type='Feature',properties=rec,geometry=transform_geom(crs,'EPSG:4326',box)))
    (OUT/'review_windows.geojson').write_text(json.dumps(dict(type='FeatureCollection',features=features)),encoding='utf8')
    (OUT/'review_windows.json').write_text(json.dumps(patch_records,indent=2),encoding='utf8')
    # Reference-only gallery intentionally contains no prediction layers.
    cards=''.join(f'<section><h2>{p["id"]} 岸段</h2><div><figure><img src="review_windows/{p["id"]}_L8.png"><figcaption>Landsat 8，30 m</figcaption></figure><figure><img src="review_windows/{p["id"]}_S2.png"><figcaption>Sentinel-2，10 m</figcaption></figure></div><p>UTM 范围：{p["bounds_utm"]}；窗口共同 QA：{p["joint_qa_fraction"]:.2%}（窗口面积比例）。标注状态：未创建。</p></section>' for p in patch_records)
    html='''<!doctype html><html lang="zh"><meta charset="utf-8"><title>抚仙湖首景参考判读</title><style>body{max-width:1050px;margin:30px auto;font:17px system-ui;background:#f4f6f8;color:#162737}section{background:white;padding:20px;margin:24px 0}section div{display:flex;flex-wrap:wrap}figure{margin:10px}img{width:384px;image-rendering:pixelated}p{line-height:1.7}</style><h1>2020-01-02 抚仙湖参考判读包</h1><p>两景相差约 16 分钟。每个窗口 3.84 × 3.84 km，北向上；按地理坐标匹配，采用固定反射率显示拉伸。窗口由 2019 年筛选轮廓按方位选择，可能重叠，不是独立样本。</p><p>本页面只展示原始观测，不包含预测结果。影像未完成配准验证，也未创建人工标签。不得将 QA 有效率作为岸线识别精度。云、阴影、混合像元与模糊水陆过渡需记录为不确定区域。</p>'''+cards+'</html>'
    html=html.replace('按地理坐标匹配，采用固定反射率显示拉伸。','按地理坐标匹配，采用固定反射率显示拉伸。S2 预览按窗口范围面积重采样到 10 m 显示网格；正式标注应使用原始 S2 GeoTIFF，不能在这些 PNG 上推断亚像元位置。')
    (OUT/'reference_review.html').write_text(html,encoding='utf8')
    print(json.dumps({k:audit[k] for k in ['grid_checks','counts','qa_fractions','mndwi']},indent=2))


if __name__ == '__main__':
    main()
