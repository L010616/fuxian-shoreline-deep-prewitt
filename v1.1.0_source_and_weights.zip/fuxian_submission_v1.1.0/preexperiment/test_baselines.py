"""Synthetic correctness checks, not empirical lake accuracy evaluation."""
import unittest
import json
import subprocess
import sys
import tempfile
from pathlib import Path
import numpy as np
import rasterio
from rasterio.enums import ColorInterp
from rasterio.transform import from_origin
from prepare_baselines import calculate


class BaselineChecks(unittest.TestCase):
    def setUp(self):
        self.bands=np.full((6,64,64),0.2,dtype=np.float32)
        self.bands[3:, :, :32]=0.02
        self.valid=np.ones((64,64),dtype=bool)
        self.zone=np.ones((64,64),dtype=bool)

    def test_separable_water_and_land(self):
        out=calculate(self.bands,self.valid,self.zone)
        self.assertTrue((out['mndwi_prediction'][:,:32]==1).all())
        self.assertTrue((out['mndwi_prediction'][:,32:]==0).all())
        self.assertEqual(out['edges'].shape,(8,64,64))

    def test_missing_pixels_do_not_create_valid_edges(self):
        self.valid[30,30]=False
        out=calculate(self.bands,self.valid,self.zone)
        self.assertEqual(out['mndwi_prediction'][30,30],255)
        self.assertTrue(np.isnan(out['edges'][:,22:39,22:39]).all())
        self.assertTrue(np.isfinite(out['edges'][:,45,45]).all())

    def test_empty_calibration_zone_rejected(self):
        with self.assertRaises(ValueError):
            calculate(self.bands,self.valid,np.zeros_like(self.zone))

    def test_rgba_mask_does_not_restrict_l8_calibration_to_s2_validity(self):
        # Regression from the real four-band GEE export: joint_valid was tagged alpha.
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            profile=dict(driver='GTiff',height=64,width=64,crs='EPSG:32648',
                         transform=from_origin(280000,2720000,30,30))
            with rasterio.open(root/'image.tif','w',count=7,dtype='float32',**profile) as s:
                s.write(np.concatenate([self.bands,self.valid[None].astype('float32')]))
            masks=np.ones((4,64,64),dtype='uint8'); masks[2:,:,:32]=0
            with rasterio.open(root/'masks.tif','w',count=4,dtype='uint8',**profile) as s:
                s.write(masks)
                s.colorinterp=(ColorInterp.red,ColorInterp.green,ColorInterp.blue,ColorInterp.alpha)
            with rasterio.open(root/'masks.tif') as s:
                self.assertEqual(int((s.read_masks(1)>0).sum()),2048)
            subprocess.run([sys.executable,str(Path(__file__).with_name('prepare_baselines.py')),
                            str(root/'image.tif'),'--shore',str(root/'masks.tif'),
                            '--output',str(root/'output')],check=True,capture_output=True)
            result=json.loads((root/'output/processing.json').read_text('utf8'))
            self.assertEqual(result['calibration_pixels'],4096)


if __name__ == '__main__':
    unittest.main()
