"""Create the GEE export script for the four test dates after model freeze."""
from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"
SOURCE = ROOT / "preexperiment/gee/06_formal_dataset_exports.js"
OUTPUT = ROOT / "preexperiment/gee/07_frozen_test_dataset_exports.js"


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = [record for record in manifest["records"] if record["split"] == "test"]
    expected = ["2024-02-14", "2024-05-04", "2025-05-07", "2025-12-01"]
    assert [record["l8_date"] for record in records] == expected

    script = SOURCE.read_text(encoding="utf-8")
    rows = json.dumps(records, ensure_ascii=False, separators=(",", ":"))
    script = re.sub(
        r"^// Fuxian Lake.*?^var seed =",
        "// Fuxian Lake exports for the four TEST dates after model freeze.\n"
        "// Model, loss, threshold, spatial constraint and seeds were frozen on 2026-09-13.\n"
        "// This script only exports inputs and masks; it does not compute test accuracy.\n"
        f"var records = {rows};\nvar wave1 = [0, 1];\nvar wave2 = [2, 3];\nvar seed =",
        script,
        count=1,
        flags=re.MULTILINE | re.DOTALL,
    )
    script = script.replace("folder:'Fuxian_formal_v1'", "folder:'Fuxian_frozen_test_v1'")
    script = script.replace("Fuxian formal dataset exports", "Fuxian frozen TEST exports")
    script = script.replace(
        "Only train/validation dates. Test dates remain sealed.",
        "Four test dates opened only after the model-freeze decision.",
    )
    script = script.replace("Prepare wave 1: 9 export tasks", "Prepare TEST wave 1: 6 export tasks")
    script = script.replace("Wave 1 prepared: 3 dates, 9 Drive tasks. Start them in Tasks.",
                            "TEST wave 1 prepared: 2 dates, 6 Drive tasks. Start them in Tasks.")
    script = script.replace("Prepare wave 2: 12 export tasks", "Prepare TEST wave 2: 6 export tasks")
    script = script.replace("Wave 2 prepared: 4 dates, 12 Drive tasks. Start them after wave 1.",
                            "TEST wave 2 prepared: 2 dates, 6 Drive tasks. Start them after wave 1.")
    script = script.replace(
        "Exports use the verified fixed grids from 2020-01-02. No test task is created.",
        "Exports use the verified fixed grids. Do not inspect model accuracy until final labels are frozen.",
    )
    OUTPUT.write_text(script, encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "test_dates": expected, "tasks": 12}, ensure_ascii=False))


if __name__ == "__main__":
    main()
