"""Build automatic shoreline drafts for seven added train/validation dates."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = ROOT / "preexperiment/results/round4_protocol/round4_split_protocol.json"
OUT = ROOT / "preexperiment/results/round4_references/added_drafts"


def main() -> int:
    protocol = json.loads(PROTOCOL.read_text(encoding="utf-8"))
    records = protocol["added_export_records"]
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    results = [builder.build_one(r) for r in records]
    summary = {
        "dataset": "Round-4 added train-validation automatic drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_REVIEW",
        "allow_training": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(r["segment_count"] for r in results),
            "high_priority_segments": sum(r["high_priority_segments"] for r in results),
        },
    }
    (OUT / "draft_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary["totals"], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
