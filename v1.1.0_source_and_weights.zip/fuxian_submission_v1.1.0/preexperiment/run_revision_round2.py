"""Post-review diagnostics and validation-only buffer sensitivity. Original tests stay frozen."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import csv, json, sys, time, math, hashlib
from pathlib import Path
import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_geom
from scipy.ndimage import binary_erosion, distance_transform_edt
import torch
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import run_multidate_ablation_pilot as a
import run_locked_test_model_comparison as locked
from run_quick_model_pilot import metrics

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'preexperiment/results/revision_round2'
OUT.mkdir(parents=True,exist_ok=True)
SEEDS=locked.SEEDS
plt.rcParams.update({'font.family':'Arial','font.size':10,'pdf.fonttype':42})
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def savefig(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=300,bbox_inches='tight')
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight'); plt.close(fig)

def audit_existing():
    ab=read(ROOT/'preexperiment/results/locked_four_date_ablation_v01/ablation_test_results.json')
    comp=read(locked.OUT/'model_comparison_test_results.json')
    keys=['iou','boundary_f1_30m','mean_symmetric_boundary_distance_m']
    rows=[]
    for name in ['dfanet','prior','parallel']:
        for mode in ['raw_macro','common_constraint_macro']:
            rows.append(dict(model=name,mode=mode,**{k:ab['summary'][name][mode][k] for k in keys}))
    dump('constraint_factorial.json',rows)
    convergence=[]
    for folder in [locked.MODEL_DIR,ROOT/'preexperiment/results/ablation_3seed_v02_corrected_labels']:
        saved=read(folder/'results_by_seed.json')
        with (folder/'training_log.csv').open(encoding='utf-8-sig') as f: logs=list(csv.DictReader(f))
        for seed, models in saved.items():
            for model,r in models.items():
                ls=[x for x in logs if x['seed']==seed and x['model']==model]
                if not ls: continue
                convergence.append(dict(source=folder.name,seed=int(seed),model=model,best_epoch=r['best_epoch'],
                    final_epoch=max(int(x['epoch']) for x in ls),best_val_loss=r['best_val_loss'],
                    final_val_loss=float(ls[-1]['val_loss']),best_at_budget_end=r['best_epoch']==15))
    dump('convergence_audit.json',convergence)
    paired=[]
    for date in comp['dates']:
        for other in ['unet_resnet18','deeplabv3plus_resnet18','segformer_mit_b0']:
            d={k:float(np.mean([comp['results_by_model_and_seed']['proposed_parallel'][str(s)]['per_date'][date]['raw'][k]-comp['results_by_model_and_seed'][other][str(s)]['per_date'][date]['raw'][k] for s in SEEDS])) for k in keys}
            paired.append(dict(date=date,comparison=other,delta_proposed_minus_other=d))
    dump('paired_date_differences.json',paired)
    fig,axs=plt.subplots(1,2,figsize=(9,3.3))
    for ax,k,title in zip(axs,keys[1:],['Boundary F1 at 30 m','ASD (m)']):
        for j,mode in enumerate(['raw_macro','common_constraint_macro']):
            vals=[ab['summary'][n][mode][k]['mean'] for n in ['dfanet','prior','parallel']]
            sd=[ab['summary'][n][mode][k]['std'] for n in ['dfanet','prior','parallel']]
            ax.bar(np.arange(3)+(j-.5)*.34,vals,.34,yerr=sd,capsize=3,color=['#439FE5','#B3D8F2'][j],label=['Raw','Hard constraint'][j])
        ax.set_xticks(range(3),['Base','Prior','Full']); ax.set_ylabel(title); ax.spines[['top','right']].set_visible(False)
        ax.legend(frameon=False,fontsize=8)
    axs[0].set_ylim(.95,1); fig.tight_layout(); savefig(fig,'supplement_constraint_comparison')
    print('Existing-result audit complete',flush=True)

def diagnostic():
    cfg=read(locked.MODEL_DIR/'config.json')
    frozen=read(locked.OUT/'model_comparison_test_results.json')
    scenes=locked.load_scenes(); locked.normalize_and_exclude(scenes,cfg['normalization'])
    device=torch.device('cuda'); rows=[]; sensitivity=[]; maxima=[]
    for seed in SEEDS:
        a.seed_all(seed)
        model=a.AblationDFANet(True,'parallel').to(device)
        cp=locked.MODEL_DIR/f'proposed_parallel_seed{seed}_best.pt'
        model.load_state_dict(torch.load(cp,map_location=device,weights_only=False)['model'])
        for scene in scenes:
            date=scene['record']['l8_date']; tag=scene['tag']
            prob=a.predict(model,scene,device); pred=prob>=.5; truth=scene['y']
            np.savez_compressed(OUT/f'probability_{tag}_seed{seed}.npz',probability=prob)
            region=scene['valid']&scene['shore']; core=binary_erosion(region,iterations=3)
            pb=(pred^binary_erosion(pred))&core; tb=(truth^binary_erosion(truth))&core
            td,ti=distance_transform_edt(~tb,return_indices=True); pd,pi=distance_transform_edt(~pb,return_indices=True)
            ds=[td[pb]*30,pd[tb]*30]; asd=float(np.mean([x.mean() for x in ds]))
            expected=frozen['results_by_model_and_seed']['proposed_parallel'][str(seed)]['per_date'][date]['raw']['mean_symmetric_boundary_distance_m']
            assert abs(asd-expected)<.01,(date,asd,expected)
            for direction,d in zip(['prediction_to_reference','reference_to_prediction'],ds):
                rows.append(dict(date=date,seed=seed,direction=direction,n=len(d),mean_m=float(d.mean()),
                    quantiles_m={str(q):float(np.percentile(d,q)) for q in [50,75,90,95,99,100]},
                    percent_over_60=float(np.mean(d>60)*100),percent_over_300=float(np.mean(d>300)*100),
                    contribution_over_60_to_directional_mean_pct=float(d[d>60].sum()/max(d.sum(),1e-9)*100)))
            sensitivity.append(dict(date=date,seed=seed,kind='published_support',asd_m=asd))
            # Alternative diagnostic: query remains fixed, nearest targets include safe valid boundaries
            # outside the 300-m band, never boundary pixels next to invalid observations.
            safe=binary_erosion(scene['valid'],iterations=1)
            fullpb=(pred^binary_erosion(pred))&safe; fulltb=(truth^binary_erosion(truth))&safe
            alt=[distance_transform_edt(~fulltb)[pb]*30,distance_transform_edt(~fullpb)[tb]*30]
            sensitivity.append(dict(date=date,seed=seed,kind='expanded_valid_target_support',asd_m=float(np.mean([d.mean() for d in alt]))))
            if date=='2025-12-01' and seed==SEEDS[0]:
                coords=np.argwhere(tb); order=np.argsort(ds[1])[-10:][::-1]
                for index in order:
                    r,c=coords[index]; x,y=rasterio.transform.xy(scene['profile']['transform'],int(r),int(c))
                    maxima.append(dict(direction='reference_to_prediction',row=int(r),col=int(c),distance_m=float(ds[1][index]),easting=x,northing=y,crs=str(scene['profile']['crs'])))
                fig,axs=plt.subplots(1,2,figsize=(8,6.2))
                rgb=np.moveaxis(scene['x_raw'][[2,1,0]],0,-1).copy()
                for k in range(3):
                    lo,hi=np.percentile(rgb[:,:,k][scene['valid']],[2,98]);rgb[:,:,k]=np.clip((rgb[:,:,k]-lo)/(hi-lo),0,1)
                for ax,bound,d,title in zip(axs,[pb,tb],ds,['Prediction to reference','Reference to prediction']):
                    ax.imshow(rgb); rr,cc=np.where(bound)
                    sc=ax.scatter(cc,rr,c=d,s=3,cmap='viridis',vmin=0,vmax=300,rasterized=True)
                    ax.set_title(title,fontsize=10); ax.set_axis_off()
                fig.colorbar(sc,ax=list(axs),label='Distance (m; values >300 m saturated)',fraction=.028,pad=.025)
                savefig(fig,'supplement_20251201_error_map')
                fig,ax=plt.subplots(figsize=(6.5,3.6))
                for d,label in zip(ds,['Prediction to reference','Reference to prediction']):
                    x=np.sort(d);ax.plot(x,np.arange(1,len(x)+1)/len(x)*100,label=label,lw=1.8)
                ax.set_xscale('symlog',linthresh=30);ax.set_xlabel('Nearest boundary distance (m)');ax.set_ylabel('Cumulative fraction (%)')
                ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False);fig.tight_layout();savefig(fig,'supplement_20251201_distance_ecdf')
            print(f'Diagnostic {date}, seed {seed}: ASD={asd:.3f}',flush=True)
        del model;torch.cuda.empty_cache()
    dump('boundary_directional_diagnostics.json',rows);dump('boundary_support_sensitivity.json',sensitivity);dump('worst_reference_points_20251201.json',maxima)

def buffer_sensitivity():
    a.DRAFTS=ROOT/'preexperiment/results/formal_trainval_drafts_v02'
    records=read(a.MANIFEST)['records']
    scenes=[a.read_scene(r) for r in records if r['split'] in ['train','validation']]
    train=[s for s in scenes if s['record']['split']=='train']; val=[s for s in scenes if s['record']['split']=='validation']
    cfg=read(ROOT/'preexperiment/results/ablation_3seed_v02_corrected_labels/config.json')
    for s in scenes:
        s['x']=np.empty_like(s['x_raw'])
        for b,t in enumerate(cfg['normalization']):s['x'][b]=(np.clip(s['x_raw'][b],t['p01'],t['p99'])-t['mean'])/t['std']
        s['x'][~np.isfinite(s['x'])]=0
    outline=read(ROOT/'preexperiment/results/screening_outline_and_bounds.geojson')['features'][0]['geometry']
    g=transform_geom('EPSG:4326',scenes[0]['profile']['crs'],outline)
    hist=rasterize([(g,1)],out_shape=scenes[0]['y'].shape,transform=scenes[0]['profile']['transform']).astype(bool)
    di=distance_transform_edt(hist)*30-15; do=distance_transform_edt(~hist)*30-15
    tw,vw=a.windows_for(train),a.windows_for(val); runs=[];logs=[];bands=[]
    dump('buffer_protocol.json',dict(status='VALIDATION_ONLY_RETRAINING_AFTER_REVIEW',widths_m=[150,300,450,600],seeds=SEEDS,
         fixed='Labels, original sampling/loss/evaluation support, normalization, architecture, training budget and threshold',
         changed='Two input prior masks from a 30-m raster approximation of the saved 2019 outline',
         geometry_note='Pixel-center EDT minus half a pixel; raster buffer, not identical to GEE geodesic vector buffer',
         labels_share_prior=True,test_used_for_width_selection=False,new_width_adopted=False))
    for width in [150,300,450,600]:
        inner=hist&(di>width); band=((hist&(di<=width))|(~hist&(do<=width)))&scenes[0]['roi']
        bands.append(dict(width_m=width,shore_area_km2=float(band.sum()*.0009),inner_area_km2=float(inner.sum()*.0009),
                          jaccard_vs_exported_300m=float((band&scenes[0]['shore']).sum()/(band|scenes[0]['shore']).sum())))
        for s in scenes:s['priors']=np.stack([inner,band]).astype('float32')
        for seed in SEEDS:
            start=time.time();a.seed_all(seed);device=torch.device('cuda')
            model=a.AblationDFANet(True,'parallel').to(device)
            opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=1e-4)
            sched=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,patience=2,factor=.5)
            tl=DataLoader(a.MultiSceneDataset(train,tw,True),batch_size=12,shuffle=True,num_workers=0)
            vl=DataLoader(a.MultiSceneDataset(val,vw,False),batch_size=12,shuffle=False,num_workers=0)
            best=math.inf;patience=0;cp=OUT/f'buffer{width}_seed{seed}_best.pt'
            for ep in range(1,16):
                tr=a.epoch(model,tl,device,opt);va=a.epoch(model,vl,device);sched.step(va)
                logs.append(dict(width_m=width,seed=seed,epoch=ep,train_loss=tr,val_loss=va))
                if va<best-1e-4:
                    best=va;patience=0;torch.save(dict(model=model.state_dict(),epoch=ep,val_loss=va),cp)
                else:patience+=1
                if ep>=9 and patience>=4:break
            ck=torch.load(cp,map_location=device,weights_only=False);model.load_state_dict(ck['model']);per=[]
            for s in val:
                prob=a.predict(model,s,device); m=metrics(prob,s['y'],s['valid'],s['valid']&s['shore'])
                per.append(dict(date=s['record']['l8_date'],**m))
            keys=['iou','boundary_f1_30m','mean_symmetric_boundary_distance_m']
            runs.append(dict(width_m=width,seed=seed,best_epoch=ck['epoch'],seconds=time.time()-start,per_date=per,
                             macro={k:float(np.mean([v[k] for v in per])) for k in keys}))
            dump('buffer_runs.json',runs);dump('buffer_training_log.json',logs)
            print(f'Buffer {width} m seed {seed}: {runs[-1]["macro"]}',flush=True)
            del model,opt;torch.cuda.empty_cache()
    dump('buffer_geometry.json',bands)
    summary=[]
    for w in [150,300,450,600]:
        r=[r for r in runs if r['width_m']==w]
        summary.append(dict(width_m=w,**{k:dict(mean=float(np.mean([t['macro'][k] for t in r])),std=float(np.std([t['macro'][k] for t in r],ddof=1))) for k in keys}))
    dump('buffer_summary.json',summary)
    fig,axs=plt.subplots(1,3,figsize=(10,3))
    for ax,k,label in zip(axs,keys,['IoU','Boundary F1 at 30 m','ASD (m)']):
        ax.errorbar([r['width_m'] for r in summary],[r[k]['mean'] for r in summary],yerr=[r[k]['std'] for r in summary],color='#439FE5',marker='o',capsize=3)
        ax.set_xticks([150,300,450,600]);ax.set_xlabel('Prior half-width (m)');ax.set_ylabel(label);ax.spines[['top','right']].set_visible(False)
    fig.tight_layout();savefig(fig,'supplement_buffer_validation')

if __name__=='__main__':
    audit_existing();diagnostic();buffer_sensitivity()
    print('ROUND2_ANALYSIS_COMPLETE',flush=True)
