"""Create publication-ready outputs for the pooled 12-date edge confirmation."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "preexperiment/results/combined_edge_confirmation_12dates.json"
OUT = ROOT / "preexperiment/results/edge_confirmation_12date_figure"

COLORS = {
    "prior_only": "#8FA2D6",
    "fixed_log_prewitt_shallow": "#A9C8B8",
    "fixed_log_prewitt_deep": "#6A5C95",
    "parameter_matched_ordinary_conv": "#E7A889",
}
LABELS = {
    "prior_only": "Spatial prior",
    "fixed_log_prewitt_shallow": "Shallow edge",
    "fixed_log_prewitt_deep": "Deep edge",
    "parameter_matched_ordinary_conv": "Matched convolution",
}


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    dates = sorted(data["dates"])
    models = data["models"]
    OUT.mkdir(parents=True, exist_ok=True)

    with (OUT / "combined_12date_model_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", "IoU", "Boundary_F1_30m", "Boundary_F1_60m", "ASD_m", "HD95_m"])
        for model in models:
            macro = data["pooled"][model]["macro"]
            writer.writerow([
                LABELS[model], macro["iou"]["mean"], macro["boundary_f1_30m"]["mean"],
                macro["boundary_f1_60m"]["mean"],
                macro["mean_symmetric_boundary_distance_m"]["mean"], macro["hd95_m"]["mean"],
            ])
    with (OUT / "combined_12date_paired_effects.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["comparison", "metric", "mean_improvement", "ci_low", "ci_high", "improved_dates", "n_dates", "exact_p"])
        for comparison, metrics in data["paired_date_level_effects"].items():
            for metric, values in metrics.items():
                writer.writerow([
                    comparison, metric, values["mean_improvement"], *values["bootstrap_95_ci"],
                    values["dates_improved"], len(dates), values["wilcoxon_exact_two_sided_p"],
                ])

    plt.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 10,
        "xtick.labelsize": 8, "ytick.labelsize": 9, "legend.fontsize": 8,
        "axes.linewidth": 0.8, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(2, 1, figsize=(7.25, 5.8), gridspec_kw={"height_ratios": [1.15, 1]}, constrained_layout=True)
    x = np.arange(len(dates))
    for model in models:
        values = [data["pooled"][model]["per_date"][date]["mean_symmetric_boundary_distance_m"] for date in dates]
        axes[0].plot(x, values, marker="o", markersize=3.7, linewidth=1.7, color=COLORS[model], label=LABELS[model])
    axes[0].set_ylabel("ASD (m)")
    axes[0].set_xticks(x, [date[2:] for date in dates], rotation=45, ha="right")
    axes[0].grid(axis="y", color="#E8E8EC", linewidth=0.7)
    axes[0].legend(ncol=2, frameon=False, loc="upper left")
    axes[0].text(-0.075, 1.02, "(a)", transform=axes[0].transAxes, fontweight="bold", fontsize=11)

    prior = data["paired_date_level_effects"]["fixed_deep_vs_prior_only"]["asd_reduction_m"]["date_level_improvement"]
    control = data["paired_date_level_effects"]["fixed_deep_vs_parameter_matched_ordinary_conv"]["asd_reduction_m"]["date_level_improvement"]
    width = 0.36
    axes[1].bar(x - width / 2, [prior[d] for d in dates], width, color=COLORS["prior_only"], label="Deep edge vs spatial prior")
    axes[1].bar(x + width / 2, [control[d] for d in dates], width, color=COLORS["parameter_matched_ordinary_conv"], label="Deep edge vs matched convolution")
    axes[1].axhline(0, color="#3E3142", linewidth=0.9)
    axes[1].set_ylabel("ASD reduction (m)")
    axes[1].set_xlabel("Independent confirmation date")
    axes[1].set_xticks(x, [date[2:] for date in dates], rotation=45, ha="right")
    axes[1].grid(axis="y", color="#E8E8EC", linewidth=0.7)
    axes[1].legend(ncol=2, frameon=False, loc="upper left")
    axes[1].text(-0.075, 1.02, "(b)", transform=axes[1].transAxes, fontweight="bold", fontsize=11)
    for ax in axes:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_axisbelow(True)
    fig.savefig(OUT / "combined_edge_confirmation_12dates.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / "combined_edge_confirmation_12dates.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(OUT)


if __name__ == "__main__":
    main()
