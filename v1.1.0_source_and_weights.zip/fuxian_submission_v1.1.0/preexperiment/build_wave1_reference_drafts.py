"""Create review-ready Sentinel-2 shoreline drafts for formal wave 1.

Outputs are diagnostics and annotation drafts, never final reference labels.
The 2019 lake geometry is used only as a search zone and seed support.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw, ImageFont
from rasterio.enums import Resampling
from rasterio.warp import reproject, transform
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu
from skimage.measure import approximate_polygon, find_contours


ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT
OUT = ROOT / "preexperiment/results/formal_wave1"
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"
WAVE1 = {"2020-05-09", "2021-02-05", "2022-03-12"}
SEED_LON_LAT = (102.8889, 24.5022)
L8_TEMPLATE = "Fuxian_L8_native_{l8_tag}.tif"
S2_TEMPLATE = "Fuxian_S2_{s2_tag}.tif"
MASK_TEMPLATE = "Fuxian_masks_native_{l8_tag}.tif"


def compact(value: str) -> str:
    return value.replace("-", "")


def split_valid(points: np.ndarray, good: np.ndarray):
    start = None
    for i, ok in enumerate(np.r_[good, False]):
        if ok and start is None:
            start = i
        if not ok and start is not None:
            if i - start >= 8:
                yield points[start:i]
            start = None


def chunks(coords: np.ndarray, limit: float = 750.0):
    piece = [coords[0].tolist()]
    distance = 0.0
    for endpoint in coords[1:]:
        start = np.asarray(piece[-1])
        length = float(np.linalg.norm(endpoint - start))
        while length > 0 and distance + length > limit:
            cut = start + (endpoint - start) * (limit - distance) / length
            piece.append(cut.tolist())
            yield np.asarray(piece)
            piece = [cut.tolist()]
            start = cut
            distance = 0.0
            length = float(np.linalg.norm(endpoint - start))
        piece.append(endpoint.tolist())
        distance += length
    if len(piece) > 1 and distance > 1e-6:
        yield np.asarray(piece)


def resample_mask(mask: np.ndarray, src_transform, src_crs, dst_shape, dst_transform):
    out = np.zeros(dst_shape, dtype="uint8")
    reproject(mask, out, src_transform=src_transform, src_crs=src_crs,
              dst_transform=dst_transform, dst_crs=src_crs,
              resampling=Resampling.nearest)
    return out


def recover_prior_interior(shore_mask: np.ndarray, transform_affine, crs) -> np.ndarray:
    """Recover the stable lake-interior component enclosed by the fixed shore band."""
    labels, _ = ndi.label(~shore_mask.astype(bool), structure=np.ones((3, 3)))
    xs, ys = transform("EPSG:4326", crs, [SEED_LON_LAT[0]], [SEED_LON_LAT[1]])
    col, row = (~transform_affine) * (xs[0], ys[0])
    label = int(labels[int(row), int(col)])
    if label == 0:
        raise RuntimeError("Fixed lake-center seed falls inside the shore band")
    return labels == label


def make_preview(s2: np.ndarray, water: np.ndarray, valid: np.ndarray,
                 uncertain: np.ndarray, path: Path, title: str):
    rgb = np.clip(s2[[2, 1, 0]].transpose(1, 2, 0).astype("float32") / 2600, 0, 1) ** 0.7
    rgb = (rgb * 255).astype("uint8")
    edge = water & ~ndi.binary_erosion(water)
    rgb[edge] = [0, 245, 255]
    rgb[uncertain & ndi.binary_dilation(edge, iterations=2)] = [255, 60, 40]
    rgb[~valid] = (0.45 * rgb[~valid] + 0.55 * np.array([150, 40, 160])).astype("uint8")
    # Preserve detail while keeping a manageable review image.
    image = Image.fromarray(rgb)
    width = 900
    height = round(image.height * width / image.width)
    image = image.resize((width, height), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (width, height + 64), "white")
    canvas.paste(image, (0, 44))
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 20)
    draw.text((14, 10), title + " | cyan=draft shoreline, red=low confidence", fill="black", font=font)
    canvas.save(path, quality=92)


def build_one(record: dict) -> dict:
    l8_tag = compact(record["l8_date"])
    s2_tag = compact(record["s2_date"])
    scene_out = OUT / l8_tag
    scene_out.mkdir(parents=True, exist_ok=True)
    l8_path = DATA_ROOT / L8_TEMPLATE.format(l8_tag=l8_tag, s2_tag=s2_tag)
    s2_path = DATA_ROOT / S2_TEMPLATE.format(l8_tag=l8_tag, s2_tag=s2_tag)
    masks_path = DATA_ROOT / MASK_TEMPLATE.format(l8_tag=l8_tag, s2_tag=s2_tag)

    with rasterio.open(l8_path) as src:
        l8_profile = src.profile.copy()
        l8_transform, crs = src.transform, src.crs
    with rasterio.open(masks_path) as src:
        masks = src.read()
    with rasterio.open(s2_path) as src:
        s2 = src.read()
        s2_profile = src.profile.copy()
        s2_transform = src.transform

    shape = s2.shape[1:]
    shore = resample_mask(masks[0], l8_transform, crs, shape, s2_transform) == 1
    prior_interior_l8 = recover_prior_interior(masks[0] == 1, l8_transform, crs)
    prior_interior = resample_mask(
        prior_interior_l8.astype("uint8"), l8_transform, crs, shape, s2_transform
    ) == 1
    joint = resample_mask(masks[3], l8_transform, crs, shape, s2_transform) == 1
    roi = resample_mask(masks[4], l8_transform, crs, shape, s2_transform) == 1
    green, nir = s2[1].astype("float32"), s2[3].astype("float32")
    valid = (s2[7] == 1) & (green + nir > 0) & joint
    ndwi = np.full(shape, np.nan, dtype="float32")
    np.divide(green - nir, green + nir, out=ndwi, where=valid)
    sample = ndwi[valid & shore & np.isfinite(ndwi)]
    threshold = float(threshold_otsu(sample))

    # The stable prior interior anchors the lake component. Spectral decisions
    # are permitted only inside the fixed +/-300 m shore band, preventing
    # cloud gaps and within-lake spectral fronts from becoming false shorelines.
    candidate = prior_interior | (valid & shore & (ndwi > threshold))
    labels, count = ndi.label(candidate, structure=np.ones((3, 3)))
    xs, ys = transform("EPSG:4326", crs, [SEED_LON_LAT[0]], [SEED_LON_LAT[1]])
    col, row = (~s2_transform) * (xs[0], ys[0])
    seed_label = int(labels[int(row), int(col)])
    if seed_label == 0:
        # A robust fallback still selects inside the fixed ROI and is recorded.
        candidate_ids, sizes = np.unique(labels[roi], return_counts=True)
        keep = candidate_ids != 0
        if not keep.any():
            raise RuntimeError(f"No connected S2 water component for {record['l8_date']}")
        seed_label = int(candidate_ids[keep][np.argmax(sizes[keep])])
        seed_mode = "LARGEST_COMPONENT_FALLBACK"
    else:
        seed_mode = "FIXED_PRIOR_INTERIOR_COMPONENT"
    water_raw = labels == seed_label
    # The lake component can contain thousands of dark-water holes caused by
    # sunglint, waves, or spectral variability. The paper target is the outer
    # lake boundary, so internal holes and island rings are excluded here.
    water = ndi.binary_fill_holes(water_raw)

    usable = ndi.binary_erosion(valid, iterations=2) & shore
    low_confidence = valid & (np.abs(ndwi - threshold) <= 0.05)
    features = []
    queue = []
    segment_count = 0
    total_length = 0.0
    pixel_size = abs(s2_transform.a)
    for contour in find_contours(water.astype("uint8"), 0.5):
        rr = np.clip(np.floor(contour[:, 0]).astype(int), 0, shape[0] - 2)
        cc = np.clip(np.floor(contour[:, 1]).astype(int), 0, shape[1] - 2)
        good = usable[rr, cc] & usable[rr + 1, cc] & usable[rr, cc + 1] & usable[rr + 1, cc + 1]
        for part in split_valid(contour, good):
            part = approximate_polygon(part, tolerance=0.3)
            xy = np.asarray([s2_transform * (p[1] + 0.5, p[0] + 0.5) for p in part])
            if len(xy) < 2:
                continue
            length = float(np.linalg.norm(np.diff(xy, axis=0), axis=1).sum())
            if length < 60:
                continue
            for piece in chunks(xy):
                segment_count += 1
                sid = f"{l8_tag}_DRAFT_{segment_count:03d}"
                prc = np.asarray([(~s2_transform) * tuple(p) for p in piece])
                pc = np.clip(np.rint(prc[:, 0]).astype(int), 0, shape[1] - 1)
                pr = np.clip(np.rint(prc[:, 1]).astype(int), 0, shape[0] - 1)
                margins = np.abs(ndwi[pr, pc] - threshold)
                margins = margins[np.isfinite(margins)]
                low_fraction = float((margins <= 0.05).mean()) if margins.size else 1.0
                median_margin = float(np.median(margins)) if margins.size else 0.0
                reasons = []
                if low_fraction >= 0.25 or median_margin < 0.04:
                    reasons.append("LOW_SPECTRAL_MARGIN")
                priority = "HIGH" if reasons else "NORMAL"
                piece_length = float(np.linalg.norm(np.diff(piece, axis=0), axis=1).sum())
                total_length += piece_length
                props = {
                    "segment_id": sid,
                    "l8_date": record["l8_date"],
                    "reference_date": record["s2_date"],
                    "split": record["split"],
                    "status": "AUTOMATIC_DRAFT_UNREVIEWED",
                    "allow_training": False,
                    "origin": "S2_NDWI_OTSU_LAKE_COMPONENT",
                    "length_m": piece_length,
                    "median_abs_ndwi_margin": median_margin,
                    "low_margin_vertex_fraction": low_fraction,
                    "review_priority": priority,
                    "review_reasons": reasons,
                }
                lon, lat = transform(crs, "EPSG:4326", piece[:, 0].tolist(), piece[:, 1].tolist())
                feature = {"type": "Feature", "properties": props,
                           "geometry": {"type": "LineString", "coordinates": list(map(list, zip(lon, lat)))}}
                features.append(feature)
                if priority == "HIGH":
                    queue.append(feature)

    draft = {"type": "FeatureCollection", "name": f"shoreline_draft_{l8_tag}", "features": features}
    review = {"type": "FeatureCollection", "name": f"review_queue_{l8_tag}", "features": queue}
    (scene_out / "shoreline_DRAFT.geojson").write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")
    (scene_out / "review_queue_HIGH.geojson").write_text(json.dumps(review, ensure_ascii=False), encoding="utf-8")

    p = s2_profile.copy()
    p.update(count=1, dtype="float32", nodata=np.nan, compress="deflate")
    with rasterio.open(scene_out / "S2_NDWI_diagnostic.tif", "w", **p) as dst:
        dst.write(ndwi, 1)
        dst.descriptions = ("S2_NDWI_DIAGNOSTIC_NOT_LABEL",)
    p.update(dtype="uint8", nodata=255)
    water_out = np.where(valid, water.astype("uint8"), 255).astype("uint8")
    with rasterio.open(scene_out / "S2_water_DRAFT.tif", "w", **p) as dst:
        dst.write(water_out, 1)
        dst.descriptions = ("AUTOMATIC_WATER_DRAFT_NOT_REFERENCE_TRUTH",)
    make_preview(s2, water, valid, low_confidence, scene_out / "shoreline_review_overview.jpg", record["l8_date"])

    result = {
        "l8_date": record["l8_date"], "s2_date": record["s2_date"],
        "calendar_gap_days": record["calendar_gap_days"], "split": record["split"],
        "temporal_review": (
            "SAME_DATE" if record["calendar_gap_days"] == 0
            else "NEAR_DATE_1_DAY_SPOT_CHECK_REQUIRED" if record["calendar_gap_days"] == 1
            else "DATE_LEVEL_SPOT_CHECK_REQUIRED"
        ),
        "threshold": threshold, "threshold_sample_pixels": int(sample.size),
        "seed_mode": seed_mode, "valid_fraction_on_shore": float(valid[shore].mean()),
        "water_area_km2_draft": float(water.sum() * pixel_size ** 2 / 1e6),
        "segment_count": segment_count, "high_priority_segments": len(queue),
        "draft_length_km": total_length / 1000,
        "label_status": "AUTOMATIC_DRAFT_UNREVIEWED", "allow_training": False,
        "outputs": {
            "draft": str(scene_out / "shoreline_DRAFT.geojson"),
            "review_queue": str(scene_out / "review_queue_HIGH.geojson"),
            "preview": str(scene_out / "shoreline_review_overview.jpg"),
        },
    }
    (scene_out / "draft_manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]
    selected = [r for r in records if r["l8_date"] in WAVE1 and r["split"] == "train"]
    results = [build_one(record) for record in selected]
    summary = {
        "dataset": "Fuxian formal wave 1 reference drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_REVIEW",
        "allow_training": False,
        "test_dates_opened": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(r["segment_count"] for r in results),
            "high_priority_segments": sum(r["high_priority_segments"] for r in results),
        },
    }
    (OUT / "wave1_draft_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
