"""Conservatively screen the seven added train/validation reference drafts."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import finalize_additional_test_reference as finalizer


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/round4_references"
DRAFT = BASE / "added_drafts"
PROTOCOL = ROOT / "preexperiment/results/round4_protocol/round4_split_protocol.json"


def main() -> int:
    protocol = json.loads(PROTOCOL.read_text(encoding="utf-8"))
    records = protocol["added_export_records"]
    compatible = BASE / "added_pairs.json"
    compatible.write_text(json.dumps({"selected": records}, ensure_ascii=False, indent=2), encoding="utf-8")
    partial = {"2020-07-28", "2021-10-19", "2023-05-18"}
    review = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "DATE_OVERVIEWS_REVIEWED",
        "reviewer": "Codex-assisted full-date visual screening",
        "records": [{
            "l8_date": r["l8_date"], "accept": True,
            "notes": ("Accepted as partial scene; all low-confidence/cloud-affected segments excluded."
                      if r["l8_date"] in partial else
                      "Accepted; visible shoreline is coherent and low-confidence segments are excluded."),
        } for r in records],
    }
    review_path = DRAFT / "date_level_review.json"
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")
    finalizer.DRAFT_ROOT = DRAFT
    finalizer.REVIEW = review_path
    finalizer.OUT = BASE / "added_screened"
    finalizer.MANIFEST = compatible
    finalizer.main()
    path = finalizer.OUT / "screened_reference_manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    manifest.update({
        "dataset": "Round-4 conservatively screened added train-validation references",
        "status": "SCREENED_FOR_TRAINING_OR_VALIDATION_ONLY",
        "allow_training": True,
        "allow_model_selection": True,
        "allow_one_time_evaluation": False,
        "test_data_used": False,
    })
    for row, source in zip(manifest["records"], records):
        row["split"] = source["split"]
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": manifest["status"],
        "dates": len(manifest["records"]),
        "retained": {r["l8_date"]: {
            "fraction": round(r["retained_length_fraction"], 3),
            "sectors": r["spatial_coverage"]["occupied_12_sectors"],
        } for r in manifest["records"]},
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
