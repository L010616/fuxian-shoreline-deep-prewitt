"""Validate and freeze the six downloaded post-2019 confirmatory image triplets."""
from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
from datetime import datetime
from pathlib import Path

import rasterio


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "drive-download-20260921T161217Z-1-001"
DATA = ROOT / "preexperiment" / "data" / "edge_confirmatory_post2019"
RAW = DATA / "analysis_ready"
MANIFEST = DATA / "selection_manifest.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def raster_signature(path: Path) -> dict:
    with rasterio.open(path) as ds:
        return {
            "bands": ds.count, "width": ds.width, "height": ds.height,
            "crs": str(ds.crs), "transform": list(tuple(ds.transform)[:6]),
            "dtypes": list(ds.dtypes), "nodata": ds.nodata,
        }


def main() -> None:
    if MANIFEST.exists():
        raise RuntimeError("Post-2019 data manifest already exists; refusing to overwrite")
    csv_path = SOURCE / "Fuxian_edgeconfirm_post2019_selection_manifest.csv"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 6:
        raise RuntimeError(f"Expected six selected pairs, found {len(rows)}")
    RAW.mkdir(parents=True, exist_ok=True)
    records = []
    for row in rows:
        l8_tag = row["l8_date"].replace("-", "")
        s2_tag = row["s2_date"].replace("-", "")
        names = {
            "l8": f"Fuxian_edgeconfirm_post2019_L8_native_{l8_tag}.tif",
            "s2": f"Fuxian_edgeconfirm_post2019_S2_{s2_tag}_for_{l8_tag}.tif",
            "mask": f"Fuxian_edgeconfirm_post2019_masks_native_{l8_tag}.tif",
        }
        paths = {k: SOURCE / v for k, v in names.items()}
        missing = [str(p) for p in paths.values() if not p.exists()]
        if missing:
            raise FileNotFoundError(missing)
        sig = {k: raster_signature(p) for k, p in paths.items()}
        if (sig["l8"]["bands"], sig["l8"]["width"], sig["l8"]["height"], sig["l8"]["crs"]) != (7, 542, 1095, "EPSG:32648"):
            raise RuntimeError(f"Unexpected Landsat grid for {l8_tag}: {sig['l8']}")
        if (sig["s2"]["bands"], sig["s2"]["width"], sig["s2"]["height"], sig["s2"]["crs"]) != (8, 1623, 3281, "EPSG:32648"):
            raise RuntimeError(f"Unexpected Sentinel-2 grid for {l8_tag}: {sig['s2']}")
        if (sig["mask"]["bands"], sig["mask"]["width"], sig["mask"]["height"], sig["mask"]["crs"]) != (5, 542, 1095, "EPSG:32648"):
            raise RuntimeError(f"Unexpected mask grid for {l8_tag}: {sig['mask']}")
        copied = {}
        for key, src in paths.items():
            dst = RAW / src.name
            shutil.copy2(src, dst)
            copied[key] = str(dst.relative_to(ROOT)).replace("\\", "/")
        records.append({
            "l8_date": row["l8_date"], "s2_date": row["s2_date"],
            "calendar_gap_days": int(float(row["day_gap"])), "window": row["window"],
            "l8_clear_shore": float(row["l8_clear_shore"]),
            "s2_clear_shore": float(row["s2_clear_shore"]),
            "quality_score": float(row["quality_score"]),
            "files": copied,
            "sha256": {k: sha256(RAW / Path(v).name) for k, v in copied.items()},
            "raster_signature": sig,
        })
    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "POST2019_CONFIRMATORY_INPUTS_VALIDATED_AND_FROZEN",
        "selection_rule": "One quality-ranked unused pair per predeclared temporal window; no model output used",
        "date_count": 6, "analysis_file_count": 18,
        "allow_training": False, "allow_model_selection": False,
        "allow_threshold_tuning": False, "model_predictions_opened": False,
        "records": records,
    }
    MANIFEST.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "dates": [r["l8_date"] for r in records]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
