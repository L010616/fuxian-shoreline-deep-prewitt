"""Create focused Sentinel-2 panels for redrawing segments 104 and 107."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw, ImageFont
from rasterio.features import rasterize
from rasterio.windows import from_bounds


ROOT = Path(__file__).resolve().parents[1]
ANN = ROOT / "preexperiment/results/native_20200102/annotation_workspace"
OUT = ANN / "ge_corrections/redraw_panels"
RASTER = ROOT / "Fuxian_S2_20200102.tif"
MASK = ANN / "ge_corrections/training_exclusion_mask_S2_10m.tif"
IDS = ("S2_DRAFT_104", "S2_DRAFT_107")


def stretch(channel: np.ndarray, valid: np.ndarray) -> np.ndarray:
    values = channel[valid]
    if values.size == 0:
        return np.zeros(channel.shape, dtype=np.uint8)
    low, high = np.percentile(values, [2, 98])
    if high <= low:
        high = low + 1
    return (np.clip((channel - low) / (high - low), 0, 1) * 255).astype(np.uint8)


def color_ndwi(ndwi: np.ndarray, valid: np.ndarray) -> np.ndarray:
    norm = np.clip((ndwi + 0.5) / 1.0, 0, 1)
    # Brown -> pale -> blue: positive NDWI is likely water.
    stops = np.array([[142, 89, 45], [235, 232, 201], [35, 110, 180]], dtype=float)
    left = norm <= 0.5
    t = np.where(left, norm * 2, (norm - 0.5) * 2)[..., None]
    out = np.empty((*norm.shape, 3), dtype=float)
    out[left] = stops[0] * (1 - t[left]) + stops[1] * t[left]
    out[~left] = stops[1] * (1 - t[~left]) + stops[2] * t[~left]
    out[~valid] = 0
    return out.astype(np.uint8)


def add_line(image: np.ndarray, line_mask: np.ndarray, color: tuple[int, int, int]) -> np.ndarray:
    out = image.copy()
    out[line_mask] = color
    return out


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    draft = json.loads((ANN / "initial_draft.json").read_text(encoding="utf-8"))
    segments = {s["id"]: s for s in draft["segments"]}
    index = []

    with rasterio.open(RASTER) as src, rasterio.open(MASK) as mask_src:
        for sid in IDS:
            coords = np.asarray(segments[sid]["coordinates"], dtype=float)
            minx, miny = coords.min(axis=0) - 180
            maxx, maxy = coords.max(axis=0) + 180
            window = from_bounds(minx, miny, maxx, maxy, src.transform).round_offsets().round_lengths()
            data = src.read([1, 2, 3, 4], window=window).astype(np.float32)
            transform = src.window_transform(window)
            valid = np.all(data > 0, axis=0)

            rgb = np.dstack(
                [stretch(data[2], valid), stretch(data[1], valid), stretch(data[0], valid)]
            )
            ndwi = np.divide(
                data[1] - data[3],
                data[1] + data[3],
                out=np.zeros_like(data[1]),
                where=(data[1] + data[3]) != 0,
            )
            ndwi_rgb = color_ndwi(ndwi, valid)
            line_geom = {"type": "LineString", "coordinates": segments[sid]["coordinates"]}
            line = rasterize(
                [(line_geom, 1)],
                out_shape=valid.shape,
                transform=transform,
                fill=0,
                all_touched=True,
                dtype="uint8",
            ).astype(bool)
            exclusion = mask_src.read(1, window=window) == 2

            rgb_line = add_line(rgb, line, (0, 255, 255))
            ndwi_line = add_line(ndwi_rgb, line, (255, 0, 255))
            excluded = rgb.copy()
            excluded[exclusion] = (
                excluded[exclusion].astype(np.uint16) // 2 + np.array([128, 0, 0], dtype=np.uint16)
            ).astype(np.uint8)
            excluded = add_line(excluded, line, (0, 255, 255))

            scale = 4
            panes = [
                Image.fromarray(arr).resize((arr.shape[1] * scale, arr.shape[0] * scale), Image.Resampling.NEAREST)
                for arr in (rgb_line, ndwi_line, excluded)
            ]
            title_h = 70
            canvas = Image.new("RGB", (sum(p.width for p in panes), max(p.height for p in panes) + title_h), "white")
            draw = ImageDraw.Draw(canvas)
            labels = ["S2 RGB + draft (cyan)", "NDWI + draft (magenta)", "training exclusion (red)"]
            x = 0
            for pane, label in zip(panes, labels):
                canvas.paste(pane, (x, title_h))
                draw.text((x + 8, 10), label, fill="black")
                x += pane.width
            draw.text((8, 38), f"{sid} | 2020-01-02 | bounds UTM48N: {minx:.0f},{miny:.0f},{maxx:.0f},{maxy:.0f}", fill="black")
            path = OUT / f"{sid}_redraw_panel.png"
            canvas.save(path)
            index.append({"segment_id": sid, "path": path.name, "bounds_utm48n": [minx, miny, maxx, maxy]})

    (OUT / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(index, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
