import json, copy, math, hashlib, html
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import xml.etree.ElementTree as E
B=Path(__file__).resolve().parent/'results/native_20200102/annotation_workspace'
O=B/'ai_review'
N={
100:('KEEP_DRAFT','主岸线连续，S2 真彩色与近红外显示清楚的水陆过渡，草稿整体沿该过渡分布。','保留草稿，细小折点尚未获得独立高分辨率证据。'),
101:('LOCAL_RECHECK','主岸线整体一致；图中下半段出现数个向水侧回折，原图中未见同样清楚的小尺度实体轮廓。','核验小回折是否为构筑物、混合像元或阈值碎边；证据不足前不自动平滑。'),
102:('KEEP_DRAFT','弧形主岸线与 S2 水陆过渡整体相符；沿岸亮色区域没有造成大范围外扩。','保留草稿，局部短折点待核；不用 30 m Landsat 强制校正 10 m S2 细节。'),
103:('KEEP_DRAFT','小湾与岸角在两种 S2 显示中均可辨，草稿捕捉主要凹凸。','保留可见部分；左端为当前线段终点，不能据此认定整条岸线连续或缺失原因。'),
104:('LOCAL_RECHECK','岸边可见构筑物样亮斑、植被和暗区；中下部水陆过渡较宽，草稿有明显回折。','核验中下部岸线与绿暗带的关系；暂不将绿暗带直接判为陆地或水生植被。'),
105:('LOCAL_RECHECK','主岸线形状大体合理；中部窄尖折和右端小钩没有清晰的独立轮廓支持。','保留主轮廓，标记尖折和小钩待核；不要仅凭指数线形推断码头。'),
106:('KEEP_DRAFT','主要岸角和小湾在 S2 两种显示中一致，草稿总体贴近水陆过渡。','保留草稿；中部短回折待核，不给出米级定位精度结论。'),
107:('LOCAL_RECHECK','湾内有多个亮点及向水侧突出的目标样结构，草稿绕行形成复杂回折；Landsat 无法清楚分辨细部。','优先核验目标是否固定并与陆地连接；明确主体外岸线、码头和船舶的标注规则后再修改。'),
108:('KEEP_DRAFT','主岸段较平直，水陆过渡总体清楚；下方植被阴影没有被大范围连入水体。','保留草稿，细小尖点和阴影过渡待高分辨率核验。'),
185:('HOLD_UNCERTAIN_LOOP','闭合圈包围水中孤立亮点，近红外有局部较亮响应；该裁图未显示与主体陆地连接，Landsat 上目标不清楚。','暂不纳入主体湖岸线或独立精度参考；核验船舶、浮台、岩礁或岛体，不能直接删除后补成确定水面。'),
186:('HOLD_UNCERTAIN_LOOP','闭合圈位于近岸绿暗过渡带；S2 两种显示均未见清晰的独立实体外缘。','作为阈值碎斑疑点暂缓使用，核验浅水、混合像元或真实目标的可能。'),
187:('HOLD_UNCERTAIN_LOOP','细长闭合圈位于湾内绿暗带，原图没有清楚的封闭实体轮廓，邻近岸线和构筑物样亮区。','暂缓使用；核验水色变化、混合像元或真实固定目标。')}
L={'KEEP_DRAFT':'保留草稿','LOCAL_RECHECK':'局部重点复核','HOLD_UNCERTAIN_LOOP':'闭合圈暂缓使用'}
P=[B/'initial_draft.json',B/'S2_shoreline_DRAFT.geojson']
H={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in P}
d=json.loads(P[0].read_text('utf8'));g=json.loads(P[1].read_text('utf8'))
S={s['id']:s for s in d['segments']};F={f['properties']['segment_id']:f for f in g['features']}
C={c['id']:c for c in json.loads((O/'crops.json').read_text('utf8'))}
R=[];G=[]
for n,(status,obs,action) in N.items():
 sid=f'S2_DRAFT_{n:03d}';s=S[sid];c=s['coordinates'];f=copy.deepcopy(F[sid]);xy=f['geometry']['coordinates']
 center=[(min(p[k] for p in xy)+max(p[k] for p in xy))/2 for k in (0,1)]
 r=dict(segment_id=sid,ai_review_status=status,decision_zh=L[status],observation=obs,recommended_action=action,
  approximate_draft_length_m=sum(math.dist(a,b) for a,b in zip(c,c[1:])),closed=c[0]==c[-1],center_lonlat=center,
  crop=C[sid]['image'],bounds_utm=C[sid]['bounds_utm'],reviewer_type='AI',reference_approved=False,
  geometry_modified=False,google_earth_verified=False,google_earth_imagery_date=None)
 R.append(r)
 f['properties'].update(ai_review_status=status,ai_observation=obs,ai_recommended_action=action,
  ai_review_date='2026-09-12',ai_review_type='SAME_DATE_S2_L8_VISUAL',google_earth_verified=False,reference_approved=False,allow_training=False)
 G.append(f)
counts=dict(Counter(r['ai_review_status'] for r in R))
payload=dict(scene_date='2020-01-02',generated_at=datetime.now(timezone.utc).isoformat(),reviewer_type='AI',
 method='Visual inspection of all twelve four-panel crops: S2 RGB, S2 NIR, S2 plus draft, native-grid L8 plus draft.',
 total_draft_segments=len(S),ai_visually_checked=len(R),not_visually_checked=len(S)-len(R),counts=counts,
 allow_training=False,independent_reference=False,google_earth_verified=False,geometry_modified=False,source_sha256=H,records=R)
(O/'east_ai_review.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),'utf8')
(O/'east_ai_review.geojson').write_text(json.dumps(dict(type='FeatureCollection',features=G),ensure_ascii=False,indent=2),'utf8')
ns='http://www.opengis.net/kml/2.2';E.register_namespace('',ns)
def sub(p,t,text=None):
 e=E.SubElement(p,f'{{{ns}}}{t}')
 if text is not None:e.text=str(text)
 return e
k=E.Element(f'{{{ns}}}kml');doc=sub(k,'Document');sub(doc,'name','东岸 AI 初审（非参考真值）')
for status,color in [('KEEP_DRAFT','ff477026'),('LOCAL_RECHECK','ff005ca8'),('HOLD_UNCERTAIN_LOOP','ff362bb1')]:
 st=sub(doc,'Style');st.set('id',status);li=sub(st,'LineStyle');sub(li,'color',color);sub(li,'width',3)
for r,f in zip(R,G):
 p=sub(doc,'Placemark');sub(p,'name',r['segment_id']+' '+r['decision_zh']);sub(p,'styleUrl','#'+r['ai_review_status'])
 sub(p,'description','AI 初审，非人工复核真值。目标影像日期 2020-01-02；Google Earth 日期尚未核实。\n'+r['observation']+'\n'+r['recommended_action'])
 look=sub(p,'LookAt');sub(look,'longitude',r['center_lonlat'][0]);sub(look,'latitude',r['center_lonlat'][1]);sub(look,'range',1200);sub(look,'tilt',0)
 li=sub(p,'LineString');sub(li,'tessellate',1);sub(li,'altitudeMode','clampToGround');sub(li,'coordinates',' '.join(f'{x},{y},0' for x,y in f['geometry']['coordinates']))
E.ElementTree(k).write(O/'east_review_queue.kml',encoding='utf-8',xml_declaration=True)
intro='2020-01-02 东岸首批 AI 初审：12 / 203 段已逐图检查，191 段尚未目视检查。5 段保留草稿，4 段局部重点复核，3 个闭合圈暂缓使用。Google Earth 历史影像尚未核验；所有线保持 DRAFT，不能直接用于训练或独立精度评价。'
limits='草稿本身由 S2 指数生成，与同一影像的一致性只能用于发现疑点。这不是独立人工复核，也未完成 Google Earth 日期、局部配准或目标持续性验证，不能报告为 Boundary F1、岸线偏移精度或模型增益。'
nextstep='核验顺序：185 → 186 → 187 → 107 → 104 → 101 → 105，再复核保留段。Google Earth 中需逐位置记录实际影像日期及来源；异日影像只能辅助识别固定地物，不能直接替代 2020-01-02 的水边位置。'
rules='主体外岸线与真实岛岸分别存储；船舶和浮动目标不能直接变成岛岸标签。与陆地连接的码头需统一规定纳入方式。未确定闭合圈需待核验或设忽略区，不能简单删除后认定整块都是水。'
lines=['# 东岸首批 AI 目视初审记录','','日期：2026-09-12。'+intro,'',
 '检查同日 S2 真彩色、近红外假彩色及草稿叠加，并与原生格网 Landsat 8 对照。S2 显示使用 10 m 波段，Landsat 原始空间信息仍为 30 m。裁图边长 300–880 m，显示重采样没有增加信息。','',limits,'',
 '| 线段 | 初审意见 | 观察与建议 |','|---|---|---|']
for r in R:lines.append(f'| {r["segment_id"]} | {r["decision_zh"]} | {r["observation"]} {r["recommended_action"]} |')
lines+=['',nextstep,'',rules,'','本轮未修改原始线坐标、未代填人工标注人、未改变训练许可。AI 意见单独保存。','',
 '交付：east_ai_review.json（逐段意见）、east_ai_review.geojson（位置与意见）、east_review_queue.kml（Earth 定位）、index.html（图文浏览）。']
(O/'东岸AI初审记录.md').write_text('\n'.join(lines),'utf8')
cards=[]
for r in R:
 cards.append(f'<article><h2>{r["segment_id"]} · {r["decision_zh"]}</h2><p>{html.escape(r["observation"])}</p><p><b>建议：</b>{html.escape(r["recommended_action"])}</p><a href="{r["crop"]}"><img src="{r["crop"]}" alt="{r["segment_id"]} 四面板对照"></a><small>定位中心：{r["center_lonlat"][0]:.7f}, {r["center_lonlat"][1]:.7f}；坐标未修改，独立复核未完成。</small></article>')
page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>抚仙湖东岸 AI 初审</title><style>body{font:16px/1.7 system-ui;max-width:1600px;margin:24px auto;padding:0 20px;background:#f3f5f4;color:#202823}header,article{background:white;border:1px solid #d8dfda;border-radius:10px;padding:20px;margin:20px 0}h1{font-size:26px}h2{font-size:20px}img{width:100%;height:auto}a{color:#216c50}small{color:#59655d}</style><header><h1>抚仙湖东岸：逐段 AI 初审</h1><p>'+intro+'</p><p>'+limits+'</p><p><a href="east_review_queue.kml">Google Earth 定位 KML</a> · <a href="east_ai_review.json">JSON</a> · <a href="east_ai_review.geojson">GeoJSON</a></p><p>图像从左到右：S2 真彩色、S2 近红外、S2 叠加草稿、Landsat 叠加同一草稿。点击可查看完整尺寸。</p></header>'+''.join(cards)+'<article><p>'+nextstep+'</p><p>'+rules+'</p></article></html>'
(O/'index.html').write_text(page,'utf8')
assert len(R)==12 and counts=={'KEEP_DRAFT':5,'LOCAL_RECHECK':4,'HOLD_UNCERTAIN_LOOP':3}
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==H[p.name] for p in P)
assert all(f['properties']['review_status']=='DRAFT' and f['geometry']==F[f['properties']['segment_id']]['geometry'] for f in G)
assert all((O/r['crop']).is_file() for r in R)
E.parse(O/'east_review_queue.kml')
print(json.dumps({'checked':len(R),'unreviewed':len(S)-len(R),'counts':counts,'originals_unchanged':True},ensure_ascii=False))

