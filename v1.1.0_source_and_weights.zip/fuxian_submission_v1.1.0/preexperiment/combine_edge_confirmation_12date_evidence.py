"""Combine two separately locked six-date confirmation evaluations.

This script performs no model inference and does not alter either locked result.
It pools the seed-averaged, date-level effects after both evaluations are closed.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon


ROOT = Path(__file__).resolve().parents[1]
SET1 = ROOT / "preexperiment/results/edge_confirmatory_post2019/locked_evaluation/post2019_confirmatory_results.json"
SET2 = ROOT / "preexperiment/results/edge_confirmation_set2/locked_evaluation/edge_confirmation_set2_results.json"
OUT = ROOT / "preexperiment/results/combined_edge_confirmation_12dates.json"
MODELS = (
    "prior_only",
    "fixed_log_prewitt_shallow",
    "fixed_log_prewitt_deep",
    "parameter_matched_ordinary_conv",
)
METRICS = (
    "precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m",
    "mean_symmetric_boundary_distance_m", "hd95_m",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return digest


def effect(candidate: dict, comparator: dict, key: str, lower_is_better: bool) -> dict:
    dates = sorted(candidate)
    values = np.asarray([
        (comparator[d][key] - candidate[d][key]) if lower_is_better
        else (candidate[d][key] - comparator[d][key])
        for d in dates
    ], dtype="float64")
    rng = np.random.default_rng(20260922)
    bootstrap = values[rng.integers(0, len(values), size=(50000, len(values)))].mean(axis=1)
    try:
        p_value = float(wilcoxon(values, alternative="two-sided", method="exact").pvalue)
    except ValueError:
        p_value = 1.0
    return {
        "positive_value_definition": "candidate improvement over comparator",
        "date_level_improvement": {date: float(value) for date, value in zip(dates, values)},
        "mean_improvement": float(values.mean()),
        "median_improvement": float(np.median(values)),
        "bootstrap_95_ci": [float(np.quantile(bootstrap, 0.025)), float(np.quantile(bootstrap, 0.975))],
        "dates_improved": int((values > 0).sum()),
        "dates_tied": int((values == 0).sum()),
        "dates_worsened": int((values < 0).sum()),
        "wilcoxon_exact_two_sided_p": p_value,
    }


def main() -> None:
    if OUT.exists():
        raise RuntimeError("Combined locked result already exists; refusing to overwrite")
    first = json.loads(SET1.read_text(encoding="utf-8"))
    second = json.loads(SET2.read_text(encoding="utf-8"))
    if first["status"] != "POST2019_CONFIRMATORY_EVALUATION_OPENED_ONCE_AND_LOCKED":
        raise RuntimeError("First confirmation set is not locked")
    if second["status"] != "EDGE_CONFIRMATION_SET2_EVALUATION_OPENED_ONCE_AND_LOCKED":
        raise RuntimeError("Second confirmation set is not locked")
    if tuple(first["models"]) != MODELS or tuple(second["models"]) != MODELS:
        raise RuntimeError("Model lists differ between locked evaluations")
    dates = first["dates"] + second["dates"]
    if len(dates) != 12 or len(set(dates)) != 12:
        raise RuntimeError("Expected 12 unique confirmation dates")

    pooled = {}
    for model in MODELS:
        per_date = {**first["seed_averaged_per_date"][model], **second["seed_averaged_per_date"][model]}
        pooled[model] = {
            "per_date": per_date,
            "macro": {
                metric: {
                    "mean": float(np.mean([per_date[date][metric] for date in dates])),
                    "sd_across_dates": float(np.std([per_date[date][metric] for date in dates], ddof=1)),
                }
                for metric in METRICS
            },
        }

    comparisons = {}
    for comparator in ("prior_only", "fixed_log_prewitt_shallow", "parameter_matched_ordinary_conv"):
        comparisons[f"fixed_deep_vs_{comparator}"] = {
            "boundary_f1_30m": effect(
                pooled["fixed_log_prewitt_deep"]["per_date"], pooled[comparator]["per_date"],
                "boundary_f1_30m", False,
            ),
            "asd_reduction_m": effect(
                pooled["fixed_log_prewitt_deep"]["per_date"], pooled[comparator]["per_date"],
                "mean_symmetric_boundary_distance_m", True,
            ),
        }
    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "POST_HOC_POOLING_OF_TWO_SEPARATELY_LOCKED_CONFIRMATION_SETS",
        "interpretation_scope": "Independent confirmation evidence; no training, model selection, or threshold tuning.",
        "source_results": [
            {"path": str(SET1.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(SET1), "dates": first["dates"]},
            {"path": str(SET2.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(SET2), "dates": second["dates"]},
        ],
        "date_count": 12,
        "dates": dates,
        "models": list(MODELS),
        "pooled": pooled,
        "paired_date_level_effects": comparisons,
    }
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    concise = {
        "macro": {
            model: {
                "BF1_30m": round(values["macro"]["boundary_f1_30m"]["mean"], 6),
                "ASD_m": round(values["macro"]["mean_symmetric_boundary_distance_m"]["mean"], 3),
                "IoU": round(values["macro"]["iou"]["mean"], 6),
            }
            for model, values in pooled.items()
        },
        "comparisons": comparisons,
    }
    print(json.dumps(concise, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
