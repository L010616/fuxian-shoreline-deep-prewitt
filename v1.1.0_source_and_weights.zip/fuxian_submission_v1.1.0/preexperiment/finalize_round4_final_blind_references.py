"""Conservatively screen and freeze round-4 blind-test shoreline references."""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
import finalize_additional_test_reference as finalizer
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'preexperiment/results/round4_final_blind'; DRAFT=BASE/'reference_drafts'; PAIRS=BASE/'evaluation_pairs.json'
notes={
 '2024-01-13':'Severe cloud contamination; retain only automatically unflagged, jointly valid visible shoreline segments.',
 '2024-08-24':'Partial cloud contamination, especially in the south; retain only jointly valid screened segments.',
 '2025-03-04':'Predominantly clear scene; retain screened shoreline and exclude local flagged segments.',
 '2026-04-24':'Mostly usable scene with local cloud; retain jointly valid screened shoreline.',
 '2026-08-14':'Severe cumulus contamination over central and southern lake; retain only clear screened segments.',
 '2026-05-26':'Widespread haze/cloud; retain only jointly valid high-confidence shoreline segments.'}
def main():
 pairs=json.loads(PAIRS.read_text(encoding='utf-8'))['selected']
 review={'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
  'status':'DATE_OVERVIEWS_REVIEWED','reviewer':'Codex-assisted full-date visual screening',
  'policy':'Keep every pre-frozen date, but evaluate only joint-valid shoreline after excluding every high-priority segment with a 30 m buffer.',
  'records':[{'l8_date':r['l8_date'],'accept':True,'notes':notes[r['l8_date']]} for r in pairs]}
 rp=DRAFT/'date_level_review.json'; rp.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
 finalizer.DRAFT_ROOT=DRAFT; finalizer.REVIEW=rp; finalizer.OUT=BASE/'screened_reference'; finalizer.MANIFEST=PAIRS
 finalizer.main()
 mp=finalizer.OUT/'screened_reference_manifest.json'; m=json.loads(mp.read_text(encoding='utf-8'))
 m.update({'dataset':'Fuxian Lake round-4 final six-date blind test',
  'status':'FROZEN_FOR_ONE_TIME_FINAL_BLIND_EVALUATION',
  'reference_scope':'Only retained shoreline intersecting joint-valid masks is eligible.',
  'all_six_prefrozen_dates_retained':True,'allow_training':False,'allow_model_selection':False,
  'allow_threshold_tuning':False})
 mp.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'status':m['status'],'dates':len(m['records']),'coverage':{r['l8_date']:{
  'retained_fraction':round(r['retained_length_fraction'],3),'sectors':r['spatial_coverage']['occupied_12_sectors']}
  for r in m['records']}},ensure_ascii=False,indent=2))
if __name__=='__main__': main()

