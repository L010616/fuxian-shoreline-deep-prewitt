"""Open the frozen 2018 confirmatory set once and evaluate the edge innovation."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import rasterio
import torch
from scipy.stats import wilcoxon

import run_multidate_ablation_pilot as ablation
import run_round4_fusion_confirmation as fusion
from evaluate_extended_boundary_support import metric as boundary_metric
from run_edge_depth_validation_screen import DeeperEdgeDFANet
from run_multidate_ablation_pilot import predict
from run_quick_model_pilot import metrics as area_metrics


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "results" / "edge_confirmatory_2018"
DATA = ROOT / "preexperiment" / "data" / "edge_confirmatory_2018" / "analysis_ready"
DRAFTS = BASE / "reference_drafts"
REF = BASE / "screened_reference"
PAIRS = BASE / "evaluation_pairs.json"
FREEZE = ROOT / "preexperiment" / "results" / "edge_second_innovation_freeze_manifest.json"
DEPTH = ROOT / "preexperiment" / "results" / "edge_depth_validation_screen"
PRIOR = ROOT / "preexperiment" / "results" / "round4_fusion_confirmation"
OUT = BASE / "locked_evaluation"
SEEDS = (20260913, 20260929, 20261017)
KEYS = (
    "precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m",
    "mean_symmetric_boundary_distance_m", "hd95_m",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def apply_frozen_normalization(scenes: list[dict], normalization: list[dict]) -> None:
    for scene in scenes:
        scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
        for band, stats in enumerate(normalization):
            scene["x"][band] = (
                np.clip(scene["x_raw"][band], stats["p01"], stats["p99"]) - stats["mean"]
            ) / stats["std"]
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        with rasterio.open(REF / scene["tag"] / "exclusion_mask_L8_30m.tif") as src:
            scene["valid"] &= ~src.read(1).astype(bool)


def evaluate_probability(probability: np.ndarray, scene: dict) -> dict:
    valid = scene["valid"]
    shore = valid & scene["shore"]
    return {
        **area_metrics(probability, scene["y"], valid, shore),
        **boundary_metric(probability, scene["y"], valid, scene["shore"]),
        "valid_pixels": int(valid.sum()),
        "valid_shore_pixels": int(shore.sum()),
    }


def macro(per_date: dict) -> dict:
    return {key: float(np.mean([row[key] for row in per_date.values()])) for key in KEYS}


def bootstrap_date_effect(deep: dict, comparator: dict, key: str, iterations: int = 20000) -> dict:
    dates = sorted(deep)
    effects = np.asarray([deep[d][key] - comparator[d][key] for d in dates], dtype="float64")
    rng = np.random.default_rng(20260921)
    sampled = effects[rng.integers(0, len(effects), size=(iterations, len(effects)))].mean(axis=1)
    try:
        p = float(wilcoxon(effects, alternative="two-sided", method="exact").pvalue)
    except ValueError:
        p = 1.0
    return {
        "date_level_effects": {d: float(v) for d, v in zip(dates, effects)},
        "mean_effect": float(effects.mean()),
        "bootstrap_95_ci": [float(np.quantile(sampled, 0.025)), float(np.quantile(sampled, 0.975))],
        "dates_improved": int((effects > 0).sum()),
        "dates_tied": int((effects == 0).sum()),
        "dates_worsened": int((effects < 0).sum()),
        "wilcoxon_exact_two_sided_p": p,
    }


def verify_frozen_checkpoints(freeze: dict) -> None:
    for item in freeze["checkpoints"]:
        path = ROOT / item["path"]
        if sha256(path) != item["sha256"]:
            raise RuntimeError(f"Frozen checkpoint hash mismatch: {path}")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    output_path = OUT / "edge_confirmatory_results.json"
    if output_path.exists():
        raise RuntimeError("Confirmatory evaluation already exists; refusing to rerun")

    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    references = json.loads((REF / "screened_reference_manifest.json").read_text(encoding="utf-8"))
    pairs = json.loads(PAIRS.read_text(encoding="utf-8"))
    if freeze["status"] != "EDGE_SECOND_INNOVATION_FROZEN_BEFORE_CONFIRMATORY_DATA_EXPORT":
        raise RuntimeError("Edge architecture was not frozen")
    if references["status"] != "FROZEN_FOR_ONE_TIME_EDGE_CONFIRMATORY_EVALUATION":
        raise RuntimeError("References were not frozen")
    if pairs["status"] != "FROZEN_BEFORE_MODEL_PREDICTIONS":
        raise RuntimeError("Date pairs were not frozen")
    verify_frozen_checkpoints(freeze)

    depth_results = json.loads((DEPTH / "edge_depth_validation_results.json").read_text(encoding="utf-8"))
    prior_results = json.loads((PRIOR / "fusion_confirmation_results.json").read_text(encoding="utf-8"))
    normalization = depth_results["normalization"]
    if not np.allclose(
        np.asarray([[x[k] for k in ("p01", "p99", "mean", "std")] for x in normalization]),
        np.asarray([[x[k] for k in ("p01", "p99", "mean", "std")] for x in prior_results["normalization"]]),
        rtol=0, atol=1e-12,
    ):
        raise RuntimeError("Prior and edge checkpoints used different training normalization")

    ablation.DATA_ROOT = DATA
    ablation.DRAFTS = DRAFTS
    ablation.L8_TEMPLATE = "Fuxian_edgeconfirm_L8_native_{tag}.tif"
    ablation.MASK_TEMPLATE = "Fuxian_edgeconfirm_masks_native_{tag}.tif"
    dates = [
        {"l8_date": row["l8_date"], "s2_date": row["s2_date"], "split": "edge_confirmatory_test"}
        for row in pairs["selected"]
    ]
    scenes = [ablation.read_scene(record) for record in dates]
    apply_frozen_normalization(scenes, normalization)

    factories = {
        "prior_only": fusion.CONFIGS["prior"][0],
        "shallow_parallel_depth0": lambda: DeeperEdgeDFANet(0),
        "deep_parallel_depth2": lambda: DeeperEdgeDFANet(2),
    }
    checkpoints = {
        "prior_only": lambda seed: PRIOR / f"prior_seed{seed}_best.pt",
        "shallow_parallel_depth0": lambda seed: DEPTH / f"edge_depth_0_seed{seed}_best.pt",
        "deep_parallel_depth2": lambda seed: DEPTH / f"edge_depth_2_seed{seed}_best.pt",
    }
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results = {}
    for model_name, factory in factories.items():
        results[model_name] = {}
        for seed in SEEDS:
            model = factory().to(device)
            checkpoint = torch.load(checkpoints[model_name](seed), map_location=device, weights_only=False)
            model.load_state_dict(checkpoint["model"])
            per_date = {
                scene["record"]["l8_date"]: evaluate_probability(predict(model, scene, device), scene)
                for scene in scenes
            }
            results[model_name][str(seed)] = {
                "checkpoint_epoch": int(checkpoint["epoch"]),
                "per_date": per_date,
                "macro": macro(per_date),
            }
            print("completed", model_name, seed, flush=True)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    summary = {}
    seed_averaged_dates = {}
    for model_name, by_seed in results.items():
        summary[model_name] = {}
        for key in KEYS:
            values = np.asarray([by_seed[str(seed)]["macro"][key] for seed in SEEDS])
            summary[model_name][key] = {
                "mean": float(values.mean()),
                "std": float(values.std(ddof=1)),
                "values": values.tolist(),
            }
        seed_averaged_dates[model_name] = {
            date: {
                key: float(np.mean([by_seed[str(seed)]["per_date"][date][key] for seed in SEEDS]))
                for key in KEYS
            }
            for date in [row["l8_date"] for row in pairs["selected"]]
        }

    paired = {}
    for comparator in ("prior_only", "shallow_parallel_depth0"):
        name = f"deep_minus_{comparator}"
        paired[name] = {
            "boundary_f1_30m": bootstrap_date_effect(
                seed_averaged_dates["deep_parallel_depth2"], seed_averaged_dates[comparator], "boundary_f1_30m"
            ),
            # For distances, positive improvement is comparator minus deep.
            "asd_reduction_m": bootstrap_date_effect(
                seed_averaged_dates[comparator], seed_averaged_dates["deep_parallel_depth2"],
                "mean_symmetric_boundary_distance_m",
            ),
        }

    deep_prior = paired["deep_minus_prior_only"]
    claim_pass = (
        deep_prior["boundary_f1_30m"]["mean_effect"] >= 0
        and deep_prior["asd_reduction_m"]["mean_effect"] > 0
    )
    payload = {
        "status": "EDGE_CONFIRMATORY_EVALUATION_OPENED_ONCE_AND_LOCKED",
        "models": list(factories),
        "seeds": list(SEEDS),
        "dates": [row["l8_date"] for row in pairs["selected"]],
        "decision_threshold": 0.5,
        "selected_architecture_before_test": freeze["selected_architecture"],
        "all_six_prefrozen_dates_included": True,
        "reference_status": "Prediction-blind conservatively screened Sentinel-2 shoreline reference; not surveyed ground truth",
        "training_model_selection_or_threshold_tuning_after_test": False,
        "device": str(device),
        "results": results,
        "summary": summary,
        "seed_averaged_per_date": seed_averaged_dates,
        "paired_date_level_effects": paired,
        "predeclared_primary_claim_passed": claim_pass,
    }
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    with (OUT / "per_date_seed_averaged.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "date", *KEYS])
        for model_name, dates_data in seed_averaged_dates.items():
            for date, row in dates_data.items():
                writer.writerow([model_name, date, *[row[k] for k in KEYS]])

    concise = {
        model: {
            "BF1_30m": round(values["boundary_f1_30m"]["mean"], 5),
            "ASD_m": round(values["mean_symmetric_boundary_distance_m"]["mean"], 3),
            "IoU": round(values["iou"]["mean"], 5),
        }
        for model, values in summary.items()
    }
    print(json.dumps({"summary": concise, "paired": paired, "claim_pass": claim_pass}, indent=2), flush=True)


if __name__ == "__main__":
    main()
