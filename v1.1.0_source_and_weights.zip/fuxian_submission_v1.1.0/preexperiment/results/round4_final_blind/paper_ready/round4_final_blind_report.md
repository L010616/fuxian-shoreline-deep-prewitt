# Round-4 final blind-test report

Six dates fixed before model selection were evaluated once after all configurations and checkpoints were frozen. All dates were retained; evaluation was limited to screened, jointly valid shoreline. Sentinel-2 derived references are not surveyed ground truth.

- Parallel edge fusion: Boundary F1 = 0.8947 ± 0.0012; ASD = 43.63 ± 0.15 m.
- Boundary-constrained DFANet: Boundary F1 = 0.8946 ± 0.0022; ASD = 45.55 ± 2.58 m.
- Original DFANet: Boundary F1 = 0.8796 ± 0.0068; ASD = 55.53 ± 5.20 m.

The parallel model improved Boundary F1 by 1.51 percentage points and reduced ASD by 11.90 m relative to DFANet. It also achieved the best blind-test boundary metrics, while the validation-selected boundary-constrained model was nearly tied in Boundary F1. Date-level Wilcoxon tests are descriptive because only six independent dates are available. No retraining, threshold tuning, or architecture changes are permitted after these results.
