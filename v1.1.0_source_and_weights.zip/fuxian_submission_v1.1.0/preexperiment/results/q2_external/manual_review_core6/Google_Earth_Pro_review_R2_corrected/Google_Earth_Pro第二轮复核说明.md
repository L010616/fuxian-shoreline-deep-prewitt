# Google Earth Pro人工岸线第二轮复核包（已修正跨湖闭合错误）

- HR01：Dianchi_Waihai，dry，Sentinel-2 20220312，文件 `HR01_Dianchi_Waihai_20220312_REVIEW_R2.kmz`
- HR02：Dianchi_Waihai，wet，Sentinel-2 20240828，文件 `HR02_Dianchi_Waihai_20240828_REVIEW_R2.kmz`
- HR03：Erhai，dry，Sentinel-2 20221118，文件 `HR03_Erhai_20221118_REVIEW_R2.kmz`
- HR04：Erhai，wet，Sentinel-2 20230529，文件 `HR04_Erhai_20230529_REVIEW_R2.kmz`
- HR05：Xingyun，dry，Sentinel-2 20200117，文件 `HR05_Xingyun_20200117_REVIEW_R2.kmz`
- HR06：Xingyun，wet，Sentinel-2 20241027，文件 `HR06_Xingyun_20241027_REVIEW_R2.kmz`

## 复核规则

1. 每次只打开一个R2 KMZ；包内不含模型预测和上一轮人工岸线。
2. 右击`02 EDIT THIS — corrected initial shoreline`，选择属性并拖动节点。
3. 仅依据包内同期Sentinel-2 RGB判读可见水陆交界；历史底图只能辅助定位。
4. 仅保留命名湖泊外岸线；排除岛屿、内部孔洞、入湖河道和不可判读延伸。
5. 保存为`HRxx_shoreline_REVIEWED_R2.kml`并放回相应HR目录。
6. 六期均需复核；HR01、HR02、HR04重点检查旧版曾出现跨湖伪线的岸段。