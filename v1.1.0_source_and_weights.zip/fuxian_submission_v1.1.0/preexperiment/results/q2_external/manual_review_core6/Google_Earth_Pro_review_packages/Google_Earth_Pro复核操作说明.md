# Google Earth Pro人工岸线复核包

- HR01：Dianchi_Waihai，dry，Sentinel-2 20220312，文件 `HR01_Dianchi_Waihai_20220312_REVIEW.kmz`
- HR02：Dianchi_Waihai，wet，Sentinel-2 20240828，文件 `HR02_Dianchi_Waihai_20240828_REVIEW.kmz`
- HR03：Erhai，dry，Sentinel-2 20221118，文件 `HR03_Erhai_20221118_REVIEW.kmz`
- HR04：Erhai，wet，Sentinel-2 20230529，文件 `HR04_Erhai_20230529_REVIEW.kmz`
- HR05：Xingyun，dry，Sentinel-2 20200117，文件 `HR05_Xingyun_20200117_REVIEW.kmz`
- HR06：Xingyun，wet，Sentinel-2 20241027，文件 `HR06_Xingyun_20241027_REVIEW.kmz`

## 操作

1. 在Google Earth Pro中选择“文件 → 打开”，打开一个KMZ。
2. 左侧“临时位置”展开该项目，勾选同期Sentinel-2 RGB和`EDIT THIS — shoreline candidate`。
3. 右击青色岸线 → 属性。属性窗口保持打开时，节点会显示；拖动节点修正，Delete/Backspace删除节点。
4. 仅保留命名湖泊外岸线；岛屿、内部孔洞和入湖沟渠不纳入。不可判读岸段在审核表中说明。
5. 完成后右击青色岸线 → 地点另存为，保存成KML或KMZ，文件名用`HRxx_shoreline_REVIEWED.kml`或`.kmz`。
6. 将保存文件放回对应HR文件夹。我会转换为GeoJSON、检查闭合性并计算指标。

Google Earth历史底图仅辅助识别地物。最终节点必须依据KMZ内标有日期的Sentinel-2 RGB覆盖层。