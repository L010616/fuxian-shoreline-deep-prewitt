"""Freeze prediction-blind references for the second six-date edge confirmation set."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

import finalize_additional_test_reference as finalizer


ROOT = Path(__file__).resolve().parents[1]
DATA_BASE = ROOT / "preexperiment/data/edge_confirmation_set2"
RESULT = ROOT / "preexperiment/results/edge_confirmation_set2"
DRAFT = RESULT / "reference_drafts"
PAIRS = RESULT / "evaluation_pairs.json"
FREEZE = RESULT / "edge_confirmation_set2_evaluation_freeze_manifest.json"

NOTES = {
    "2021-04-10": "Cloud affected; retain only joint-valid normal-priority shoreline segments.",
    "2021-09-01": "Partial cloud cover; retain only joint-valid normal-priority shoreline segments.",
    "2022-04-29": "Clear coverage; exclude every automatically flagged low-confidence segment.",
    "2023-02-11": "Quality replacement selected before predictions; near-complete clear coverage.",
    "2023-06-03": "Partial cloud cover; retain only joint-valid normal-priority shoreline segments.",
    "2025-02-16": "Partial Landsat coverage; retain only joint-valid normal-priority shoreline segments.",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    if FREEZE.exists():
        raise RuntimeError("Edge confirmation set 2 is already frozen; refusing to overwrite")
    source_path = DATA_BASE / "selection_manifest_final.json"
    source = json.loads(source_path.read_text(encoding="utf-8"))
    expected = "EDGE_CONFIRMATION_SET2_FINAL_SIX_INPUTS_VALIDATED_BEFORE_REFERENCE_FREEZE"
    if source.get("status") != expected or source.get("date_count") != 6:
        raise RuntimeError("Final six input dates are not ready for freezing")
    selected = [
        {
            "l8_date": row["l8_date"],
            "s2_date": row["s2_date"],
            "calendar_gap_days": row["calendar_gap_days"],
            "selection_window": row["window"],
            "season": row["season"],
        }
        for row in source["records"]
    ]
    pairs = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "FROZEN_BEFORE_MODEL_PREDICTIONS",
        "purpose": "second independent edge and matched-control confirmation",
        "all_six_dates_retained": True,
        "rejected_before_predictions": source["rejected_before_predictions"],
        "selected": selected,
    }
    RESULT.mkdir(parents=True, exist_ok=True)
    PAIRS.write_text(json.dumps(pairs, ensure_ascii=False, indent=2), encoding="utf-8")

    review = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "DATE_OVERVIEWS_REVIEWED",
        "reviewer": "Codex-assisted prediction-blind full-date visual screening",
        "model_predictions_opened": False,
        "policy": (
            "Retain all six dates; evaluate only joint-valid normal-priority shoreline and "
            "buffer every excluded high-priority segment by 30 m."
        ),
        "records": [
            {"l8_date": row["l8_date"], "accept": True, "notes": NOTES[row["l8_date"]]}
            for row in selected
        ],
    }
    review_path = DRAFT / "date_level_review_set2.json"
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")

    finalizer.DATA_ROOT = DATA_BASE / "analysis_ready"
    finalizer.DRAFT_ROOT = DRAFT
    finalizer.REVIEW = review_path
    finalizer.OUT = RESULT / "screened_reference"
    finalizer.MANIFEST = PAIRS
    finalizer.L8_TEMPLATE = "Fuxian_edgeconfirm_set2_L8_native_{l8_tag}.tif"
    finalizer.S2_TEMPLATE = "Fuxian_edgeconfirm_set2_S2_{s2_tag}_for_{l8_tag}.tif"
    finalizer.main()

    reference_manifest = finalizer.OUT / "screened_reference_manifest.json"
    frozen_reference = json.loads(reference_manifest.read_text(encoding="utf-8"))
    if len(frozen_reference["records"]) != 6:
        raise RuntimeError("Reference freeze did not retain exactly six dates")
    for row in frozen_reference["records"]:
        if row["retained_segments"] <= 0 or row["retained_length_km"] <= 0:
            raise RuntimeError(f"No retained reference shoreline for {row['l8_date']}")
    frozen_reference.update(
        {
            "dataset": "Fuxian Lake edge confirmation set 2",
            "status": "FROZEN_FOR_ONE_TIME_EDGE_CONFIRMATION_SET2_EVALUATION",
            "all_six_dates_retained": True,
            "reference_scope": "Only retained joint-valid normal-priority shoreline is eligible.",
            "allow_training": False,
            "allow_model_selection": False,
            "allow_threshold_tuning": False,
            "model_predictions_opened_before_freeze": False,
        }
    )
    reference_manifest.write_text(
        json.dumps(frozen_reference, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    depth = ROOT / "preexperiment/results/edge_depth_validation_screen"
    prior = ROOT / "preexperiment/results/round4_fusion_confirmation"
    control = ROOT / "preexperiment/results/parameter_matched_conv_control"
    seeds = (20260913, 20260929, 20261017)
    checkpoints = []
    for seed in seeds:
        for role, path in (
            ("prior_only", prior / f"prior_seed{seed}_best.pt"),
            ("fixed_log_prewitt_shallow", depth / f"edge_depth_0_seed{seed}_best.pt"),
            ("fixed_log_prewitt_deep", depth / f"edge_depth_2_seed{seed}_best.pt"),
            ("parameter_matched_ordinary_conv", control / f"matched_conv_seed{seed}_best.pt"),
        ):
            checkpoints.append(
                {
                    "role": role,
                    "seed": seed,
                    "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                    "sha256": sha256(path),
                }
            )
    freeze = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "MODELS_REFERENCES_AND_DATES_FROZEN_BEFORE_EDGE_CONFIRMATION_SET2_PREDICTIONS",
        "dates": selected,
        "rejected_before_predictions": source["rejected_before_predictions"],
        "decision_threshold": 0.5,
        "boundary_tolerances_m": [30, 60],
        "primary_comparisons": [
            "fixed_log_prewitt_deep vs prior_only",
            "fixed_log_prewitt_deep vs parameter_matched_ordinary_conv",
        ],
        "checkpoints": checkpoints,
        "input_manifest_sha256": sha256(source_path),
        "reference_manifest_sha256": sha256(reference_manifest),
        "pairs_manifest_sha256": sha256(PAIRS),
    }
    FREEZE.write_text(json.dumps(freeze, ensure_ascii=False, indent=2), encoding="utf-8")
    coverage = {
        row["l8_date"]: {
            "retained_fraction": round(row["retained_length_fraction"], 3),
            "retained_km": round(row["retained_length_km"], 2),
            "segments": row["retained_segments"],
            "sectors": row["spatial_coverage"]["occupied_12_sectors"],
        }
        for row in frozen_reference["records"]
    }
    print(json.dumps({"status": freeze["status"], "coverage": coverage}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
