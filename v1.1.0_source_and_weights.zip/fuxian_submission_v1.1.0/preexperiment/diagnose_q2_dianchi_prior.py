"""Model-independent diagnostic of the fixed JRC prior versus S2 draft."""
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject
from scipy import ndimage as ndi
import run_q2_cross_lake_zero_shot as exp
import q2_external_reference_drafts as ext

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'preexperiment/results/q2_external/screened_reference_freeze/Dianchi_prior_reference_diagnostic.png'
records=[r for r in exp.selected_records() if r['lake']=='Dianchi_Waihai']
fig,axes=plt.subplots(2,3,figsize=(10,8));
for ax,r in zip(axes.ravel(),records):
 with rasterio.open(r['paths']['l8']) as ds:
  rgb=ds.read([3,2,1]).astype('float32'); prof=ds.profile
  valid=np.all(np.isfinite(rgb)&(rgb>-9000),axis=0); chans=[]
  for b in rgb:
   lo,hi=np.percentile(b[valid],[2,98]); chans.append(np.clip((b-lo)/max(hi-lo,1e-6),0,1)**.82)
  image=np.moveaxis(np.stack(chans),0,-1)
 with rasterio.open(r['paths']['qa']) as qa:
  water=ndi.binary_fill_holes(ext.main_component(qa.read(1)>=2,qa,r['lake']))
 with rasterio.open(r['paths']['draft']) as ds:
  src=ds.read(1); src=np.where(src==255,np.nan,src).astype('float32'); dst=np.full(water.shape,np.nan,'float32')
  reproject(src,dst,src_transform=ds.transform,src_crs=ds.crs,src_nodata=np.nan,dst_transform=prof['transform'],dst_crs=prof['crs'],dst_nodata=np.nan,resampling=Resampling.average)
 ref=dst>=.5
 jrc_edge=water^ndi.binary_erosion(water); ref_edge=ref^ndi.binary_erosion(ref)
 overlay=image.copy(); overlay[ndi.binary_dilation(jrc_edge,iterations=2)]=np.array([143,162,214])/255; overlay[ndi.binary_dilation(ref_edge,iterations=1)]=np.array([217,154,174])/255
 ax.imshow(overlay);ax.set_title(r['l8_date']);ax.set_xticks([]);ax.set_yticks([])
fig.suptitle('Dianchi Waihai: JRC seed-connected outer boundary (blue) vs S2 draft (coral)')
fig.tight_layout(rect=[0,0,1,.97]);fig.savefig(OUT,dpi=250,bbox_inches='tight')
print(OUT)
