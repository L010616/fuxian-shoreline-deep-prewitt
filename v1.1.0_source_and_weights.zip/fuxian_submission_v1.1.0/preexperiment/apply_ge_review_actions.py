"""Apply the five-site Google Earth screening decisions to draft data.

This script never edits the original automatic shoreline draft. It creates a
screened draft, a two-segment redraw queue, three conservative uncertainty
zones, and training-exclusion masks aligned to the S2 and native L8 rasters.
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform_geom
from scipy.ndimage import binary_dilation


ROOT = Path(__file__).resolve().parents[1]
ANN = ROOT / "preexperiment/results/native_20200102/annotation_workspace"
OUT = ANN / "ge_corrections"
SOURCE_DRAFT = ANN / "initial_draft.json"
S2_RASTER = ROOT / "Fuxian_S2_20200102.tif"
L8_RASTER = ROOT / "Fuxian_L8_native_20200102.tif"

REDRAW_IDS = {"S2_DRAFT_104", "S2_DRAFT_107"}
LOOP_IDS = {"S2_DRAFT_185", "S2_DRAFT_186", "S2_DRAFT_187"}
ALL_IDS = REDRAW_IDS | LOOP_IDS

ACTIONS = {
    "S2_DRAFT_104": "REDRAW_MAIN_SHORE",
    "S2_DRAFT_107": "REDRAW_MAIN_SHORE",
    "S2_DRAFT_185": "EXCLUDE_LOOP_IGNORE_OBJECT",
    "S2_DRAFT_186": "EXCLUDE_LOOP_SHALLOW_WATER",
    "S2_DRAFT_187": "EXCLUDE_LOOP_SHALLOW_WATER",
}

REASONS = {
    "S2_DRAFT_104": "Draft follows a shallow-water colour boundary and park/building edges.",
    "S2_DRAFT_107": "Draft loops around overwater structures, piers, and moored boats.",
    "S2_DRAFT_185": "Closed loop is water; a small regular object is artificial or floating.",
    "S2_DRAFT_186": "No fixed land; feature is a nearshore deep/shallow transition.",
    "S2_DRAFT_187": "Elongated loop follows a shallow-water band, not a stable island.",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def line_geometry(segment: dict) -> dict:
    return {"type": "LineString", "coordinates": segment["coordinates"]}


def feature_wgs84(segment: dict, extra: dict | None = None) -> dict:
    props = copy.deepcopy(segment.get("properties", {}))
    props["segment_id"] = segment["id"]
    if extra:
        props.update(extra)
    geometry = transform_geom("EPSG:32648", "EPSG:4326", line_geometry(segment), precision=8)
    return {"type": "Feature", "geometry": geometry, "properties": props}


def bbox_polygon(segment: dict, padding_m: float = 30.0) -> dict:
    coords = np.asarray(segment["coordinates"], dtype=float)
    minx, miny = coords.min(axis=0) - padding_m
    maxx, maxy = coords.max(axis=0) + padding_m
    ring = [
        [float(minx), float(miny)],
        [float(maxx), float(miny)],
        [float(maxx), float(maxy)],
        [float(minx), float(maxy)],
        [float(minx), float(miny)],
    ]
    return {"type": "Polygon", "coordinates": [ring]}


def build_mask(raster_path: Path, segments: dict[str, dict], output_path: Path) -> dict:
    with rasterio.open(raster_path) as src:
        profile = src.profile.copy()
        resolution = abs(src.transform.a)
        shape = (src.height, src.width)

        uncertain_shapes = [(bbox_polygon(segments[sid], 30.0), 1) for sid in sorted(LOOP_IDS)]
        uncertain = rasterize(
            uncertain_shapes,
            out_shape=shape,
            transform=src.transform,
            fill=0,
            dtype="uint8",
            all_touched=True,
        ).astype(bool)

        redraw_lines = [(line_geometry(segments[sid]), 1) for sid in sorted(REDRAW_IDS)]
        redraw = rasterize(
            redraw_lines,
            out_shape=shape,
            transform=src.transform,
            fill=0,
            dtype="uint8",
            all_touched=True,
        ).astype(bool)
        redraw = binary_dilation(redraw, iterations=max(1, math.ceil(30.0 / resolution)))

        mask = np.zeros(shape, dtype=np.uint8)
        mask[uncertain] = 1
        mask[redraw & ~uncertain] = 2

        profile.update(
            driver="GTiff",
            count=1,
            dtype="uint8",
            nodata=255,
            compress="deflate",
            predictor=2,
        )
        with rasterio.open(output_path, "w", **profile) as dst:
            dst.write(mask, 1)
            dst.set_band_description(1, "training_exclusion_code")
            dst.update_tags(
                STATUS="DRAFT",
                CODE_0="usable_pending_normal_review",
                CODE_1="excluded_uncertain_loop_185_187",
                CODE_2="excluded_pending_redraw_104_107",
                BUFFER_M="30",
                REFERENCE_CAVEAT="GE dates 2018-10-21 and 2020-03-14 are not same-date truth for 2020-01-02",
            )

    values, counts = np.unique(mask, return_counts=True)
    return {
        "path": output_path.name,
        "reference_raster": raster_path.name,
        "shape": list(shape),
        "resolution_m": resolution,
        "pixel_counts": {str(int(v)): int(c) for v, c in zip(values, counts)},
        "sha256": sha256(output_path),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    original_hash = sha256(SOURCE_DRAFT)
    draft = json.loads(SOURCE_DRAFT.read_text(encoding="utf-8"))
    segments = {item["id"]: item for item in draft["segments"]}
    missing = sorted(ALL_IDS - segments.keys())
    if missing:
        raise KeyError(f"Missing target segments: {missing}")

    screened_features = []
    for item in draft["segments"]:
        if item["id"] in LOOP_IDS:
            continue
        extra = {"dataset_status": "DRAFT"}
        if item["id"] in REDRAW_IDS:
            extra.update(
                {
                    "google_earth_action": ACTIONS[item["id"]],
                    "google_earth_reason": REASONS[item["id"]],
                    "review_status": "REDRAW_REQUIRED",
                    "allow_training": False,
                }
            )
        screened_features.append(feature_wgs84(item, extra))

    screened = {
        "type": "FeatureCollection",
        "name": "shoreline_screened_DRAFT",
        "status": "DRAFT",
        "scene_date": draft.get("scene_date"),
        "allow_training": False,
        "features": screened_features,
    }
    screened_path = OUT / "shoreline_screened_DRAFT.geojson"
    write_json(screened_path, screened)

    redraw = {
        "type": "FeatureCollection",
        "name": "redraw_queue_104_107",
        "status": "REDRAW_REQUIRED",
        "allow_training": False,
        "features": [
            feature_wgs84(
                segments[sid],
                {
                    "google_earth_action": ACTIONS[sid],
                    "google_earth_reason": REASONS[sid],
                    "review_status": "REDRAW_REQUIRED",
                    "allow_training": False,
                },
            )
            for sid in sorted(REDRAW_IDS)
        ],
    }
    redraw_path = OUT / "redraw_queue_104_107.geojson"
    write_json(redraw_path, redraw)

    ignore_features = []
    for sid in sorted(LOOP_IDS):
        geom_utm = bbox_polygon(segments[sid], 30.0)
        ignore_features.append(
            {
                "type": "Feature",
                "geometry": transform_geom("EPSG:32648", "EPSG:4326", geom_utm, precision=8),
                "properties": {
                    "segment_id": sid,
                    "google_earth_action": ACTIONS[sid],
                    "google_earth_reason": REASONS[sid],
                    "buffer_m": 30,
                    "review_status": "EXCLUDED_PENDING_SAME_DATE_REVIEW",
                    "allow_training": False,
                },
            }
        )
    ignore = {
        "type": "FeatureCollection",
        "name": "ignore_zones_185_187",
        "status": "DRAFT",
        "allow_training": False,
        "features": ignore_features,
    }
    ignore_path = OUT / "ignore_zones_185_187.geojson"
    write_json(ignore_path, ignore)

    mask_records = [
        build_mask(S2_RASTER, segments, OUT / "training_exclusion_mask_S2_10m.tif"),
        build_mask(L8_RASTER, segments, OUT / "training_exclusion_mask_L8_30m.tif"),
    ]

    manifest = {
        "schema_version": "1.0",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scene_date": "2020-01-02",
        "status": "DRAFT",
        "allow_training": False,
        "source": {
            "path": str(SOURCE_DRAFT.relative_to(ROOT)),
            "feature_count": len(draft["segments"]),
            "sha256_before_and_after": original_hash,
            "original_modified": False,
        },
        "decisions": {
            "redraw_ids": sorted(REDRAW_IDS),
            "excluded_loop_ids": sorted(LOOP_IDS),
            "screened_feature_count": len(screened_features),
        },
        "outputs": {
            "screened_draft": {"path": screened_path.name, "feature_count": len(screened_features), "sha256": sha256(screened_path)},
            "redraw_queue": {"path": redraw_path.name, "feature_count": len(redraw["features"]), "sha256": sha256(redraw_path)},
            "ignore_zones": {"path": ignore_path.name, "feature_count": len(ignore_features), "sha256": sha256(ignore_path)},
            "masks": mask_records,
        },
        "reference_review": {
            "source": "Google Earth Pro historical imagery visual screening",
            "dates": ["2018-10-21", "2020-03-14"],
            "target_date": "2020-01-02",
            "caveat": "The nearest clear image is 72 days later; this screening is not independent same-date ground truth.",
        },
        "mask_codes": {"0": "usable pending normal review", "1": "uncertain loop excluded", "2": "pending redraw excluded", "255": "nodata"},
    }
    if sha256(SOURCE_DRAFT) != original_hash:
        raise RuntimeError("Original draft changed during processing")
    write_json(OUT / "ge_correction_manifest.json", manifest)

    readme = """# Google Earth 五处审查落实包（DRAFT）

本目录把五处简化审查结果落实为可执行的数据层文件，原始 `initial_draft.json` 未修改。

- `shoreline_screened_DRAFT.geojson`：删除 185、186、187 三个伪岸线环；保留 104、107，但明确标为 `REDRAW_REQUIRED`。共 200 段。
- `redraw_queue_104_107.geojson`：只含需要沿稳定陆水交界重画的 104、107。
- `ignore_zones_185_187.geojson`：三处疑点外扩 30 m 的保守忽略区。
- `training_exclusion_mask_S2_10m.tif` 与 `training_exclusion_mask_L8_30m.tif`：分别与 S2、L8 原生网格对齐。0=当前可用区，1=疑点环排除区，2=待重画岸线缓冲区，255=无数据。
- `ge_correction_manifest.json`：来源、数量、哈希、掩膜像元统计与日期限制。

所有输出仍是草稿，`allow_training=false`。Google Earth 清晰影像日期为 2018-10-21 和 2020-03-14，不能替代 2020-01-02 同日独立真值。104、107 重画并复核后，才可重新生成训练标签。
"""
    (OUT / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
