"""Create paper-facing tables, Chinese text, and a protocol audit for Q2 transfer."""
from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "preexperiment" / "results"
VERSION = "q2_cross_lake_zero_shot_v04_waihai_target"
OUT = RESULTS / VERSION
MODELS = (
    ("spatial_prior", "Spatial prior"),
    ("deep_prewitt", "Deep Prewitt"),
    ("parameter_matched_ordinary_conv", "Matched convolution"),
)
METRICS = (
    ("precision", "Precision", 4),
    ("recall", "Recall", 4),
    ("f1", "F1", 4),
    ("iou", "IoU", 4),
    ("boundary_f1_30m", "BF1-30 m", 4),
    ("mean_symmetric_boundary_distance_m", "ASD/m", 2),
)
LAKES = (
    ("lake:Dianchi_Waihai", "Dianchi Waihai"),
    ("lake:Erhai", "Erhai"),
    ("lake:Xingyun", "Xingyun"),
)


def formatted(group: dict, metric: str, digits: int) -> str:
    row = group[metric]
    return f"{row['mean']:.{digits}f} ± {row['date_sd']:.{digits}f}"


def write_table(path: Path, rows: list[list[str]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        csv.writer(stream).writerows(rows)


def main() -> None:
    data = json.loads((OUT / "cross_lake_zero_shot_results.json").read_text(encoding="utf-8"))

    header = ["Model", "n"] + [label for _, label, _ in METRICS]
    overall = [header]
    for key, label in MODELS:
        group = data["summary"][key]["all_18_dates"]
        overall.append([label, "18"] + [formatted(group, metric, digits)
                                             for metric, _, digits in METRICS])
    write_table(OUT / "Table_cross_lake_overall.csv", overall)

    by_lake = [["Model", "Lake", "n"] + [label for _, label, _ in METRICS]]
    for key, label in MODELS:
        for group_key, lake_label in LAKES:
            group = data["summary"][key][group_key]
            by_lake.append([label, lake_label, "6"] + [formatted(group, metric, digits)
                                                        for metric, _, digits in METRICS])
    write_table(OUT / "Table_cross_lake_by_lake.csv", by_lake)

    season = [["Model", "Season", "n"] + [label for _, label, _ in METRICS]]
    for key, label in MODELS:
        for season_key, season_label in (("season:dry", "Dry"), ("season:wet", "Wet")):
            group = data["summary"][key][season_key]
            season.append([label, season_label, "9"] + [formatted(group, metric, digits)
                                                         for metric, _, digits in METRICS])
    write_table(OUT / "Table_cross_lake_by_season.csv", season)

    versions = (
        ("q2_cross_lake_zero_shot_v01", "Initial audit", "Seed-connected JRC target; automated proxy audit"),
        ("q2_cross_lake_zero_shot_v02_hard_constraint", "Constraint audit", "Deterministic interior/exterior constraint"),
        ("q2_cross_lake_zero_shot_v03_outer_shore", "Outer-shore audit", "Internal holes filled before shoreline evaluation"),
        (VERSION, "Final named-target protocol", "Dianchi Waihai separated from Caohai by a fixed geographic rule"),
    )
    audit_rows = [["Version", "Status", "Target definition", "Spatial prior BF1", "Deep Prewitt BF1",
                   "Matched conv. BF1", "Spatial prior ASD/m", "Deep Prewitt ASD/m", "Matched conv. ASD/m"]]
    for version, status, definition in versions:
        content = json.loads((RESULTS / version / "cross_lake_zero_shot_results.json").read_text(encoding="utf-8"))
        values: list[str] = []
        for metric in ("boundary_f1_30m", "mean_symmetric_boundary_distance_m"):
            for model, _ in MODELS:
                values.append(f"{content['summary'][model]['all_18_dates'][metric]['mean']:.4f}"
                              if metric == "boundary_f1_30m" else
                              f"{content['summary'][model]['all_18_dates'][metric]['mean']:.2f}")
        audit_rows.append([version, status, definition] + values[:3] + values[3:])
    write_table(OUT / "protocol_correction_audit.csv", audit_rows)

    comparison = data["paired_date_effects"]["deep_prewitt_vs_spatial_prior"]
    matched = data["paired_date_effects"]["deep_prewitt_vs_parameter_matched_ordinary_conv"]
    deep = data["summary"]["deep_prewitt"]["all_18_dates"]
    text = f"""# 跨湖零样本实验：可写入论文的中文文本

## 方法

为检验模型对未见湖泊的空间外推能力，将仅在抚仙湖训练并冻结的检查点直接应用于滇池外海、洱海和星云湖。每个目标湖选取6个未参与训练、验证、阈值确定或检查点选择的日期，其中干季和湿季各3期，共18期。Sentinel-2岸线代理在查看模型预测前生成，随后依据不含模型叠加的影像质量图进行独立复核；18期全部保留并在推理前冻结。所有模型采用相同的固定空间约束和0.5阈值。由于JRC水体先验中的滇池外海与草海经狭窄水道连通，本研究依据命名制图对象，使用固定投影坐标边界将草海从滇池外海目标中剔除；该规则对全部日期和模型一致，且不依据预测误差调整。

## 结果

在18期跨湖零样本测试中，深层Prewitt模型取得Precision {deep['precision']['mean']:.4f} ± {deep['precision']['date_sd']:.4f}、Recall {deep['recall']['mean']:.4f} ± {deep['recall']['date_sd']:.4f}、F1 {deep['f1']['mean']:.4f} ± {deep['f1']['date_sd']:.4f}、IoU {deep['iou']['mean']:.4f} ± {deep['iou']['date_sd']:.4f}、30 m Boundary F1 {deep['boundary_f1_30m']['mean']:.4f} ± {deep['boundary_f1_30m']['date_sd']:.4f}和ASD {deep['mean_symmetric_boundary_distance_m']['mean']:.2f} ± {deep['mean_symmetric_boundary_distance_m']['date_sd']:.2f} m。与仅使用空间先验的模型相比，深层Prewitt分支在18/18期提高Boundary F1，平均增益为{comparison['boundary_f1_30m']['mean_improvement']:.4f}（日期自助法95% CI：{comparison['boundary_f1_30m']['bootstrap_95_ci'][0]:.4f}–{comparison['boundary_f1_30m']['bootstrap_95_ci'][1]:.4f}；配对Wilcoxon p={comparison['boundary_f1_30m']['wilcoxon_two_sided_p']:.6f}），并在18/18期降低ASD，平均减少{comparison['asd_reduction_m']['mean_improvement']:.2f} m（95% CI：{comparison['asd_reduction_m']['bootstrap_95_ci'][0]:.2f}–{comparison['asd_reduction_m']['bootstrap_95_ci'][1]:.2f} m；p={comparison['asd_reduction_m']['wilcoxon_two_sided_p']:.6f}）。与参数量匹配的普通卷积分支相比，深层Prewitt的Boundary F1平均提高{matched['boundary_f1_30m']['mean_improvement']:.4f}，但置信区间跨0且差异不显著（p={matched['boundary_f1_30m']['wilcoxon_two_sided_p']:.3f}），因此该对照仅支持具有方向一致性的边缘改进趋势，不能作为其显著优于普通卷积的证据。

## 解释边界

这里的参考为独立冻结的Sentinel-2遥感岸线代理，所得指标衡量跨传感器岸线一致性，不代表相对于现场测量岸线的绝对定位精度。整体区域指标受湖体内部大量易分类像元主导，因此应以Boundary F1和ASD作为跨湖边缘泛化的主要证据。协议修正前的v01–v03仅用于追踪目标定义问题，不纳入论文推断；正式结果仅采用v04命名湖泊外岸线协议。
"""
    (OUT / "paper_ready_cross_lake_text_cn.md").write_text(text, encoding="utf-8")

    audit = """# 跨湖实验协议修正审计

- v01发现滇池方向性距离异常：预测到参考的95%距离约5.5 km，而参考到预测距离较小。
- 模型无关的目标掩膜诊断确认，JRC种子连通水体同时包含滇池外海与草海；参考代理只对应外海。
- v02与v03分别检查硬约束和外岸线定义，仍未解决命名湖泊范围不一致。
- v04按固定地理规则分离草海，并对全部模型、日期使用同一目标范围。18个日期均保留，未按性能删除样本。
- v01–v03是协议审计运行；v04是唯一用于论文统计推断的冻结协议结果。
"""
    (OUT / "protocol_correction_audit.md").write_text(audit, encoding="utf-8")
    print(f"Final cross-lake tables and text written to {OUT}")


if __name__ == "__main__":
    main()
