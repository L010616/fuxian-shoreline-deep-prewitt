"""Tables, figures, and honest interpretation of post-review scope sensitivities."""
from __future__ import annotations
import csv
import json
import os
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"preexperiment/results/v25_supplementary_20261001"
os.environ["MPLCONFIGDIR"]=str(OUT/"matplotlib_cache")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

METRICS=("precision","recall","f1","iou","boundary_f1_30m","boundary_f1_60m","mean_symmetric_boundary_distance_m","hd95_m")
LAKES=("Dianchi_Waihai","Erhai","Xingyun")
MODELS=("spatial_prior","deep_prewitt","parameter_matched_ordinary_conv")
LABELS={"spatial_prior":"Spatial prior","deep_prewitt":"Deep Prewitt","parameter_matched_ordinary_conv":"Matched conv."}
COLORS={"spatial_prior":"#8FA2D6","deep_prewitt":"#6A5C95","parameter_matched_ordinary_conv":"#E7A889"}


def readcsv(path):return list(csv.DictReader(path.open(encoding="utf-8-sig",newline="")))
def writecsv(path,rows):
    with path.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def bootstrap(by_lake,rng):
    chosen=rng.integers(0,3,size=(100000,3)); drawn=np.empty(chosen.shape)
    arrays=[np.asarray(by_lake[l]) for l in LAKES]
    for pos in range(3):
        for i,a in enumerate(arrays):
            mask=chosen[:,pos]==i
            drawn[mask,pos]=a[rng.integers(0,len(a),size=(int(mask.sum()),len(a)))].mean(1)
    return np.quantile(drawn.mean(1),[.025,.975])


def main():
    audit=OUT/'scope_audit'
    completion=json.loads((audit/'completion.json').read_text(encoding='utf-8'))
    assert completion['n_dates']==18 and completion['original_results_reproduced']
    rows=readcsv(audit/'all_scope_per_date_seed_metrics.csv')
    assert len({r['l8_date']+'_'+r['lake'] for r in rows})==18
    # Averaging metric values over seeds is distinct from thresholding mean probability.
    grouped={}
    for r in rows:
        if r['aggregation']=='single_seed':
            k=(r['model'],r['scope'],r['lake'],r['l8_date'])
            grouped.setdefault(k,[]).append(r)
    for group in grouped.values():
        assert len(group)==3
        rows.append({**group[0],'aggregation':'seed_metric_mean','seed':'mean',
                     **{k:float(np.mean([float(r[k]) for r in group])) for k in METRICS}})
    writecsv(audit/'per_date_with_seed_metric_mean.csv',rows)
    configs=sorted({(r['scope'],r['prediction'],r['aggregation']) for r in rows if r['aggregation']!='single_seed'})
    summary,contrasts=[],[]; rng=np.random.default_rng(20261001)
    for scope,prediction,aggregation in configs:
        subset=[r for r in rows if (r['scope'],r['prediction'],r['aggregation'])==(scope,prediction,aggregation)]
        n_expected=6 if scope.startswith('manual') else 18
        for m in MODELS:
            selected=[r for r in subset if r['model']==m]
            assert len(selected)==n_expected
            result={'scope':scope,'prediction':prediction,'aggregation':aggregation,'model':m,'n_dates':len(selected)}
            for metric in METRICS:
                a=np.array([float(r[metric]) for r in selected])
                result[metric+'_mean']=float(a.mean()); result[metric+'_date_sd']=float(a.std(ddof=1))
            summary.append(result)
        lookup={(r['model'],r['lake'],r['l8_date']):r for r in subset}
        for baseline in ('spatial_prior','parameter_matched_ordinary_conv'):
            for metric,sign in (('boundary_f1_30m',1),('mean_symmetric_boundary_distance_m',-1)):
                by_lake={l:[] for l in LAKES}
                for r in subset:
                    if r['model']!='deep_prewitt':continue
                    b=lookup[(baseline,r['lake'],r['l8_date'])]
                    by_lake[r['lake']].append(sign*(float(r[metric])-float(b[metric])))
                means={l:float(np.mean(v)) for l,v in by_lake.items()}
                ci=bootstrap(by_lake,rng)
                effects=np.concatenate([np.array(v) for v in by_lake.values()])
                contrasts.append({'scope':scope,'prediction':prediction,'aggregation':aggregation,'baseline':baseline,'metric':metric,
                                  'n_dates':n_expected,'n_lakes':3,'equal_lake_mean_improvement':float(np.mean(list(means.values()))),
                                  'hierarchical_descriptive_95_low':float(ci[0]),'hierarchical_descriptive_95_high':float(ci[1]),
                                  'dates_improved':int((effects>0).sum()),'lakes_improved':int(sum(v>0 for v in means.values())),
                                  **{l+'_mean_improvement':v for l,v in means.items()}})
    writecsv(audit/'all_metrics_scope_summary.csv',summary)
    writecsv(audit/'scope_paired_lake_statistics.csv',contrasts)
    coverage=readcsv(audit/'reference_band_coverage.csv')
    coverage_summary=[]
    for ref in ('expanded_S2_spectral_proxy','manual_R2_outer_ring'):
        selected=[r for r in coverage if r['reference']==ref]
        a=np.array([float(r['coverage_fraction_on_joint_valid_ring']) for r in selected])
        coverage_summary.append({'reference':ref,'n_dates':len(a),'mean_coverage':float(a.mean()),'median_coverage':float(np.median(a)),
                                 'min_coverage':float(a.min()),'dates_ge_95_percent':int((a>=.95).sum()),
                                 'valid_ring_weighted_coverage':sum(float(r['inside_original_band_km']) for r in selected)/sum(float(r['joint_valid_outer_ring_km']) for r in selected),
                                 'valid_ring_km_total':sum(float(r['joint_valid_outer_ring_km']) for r in selected),
                                 'excluded_valid_ring_km_total':sum(float(r['outside_original_band_km']) for r in selected)})
    writecsv(audit/'reference_coverage_summary.csv',coverage_summary)
    # Raw vs constrained under the same reference and support.
    differences=[]
    ens=[r for r in rows if r['aggregation']=='probability_ensemble']
    ll={(r['model'],r['scope'],r['lake'],r['l8_date'],r['prediction']):r for r in ens}
    for r in ens:
        if r['prediction']!='raw':continue
        c=ll[(r['model'],r['scope'],r['lake'],r['l8_date'],'constrained')]
        differences.append({'model':r['model'],'scope':r['scope'],'lake':r['lake'],'l8_date':r['l8_date'],
                            **{k+'_constrained_minus_raw':float(c[k])-float(r[k]) for k in METRICS}})
    writecsv(audit/'hard_constraint_metric_differences.csv',differences)
    legacy=[r for r in differences if r['scope']=='legacy_belt']
    legacy_max={k:max(abs(r[k+'_constrained_minus_raw']) for r in legacy) for k in METRICS}
    key=lambda scope,base,metric:next(r for r in contrasts if r['scope']==scope and r['baseline']==base and r['metric']==metric and r['prediction']=='raw' and r['aggregation']=='probability_ensemble')
    focused={scope:{b:{metric:key(scope,b,metric) for metric in ('boundary_f1_30m','mean_symmetric_boundary_distance_m')}
                     for b in ('spatial_prior','parameter_matched_ordinary_conv')}
             for scope in ('legacy_belt','expanded_proxy_full','manual_full')}
    result={'completion':completion,'coverage':coverage_summary,'legacy_hard_constraint_max_differences':legacy_max,'focused_effects':focused,
            'spectral_proxy_warning':'Xingyun 2022-03-12 expanded NDWI proxy contains an apparent intralake indentation not supported clearly by RGB; never treat this automatic mask as verified ground truth. All dates retained in exploratory sensitivity; manual references form the stronger scope check.'}
    (OUT/'supplementary_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    make_figures(rows,coverage,contrasts)
    make_report(result)
    print(json.dumps(result,ensure_ascii=False,indent=2))


def make_figures(rows,coverage,contrasts):
    plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#404047'})
    fig,axes=plt.subplots(2,2,figsize=(11.0,6.5))
    ax=axes[0,0]
    p=[r for r in coverage if r['reference']=='expanded_S2_spectral_proxy']
    for l,c in zip(LAKES,('#8FA2D6','#A9C8B8','#E7A889')):
        pp=[(i,r) for i,r in enumerate(p) if r['lake']==l]
        ax.scatter([i for i,r in pp],[100*float(r['coverage_fraction_on_joint_valid_ring']) for i,r in pp],color=c,label=l.replace('_',' '),s=33)
    ax.axhline(95,color='#888888',lw=.8,ls='--');ax.set_ylim(80,101);ax.set_ylabel('Valid outer-shoreline coverage (%)')
    ax.set_xticks(range(18),[r['l8_date'][2:] for r in p],rotation=70,fontsize=8)
    ax.legend(frameon=False,fontsize=9,loc='lower left');ax.set_title('Expanded S2 proxy: diagnostic only',fontsize=11)
    ax=axes[0,1]; p=[r for r in coverage if r['reference']=='manual_R2_outer_ring']
    ax.bar(np.arange(6),[100*float(r['coverage_fraction_on_joint_valid_ring']) for r in p],color='#6A5C95',width=.62)
    ax.set_ylim(95,100.5);ax.set_ylabel('Valid manual shoreline coverage (%)')
    lake_tick_labels={'Dianchi_Waihai':'Dianchi\nWaihai','Erhai':'Erhai','Xingyun':'Xingyun'}
    ax.set_xticks(range(6),[lake_tick_labels[r['lake']]+'\n'+r['l8_date'] for r in p],rotation=0,ha='center',fontsize=8)
    ax.tick_params(axis='x',pad=7)
    ax.set_title('Six manually delineated outer rings',fontsize=11)
    for ax,metric in zip(axes[1],('boundary_f1_30m','mean_symmetric_boundary_distance_m')):
        for bi,baseline in enumerate(('spatial_prior','parameter_matched_ordinary_conv')):
            pp=[next(r for r in contrasts if r['scope']==scope and r['prediction']=='raw' and r['aggregation']=='probability_ensemble' and r['baseline']==baseline and r['metric']==metric) for scope in ('legacy_belt','expanded_proxy_full','manual_full')]
            xs=np.arange(3)+(bi-.5)*.16;v=np.array([r['equal_lake_mean_improvement'] for r in pp])
            lo=np.array([r['hierarchical_descriptive_95_low'] for r in pp]);hi=np.array([r['hierarchical_descriptive_95_high'] for r in pp])
            ax.errorbar(xs,v,yerr=[v-lo,hi-v],fmt='o' if bi==0 else 's',color='#6A5C95' if bi==0 else '#8FA2D6',capsize=3,label='vs spatial prior' if bi==0 else 'vs matched conv.')
        ax.axhline(0,color='#777777',ls='--',lw=.8);ax.set_xticks(range(3),['Original band\n18 dates','Expanded proxy\n18 dates','Manual full scope\n6 dates'])
        ax.set_ylabel('Boundary F1 gain' if metric.startswith('boundary') else 'ASD reduction (m)');ax.legend(frameon=False,loc='best',fontsize=9)
    for tag,ax in zip(('(a)','(b)','(c)','(d)'),axes.flat):
        ax.text(-.13,1.14,tag,transform=ax.transAxes,fontweight='bold',fontsize=12);ax.grid(axis='y',color='#E6E8EC',lw=.7);ax.set_axisbelow(True)
    fig.subplots_adjust(wspace=.30,hspace=.66,top=.91,bottom=.09)
    fig.savefig(OUT/'scope_sensitivity_group.png',dpi=350,bbox_inches='tight')
    fig.savefig(OUT/'scope_sensitivity_group_labels_fixed.png',dpi=350,bbox_inches='tight')
    fig.savefig(OUT/'scope_sensitivity_group.svg',bbox_inches='tight');plt.close(fig)
    temporal=readcsv(OUT/'temporal_blocks/per_episode_effects.csv')
    fig,axes=plt.subplots(1,2,figsize=(8.8,3.5))
    for ax,metric in zip(axes,('boundary_f1_30m','mean_symmetric_boundary_distance_m')):
        for i,b in enumerate(('prior_only','parameter_matched_ordinary_conv')):
            pp=[r for r in temporal if r['baseline']==b and r['metric']==metric]
            ax.plot([0,1,2],[float(r['mean_improvement']) for r in pp],marker='o' if i==0 else 's',color='#6A5C95' if i==0 else '#8FA2D6',ls='-' if i==0 else '--',label='vs spatial prior' if i==0 else 'vs matched conv.')
        ax.set_xticks(range(3),['2020 early\nn=3','2022 late\nn=2','2024 late\nn=1']);ax.axhline(0,color='#888888',ls=':',lw=.9)
        ax.set_ylabel('Boundary F1 gain' if metric.startswith('boundary') else 'ASD reduction (m)');ax.legend(frameon=False,fontsize=9,loc='best');ax.grid(color='#E6E8EC',lw=.7);ax.set_axisbelow(True)
    for tag,ax in zip(('(a)','(b)'),axes):ax.text(-.15,1.04,tag,transform=ax.transAxes,fontweight='bold',fontsize=12)
    fig.tight_layout();fig.savefig(OUT/'temporal_episode_effects.png',dpi=350,bbox_inches='tight');fig.savefig(OUT/'temporal_episode_effects.svg',bbox_inches='tight');plt.close(fig)


def make_report(result):
    f=result['focused_effects'];c=result['coverage'];t=json.loads((OUT/'temporal_blocks/temporal_statistics.json').read_text())['results']
    temporal=next(r for r in t if r['baseline']=='prior_only' and r['metric']=='mean_symmetric_boundary_distance_m')
    fmt=lambda r:f"{r['equal_lake_mean_improvement']:.4f} [{r['hierarchical_descriptive_95_low']:.4f}, {r['hierarchical_descriptive_95_high']:.4f}]"
    text=f"""# 第25版补充实验报告

这是看过原结果后的范围与统计敏感性分析，不是新的盲测。未训练、选模、改变阈值或替换日期，原正式结果全部保留。

## 岸线带覆盖

- 在扩大至固定1 km缓冲范围的18期S2光谱诊断中，原岸线带对有效外轮廓的日期平均覆盖率为{c[0]['mean_coverage']:.2%}，中位数{c[0]['median_coverage']:.2%}；{c[0]['dates_ge_95_percent']}/18期达到95%。
- 六期人工外轮廓的日期平均覆盖率为{c[1]['mean_coverage']:.2%}，最小{c[1]['min_coverage']:.2%}；有效人工岸线合计{c[1]['valid_ring_km_total']:.2f} km，带外合计{c[1]['excluded_valid_ring_km_total']:.2f} km。
- 星云湖2022-03-12的扩大S2光谱轮廓出现明显湖内凹入，RGB并不能清楚支持该自动判定。原草稿强制稳定内部为水，而新诊断仅在缺测处用JRC连接，因此该差异也包含水色造成的光谱判定失败，不能当作真实水位变化。本补充保留该日期，同时明确自动诊断不是人工或实测真值。

## 扩大评价范围后的模型对照

以下均使用原冻结的三种模型和三个种子，阈值0.5；对三个种子的概率取均值后评价，与原跨湖表的实际聚合方式一致。文件也另列逐种子指标均值，避免混淆。

|参考与范围|相对空间先验BF1增益|相对空间先验ASD降低/m|相对匹配卷积BF1增益|相对匹配卷积ASD降低/m|
|---|---|---|---|---|
"""
    for scope,label in [('legacy_belt','原18期带内'),('expanded_proxy_full','18期扩大自动参考范围（诊断）'),('manual_full','6期人工参考扩大范围')]:
        text+='|'+label+'|'+ '|'.join(fmt(f[scope][b][m]) for b in ('spatial_prior','parameter_matched_ordinary_conv') for m in ('boundary_f1_30m','mean_symmetric_boundary_distance_m'))+'|\n'
    text+=f"""
方括号为湖泊—日期两级自助法描述性95%区间，只有三个湖泊，不能作广泛湖泊总体显著性判断。区域Precision、Recall、F1、IoU、BF1@60m及HD95也已全部计算，并报告日期样本标准差，详见all_metrics_scope_summary.csv。

## 六日期时间分组

2020年三期、2022年两期、2024年一期构成三个观测时间组。深层Prewitt相对空间先验的日期平均ASD降低仍为{temporal['date_mean_improvement']:.2f} m；组等权平均降低{temporal['equal_episode_mean_improvement']:.2f} m，三个时间组方向全部为正。时间组—日期两级描述性区间为{temporal['episode_date_hierarchical_low']:.2f}—{temporal['episode_date_hierarchical_high']:.2f} m，但组层级双侧精确符号翻转检验p={temporal['episode_exact_signflip_p']:.2f}。应删除“六期完全独立”及依赖p=0.0313的强显著性措辞，改写为“六期均改善，三个时间组方向一致”。

## 复现与解释修订

本次旧版18期结果逐模型全部复现，最大指标差{result['completion']['max_original_result_difference']:.3g}。原跨湖及人工评价代码实际上施加过统一硬空间约束；现在原带内的raw/constrained对照可用于判断其是否改变数值，扩大范围需明确区分。论文不能继续笼统声称所有跨湖统计来自raw预测。

原跨湖/人工表实际上评价三个种子的平均概率，而最终抚仙湖表先逐种子评价再平均指标。论文须分别说明，或统一聚合并更新对应表；本补充同时提供两种统计，未隐瞒该差异。

建议正文采用六期人工参考扩大范围作为可信度较强的范围核查，将18期扩大自动轮廓放入补充材料作光谱与范围压力测试。不得把自动异常轮廓写成人工确认岸线，或把后审敏感性分析写成新的独立验证。
"""
    (OUT/'补充实验结果与论文修改建议.md').write_text(text,encoding='utf-8')
    a=f['manual_full']['spatial_prior']; b=f['manual_full']['parameter_matched_ordinary_conv']
    en=f"""# Draft supplementary methods and results

This post-review sensitivity analysis retained all original dates, frozen checkpoints, source normalization, and the 0.5 decision threshold. It did not constitute a new blinded confirmation experiment. The original target-lake footprint was expanded by a fixed 1-km Euclidean buffer, retaining the predefined geographic separation of Dianchi Waihai. Previously recorded NDWI thresholds were reused without tuning. Valid observed pixels were classified throughout the expanded domain; JRC water filled missing pixels only for component connectivity. The target-centre component was retained and internal holes filled. These automatic masks remain spectral diagnostics, not surveyed or manually verified ground truth. The six existing manually delineated closed outer rings were evaluated independently over the same expanded, jointly valid domain.

The original band covered a mean {c[1]['mean_coverage']*100:.2f}% of the six valid manual outer shorelines (minimum {c[1]['min_coverage']*100:.2f}%). Using raw mean-probability predictions over the expanded manual domain, lake-equal gains of deep Prewitt over spatial prior were {a['boundary_f1_30m']['equal_lake_mean_improvement']:.4f} in Boundary F1 and {a['mean_symmetric_boundary_distance_m']['equal_lake_mean_improvement']:.2f} m in ASD reduction. The respective descriptive hierarchical intervals were [{a['boundary_f1_30m']['hierarchical_descriptive_95_low']:.4f}, {a['boundary_f1_30m']['hierarchical_descriptive_95_high']:.4f}] and [{a['mean_symmetric_boundary_distance_m']['hierarchical_descriptive_95_low']:.2f}, {a['mean_symmetric_boundary_distance_m']['hierarchical_descriptive_95_high']:.2f}] m. Only three lakes were available, restricting inference to these observed targets.

The six Fuxian confirmation dates belonged to three temporal episodes (three dates in early 2020, two in late 2022, and one in late 2024). ASD reductions over spatial prior were positive in all three episodes. Their equal-episode mean was {temporal['equal_episode_mean_improvement']:.2f} m, compared with the original date-weighted mean of {temporal['date_mean_improvement']:.2f} m. A two-sided exact episode-level sign-flip test yielded p={temporal['episode_exact_signflip_p']:.2f}. Accordingly, the evidence supports consistent observed distance refinement, while significance claims based on six statistically independent dates are unwarranted.

Aggregation must be stated explicitly: the original cross-lake and manual tables used metrics of the mean probability from three seeds; the Fuxian confirmation tables used means of per-seed metrics. Both quantities are supplied in this audit. Expanded automatic S2 masks, including the questionable Xingyun 2022-03-12 spectral indentation, are diagnostic only and did not replace any frozen formal reference.
"""
    (OUT/'supplementary_methods_results_en.md').write_text(en,encoding='utf-8')


if __name__=='__main__':main()
