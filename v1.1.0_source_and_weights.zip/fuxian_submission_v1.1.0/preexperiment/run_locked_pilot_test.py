"""One-time locked pilot evaluation on the frozen screened 2025 references."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
import torch

import run_multidate_ablation_pilot as ablation
from run_multidate_ablation_pilot import AblationDFANet, predict
from run_quick_model_pilot import metrics


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/ablation_3seed_v02_corrected_labels"
REF_DIR = ROOT / "preexperiment/results/formal_test_drafts_v02/manual_review_v01/pilot_test_reference_v01"
OUT = ROOT / "preexperiment/results/locked_pilot_test_v01"
SEEDS = [20260913, 20260929, 20261017]
DATES = [
    {"l8_date": "2025-05-07", "s2_date": "2025-05-05", "split": "test"},
    {"l8_date": "2025-12-01", "s2_date": "2025-12-01", "split": "test"},
]


def apply_frozen_normalization(scenes: list[dict], stats: list[dict]) -> None:
    for scene in scenes:
        scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
        for b, stat in enumerate(stats):
            scene["x"][b] = (
                np.clip(scene["x_raw"][b], stat["p01"], stat["p99"]) - stat["mean"]
            ) / stat["std"]
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        mask_path = REF_DIR / scene["tag"] / "pilot_exclusion_mask_L8_30m.tif"
        with rasterio.open(mask_path) as src:
            exclusion = src.read(1).astype(bool)
        scene["valid"] &= ~exclusion


def macro(per_date: dict) -> dict:
    keys = (
        "precision", "recall", "f1", "iou", "boundary_f1_30m",
        "boundary_f1_60m", "mean_symmetric_boundary_distance_m",
    )
    return {key: float(np.mean([row[key] for row in per_date.values()])) for key in keys}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    reference_manifest = json.loads((REF_DIR / "pilot_test_reference_manifest.json").read_text(encoding="utf-8"))
    if reference_manifest["status"] != "FROZEN_FOR_ONE_TIME_PILOT_EVALUATION":
        raise RuntimeError("Pilot reference is not frozen")
    if not reference_manifest["allow_one_time_pilot_test_evaluation"]:
        raise RuntimeError("Pilot evaluation is not authorized by the frozen manifest")
    result_path = OUT / "pilot_test_results.json"
    if result_path.exists():
        raise RuntimeError("Locked pilot test already exists; refusing to rerun")

    ablation.DRAFTS = ROOT / "preexperiment/results/formal_test_drafts_v02"
    scenes = [ablation.read_scene(record) for record in DATES]
    config = json.loads((MODEL_DIR / "config.json").read_text(encoding="utf-8"))
    apply_frozen_normalization(scenes, config["normalization"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_results = {}
    for seed in SEEDS:
        model = AblationDFANet(prior=True, edge_mode="parallel").to(device)
        checkpoint = torch.load(
            MODEL_DIR / f"parallel_seed{seed}_best.pt",
            map_location=device,
            weights_only=False,
        )
        model.load_state_dict(checkpoint["model"])
        per_date = {}
        for scene in scenes:
            probability = predict(model, scene, device)
            raw = metrics(probability, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
            constrained = probability.copy()
            constrained[scene["interior"]] = 1.0
            constrained[scene["roi"] & ~scene["shore"] & ~scene["interior"]] = 0.0
            constrained[~scene["roi"]] = 0.0
            common = metrics(constrained, scene["y"], scene["valid"], scene["valid"] & scene["shore"])
            per_date[scene["record"]["l8_date"]] = {"raw": raw, "common_constraint": common}
        all_results[str(seed)] = {
            "checkpoint_epoch": int(checkpoint["epoch"]),
            "per_date": per_date,
            "raw_macro": macro({date: row["raw"] for date, row in per_date.items()}),
            "common_constraint_macro": macro({date: row["common_constraint"] for date, row in per_date.items()}),
        }
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    summary = {}
    for mode in ("raw_macro", "common_constraint_macro"):
        summary[mode] = {}
        for metric_name in all_results[str(SEEDS[0])][mode]:
            values = np.asarray([all_results[str(seed)][mode][metric_name] for seed in SEEDS])
            summary[mode][metric_name] = {
                "mean": float(values.mean()),
                "std": float(values.std(ddof=1)),
                "values": values.tolist(),
            }
    output = {
        "status": "LOCKED_PILOT_TEST_OPENED_ONCE",
        "paper_claim_status": "PILOT_ONLY_NOT_FINAL_SCI_TEST",
        "model": "frozen parallel LoG-Prewitt DFANet v0.2",
        "seeds": SEEDS,
        "dates": [record["l8_date"] for record in DATES],
        "decision_threshold": 0.5,
        "reference_manifest": str((REF_DIR / "pilot_test_reference_manifest.json").relative_to(ROOT)),
        "training_or_model_selection_after_test": False,
        "device": str(device),
        "results_by_seed": all_results,
        "summary": summary,
        "limitations": reference_manifest["limitations"],
    }
    result_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": output["status"], "summary": summary}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
