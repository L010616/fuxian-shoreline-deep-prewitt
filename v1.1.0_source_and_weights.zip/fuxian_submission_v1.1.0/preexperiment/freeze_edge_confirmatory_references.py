"""Prediction-blind screening and freezing of the 2018 confirmatory references."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import finalize_additional_test_reference as finalizer


ROOT = Path(__file__).resolve().parents[1]
DATA_BASE = ROOT / "preexperiment" / "data" / "edge_confirmatory_2018"
RESULT_BASE = ROOT / "preexperiment" / "results" / "edge_confirmatory_2018"
DRAFT = RESULT_BASE / "reference_drafts"
PAIRS = RESULT_BASE / "evaluation_pairs.json"

NOTES = {
    "2018-01-28": "Predominantly usable shoreline; exclude invalid and low-margin segments conservatively.",
    "2018-02-13": "Clear full-lake reference view; exclude automatically flagged low-margin segments.",
    "2018-03-01": "Clear full-lake reference view with light haze; retain only normal-priority segments.",
    "2018-04-02": "Substantial cloud and invalid coverage; retain only visible joint-valid normal-priority shoreline.",
    "2018-05-20": "Partial cloud contamination; retain only visible joint-valid normal-priority shoreline.",
    "2018-11-28": "Clear full-lake reference view; exclude automatically flagged low-margin segments.",
}


def iso_date(compact: str) -> str:
    return f"{compact[:4]}-{compact[4:6]}-{compact[6:]}"


def main() -> None:
    source = json.loads((DATA_BASE / "selection_manifest.json").read_text(encoding="utf-8"))
    selected = []
    for row in source["records"]:
        l8_date = iso_date(row["l8_date"])
        s2_date = iso_date(row["s2_target_and_actual_date"])
        d1 = datetime.strptime(l8_date, "%Y-%m-%d").date()
        d2 = datetime.strptime(s2_date, "%Y-%m-%d").date()
        selected.append(
            {
                "l8_date": l8_date,
                "s2_date": s2_date,
                "calendar_gap_days": abs((d1 - d2).days),
                "selection_source": row["source_group"],
            }
        )
    pairs = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "FROZEN_BEFORE_MODEL_PREDICTIONS",
        "purpose": "one-time independent confirmation of the formal edge-branch innovation",
        "all_prefrozen_dates_retained": True,
        "selected": selected,
    }
    PAIRS.parent.mkdir(parents=True, exist_ok=True)
    PAIRS.write_text(json.dumps(pairs, ensure_ascii=False, indent=2), encoding="utf-8")

    review = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "DATE_OVERVIEWS_REVIEWED",
        "reviewer": "Codex-assisted prediction-blind full-date visual screening",
        "model_predictions_opened": False,
        "policy": (
            "Retain every prefrozen date; evaluate only visible joint-valid shoreline and "
            "exclude every automatically high-priority segment with a 30 m buffer."
        ),
        "records": [
            {"l8_date": row["l8_date"], "accept": True, "notes": NOTES[row["l8_date"]]}
            for row in selected
        ],
    }
    review_path = DRAFT / "date_level_review.json"
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding="utf-8")

    finalizer.DATA_ROOT = DATA_BASE / "analysis_ready"
    finalizer.DRAFT_ROOT = DRAFT
    finalizer.REVIEW = review_path
    finalizer.OUT = RESULT_BASE / "screened_reference"
    finalizer.MANIFEST = PAIRS
    finalizer.L8_TEMPLATE = "Fuxian_edgeconfirm_L8_native_{l8_tag}.tif"
    finalizer.S2_TEMPLATE = "Fuxian_edgeconfirm_S2_harmonized_{s2_tag}_for_{l8_tag}.tif"
    finalizer.main()

    manifest_path = finalizer.OUT / "screened_reference_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.update(
        {
            "dataset": "Fuxian Lake 2018 edge-branch independent confirmatory set",
            "status": "FROZEN_FOR_ONE_TIME_EDGE_CONFIRMATORY_EVALUATION",
            "all_six_prefrozen_dates_retained": True,
            "reference_scope": "Only retained joint-valid normal-priority shoreline is eligible.",
            "allow_training": False,
            "allow_model_selection": False,
            "allow_threshold_tuning": False,
            "model_predictions_opened_before_freeze": False,
        }
    )
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "status": manifest["status"],
                "coverage": {
                    r["l8_date"]: {
                        "retained_fraction": round(r["retained_length_fraction"], 3),
                        "retained_km": round(r["retained_length_km"], 2),
                        "occupied_12_sectors": r["spatial_coverage"]["occupied_12_sectors"],
                    }
                    for r in manifest["records"]
                },
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
