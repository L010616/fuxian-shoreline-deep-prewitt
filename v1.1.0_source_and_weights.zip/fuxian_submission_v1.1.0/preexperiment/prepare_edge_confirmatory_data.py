from __future__ import annotations

import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio


ROOT = Path(r"D:\Document\ChatGPT\水色")
DOWNLOAD = ROOT / "drive-download-20260921T075616Z-1-001"
OUT = ROOT / "preexperiment" / "data" / "edge_confirmatory_2018"
RAW = OUT / "raw_selected"
READY = OUT / "analysis_ready"

RECORDS = [
    ("20180128", "20180127", True),
    ("20180213", "20180211", True),
    ("20180301", "20180303", False),
    ("20180402", "20180402", False),
    ("20180520", "20180522", False),
    ("20181128", "20181128", True),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def raster_info(path: Path) -> dict:
    with rasterio.open(path) as ds:
        return {
            "width": ds.width,
            "height": ds.height,
            "band_count": ds.count,
            "band_names": list(ds.descriptions),
            "dtypes": list(ds.dtypes),
            "crs": str(ds.crs),
            "transform": list(ds.transform)[:6],
            "bounds": list(ds.bounds),
            "nodata": ds.nodata,
        }


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def normalize_recovery_s2(source: Path, destination: Path) -> None:
    """Convert recovery spectral DNs to the harmonized scale.

    The recovery GEE script merged legacy and harmonized collections. Direct
    comparison on the three dates exported by both scripts showed that bands
    B2, B3, B4, B8, B11 and B12 in the recovery files equal the original
    harmonized values plus exactly 1000 DN. SCL and s2_valid are unchanged.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(source) as src:
        profile = src.profile.copy()
        profile.update(
            driver="GTiff",
            compress="DEFLATE",
            predictor=2,
            tiled=True,
            blockxsize=256,
            blockysize=256,
            nodata=0,
        )
        with rasterio.open(destination, "w", **profile) as dst:
            dst.descriptions = src.descriptions
            dst.update_tags(
                radiometric_normalization="bands 1-6: max(DN-1000, 0)",
                normalization_basis="three duplicate original/recovery pairs had exact +1000 DN offset",
            )
            for _, window in src.block_windows(1):
                data = src.read(window=window)
                spectra = data[:6].astype(np.int32) - 1000
                data[:6] = np.clip(spectra, 0, 65535).astype(np.uint16)
                dst.write(data, window=window)


def validate_profile(path: Path, kind: str) -> None:
    info = raster_info(path)
    expected = {
        "l8": (542, 1095, 7, "EPSG:32648", [30.0, 0.0, 277935.0, 0.0, -30.0, 2727015.0]),
        "s2": (1623, 3281, 8, "EPSG:32648", [10.0, 0.0, 277960.0, 0.0, -10.0, 2726990.0]),
        "mask": (542, 1095, 5, "EPSG:32648", [30.0, 0.0, 277935.0, 0.0, -30.0, 2727015.0]),
    }[kind]
    got = (info["width"], info["height"], info["band_count"], info["crs"], info["transform"])
    if got != expected:
        raise ValueError(f"Unexpected {kind} profile for {path.name}: {got}")


def verify_duplicate_offsets() -> list[dict]:
    checks = []
    for l8_date, s2_date, original_ok in RECORDS:
        if not original_ok:
            continue
        original = DOWNLOAD / f"Fuxian_edgeconfirm_S2_{s2_date}_for_{l8_date}.tif"
        recovery = DOWNLOAD / f"Fuxian_edgeconfirm_recovery_S2_target{s2_date}_for_{l8_date}.tif"
        with rasterio.open(original) as a, rasterio.open(recovery) as b:
            spectral_ok = True
            ancillary_ok = True
            compared = 0
            for _, window in a.block_windows(1):
                aa = a.read(window=window).astype(np.int32)
                bb = b.read(window=window).astype(np.int32)
                valid = (aa[:6] > 0) & (bb[:6] > 0)
                if np.any(valid):
                    spectral_ok &= bool(np.all((bb[:6] - aa[:6])[valid] == 1000))
                    compared += int(valid.sum())
                ancillary_ok &= bool(np.array_equal(aa[6:], bb[6:]))
            if not spectral_ok or not ancillary_ok:
                raise ValueError(f"Recovery offset check failed for {l8_date}")
            checks.append(
                {
                    "l8_date": l8_date,
                    "s2_date": s2_date,
                    "spectral_offset_dn": 1000,
                    "spectral_values_compared": compared,
                    "scl_and_valid_identical": True,
                }
            )
    return checks


def main() -> None:
    if not DOWNLOAD.exists():
        raise FileNotFoundError(DOWNLOAD)
    RAW.mkdir(parents=True, exist_ok=True)
    READY.mkdir(parents=True, exist_ok=True)

    duplicate_checks = verify_duplicate_offsets()
    manifest_rows = []

    for l8_date, s2_date, original_ok in RECORDS:
        l8_src = DOWNLOAD / f"Fuxian_edgeconfirm_L8_native_{l8_date}.tif"
        if original_ok:
            s2_src = DOWNLOAD / f"Fuxian_edgeconfirm_S2_{s2_date}_for_{l8_date}.tif"
            mask_src = DOWNLOAD / f"Fuxian_edgeconfirm_masks_native_{l8_date}.tif"
            source_group = "original_success"
            adjustment = 0
        else:
            s2_src = DOWNLOAD / f"Fuxian_edgeconfirm_recovery_S2_target{s2_date}_for_{l8_date}.tif"
            mask_src = DOWNLOAD / f"Fuxian_edgeconfirm_recovery_masks_native_{l8_date}.tif"
            source_group = "recovery_for_failed_original"
            # These files fill genuinely missing original exports. Their
            # dark-water DNs already occupy the expected harmonized range.
            adjustment = 0

        for source in (l8_src, s2_src, mask_src):
            if not source.exists():
                raise FileNotFoundError(source)
        validate_profile(l8_src, "l8")
        validate_profile(s2_src, "s2")
        validate_profile(mask_src, "mask")

        raw_l8 = RAW / l8_src.name
        raw_s2 = RAW / s2_src.name
        raw_mask = RAW / mask_src.name
        for source, dest in ((l8_src, raw_l8), (s2_src, raw_s2), (mask_src, raw_mask)):
            copy_file(source, dest)

        ready_l8 = READY / f"Fuxian_edgeconfirm_L8_native_{l8_date}.tif"
        ready_s2 = READY / f"Fuxian_edgeconfirm_S2_harmonized_{s2_date}_for_{l8_date}.tif"
        ready_mask = READY / f"Fuxian_edgeconfirm_masks_native_{l8_date}.tif"
        copy_file(l8_src, ready_l8)
        copy_file(mask_src, ready_mask)
        copy_file(s2_src, ready_s2)

        for path, kind in ((ready_l8, "l8"), (ready_s2, "s2"), (ready_mask, "mask")):
            validate_profile(path, kind)

        manifest_rows.append(
            {
                "l8_date": l8_date,
                "s2_target_and_actual_date": s2_date,
                "source_group": source_group,
                "recovery_spectral_adjustment_dn": adjustment,
                "raw_l8": str(raw_l8.relative_to(ROOT)),
                "raw_s2": str(raw_s2.relative_to(ROOT)),
                "raw_mask": str(raw_mask.relative_to(ROOT)),
                "analysis_l8": str(ready_l8.relative_to(ROOT)),
                "analysis_s2": str(ready_s2.relative_to(ROOT)),
                "analysis_mask": str(ready_mask.relative_to(ROOT)),
                "sha256_analysis_l8": sha256(ready_l8),
                "sha256_analysis_s2": sha256(ready_s2),
                "sha256_analysis_mask": sha256(ready_mask),
            }
        )

    ready_files = sorted(READY.glob("*.tif"))
    if len(ready_files) != 18:
        raise ValueError(f"Expected 18 analysis-ready files, found {len(ready_files)}")

    inventory = []
    for path in ready_files:
        info = raster_info(path)
        inventory.append(
            {
                "filename": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                **info,
            }
        )

    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "analysis_ready",
        "selection_rule": (
            "Keep all six successful original Landsat exports; use original Sentinel-2 and masks "
            "where the first export succeeded; use recovery Sentinel-2 and masks only where the "
            "first export failed. No radiometric adjustment is applied to selected files."
        ),
        "date_count": 6,
        "analysis_file_count": len(ready_files),
        "duplicate_offset_evidence": duplicate_checks,
        "records": manifest_rows,
        "excluded_downloads": sorted(
            p.name
            for p in DOWNLOAD.glob("*.tif")
            if p.name not in {Path(r[k]).name for r in manifest_rows for k in ("raw_l8", "raw_s2", "raw_mask")}
        ),
    }
    (OUT / "selection_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (OUT / "analysis_inventory.json").write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (OUT / "analysis_inventory.csv").open("w", encoding="utf-8-sig", newline="") as f:
        fields = ["filename", "bytes", "sha256", "width", "height", "band_count", "band_names", "dtypes", "crs", "transform", "bounds", "nodata"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in inventory:
            writer.writerow({k: row[k] for k in fields})

    readme = f"""# Fuxian Lake 2018 independent confirmatory set

- Six Landsat 8 dates, six paired Sentinel-2 dates, and six quality-mask files.
- `raw_selected/` preserves the 18 selected GEE exports without modification.
- `analysis_ready/` contains the 18 inputs to use in reference preparation and locked evaluation.
- No radiometric adjustment is applied to the three recovery files used to fill failed exports; their dark-water values are already in the expected harmonized range.
- Three redundant recovery files were excluded because corresponding original exports already existed. In those duplicate pairs the recovery spectral values were exactly +1000 DN while SCL and `s2_valid` were identical, confirming that mixing the duplicate versions would be inconsistent.
- Do not inspect model predictions until reference masks and quality-based exclusions have been frozen.

Analysis-ready dates:
"""
    for row in manifest_rows:
        readme += f"\n- L8 {row['l8_date']} / S2 {row['s2_target_and_actual_date']} / {row['source_group']}"
    readme += "\n"
    (OUT / "README.md").write_text(readme, encoding="utf-8")

    print(json.dumps({"out": str(OUT), "raw_files": len(list(RAW.glob('*.tif'))), "analysis_files": len(ready_files)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
