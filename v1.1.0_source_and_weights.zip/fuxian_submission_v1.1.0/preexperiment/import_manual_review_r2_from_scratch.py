"""Import the six from-scratch human shorelines from Google Earth Pro.

This review round is kept separate from the earlier sequential review because
the earlier initial candidates contained a forced-closure defect.  The user
redrew all six shorelines manually from the exact-date Sentinel-2 overlays.
"""
from __future__ import annotations

import csv
import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import numpy as np
from rasterio.warp import transform
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "人工审核-1"
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
MANIFEST = json.loads((PACK / "manual_review_manifest.json").read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_kml(path: Path) -> list[list[float]]:
    root = ET.parse(path).getroot()
    ns = {"k": "http://www.opengis.net/kml/2.2"}
    lines = root.findall(".//k:LineString", ns)
    if len(lines) != 1:
        raise RuntimeError(f"{path.name}: expected one LineString, found {len(lines)}")
    text = lines[0].findtext("k:coordinates", default="", namespaces=ns)
    coords = [[float(v.split(",")[0]), float(v.split(",")[1])] for v in text.split()]
    if len(coords) < 4:
        raise RuntimeError(f"{path.name}: too few vertices")
    return coords


def read_geojson(path: Path) -> list[list[float]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    lines = [f["geometry"]["coordinates"] for f in payload.get("features", [])
             if (f.get("geometry") or {}).get("type") == "LineString"]
    if len(lines) != 1:
        raise RuntimeError(f"{path}: expected one LineString")
    return lines[0]


def projected(coords: list[list[float]]) -> np.ndarray:
    a = np.asarray(coords, dtype=float)
    zone = int((float(a[:, 0].mean()) + 180) // 6) + 1
    x, y = transform("EPSG:4326", f"EPSG:{32600 + zone}",
                     a[:, 0].tolist(), a[:, 1].tolist())
    return np.column_stack([x, y])


def densify(points: np.ndarray, step: float = 5.0) -> np.ndarray:
    out = []
    for start, end in zip(points[:-1], points[1:]):
        n = max(1, int(np.ceil(np.linalg.norm(end - start) / step)))
        out.extend(start + (end - start) * i / n for i in range(n))
    out.append(points[-1])
    return np.asarray(out)


def distance_summary(a: np.ndarray, b: np.ndarray) -> dict:
    da, db = densify(a), densify(b)
    values = np.concatenate([cKDTree(db).query(da)[0], cKDTree(da).query(db)[0]])
    return {
        "candidate_distance_median_m": float(np.median(values)),
        "candidate_distance_mean_m": float(np.mean(values)),
        "candidate_distance_p95_m": float(np.percentile(values, 95)),
        "candidate_distance_max_m": float(values.max()),
        "candidate_fraction_gt_10m": float(np.mean(values > 10)),
        "candidate_fraction_gt_20m": float(np.mean(values > 20)),
        "candidate_fraction_gt_30m": float(np.mean(values > 30)),
    }


def main() -> None:
    records = []
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    for scene in MANIFEST["scenes"]:
        sid = scene["scene_id"]
        source = SOURCE / f"{sid}_shoreline_REVIEWED_R2.kml"
        if not source.exists():
            raise FileNotFoundError(source)
        coords = read_kml(source)
        xy = projected(coords)
        gap = float(np.linalg.norm(xy[0] - xy[-1]))
        if gap > 0.05:
            raise RuntimeError(f"{sid}: endpoint gap {gap:.3f} m")
        segments = np.linalg.norm(np.diff(xy, axis=0), axis=1)
        length = float(segments.sum())
        candidate_path = PACK / sid / "shoreline_CORRECTED_INITIAL.geojson"
        candidate_xy = projected(read_geojson(candidate_path))

        feature = {
            "type": "Feature",
            "properties": {
                "scene_id": sid, "lake": scene["lake"], "season": scene["season"],
                "l8_date": scene["l8_date"], "s2_date": scene["s2_date"],
                "status": "SINGLE_HUMAN_REVIEWER_FROM_SCRATCH_R2",
                "review_protocol": "prediction_blind_from_scratch_manual_digitization",
                "source_kml": str(source), "source_kml_sha256": digest(source),
                "reviewer": "USER_HUMAN_REVIEWER", "length_m": round(length, 3),
                "manual_uncertainty_nominal_m": 10,
                "manual_uncertainty_sensitivity_m": [-20, -10, 0, 10, 20],
                "created_at": now,
            },
            "geometry": {"type": "LineString", "coordinates": coords},
        }
        out = PACK / sid / "shoreline_REVIEWED_R2.geojson"
        out.write_text(json.dumps({"type": "FeatureCollection", "features": [feature]},
                                  ensure_ascii=False, indent=2), encoding="utf-8")
        records.append({
            "scene_id": sid, "lake": scene["lake"], "season": scene["season"],
            "l8_date": scene["l8_date"], "s2_date": scene["s2_date"],
            "vertices": len(coords), "closed": True, "closure_m": gap,
            "length_m": length, "max_segment_m": float(segments.max()),
            "segments_gt_300m": int(np.sum(segments > 300)),
            "segments_gt_500m": int(np.sum(segments > 500)),
            **distance_summary(xy, candidate_xy),
            "source_kml_sha256": digest(source),
            "reviewed_geojson": str(out), "reviewed_geojson_sha256": digest(out),
        })

    with (PACK / "manual_review_R2_geometry_qc.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)
    (PACK / "manual_review_R2_geometry_qc.json").write_text(json.dumps({
        "created_at": now,
        "review_stage": "single_human_reviewer_from_scratch_R2",
        "previous_review_geometry_visible": False,
        "model_predictions_visible": False,
        "uncertainty_policy": "nominal 10 m; sensitivity by 10 m and 20 m inward/outward raster perturbations",
        "records": records,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
