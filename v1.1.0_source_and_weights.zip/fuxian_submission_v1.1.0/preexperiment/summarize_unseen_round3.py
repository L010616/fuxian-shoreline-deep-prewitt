"""Create paper-ready summaries and paired tests for unseen-date evaluation."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/unseen_test_round3"
RESULT = BASE / "locked_evaluation/unseen_test_results.json"
OUT = BASE / "paper_ready"
DISPLAY = {
    "dfanet": "DFANet",
    "prior": "Boundary-constrained DFANet",
    "log": "LoG-enhanced DFANet",
    "prewitt": "Prewitt-enhanced DFANet",
    "parallel": "Parallel LoG-Prewitt DFANet",
    "unet_resnet18": "U-Net",
    "deeplabv3plus_resnet18": "DeepLabV3+",
    "segformer_mit_b0": "SegFormer",
}
METRICS = ["precision", "recall", "f1", "iou", "boundary_f1_30m",
           "boundary_f1_60m", "mean_symmetric_boundary_distance_m", "hd95_m"]


def paired_date_values(data: dict, model: str, metric: str) -> np.ndarray:
    """Return one value per independent date after averaging random seeds."""
    values = []
    for date in data["dates"]:
        seed_values = [
            data["results"][model][str(seed)]["per_date"][date]["raw"][metric]
            for seed in data["seeds"]
        ]
        values.append(float(np.mean(seed_values)))
    return np.asarray(values, dtype=float)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    data = json.loads(RESULT.read_text(encoding="utf-8"))
    rows = []
    for model, name in DISPLAY.items():
        summary = data["summary"][model]["raw_macro"]
        rows.append({
            "model": name,
            "precision_mean": summary["precision"]["mean"],
            "precision_sd": summary["precision"]["std"],
            "recall_mean": summary["recall"]["mean"],
            "recall_sd": summary["recall"]["std"],
            "f1_mean": summary["f1"]["mean"],
            "f1_sd": summary["f1"]["std"],
            "iou_mean": summary["iou"]["mean"],
            "iou_sd": summary["iou"]["std"],
            "boundary_f1_30m_mean": summary["boundary_f1_30m"]["mean"],
            "boundary_f1_30m_sd": summary["boundary_f1_30m"]["std"],
            "asd_m_mean": summary["mean_symmetric_boundary_distance_m"]["mean"],
            "asd_m_sd": summary["mean_symmetric_boundary_distance_m"]["std"],
            "hd95_m_mean": summary["hd95_m"]["mean"],
            "hd95_m_sd": summary["hd95_m"]["std"],
        })
    with (OUT / "table_unseen_five_date_model_comparison.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)

    tests = []
    parallel_bf = paired_date_values(data, "parallel", "boundary_f1_30m")
    parallel_asd = paired_date_values(data, "parallel", "mean_symmetric_boundary_distance_m")
    for model in DISPLAY:
        if model == "parallel":
            continue
        bf = paired_date_values(data, model, "boundary_f1_30m")
        asd = paired_date_values(data, model, "mean_symmetric_boundary_distance_m")
        tests.append({
            "comparison": f"parallel_vs_{model}",
            "n_independent_dates": len(bf),
            "bf1_difference_parallel_minus_comparator": float(np.mean(parallel_bf - bf)),
            "bf1_wilcoxon_p_two_sided": float(wilcoxon(parallel_bf, bf).pvalue),
            "asd_difference_m_parallel_minus_comparator": float(np.mean(parallel_asd - asd)),
            "asd_wilcoxon_p_two_sided": float(wilcoxon(parallel_asd, asd).pvalue),
        })
    with (OUT / "paired_tests_parallel.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=tests[0].keys())
        writer.writeheader(); writer.writerows(tests)

    per_date_rows = []
    for model, name in DISPLAY.items():
        for date in data["dates"]:
            for metric in ("boundary_f1_30m", "mean_symmetric_boundary_distance_m", "iou"):
                vals = np.asarray([
                    data["results"][model][str(seed)]["per_date"][date]["raw"][metric]
                    for seed in data["seeds"]
                ])
                per_date_rows.append({
                    "model": name, "date": date, "metric": metric,
                    "mean": float(vals.mean()), "sd": float(vals.std(ddof=1)),
                })
    with (OUT / "per_date_metrics.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=per_date_rows[0].keys())
        writer.writeheader(); writer.writerows(per_date_rows)

    parallel = next(r for r in rows if r["model"] == DISPLAY["parallel"])
    prior = next(r for r in rows if r["model"] == DISPLAY["prior"])
    dfanet = next(r for r in rows if r["model"] == DISPLAY["dfanet"])
    log = next(r for r in rows if r["model"] == DISPLAY["log"])
    report = f"""# 新增未使用日期独立测试结果

## 数据状态

- 下载6个日期，其中2024-05-04已在旧测试中使用，已排除。
- 最终新增5个未参与训练、验证、阈值选择或既有测试的日期。
- 参考岸线为Sentinel-2自动草稿经保守筛选所得，所有低置信岸段及其30 m缓冲区均不参与评价。
- 8种模型均使用已冻结检查点、0.5固定阈值和3个随机种子，未在新增日期上训练或调参。

## 主要结果

并联LoG-Prewitt模型的Boundary F1@30 m为{parallel['boundary_f1_30m_mean']:.4f}±{parallel['boundary_f1_30m_sd']:.4f}，平均岸线偏移为{parallel['asd_m_mean']:.2f}±{parallel['asd_m_sd']:.2f} m，IoU为{parallel['iou_mean']:.4f}±{parallel['iou_sd']:.4f}。相较原始DFANet，其Boundary F1提高{parallel['boundary_f1_30m_mean']-dfanet['boundary_f1_30m_mean']:.4f}，平均岸线偏移减少{dfanet['asd_m_mean']-parallel['asd_m_mean']:.2f} m。

仅边界约束模型取得最高Boundary F1（{prior['boundary_f1_30m_mean']:.4f}）和最低平均岸线偏移（{prior['asd_m_mean']:.2f} m）；LoG单分支模型也略优于并联模型（Boundary F1={log['boundary_f1_30m_mean']:.4f}，平均岸线偏移={log['asd_m_mean']:.2f} m）。因此新增独立测试支持空间边界约束的有效性，也支持边缘特征相对原始DFANet的总体增益，但不支持“并联模型稳定优于所有消融模型”的表述。

## 写作建议

论文应将核心贡献收紧为“空间先验约束显著缩小复杂背景误差，边缘分支进一步改变局部边界响应”，避免声称并联结构在所有数据上最优。若仍以并联结构为最终模型，需要补充融合权重或门控机制的验证；该改动必须使用训练/验证集完成，不能再依据这5个已开启的测试日期选择模型。
"""
    (OUT / "新增五日期实验报告.md").write_text(report, encoding="utf-8")
    print(json.dumps({"table_rows": len(rows), "paired_tests": tests, "report": str(OUT / '新增五日期实验报告.md')}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
