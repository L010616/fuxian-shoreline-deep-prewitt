"""Image-based QC for an expanded-proxy excursion, with no reference edits."""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"preexperiment/results/v25_supplementary_20261001"
os.environ["MPLCONFIGDIR"]=str(OUT/"matplotlib_cache")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import rasterio
from scipy import ndimage as ndi
import run_q2_cross_lake_zero_shot as base


def main():
    record=next(r for r in base.selected_records() if r['lake']=='Xingyun' and r['l8_date']=='20220312')
    s=base.read_scene(record)
    arrays=dict(np.load(OUT/'scope_audit/references/Xingyun_20220312.npz'))
    with rasterio.open(record['paths']['s2']) as src:
        rgb=src.read([3,2,1],out_shape=(3,*s['y'].shape)).astype(float).transpose(1,2,0)
    rgb=np.clip((rgb-100)/3200,0,1)**.8
    rgb[~np.all(np.isfinite(rgb),axis=2)]=1
    rr,cc=np.where(arrays['wide'])
    r0,r1=max(0,rr.min()-8),min(rgb.shape[0],rr.max()+9)
    c0,c1=max(0,cc.min()-8),min(rgb.shape[1],cc.max()+9)
    sl=np.s_[r0:r1,c0:c1]
    fig,ax=plt.subplots(1,2,figsize=(8.8,4.8))
    for a in ax:
        a.imshow(rgb[sl]);a.set_axis_off()
    ax[0].contour(arrays['old_truth'][sl],levels=[.5],colors=['#6A5C95'],linewidths=1.4)
    ax[1].contour(arrays['wide_truth'][sl],levels=[.5],colors=['#E7A889'],linewidths=1.4)
    for a in ax:
        a.contour(arrays['wide'][sl],levels=[.5],colors=['#85858A'],linewidths=.8,linestyles='--')
    ax[0].set_title('(a) Original band-restricted S2 proxy',fontsize=11)
    ax[1].set_title('(b) Expanded S2 proxy: scope diagnostic',fontsize=11)
    fig.legend([Line2D([0],[0],color='#6A5C95',lw=1.8),Line2D([0],[0],color='#E7A889',lw=1.8),Line2D([0],[0],color='#85858A',ls='--')],
               ['Original proxy','Expanded proxy','Fixed expanded domain'],loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,.98),fontsize=10)
    fig.subplots_adjust(top=.87,bottom=.04,wspace=.10)
    fig.savefig(OUT/'scope_audit/Xingyun_20220312_reference_scope_qc.png',dpi=250,bbox_inches='tight')
    plt.close(fig)


if __name__=='__main__':main()
