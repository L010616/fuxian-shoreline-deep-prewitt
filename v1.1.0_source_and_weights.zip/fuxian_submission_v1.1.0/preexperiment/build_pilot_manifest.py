"""Build a provisional 12-date pilot from observed Landsat QA, pending S2 review."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = json.loads((ROOT / 'results/landsat8_shore_qa_2020_2025.json').read_text(encoding='utf8'))
by_date = {r['date']: r for r in rows}
dates = [
    ('2020-01-18','train','early-year clear example'),
    ('2020-05-09','train','May example'),
    ('2021-05-12','train','May example with higher scene cloud but clear shore'),
    ('2021-11-20','train','late-year clear example'),
    ('2022-04-13','train','April clear example'),
    ('2022-08-19','train','August example'),
    ('2023-01-26','validation','clear validation example'),
    ('2023-05-18','validation','partial valid shore; common mask required'),
    ('2024-05-04','test','held-out May example'),
    ('2024-08-24','test','held-out August example'),
    ('2025-05-07','test','held-out May example'),
    ('2025-12-01','test','held-out late-year example'),
]
manifest=[]
for date,split,reason in dates:
    row=dict(by_date[date])
    assert row['shore_valid']>=0.8
    row.update(split=split,selection_reason=reason,
               status='PROVISIONAL_PENDING_S2_PAIR_QA_AND_VISUAL_REVIEW',
               s2_reference_date=None,reference_label=None,
               label_status='NOT_CREATED',allow_training=False)
    manifest.append(row)
result={
    'purpose':'Initial data-preparation pilot, not the final paper sample size',
    'source':'results/landsat8_shore_qa_2020_2025.json',
    'selection':'Manual calendar coverage from observed QA; no model results inspected',
    'test_rule':'Test dates remain held out from model/threshold selection',
    'records':manifest,
}
(ROOT/'results/pilot_manifest_provisional.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
summary=[]
for year in range(2020,2026):
    subset=[r for r in rows if r['year']==year]
    summary.append({'year':year,'screened':len(subset),
                    'shore_valid_ge_90':sum(r['shore_valid']>=.9 for r in subset),
                    'shore_valid_ge_80':sum(r['shore_valid']>=.8 for r in subset)})
(ROOT/'results/shore_qa_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps({'provisional_dates':len(manifest),'year_summary':summary},indent=2))
