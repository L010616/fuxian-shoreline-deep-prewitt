"""Create manuscript-ready CSV/Markdown tables from frozen development results."""
from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "preexperiment/results"
OUT = ROOT / "preexperiment/manuscript_ready"
METRICS = [
    ("precision", "Precision"), ("recall", "Recall"), ("f1", "F1"),
    ("iou", "IoU"), ("boundary_f1_30m", "Boundary F1 30 m"),
    ("boundary_f1_60m", "Boundary F1 60 m"),
    ("mean_symmetric_boundary_distance_m", "Mean boundary distance (m)"),
]


def fmt(cell: dict, digits: int = 4) -> str:
    return f"{cell['mean']:.{digits}f} ± {cell['std']:.{digits}f}"


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ablation = json.loads((RESULTS / "ablation_3seed_v02_corrected_labels/summary_mean_std.json").read_text(encoding="utf-8"))
    labels = {"dfanet": "DFANet", "prior": "DFANet + spatial prior", "log": "+ LoG", "prewitt": "+ Prewitt", "parallel": "Parallel LoG–Prewitt"}
    ablation_rows = []
    for key, label in labels.items():
        values = ablation[key]["raw"]
        row = {"Model": label}
        for metric, title in METRICS:
            row[title] = fmt(values[metric], 2 if metric.endswith("_m") else 4)
        ablation_rows.append(row)
    write_csv(OUT / "table_ablation_3seed.csv", ablation_rows)

    comparison = json.loads((RESULTS / "fair_comparison_3seed_corrected_labels_v03/summary_mean_std.json").read_text(encoding="utf-8"))
    cmp_labels = {
        "proposed_parallel": "Proposed", "unet_resnet18": "U-Net",
        "deeplabv3plus_resnet18": "DeepLabV3+", "segformer_mit_b0": "SegFormer-B0",
    }
    comparison_rows = []
    for key, label in cmp_labels.items():
        values = comparison[key]["raw"]
        row = {"Model": label}
        for metric, title in METRICS:
            row[title] = fmt(values[metric], 2 if metric.endswith("_m") else 4)
        comparison_rows.append(row)
    write_csv(OUT / "table_model_comparison_3seed.csv", comparison_rows)

    proposed = comparison["proposed_parallel"]["raw"]
    gains = []
    for key, label in list(cmp_labels.items())[1:]:
        base = comparison[key]["raw"]
        gains.append({
            "Compared with": label,
            "IoU difference": f"{proposed['iou']['mean'] - base['iou']['mean']:+.4f}",
            "Boundary F1 30 m difference": f"{proposed['boundary_f1_30m']['mean'] - base['boundary_f1_30m']['mean']:+.4f}",
            "Boundary distance reduction (m)": f"{base['mean_symmetric_boundary_distance_m']['mean'] - proposed['mean_symmetric_boundary_distance_m']['mean']:+.2f}",
            "Boundary distance reduction (%)": f"{100 * (base['mean_symmetric_boundary_distance_m']['mean'] - proposed['mean_symmetric_boundary_distance_m']['mean']) / base['mean_symmetric_boundary_distance_m']['mean']:.1f}%",
        })
    write_csv(OUT / "table_model_improvements.csv", gains)

    note = """# 可直接用于论文的冻结开发结果表

本目录中的表格由数据集 v0.2 的冻结 JSON 自动生成，数值均为 3 个随机种子的均值 ± 样本标准差。它们可用于论文的消融实验和模型对比部分，但应表述为独立验证集结果；最终测试集结果将在新增两个日期完成后单独生成。

- `table_ablation_3seed.csv`：DFANet、空间先验、单 LoG、单 Prewitt、并联模型。
- `table_model_comparison_3seed.csv`：本文方法与 U-Net、DeepLabV3+、SegFormer-B0。
- `table_model_improvements.csv`：本文方法相对各基线的绝对提升和边界距离降幅。

3 个随机种子不足以支撑可靠的显著性检验，正文报告均值、标准差和逐日期稳定性即可，不应使用 p 值制造过强结论。
"""
    (OUT / "README.md").write_text(note, encoding="utf-8")
    print(json.dumps({"output": str(OUT), "tables": 3}, ensure_ascii=False))


if __name__ == "__main__":
    main()
