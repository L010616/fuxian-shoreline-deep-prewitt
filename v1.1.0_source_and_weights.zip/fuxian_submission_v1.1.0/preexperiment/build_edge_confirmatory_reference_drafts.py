"""Build prediction-blind Sentinel-2 shoreline drafts for the 2018 edge test."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "data" / "edge_confirmatory_2018"
MANIFEST = BASE / "selection_manifest.json"
OUT = ROOT / "preexperiment" / "results" / "edge_confirmatory_2018" / "reference_drafts"


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest.get("status") != "analysis_ready":
        raise RuntimeError("Confirmatory inputs are not frozen and analysis-ready")

    builder.DATA_ROOT = BASE / "analysis_ready"
    builder.OUT = OUT
    builder.L8_TEMPLATE = "Fuxian_edgeconfirm_L8_native_{l8_tag}.tif"
    builder.S2_TEMPLATE = "Fuxian_edgeconfirm_S2_harmonized_{s2_tag}_for_{l8_tag}.tif"
    builder.MASK_TEMPLATE = "Fuxian_edgeconfirm_masks_native_{l8_tag}.tif"
    OUT.mkdir(parents=True, exist_ok=True)

    records = []
    for row in manifest["records"]:
        records.append(
            {
                "l8_date": f"{row['l8_date'][:4]}-{row['l8_date'][4:6]}-{row['l8_date'][6:]}",
                "s2_date": (
                    f"{row['s2_target_and_actual_date'][:4]}-"
                    f"{row['s2_target_and_actual_date'][4:6]}-"
                    f"{row['s2_target_and_actual_date'][6:]}"
                ),
                "calendar_gap_days": abs(
                    __import__("datetime").datetime.strptime(row["l8_date"], "%Y%m%d").date()
                    - __import__("datetime").datetime.strptime(row["s2_target_and_actual_date"], "%Y%m%d").date()
                ).days,
                "split": "edge_confirmatory_test",
            }
        )

    results = [builder.build_one(record) for record in records]
    payload = {
        "dataset": "Fuxian Lake 2018 edge-branch independent confirmatory reference drafts",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_PREDICTION_BLIND_SCREENING",
        "allow_training": False,
        "allow_model_selection": False,
        "allow_threshold_tuning": False,
        "allow_evaluation": False,
        "model_predictions_opened": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(r["segment_count"] for r in results),
            "high_priority_segments": sum(r["high_priority_segments"] for r in results),
        },
    }
    (OUT / "draft_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload["totals"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
