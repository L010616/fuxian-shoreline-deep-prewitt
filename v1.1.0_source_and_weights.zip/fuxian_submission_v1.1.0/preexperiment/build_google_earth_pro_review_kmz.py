"""Build six corrected Google Earth Pro review packages.

Each KMZ contains the exact-date Sentinel-2 RGB and the topology-safe initial
shoreline as an editable KML path. Model predictions and prior reviews are not
included, so this remains a model-blind independent review.
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np
import rasterio
from PIL import Image
from rasterio.enums import Resampling
from rasterio.transform import array_bounds
from rasterio.warp import calculate_default_transform, reproject


ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
MANIFEST = json.loads((PACK / "manual_review_manifest.json").read_text(encoding="utf-8"))


def stretch(rgb: np.ndarray, valid: np.ndarray) -> np.ndarray:
    out = np.zeros_like(rgb, dtype=np.uint8)
    for index in range(3):
        values = rgb[index][valid & np.isfinite(rgb[index])]
        low, high = np.percentile(values, (2, 98))
        out[index] = np.clip((rgb[index] - low) / max(high - low, 1e-6) * 255, 0, 255).astype(np.uint8)
    return out


def rgb_png(source: Path, target: Path) -> tuple[float, float, float, float]:
    with rasterio.open(source) as src:
        raw = src.read([3, 2, 1]).astype("float32")  # B4, B3, B2
        valid = src.read(8) > 0 if src.count >= 8 else np.all(raw > 0, axis=0)
        image = stretch(raw, valid)
        dst_transform, width, height = calculate_default_transform(
            src.crs, "EPSG:4326", src.width, src.height, *src.bounds
        )
        warped = np.zeros((4, height, width), dtype=np.uint8)
        for band in range(3):
            reproject(image[band], warped[band], src_transform=src.transform, src_crs=src.crs,
                      dst_transform=dst_transform, dst_crs="EPSG:4326",
                      resampling=Resampling.bilinear)
        reproject(valid.astype(np.uint8) * 255, warped[3], src_transform=src.transform,
                  src_crs=src.crs, dst_transform=dst_transform, dst_crs="EPSG:4326",
                  resampling=Resampling.nearest)
    Image.fromarray(np.moveaxis(warped, 0, -1), mode="RGBA").save(target, optimize=True)
    south, west, north, east = array_bounds(height, width, dst_transform)
    return west, south, east, north


def kml_text(scene: dict, bounds: tuple[float, float, float, float], coordinates: list) -> str:
    west, south, east, north = bounds
    coord_text = " ".join(f"{x:.8f},{y:.8f},0" for x, y in coordinates)
    label = f"{scene['scene_id']} {scene['lake']} {scene['season']} S2 {scene['s2_date']}"
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>{escape(label)} — corrected model-blind review R2</name>
    <description>Exact-date Sentinel-2 RGB and topology-safe initial shoreline. No model prediction or previous reviewed shoreline is included.</description>
    <Style id="shore"><LineStyle><color>ff00ffff</color><width>3</width></LineStyle><PolyStyle><fill>0</fill></PolyStyle></Style>
    <GroundOverlay>
      <name>01 Exact-date Sentinel-2 RGB ({escape(scene['s2_date'])})</name>
      <Icon><href>exact_date_sentinel2_rgb.png</href></Icon>
      <LatLonBox><north>{north:.10f}</north><south>{south:.10f}</south><east>{east:.10f}</east><west>{west:.10f}</west></LatLonBox>
    </GroundOverlay>
    <Placemark>
      <name>02 EDIT THIS — corrected initial shoreline</name>
      <description>Independent R2 review. Keep one closed named-lake outer shoreline. Exclude islands, internal holes, and inlet channels. Save as HRxx_shoreline_REVIEWED_R2.kml.</description>
      <styleUrl>#shore</styleUrl>
      <LineString><tessellate>1</tessellate><altitudeMode>clampToGround</altitudeMode><coordinates>{coord_text}</coordinates></LineString>
    </Placemark>
  </Document>
</kml>'''


def main() -> None:
    out = PACK / "Google_Earth_Pro_review_R2_corrected"
    out.mkdir(exist_ok=True)
    lines = ["# Google Earth Pro人工岸线第二轮复核包（已修正跨湖闭合错误）", ""]
    for scene in MANIFEST["scenes"]:
        scene_dir = PACK / scene["scene_id"]
        candidate = json.loads((scene_dir / "shoreline_CORRECTED_INITIAL.geojson").read_text(encoding="utf-8"))
        coords = candidate["features"][0]["geometry"]["coordinates"]
        png = out / f"{scene['scene_id']}_exact_date_sentinel2_rgb.png"
        bounds = rgb_png(Path(scene["inputs"]["sentinel2_multiband"]), png)
        kml = kml_text(scene, bounds, coords)
        kmz = out / f"{scene['scene_id']}_{scene['lake']}_{scene['s2_date']}_REVIEW_R2.kmz"
        with zipfile.ZipFile(kmz, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("doc.kml", kml)
            archive.write(png, "exact_date_sentinel2_rgb.png")
        png.unlink()
        lines.append(f"- {scene['scene_id']}：{scene['lake']}，{scene['season']}，Sentinel-2 {scene['s2_date']}，文件 `{kmz.name}`")
        print(kmz)
    lines += [
        "", "## 复核规则", "",
        "1. 每次只打开一个R2 KMZ；包内不含模型预测和上一轮人工岸线。",
        "2. 右击`02 EDIT THIS — corrected initial shoreline`，选择属性并拖动节点。",
        "3. 仅依据包内同期Sentinel-2 RGB判读可见水陆交界；历史底图只能辅助定位。",
        "4. 仅保留命名湖泊外岸线；排除岛屿、内部孔洞、入湖河道和不可判读延伸。",
        "5. 保存为`HRxx_shoreline_REVIEWED_R2.kml`并放回相应HR目录。",
        "6. 六期均需复核；HR01、HR02、HR04重点检查旧版曾出现跨湖伪线的岸段。",
    ]
    (out / "Google_Earth_Pro第二轮复核说明.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
