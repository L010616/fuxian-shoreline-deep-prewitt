"""Add 12 model-blind local shoreline sectors to each core human-review scene."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import rasterio
from rasterio.warp import transform
from scipy import ndimage as ndi


ROOT = Path(r"D:\Document\ChatGPT\水色")
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
HALF_WINDOW = 180  # 3.6 km square at 10 m, enough context for local editing.


def stretch(raw: np.ndarray, valid: np.ndarray) -> np.ndarray:
    channels = []
    for band in raw:
        sample = band[valid & (band > 0)]
        low, high = np.percentile(sample, [2, 98])
        channels.append(np.clip((band - low) / max(high - low, 1), 0, 1) ** 0.85)
    return np.moveaxis(np.stack(channels), 0, -1)


def main() -> None:
    for scene_dir in sorted(path for path in PACK.glob("HR*") if path.is_dir()):
        item = json.loads((scene_dir / "review_input_manifest.json").read_text(encoding="utf-8"))
        with rasterio.open(item["inputs"]["sentinel2_multiband"]) as src:
            raw = src.read([3, 2, 1]).astype("float32")
            valid = src.read(8) > 0
            affine = src.transform
            crs = src.crs
        with rasterio.open(scene_dir / "S2_water_FOR_REVIEW_10m.tif") as src:
            mask = src.read(1)
        water = mask == 1
        valid &= mask != 255
        edge = water ^ ndi.binary_erosion(water)
        edge = ndi.binary_dilation(edge, iterations=1)
        rgb = stretch(raw, valid)

        shoreline = json.loads((scene_dir / "shoreline_FOR_REVIEW.geojson").read_text(encoding="utf-8"))
        largest = max(shoreline["features"], key=lambda f: float(f["properties"].get("length_m", 0)))
        coordinates = np.asarray(largest["geometry"]["coordinates"], dtype=float)
        x, y = transform("EPSG:4326", crs, coordinates[:, 0].tolist(), coordinates[:, 1].tolist())
        cols, rows = (~affine) * (np.asarray(x), np.asarray(y))
        points = np.column_stack([rows, cols])
        # GeoJSON vertices follow the outer shoreline; index spacing approximates
        # equal arc-length spacing because the contour was generated on a 10 m grid.
        indices = np.linspace(0, len(points) - 1, 12, endpoint=False, dtype=int)

        fig, axes = plt.subplots(3, 4, figsize=(10.2, 8.0), constrained_layout=True)
        sector_manifest = []
        for sector, (axis, point_index) in enumerate(zip(axes.flat, indices), start=1):
            row, col = points[point_index]
            row = int(round(row)); col = int(round(col))
            r0 = max(0, row - HALF_WINDOW); r1 = min(rgb.shape[0], row + HALF_WINDOW)
            c0 = max(0, col - HALF_WINDOW); c1 = min(rgb.shape[1], col + HALF_WINDOW)
            local = rgb[r0:r1, c0:c1].copy()
            local_edge = edge[r0:r1, c0:c1]
            local_valid = valid[r0:r1, c0:c1]
            local[local_edge & local_valid] = np.array([0.23, 0.82, 0.86])
            local[~local_valid] = 0.65 * local[~local_valid] + 0.35 * np.array([0.90, 0.35, 0.45])
            axis.imshow(local)
            axis.scatter([col - c0], [row - r0], s=22, facecolors="none", edgecolors="#E7A889", linewidths=1.4)
            axis.set_title(f"S{sector:02d}", fontsize=9, fontweight="bold", pad=2)
            axis.set_xticks([]); axis.set_yticks([])
            for spine in axis.spines.values():
                spine.set_visible(True); spine.set_linewidth(0.55); spine.set_color("#7D8085")
            sector_manifest.append({"sector": f"S{sector:02d}", "center_row": row, "center_col": col,
                                    "window": [r0, r1, c0, c1], "review_status": "UNREVIEWED", "notes": ""})
        fig.suptitle(f"{item['scene_id']} local shoreline review | cyan=draft, red=invalid, coral circle=sector center",
                     fontsize=11, fontweight="bold")
        fig.savefig(scene_dir / "sector_review_sheet.png", dpi=220, bbox_inches="tight")
        plt.close(fig)
        (scene_dir / "sector_review_manifest.json").write_text(json.dumps({
            "scene_id": item["scene_id"], "status": "UNREVIEWED", "model_outputs_shown": False,
            "half_window_pixels": HALF_WINDOW, "pixel_size_m": 10, "sectors": sector_manifest,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Model-blind sector sheets created for all six scenes")


if __name__ == "__main__":
    main()
