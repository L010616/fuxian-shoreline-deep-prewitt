"""Post-review descriptive baselines; no threshold or date selection using labels.

Run freeze first, then evaluate. Preserves the frozen expanded-domain audit.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os
from datetime import datetime
from pathlib import Path
import numpy as np
import rasterio
from rasterio.warp import transform
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu
import run_v25_scope_audit as audit

ROOT=audit.ROOT
OUT=ROOT/'preexperiment/results/v27_index_jrc_20261001'
KEYS=('precision','recall','f1','iou','boundary_f1_30m','boundary_f1_60m','mean_symmetric_boundary_distance_m','hd95_m')
METHODS=('ndwi_zero','ndwi_otsu','mndwi_zero','mndwi_otsu','jrc_2019')
NBOOT=100000
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def csvwrite(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def csvread(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def freeze():
    OUT.mkdir(parents=True,exist_ok=True)
    p=OUT/'protocol_before_evaluation.json'
    if p.exists():raise RuntimeError('Protocol already exists; refusing overwrite')
    previous=json.loads((audit.AUDIT/'protocol_before_inference.json').read_text(encoding='utf-8'))
    records=[]
    for r,m in zip(audit.base.selected_records(),previous['records']):
        rp=audit.AUDIT/'references'/f"{m['tag']}.npz"
        if sha(rp)!=m['reference_cache_sha256']:raise RuntimeError('Reference cache changed')
        records.append({'tag':m['tag'],'lake':r['lake'],'l8_date':r['l8_date'],'s2_date':r['s2_date'],'season':r['season'],
          'inputs':{k:{'path':str(v.relative_to(ROOT)),'sha256':sha(v)} for k,v in r['paths'].items()},'reference_cache_sha256':sha(rp)})
    dump(p,{'created_at':datetime.now().astimezone().isoformat(),'status':'POST_REVIEW_DESCRIPTIVE_RULE_FREEZE',
      'script_sha256':sha(Path(__file__)),'original_scope_protocol_sha256':sha(audit.AUDIT/'protocol_before_inference.json'),
      'methods':list(METHODS),'index_definitions':{'ndwi':'(green-NIR)/(green+NIR)','mndwi':'(green-SWIR1)/(green+SWIR1)'},
      'inputs':'Original physical Landsat surface reflectance, before training standardization.',
      'threshold_rule':'Strict index > 0 or per-image Otsu, 256 bins, all finite index pixels in the SAME frozen expanded common-valid mask. Otsu uses no reference water labels.',
      'denominator_rule':'abs(sum)>1e-8; undefined index pixels assigned nonwater, counted, never removed from metric support.',
      'postprocessing':'None for indices: no component selection, hole filling, morphological cleanup or hard interior/exterior probability assignment. Threshold masks retained over complete exported grid; evaluation uses frozen support.',
      'jrc_rule':'2019 waterClass>=2, fixed named lake-centre component, hole fill, fixed Waihai north cut as original read_scene; same footprint all dates.',
      'primary_reference':'Existing six prediction-blind manual rings rasterized in the earlier audit; expanded 1km support and common-valid masks unchanged.',
      'secondary_reference':'All 18 expanded S2 spectral masks, diagnostic only, not surveyed truth.',
      'neural_comparator':'Existing raw three-seed probability ensembles, 0.5 cutoff, same expanded support.',
      'metrics':list(KEYS),'uncertainty':'Mean +/- between-date sample SD; paired deep-minus-control BF and control-minus-deep ASD; equal-lake two-stage 100000 bootstrap, seed 271001; descriptive three lake clusters.',
      'empty_boundary':'Keep date; region scores computed; unavailable boundary scores null; report count. No such date may be silently excluded.',
      'records':records})
    print('FROZEN',p,flush=True)
def evaluate():
    p=OUT/'protocol_before_evaluation.json';protocol=json.loads(p.read_text(encoding='utf-8'))
    if sha(Path(__file__))!=protocol['script_sha256']:raise RuntimeError('Script changed after freeze')
    if (OUT/'completion.json').exists():raise RuntimeError('Results locked; refusing overwrite')
    rows=[];thresholds=[]
    for r,m in zip(audit.base.selected_records(),protocol['records']):
        for k,inp in m['inputs'].items():
            if sha(r['paths'][k])!=inp['sha256']:raise RuntimeError('Input changed')
        rp=audit.AUDIT/'references'/f"{m['tag']}.npz"
        if sha(rp)!=m['reference_cache_sha256']:raise RuntimeError('Reference changed')
        arr=dict(np.load(rp));s=audit.base.read_scene(r)
        x=s['x_raw'];valid=arr['wide_valid'];preds={}
        for name,b in (('ndwi',3),('mndwi',4)):
            den=x[1]+x[b];defined=np.isfinite(den)&(np.abs(den)>1e-8)
            idx=np.full(den.shape,np.nan,dtype='float32');np.divide(x[1]-x[b],den,out=idx,where=defined)
            defined &= np.isfinite(idx)
            otsu=float(threshold_otsu(idx[valid&defined],nbins=256))
            for variant,t in (('zero',0.),('otsu',otsu)):
                preds[f'{name}_{variant}']=defined&(idx>t)
                thresholds.append({'tag':m['tag'],'method':f'{name}_{variant}','threshold':t,'threshold_sample_pixels':int((valid&defined).sum()),'undefined_evaluated_pixels':int((valid&~defined).sum())})
        with rasterio.open(r['paths']['qa']) as qa:
            lake=audit.base.external.main_component(qa.read(1)>=2,qa,r['lake'])
            if r['lake']=='Dianchi_Waihai':
                north=qa.transform.f+(np.arange(qa.height)+.5)*qa.transform.e
                lake &= north[:,None]<=2763300.
                labels,_=ndi.label(lake,structure=np.ones((3,3),dtype='uint8'))
                sx,sy=transform('EPSG:4326',qa.crs,[102.7049],[24.8379]);c,rr=(~qa.transform)*(sx[0],sy[0])
                lab=int(labels[round(rr),round(c)])
                if not lab:raise RuntimeError('Waihai centre lost')
                lake=labels==lab
            preds['jrc_2019']=ndi.binary_fill_holes(lake)
        definitions={'expanded_proxy_full':arr['wide_truth']}
        if 'manual_truth' in arr:definitions['manual_full']=arr['manual_truth']
        for scope,truth in definitions.items():
            cache=audit.support(truth,valid,arr['wide'])
            for name,pred in preds.items():
                try:metric=audit.measure(pred.astype('float32'),truth,valid,cache);status='OK'
                except RuntimeError as e:
                    if str(e)!='Empty predicted boundary':raise
                    a,b=pred[valid],truth[valid];tp=int((a&b).sum());fp=int((a&~b).sum());fn=int((~a&b).sum())
                    pp=tp/max(tp+fp,1);rr=tp/max(tp+fn,1)
                    metric={'precision':pp,'recall':rr,'f1':2*pp*rr/max(pp+rr,1e-12),'iou':tp/max(tp+fp+fn,1)}
                    metric.update({k:None for k in KEYS if k not in metric});status='EMPTY_BOUNDARY'
                rows.append({'model':name,'scope':scope,**{k:m[k] for k in ('lake','l8_date','s2_date','season')},'status':status,**{k:metric[k] for k in KEYS}})
        print('EVALUATED',m['tag'],flush=True)
    old=csvread(audit.AUDIT/'all_scope_per_date_seed_metrics.csv')
    for x in old:
        if x['aggregation']=='probability_ensemble' and x['prediction']=='raw' and x['scope'] in ('manual_full','expanded_proxy_full'):
            rows.append({'model':x['model'],'scope':x['scope'],**{k:x[k] for k in ('lake','l8_date','s2_date','season')},'status':'OK',**{k:float(x[k]) for k in KEYS}})
    csvwrite(OUT/'per_date_metrics.csv',rows);csvwrite(OUT/'index_thresholds.csv',thresholds)
    summaries=[];effects=[];rng=np.random.default_rng(271001)
    for scope,n in (('manual_full',6),('expanded_proxy_full',18)):
        sub=[x for x in rows if x['scope']==scope]
        models=sorted({x['model'] for x in sub})
        deep={(x['lake'],x['l8_date']):x for x in sub if x['model']=='deep_prewitt'}
        for model in models:
            mr=[x for x in sub if x['model']==model];assert len(mr)==n
            summ={'scope':scope,'model':model,'n_dates':len(mr),'n_lakes':3,'empty_boundary_dates':sum(x['status']!='OK' for x in mr)}
            for k in KEYS:
                vals=[x[k] for x in mr if x[k] is not None]
                summ[k+'_mean']=float(np.mean(vals)) if len(vals)==n else None
                summ[k+'_date_sd']=float(np.std(vals,ddof=1)) if len(vals)==n else None
            summaries.append(summ)
            if model=='deep_prewitt' or summ['empty_boundary_dates']:continue
            for key,direction in (('boundary_f1_30m',1),('mean_symmetric_boundary_distance_m',-1)):
                lakes=sorted({x['lake'] for x in mr});lv=[];boots=[];positive_dates=0
                for lake in lakes:
                    ds=np.array([direction*(deep[(x['lake'],x['l8_date'])][key]-x[key]) for x in mr if x['lake']==lake])
                    lv.append(float(ds.mean()));positive_dates+=int((ds>0).sum())
                    boots.append(ds[rng.integers(0,len(ds),size=(NBOOT,3,len(ds)))].mean(axis=2))
                b=np.stack(boots,axis=2);selected=rng.integers(0,3,size=(NBOOT,3))
                distr=b[np.arange(NBOOT)[:,None],np.arange(3)[None,:],selected].mean(axis=1);lo,hi=np.percentile(distr,[2.5,97.5])
                effects.append({'scope':scope,'control':model,'metric':key,'equal_lake_effect':float(np.mean(lv)),'ci_low':float(lo),'ci_high':float(hi),'positive_dates':positive_dates,'n_dates':n,'positive_lakes':sum(x>0 for x in lv),'lake_effects':json.dumps(dict(zip(lakes,lv)))})
    csvwrite(OUT/'summary_mean_date_sd.csv',summaries);csvwrite(OUT/'paired_equal_lake_effects.csv',effects)
    dump(OUT/'completion.json',{'status':'COMPLETE','created_at':datetime.now().astimezone().isoformat(),'protocol_sha256':sha(p),'n_metrics':len(rows),'empty_boundary_cases':sum(x['status']!='OK' for x in rows),'all_dates_retained':True})
    print(json.dumps([x for x in summaries if x['scope']=='manual_full'],indent=2),flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('freeze','evaluate'));a=parser.parse_args()
    freeze() if a.stage=='freeze' else evaluate()
