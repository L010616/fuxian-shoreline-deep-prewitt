"""Generate automatic S2 shoreline drafts for frozen test dates without evaluation."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/formal_test_drafts_v02"
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"


def main() -> None:
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]
    selected = [record for record in records if record["split"] == "test"]
    results = [builder.build_one(record) for record in selected]
    summary = {
        "dataset": "Fuxian frozen-test automatic shoreline drafts v0.2",
        "method": "fixed prior interior plus S2 NDWI decisions restricted to the shore band",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_MANUAL_REVIEW",
        "purpose": "reference-label preparation only; test accuracy remains unopened",
        "allow_test_evaluation": False,
        "test_inputs_opened_after_model_freeze": True,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(record["segment_count"] for record in results),
            "high_priority_segments": sum(record["high_priority_segments"] for record in results),
        },
    }
    (OUT / "test_draft_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
