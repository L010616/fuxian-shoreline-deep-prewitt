"""Build a concise, reproducible writing brief from all frozen outputs."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/manuscript_ready"
RESULTS = ROOT / "preexperiment/results"


def pm(cell, digits=4):
    return f"{cell['mean']:.{digits}f} ± {cell['std']:.{digits}f}"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()


def main():
    comparison_path = RESULTS / "locked_four_date_model_comparison_v01/model_comparison_test_results.json"
    ablation_path = RESULTS / "locked_four_date_ablation_v01/ablation_test_results.json"
    per_date_path = OUT / "final_test/four_date_test_results.json"
    efficiency_path = OUT / "table_model_efficiency.json"
    comparison = json.loads(comparison_path.read_text(encoding="utf-8"))
    ablation = json.loads(ablation_path.read_text(encoding="utf-8"))
    per_date = json.loads(per_date_path.read_text(encoding="utf-8"))
    efficiency = json.loads(efficiency_path.read_text(encoding="utf-8"))
    labels = {"proposed_parallel": "本文模型", "unet_resnet18": "U-Net", "deeplabv3plus_resnet18": "DeepLabV3+", "segformer_mit_b0": "SegFormer-B0"}
    ab_labels = {"dfanet": "DFANet", "prior": "DFANet + 空间先验", "log": "+ LoG", "prewitt": "+ Prewitt", "parallel": "完整并联"}
    lines = [
        "# 抚仙湖湖界提取实验写作就绪说明", "",
        "## 当前状态", "",
        "预实验与四期封存测试已经闭环，可以开始撰写论文。训练、验证、消融、常用模型对比、逐日期稳定性、效率测试和定性图均已有冻结结果。后续不得根据测试集结果继续调模型或改阈值。", "",
        "数据按日期隔离：训练 6 期（2020-01-02、2020-05-09、2021-02-05、2021-05-12、2022-03-12、2022-08-19），验证 2 期（2023-01-26、2023-03-31），测试 4 期（2025-05-07、2025-12-01、2026-01-18、2026-02-03）。每个模型使用 3 个固定随机种子。", "",
        "## 建议题目", "",
        "**Boundary-constrained dual-edge feature aggregation network for fine shoreline extraction of Fuxian Lake from Landsat 8 imagery**", "",
        "中文：**面向 Landsat 8 抚仙湖精细湖界提取的边界约束与双边缘特征聚合网络**", "",
        "## 四期测试主要结果", "",
        "| 模型 | IoU | Boundary F1 (30 m) | Boundary F1 (60 m) | 平均岸线距离/m |", "|---|---:|---:|---:|---:|",
    ]
    for key, label in labels.items():
        s = comparison["summary"][key]["raw_macro"]
        lines.append(f"| {label} | {pm(s['iou'])} | {pm(s['boundary_f1_30m'])} | {pm(s['boundary_f1_60m'])} | {pm(s['mean_symmetric_boundary_distance_m'],2)} |")
    lines += ["", "三个种子的统计单位是模型重复；总体指标先在每个种子内对四个日期作宏平均，再报告三种子的均值和样本标准差。", "",
              "## 四期测试消融", "", "| 变体 | IoU | Boundary F1 (30 m) | 平均岸线距离/m |", "|---|---:|---:|---:|"]
    for key, label in ab_labels.items():
        s = ablation["summary"][key]["raw_macro"]
        lines.append(f"| {label} | {pm(s['iou'])} | {pm(s['boundary_f1_30m'])} | {pm(s['mean_symmetric_boundary_distance_m'],2)} |")
    lines += ["", "空间先验贡献最稳定。完整并联模型相对原始 DFANet 的 IoU 提高 0.00042，30 m Boundary F1 提高 0.00297，平均岸线距离减少 2.64 m。完整模型相对仅空间先验的 IoU 提高 0.00016，但边界指标基本持平。", "",
              "## 逐日期稳定性", "", "| 日期 | IoU | Boundary F1 (30 m) | 平均岸线距离/m |", "|---|---:|---:|---:|"]
    for date in per_date["dates"]:
        s = per_date["per_date_summary"][date]["raw"]
        lines.append(f"| {date} | {pm(s['iou'])} | {pm(s['boundary_f1_30m'])} | {pm(s['mean_symmetric_boundary_distance_m'],2)} |")
    lines += ["", "2025-12-01 是明确困难日期，主要偏差集中在中西岸局部。其余三期平均岸线距离约为 9–10 m。正文应保留这一差异并讨论近岸光谱、配准、混合像元和自动参考岸线的共同影响。", "",
              "## 效率", "", "| 模型 | 参数量 | 256×256 图块推理/ms | 峰值显存/MB |", "|---|---:|---:|---:|"]
    for row in efficiency:
        lines.append(f"| {labels[row['model']]} | {row['parameters']:,} | {row['mean_inference_ms']:.2f} ± {row['std_inference_ms']:.2f} | {row['peak_allocated_mb']:.1f} |")
    lines += ["", "效率测试环境为 NVIDIA GeForce RTX 4070 Laptop GPU，单图块、批量大小 1、20 次预热和 100 次重复。本文模型参数量约 7.72 万。", "",
              "## 可直接写入结果部分的表述", "",
              "在四个独立测试日期上，本文模型取得 0.9958 ± 0.0001 的 IoU、0.9777 ± 0.0024 的 30 m Boundary F1 和 27.61 ± 2.07 m 的平均对称岸线距离。相较 U-Net，30 m Boundary F1 提高 0.0056，平均岸线距离减少 2.29 m；相较 DeepLabV3+ 和 SegFormer-B0，边界优势更明显。", "",
              "消融结果表明，空间先验是减少复杂背景干扰和改善岸线位置的主要因素。完整并联模型在四个测试日期上均获得高于仅空间先验模型的 IoU，但两者在边界指标上接近，说明 LoG 与 Prewitt 特征的增益主要表现为整体分割稳定性，其边界收益具有场景依赖性。", "",
              "逐日期结果显示，模型在 2025-05-07、2026-01-18 和 2026-02-03 上的平均岸线距离为 8.88–10.40 m，而 2025-12-01 增至 81.36 m。定性结果显示该误差主要集中于中西岸局部，反映出 30 m 混合像元、近岸光谱差异和参考岸线不确定性仍会限制精细定位。", "",
              "## 结论允许写到什么程度", "",
              "可以写：完整方法优于原始 DFANet 和三种常用语义分割模型；空间先验显著减少非岸线背景影响；模型轻量且推理快；双边缘分支提高 IoU，但边界收益随日期变化。", "",
              "不要写：双边缘分支在所有日期显著优于仅空间约束；平均岸线误差稳定低于一个 Landsat 像元；参考岸线是独立测量真值；结果已经证明可无条件推广到其他湖泊。", "",
              "## 投稿前仍必须完成的最小工作", "",
              "1. 由第二位人工审阅者独立抽查测试集保留岸段。可采用简化方案：每个测试日期 6 个空间均匀岸段，共 24 段；记录 PASS、修正或排除。若发生修正，只重新计算一次最终指标并保留变更记录。", "",
              "2. 在方法中明确参考岸线为近同期 Sentinel-2 筛查岸线，报告 Landsat–Sentinel 日期差、保留岸线比例及无效像元排除规则。", "",
              "3. 写作时使用本目录中的封存表和图。早期单日期预实验及旧版 Word 初稿中的数值不得作为最终结果。", "",
              "年度时序应用可缩短为 2020—2026 年若干代表性日期，作为方法应用展示；它不是当前模型有效性结论的必要前提。", "",
              "## 写作文件索引", "",
              "- `table_locked_test_model_comparison.csv`：正文模型对比表。", "- `table_locked_test_ablation.csv`：正文消融表。",
              "- `final_test/table_four_date_per_date.csv`：逐日期稳定性。", "- `table_model_efficiency.csv`：效率表。",
              "- `figures/figure_locked_test_model_comparison.pdf`：测试模型对比图。", "- `figures/figure_locked_test_ablation.pdf`：测试消融图。",
              "- `final_test/figure_four_date_boundary_performance.pdf`：逐日期边界性能。", "- `figures/figure_qualitative_20251201.pdf`：困难日期定性对比。",
              "- `figures/figure_qualitative_20260203.pdf`：典型日期定性对比。", ""]
    brief = OUT / "论文写作就绪说明.md"
    brief.write_text("\n".join(lines), encoding="utf-8")
    frozen = [comparison_path, ablation_path, per_date_path, efficiency_path,
              RESULTS / "formal_test_drafts_v02/manual_review_v01/pilot_test_reference_v01/pilot_test_reference_manifest.json",
              RESULTS / "formal_test_drafts_v03_additional/screened_reference_v01/screened_reference_manifest.json"]
    manifest = {"created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "status": "EXPERIMENTS_CLOSED_MANUSCRIPT_DRAFTING_MAY_BEGIN",
                "no_further_test_guided_tuning": True,
                "files": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in frozen]}
    (OUT / "experiment_freeze_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"brief": str(brief), "status": manifest["status"]}, ensure_ascii=False))


if __name__ == "__main__": main()
