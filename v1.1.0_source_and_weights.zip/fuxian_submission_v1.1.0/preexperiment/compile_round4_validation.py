import json, csv, hashlib
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(r'D:\Document\ChatGPT\水色')
CONF = ROOT/'preexperiment/results/round4_fusion_confirmation/fusion_confirmation_results.json'
REM = ROOT/'preexperiment/results/round4_remaining_models/remaining_model_results.json'
OUT = ROOT/'preexperiment/results/round4_validation_summary'
OUT.mkdir(parents=True, exist_ok=True)
conf = json.loads(CONF.read_text(encoding='utf-8'))
rem = json.loads(REM.read_text(encoding='utf-8'))

models = [
 ('DFANet','dfanet','rem'),
 ('Boundary-constrained DFANet','prior','conf'),
 ('LoG-enhanced DFANet','log','conf'),
 ('Prewitt-enhanced DFANet','prewitt','rem'),
 ('Parallel edge fusion','parallel_concat_ew0p0','conf'),
 ('U-Net','unet_resnet18','rem'),
 ('DeepLabV3+','deeplabv3plus_resnet18','rem'),
 ('SegFormer','segformer_mit_b0','rem'),
]
rows=[]
for label,key,src in models:
    s=(conf if src=='conf' else rem)['summary'][key]
    rows.append({
      'model':label,
      'config_key':key,
      'bf1_30m_mean':s['boundary_f1_30m']['mean'],
      'bf1_30m_sd':s['boundary_f1_30m']['std'],
      'asd_m_mean':s['mean_symmetric_boundary_distance_m']['mean'],
      'asd_m_sd':s['mean_symmetric_boundary_distance_m']['std'],
      'iou_mean':s['iou']['mean'],
      'iou_sd':s['iou']['std'],
      'bf1_60m_mean':s['boundary_f1_60m']['mean'],
      'bf1_60m_sd':s['boundary_f1_60m']['std'],
      'selected_for_blind_test': key=='prior'
    })
with (OUT/'round4_main_validation_comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

# Fusion sensitivity table, explicitly separate from confirmatory model comparison.
sens=[]
for key in ['parallel_concat_ew0p0','parallel_concat_ew0p1','parallel_weighted_ew0p0']:
    s=conf['summary'][key]
    sens.append({'fusion_config':key,'bf1_30m_mean':s['boundary_f1_30m']['mean'],
                 'bf1_30m_sd':s['boundary_f1_30m']['std'],
                 'asd_m_mean':s['mean_symmetric_boundary_distance_m']['mean'],
                 'asd_m_sd':s['mean_symmetric_boundary_distance_m']['std']})
with (OUT/'round4_fusion_sensitivity.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=sens[0].keys()); w.writeheader(); w.writerows(sens)

# One-color, journal-ready validation figure.
plt.rcParams.update({'font.family':'Arial','font.size':9,'axes.linewidth':0.8})
fig,axs=plt.subplots(1,2,figsize=(10.0,4.2),dpi=180)
y=np.arange(len(rows)); color='#4C78A8'
labels=[r['model'] for r in rows]
axs[0].barh(y,[r['bf1_30m_mean'] for r in rows],xerr=[r['bf1_30m_sd'] for r in rows],
            color=color,edgecolor='black',linewidth=.45,capsize=2.5,error_kw={'elinewidth':.8})
axs[0].set_yticks(y,labels); axs[0].invert_yaxis(); axs[0].set_xlim(.90,1.005)
axs[0].set_xlabel('Boundary F1 (30 m)'); axs[0].text(-.12,1.02,'(a)',transform=axs[0].transAxes,fontweight='bold',fontsize=12)
axs[1].barh(y,[r['asd_m_mean'] for r in rows],xerr=[r['asd_m_sd'] for r in rows],
            color=color,edgecolor='black',linewidth=.45,capsize=2.5,error_kw={'elinewidth':.8})
axs[1].set_yticks(y,[]); axs[1].invert_yaxis(); axs[1].set_xlabel('Average shoreline distance (m)'); axs[1].text(-.12,1.02,'(b)',transform=axs[1].transAxes,fontweight='bold',fontsize=12)
for ax in axs:
    ax.grid(axis='x',color='#D9D9D9',linewidth=.55); ax.set_axisbelow(True)
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
fig.tight_layout(w_pad=1.1)
fig.savefig(OUT/'round4_validation_model_comparison.png',dpi=600,bbox_inches='tight')
fig.savefig(OUT/'round4_validation_model_comparison.tif',dpi=600,bbox_inches='tight',pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)

# Freeze every checkpoint relevant to the blind comparison.
ckpts=[]
for d in [CONF.parent,REM.parent]:
    for p in sorted(d.glob('*_best.pt')):
        h=hashlib.sha256()
        with p.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
        ckpts.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h.hexdigest(),'bytes':p.stat().st_size})
freeze={
 'status':'ALL_COMPARATOR_CONFIGS_AND_CHECKPOINTS_FROZEN_BEFORE_BLIND_TEST',
 'frozen_utc':datetime.now(timezone.utc).isoformat(),
 'test_data_accessed':False,
 'training_dates':conf['training_dates'], 'validation_dates':conf['validation_dates'],
 'training_windows':conf['training_windows'],'validation_windows':conf['validation_windows'],
 'seeds':conf['seeds'],'decision_threshold':0.5,
 'primary_metric':'Boundary F1 at 30 m','tie_breaker':'lower mean symmetric boundary distance',
 'selected_final_config':'prior',
 'main_comparison_configs':[r['config_key'] for r in rows],
 'fusion_sensitivity_configs':[r['fusion_config'] for r in sens],
 'architecture_changes_after_blind_test_allowed':False,
 'checkpoint_count':len(ckpts),'checkpoints':ckpts
}
(OUT/'round4_preblind_freeze_manifest.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rows':len(rows),'checkpoints':len(ckpts),'selected':'prior','outputs':[p.name for p in OUT.iterdir()]},ensure_ascii=False,indent=2))
