"""Build the prediction-blind reference draft for the set-2 replacement date."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "data" / "edge_confirmation_set2"
MANIFEST = BASE / "selection_manifest_final.json"
OUT = ROOT / "preexperiment" / "results" / "edge_confirmation_set2" / "reference_drafts"
REPLACEMENT_DATE = "2023-02-11"


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    expected = "EDGE_CONFIRMATION_SET2_FINAL_SIX_INPUTS_VALIDATED_BEFORE_REFERENCE_FREEZE"
    if manifest.get("status") != expected:
        raise RuntimeError("Final set-2 inputs are not validated")
    record = next(row for row in manifest["records"] if row["l8_date"] == REPLACEMENT_DATE)

    builder.DATA_ROOT = BASE / "analysis_ready"
    builder.OUT = OUT
    builder.L8_TEMPLATE = "Fuxian_edgeconfirm_set2_L8_native_{l8_tag}.tif"
    builder.S2_TEMPLATE = "Fuxian_edgeconfirm_set2_S2_{s2_tag}_for_{l8_tag}.tif"
    builder.MASK_TEMPLATE = "Fuxian_edgeconfirm_set2_masks_native_{l8_tag}.tif"
    result = builder.build_one({
        "l8_date": record["l8_date"],
        "s2_date": record["s2_date"],
        "calendar_gap_days": record["calendar_gap_days"],
        "split": "edge_confirmation_set2_prediction_blind_reference",
    })
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
