"""Create compact tables and a geometry-QC figure for provisional review."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
RESULT = ROOT / "preexperiment/results/q2_manual_core6_evaluation_single_reviewer_provisional"
FIG_DIR = Path(r"D:\Document\Codex资源")


def main() -> None:
    payload = json.loads((RESULT / "manual_core6_results.json").read_text(encoding="utf-8"))
    model_labels = {
        "spatial_prior": "Spatial prior",
        "deep_prewitt": "Deep Prewitt",
        "parameter_matched_ordinary_conv": "Matched conv.",
    }
    keys = ["precision", "recall", "f1", "iou", "boundary_f1_30m",
            "boundary_f1_60m", "mean_symmetric_boundary_distance_m", "hd95_m"]
    with (RESULT / "manual_core6_summary_mean_sd.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", "n_dates", *sum(([f"{k}_mean", f"{k}_date_sd"] for k in keys), [])])
        for model, label in model_labels.items():
            summary = payload["summary"][model]["all_18_dates"]
            values = []
            for key in keys:
                values.extend([summary[key]["mean"], summary[key]["date_sd"]])
            writer.writerow([label, summary["n_dates"], *values])

    fig, axes = plt.subplots(2, 3, figsize=(11.2, 6.7), constrained_layout=True)
    for index, ax in enumerate(axes.flat, start=1):
        scene = f"HR{index:02d}"
        candidate = json.loads((PACK / scene / "shoreline_AI_ASSISTED_CANDIDATE.geojson").read_text(encoding="utf-8"))
        reviewed = json.loads((PACK / scene / "shoreline_REVIEWED.geojson").read_text(encoding="utf-8"))
        c = np.asarray(candidate["features"][0]["geometry"]["coordinates"])
        r = np.asarray(reviewed["features"][0]["geometry"]["coordinates"])
        ax.plot(c[:, 0], c[:, 1], color="#E7A889", lw=1.2, alpha=0.9, label="AI candidate")
        ax.plot(r[:, 0], r[:, 1], color="#6A5C95", lw=1.35, alpha=0.95, label="Reviewed")
        ax.set_title(f"({chr(96+index)}) {scene}", loc="left", fontsize=10, weight="bold")
        ax.set_aspect("equal", adjustable="datalim")
        ax.set_xticks([]); ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_color("#D8D8DE")
        if index == 1:
            ax.legend(loc="upper left", frameon=False, fontsize=8)
    fig.suptitle("Manual shoreline geometry QC", fontsize=13, weight="bold", color="#3E3142")
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    out = FIG_DIR / "Q2_manual_core6_geometry_QC.png"
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(out)


if __name__ == "__main__":
    main()
