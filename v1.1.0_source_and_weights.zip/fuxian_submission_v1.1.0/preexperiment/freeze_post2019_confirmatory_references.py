"""Prediction-blind screening and freezing of post-2019 confirmatory references."""
from __future__ import annotations
import hashlib, json
from datetime import datetime
from pathlib import Path
import finalize_additional_test_reference as finalizer

ROOT=Path(__file__).resolve().parents[1]
DATA_BASE=ROOT/'preexperiment/data/edge_confirmatory_post2019'
RESULT=ROOT/'preexperiment/results/edge_confirmatory_post2019'
DRAFT=RESULT/'reference_drafts'
PAIRS=RESULT/'evaluation_pairs.json'
FREEZE=RESULT/'post2019_evaluation_freeze_manifest.json'

NOTES={
 '2021-03-25':'High overall coverage; exclude all automatically flagged low-margin or invalid segments.',
 '2021-12-22':'Clouds affect western and southern shores; retain only joint-valid normal-priority segments.',
 '2022-02-08':'Near-complete clear coverage; exclude automatically flagged low-confidence segments.',
 '2023-11-10':'Clouds affect several sectors; retain only joint-valid normal-priority segments.',
 '2024-04-18':'Replacement selected before predictions; partial cloud cover, retain only visible joint-valid normal-priority segments.',
 '2026-02-19':'High overall coverage with central cloud; exclude automatically flagged low-confidence segments.'}

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def main():
    if FREEZE.exists(): raise RuntimeError('Post-2019 evaluation already frozen; refusing to overwrite')
    src=json.loads((DATA_BASE/'selection_manifest_v2.json').read_text(encoding='utf-8'))
    if src['status']!='POST2019_FINAL_SIX_INPUTS_VALIDATED_AND_FROZEN': raise RuntimeError('Inputs not frozen')
    selected=[{'l8_date':r['l8_date'],'s2_date':r['s2_date'],
      'calendar_gap_days':r['calendar_gap_days'],'selection_window':r['window']} for r in src['records']]
    pairs={'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
      'status':'FROZEN_BEFORE_MODEL_PREDICTIONS','purpose':'post-2019 independent edge and matched-control confirmation',
      'all_six_dates_retained':True,'selected':selected}
    RESULT.mkdir(parents=True,exist_ok=True); PAIRS.write_text(json.dumps(pairs,ensure_ascii=False,indent=2),encoding='utf-8')
    review={'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
      'status':'DATE_OVERVIEWS_REVIEWED','reviewer':'Codex-assisted prediction-blind full-date visual screening',
      'model_predictions_opened':False,
      'policy':'Retain all six dates; evaluate only joint-valid normal-priority shoreline and buffer every excluded high-priority segment by 30 m.',
      'records':[{'l8_date':r['l8_date'],'accept':True,'notes':NOTES[r['l8_date']]} for r in selected]}
    review_path=DRAFT/'date_level_review_post2019.json'; review_path.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
    finalizer.DATA_ROOT=DATA_BASE/'analysis_ready'; finalizer.DRAFT_ROOT=DRAFT; finalizer.REVIEW=review_path
    finalizer.OUT=RESULT/'screened_reference'; finalizer.MANIFEST=PAIRS
    finalizer.L8_TEMPLATE='Fuxian_edgeconfirm_post2019_L8_native_{l8_tag}.tif'
    finalizer.S2_TEMPLATE='Fuxian_edgeconfirm_post2019_S2_{s2_tag}_for_{l8_tag}.tif'
    finalizer.main()
    mp=finalizer.OUT/'screened_reference_manifest.json'; m=json.loads(mp.read_text(encoding='utf-8'))
    m.update({'dataset':'Fuxian Lake post-2019 edge confirmatory set',
      'status':'FROZEN_FOR_ONE_TIME_POST2019_CONFIRMATORY_EVALUATION','all_six_dates_retained':True,
      'reference_scope':'Only retained joint-valid normal-priority shoreline is eligible.',
      'allow_training':False,'allow_model_selection':False,'allow_threshold_tuning':False,
      'model_predictions_opened_before_freeze':False})
    mp.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')

    deep=ROOT/'preexperiment/results/edge_depth_validation_screen'
    prior=ROOT/'preexperiment/results/round4_fusion_confirmation'
    control=ROOT/'preexperiment/results/parameter_matched_conv_control'
    seeds=(20260913,20260929,20261017); checkpoints=[]
    for seed in seeds:
      for role,path in [
       ('prior_only',prior/f'prior_seed{seed}_best.pt'),
       ('fixed_log_prewitt',deep/f'edge_depth_2_seed{seed}_best.pt'),
       ('parameter_matched_ordinary_conv',control/f'matched_conv_seed{seed}_best.pt')]:
        checkpoints.append({'role':role,'seed':seed,'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':sha256(path)})
    freeze={'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
      'status':'MODELS_REFERENCES_AND_DATES_FROZEN_BEFORE_POST2019_PREDICTIONS',
      'dates':selected,'threshold':0.5,'boundary_tolerances_m':[30,60],
      'primary_comparisons':['fixed_log_prewitt vs prior_only','fixed_log_prewitt vs parameter_matched_ordinary_conv'],
      'checkpoints':checkpoints,'reference_manifest_sha256':sha256(mp),'pairs_manifest_sha256':sha256(PAIRS)}
    FREEZE.write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':freeze['status'],'coverage':{r['l8_date']:{'retained_fraction':round(r['retained_length_fraction'],3),'retained_km':round(r['retained_length_km'],2),'sectors':r['spatial_coverage']['occupied_12_sectors']} for r in m['records']}},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
