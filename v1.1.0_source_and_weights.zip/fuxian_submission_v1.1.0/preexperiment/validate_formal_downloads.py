"""Validate downloaded GEE GeoTIFFs before formal shoreline processing.

The script is read-only. It discovers files recursively, checks the fixed export
grids, band counts, data types, masks, and records what is ready for the next
stage. Test dates are excluded by default.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"
OUT_DIR = ROOT / "preexperiment/results/formal_dataset_qc"

L8_TRANSFORM = (30.0, 0.0, 277935.0, 0.0, -30.0, 2727015.0)
S2_TRANSFORM = (10.0, 0.0, 277960.0, 0.0, -10.0, 2726990.0)
L8_SHAPE = (1095, 542)
S2_SHAPE = (3281, 1623)

WAVE1_DATES = {"2020-05-09", "2021-02-05", "2022-03-12"}


def compact(date: str) -> str:
    return date.replace("-", "")


def expected_name(kind: str, record: dict) -> str:
    if kind == "l8":
        return f"Fuxian_L8_native_{compact(record['l8_date'])}.tif"
    if kind == "masks":
        return f"Fuxian_masks_native_{compact(record['l8_date'])}.tif"
    return f"Fuxian_S2_{compact(record['s2_date'])}.tif"


def discover(root: Path) -> dict[str, list[Path]]:
    found: dict[str, list[Path]] = {}
    for path in root.rglob("*.tif"):
        found.setdefault(path.name.lower(), []).append(path)
    return found


def check_transform(actual, expected) -> bool:
    values = (actual.a, actual.b, actual.c, actual.d, actual.e, actual.f)
    return bool(np.allclose(values, expected, rtol=0, atol=1e-7))


def inspect_tif(path: Path, kind: str) -> dict:
    spec = {
        "l8": {"count": 7, "shape": L8_SHAPE, "transform": L8_TRANSFORM},
        "masks": {"count": 5, "shape": L8_SHAPE, "transform": L8_TRANSFORM},
        "s2": {"count": 8, "shape": S2_SHAPE, "transform": S2_TRANSFORM},
    }[kind]
    errors: list[str] = []
    warnings: list[str] = []
    with rasterio.open(path) as src:
        meta = {
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "crs": src.crs.to_string() if src.crs else None,
            "shape": [src.height, src.width],
            "count": src.count,
            "dtypes": list(src.dtypes),
            "nodata": src.nodata,
            "descriptions": list(src.descriptions),
            "transform": [src.transform.a, src.transform.b, src.transform.c,
                          src.transform.d, src.transform.e, src.transform.f],
        }
        if meta["crs"] != "EPSG:32648":
            errors.append(f"CRS should be EPSG:32648, got {meta['crs']}")
        if tuple(meta["shape"]) != spec["shape"]:
            errors.append(f"shape should be {spec['shape']}, got {tuple(meta['shape'])}")
        if src.count != spec["count"]:
            errors.append(f"band count should be {spec['count']}, got {src.count}")
        if not check_transform(src.transform, spec["transform"]):
            errors.append("affine transform does not match the fixed export grid")

        # Read masks fully; sample imagery on a regular grid to avoid a needless
        # full-array load during intake.
        if kind == "masks" and src.count == 5:
            arr = src.read()
            unique = [np.unique(b).tolist() for b in arr]
            meta["unique_values"] = unique
            if any(not set(v).issubset({0, 1}) for v in unique):
                errors.append("mask bands contain values outside {0,1}")
            shore = arr[0] == 1
            meta["shore_pixels"] = int(shore.sum())
            meta["joint_valid_fraction_on_shore"] = (
                float((arr[3][shore] == 1).mean()) if shore.any() else None
            )
            if not np.array_equal(arr[3] == 1, (arr[1] == 1) & (arr[2] == 1)):
                errors.append("joint_valid is inconsistent with l8_valid AND s2_valid")
        else:
            rows = np.linspace(0, src.height - 1, min(src.height, 128), dtype=int)
            cols = np.linspace(0, src.width - 1, min(src.width, 128), dtype=int)
            sample = src.read()[:, rows][:, :, cols]
            meta["sample_min"] = [float(x) for x in sample.min(axis=(1, 2))]
            meta["sample_max"] = [float(x) for x in sample.max(axis=(1, 2))]
            if not np.isfinite(sample).all():
                errors.append("sample contains NaN or infinity")
        if not all(meta["descriptions"]):
            warnings.append("one or more band descriptions are absent")

    meta["errors"] = errors
    meta["warnings"] = warnings
    meta["status"] = "PASS" if not errors else "FAIL"
    return meta


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=ROOT,
                        help="Folder containing downloaded TIFFs; searched recursively")
    parser.add_argument("--scope", choices=("wave1", "trainval", "test"), default="wave1")
    args = parser.parse_args()

    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]
    if args.scope == "test":
        records = [r for r in records if r["split"] == "test"]
    else:
        records = [r for r in records if r["split"] != "test"]
    if args.scope == "wave1":
        records = [r for r in records if r["l8_date"] in WAVE1_DATES]

    found = discover(args.input.resolve())
    rows = []
    for record in records:
        row = {
            "l8_date": record["l8_date"],
            "s2_date": record["s2_date"],
            "split": record["split"],
            "qa_group": record["qa_group"],
            "files": {},
        }
        for kind in ("l8", "s2", "masks"):
            name = expected_name(kind, record)
            matches = found.get(name.lower(), [])
            if not matches:
                row["files"][kind] = {"expected_name": name, "status": "MISSING"}
            elif len(matches) > 1:
                row["files"][kind] = {
                    "expected_name": name, "status": "DUPLICATE",
                    "paths": [str(p) for p in matches],
                }
            else:
                row["files"][kind] = inspect_tif(matches[0], kind)
        states = [x["status"] for x in row["files"].values()]
        row["status"] = "PASS" if states == ["PASS", "PASS", "PASS"] else "INCOMPLETE_OR_FAILED"
        rows.append(row)

    report = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "input_root": str(args.input.resolve()),
        "scope": args.scope,
        "test_dates_opened": args.scope == "test",
        "expected_dates": len(records),
        "passed_dates": sum(r["status"] == "PASS" for r in rows),
        "records": rows,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    output = OUT_DIR / f"download_qc_{args.scope}.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"QC report: {output}")
    print(f"Ready dates: {report['passed_dates']}/{report['expected_dates']}")
    for row in rows:
        print(row["l8_date"], row["status"],
              ", ".join(f"{k}={v['status']}" for k, v in row["files"].items()))
    return 0 if report["passed_dates"] == report["expected_dates"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
