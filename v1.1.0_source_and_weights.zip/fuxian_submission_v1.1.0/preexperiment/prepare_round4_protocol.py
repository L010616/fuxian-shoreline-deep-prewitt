"""Freeze round-4 data roles and generate train/validation GEE exports."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PRE = ROOT / "preexperiment"
PAIR_SOURCE = PRE / "results/s2_pair_quality_2020_2025.json"
OUT = PRE / "results/round4_protocol"
GEE_SOURCE = PRE / "gee/06_formal_dataset_exports.js"
GEE_OUT = PRE / "gee/09_round4_trainval_exports.js"

EXISTING_TRAIN = ["2020-01-02", "2020-05-09", "2021-02-05", "2021-05-12", "2022-03-12", "2022-08-19"]
ADDED = {
    "2020-01-18": ("2020-01-17", "train"),
    "2020-07-28": ("2020-07-30", "train"),
    "2021-01-04": ("2021-01-06", "train"),
    "2021-10-19": ("2021-10-18", "train"),
    "2022-04-13": ("2022-04-16", "train"),
    "2022-12-09": ("2022-12-07", "train"),
    "2023-05-18": ("2023-05-21", "validation"),
}
EXISTING_VALIDATION = ["2023-01-26", "2023-03-31"]
RESERVED_FINAL = [
    {"l8_date": "2024-01-13", "s2_date": "2024-01-11", "role": "final_blind_test", "status": "SEALED"},
    {"l8_date": "2024-08-24", "s2_date": "2024-08-23", "role": "final_blind_test", "status": "SEALED"},
    {"l8_date": "2025-03-04", "s2_date": "2025-03-01", "role": "final_blind_test", "status": "SEALED"},
    {"l8_date": None, "s2_date": None, "role": "final_blind_test_2026_QA_slot_1", "status": "SEALED_SELECTION_RULE"},
    {"l8_date": None, "s2_date": None, "role": "final_blind_test_2026_QA_slot_2", "status": "SEALED_SELECTION_RULE"},
    {"l8_date": None, "s2_date": None, "role": "final_blind_test_2026_QA_slot_3", "status": "SEALED_SELECTION_RULE"},
]


def main() -> int:
    pairs = json.loads(PAIR_SOURCE.read_text(encoding="utf-8"))
    lookup = {(r["l8_date"], r["s2_date"]): r for r in pairs}
    records = []
    for date, (s2_date, split) in ADDED.items():
        row = dict(lookup[(date, s2_date)])
        row.update({
            "split": split,
            "qa_group": "core" if row["joint_shore_valid"] >= 0.90 else "partial",
            "status": "FROZEN_FOR_EXPORT_AND_REFERENCE_REVIEW",
            "allow_training": False,
        })
        records.append(row)

    protocol = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "ROUND4_SPLITS_FROZEN_BEFORE_MODEL_TRAINING",
        "selection_basis": "Image quality, seasonal coverage and temporal separation only; no model output used.",
        "training_dates_existing": EXISTING_TRAIN,
        "training_dates_added": [r["l8_date"] for r in records if r["split"] == "train"],
        "training_dates_total": EXISTING_TRAIN + [r["l8_date"] for r in records if r["split"] == "train"],
        "validation_dates_existing": EXISTING_VALIDATION,
        "validation_dates_added": [r["l8_date"] for r in records if r["split"] == "validation"],
        "validation_dates_total": EXISTING_VALIDATION + [r["l8_date"] for r in records if r["split"] == "validation"],
        "added_export_records": records,
        "final_blind_test": RESERVED_FINAL,
        "final_2026_selection_rule": {
            "date_range": ["2026-03-01", "2026-10-01"],
            "sensor": "Landsat 8 Collection 2 Level 2",
            "pairing": "Sentinel-2 SR Harmonized within plus/minus 2 days",
            "ranking": "joint shoreline clear fraction, then smaller day gap",
            "count": 3,
            "model_outputs_may_be_used": False,
            "imagery_and_reference_remain_sealed_until_final_model_is_frozen": True,
        },
        "opened_robustness_dates_not_eligible_for_final_test": [
            "2024-02-14", "2024-04-02", "2024-05-04", "2024-10-27",
            "2025-01-31", "2025-04-21", "2025-05-07", "2025-10-14", "2025-12-01",
            "2026-01-18", "2026-02-03",
        ],
        "fusion_selection_data": "training and validation dates only",
        "test_access_before_fusion_freeze": False,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "round4_split_protocol.json").write_text(
        json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Reuse the already verified fixed-grid export implementation and replace
    # only its record list, waves, folder and panel text.
    text = GEE_SOURCE.read_text(encoding="utf-8")
    text = re.sub(r"var records = .*?;\r?\nvar wave1 = .*?;\r?\nvar wave2 = .*?;",
                  "var records = " + json.dumps(records, ensure_ascii=False, separators=(",", ":")) +
                  ";\nvar wave1 = [0,1,2,3];\nvar wave2 = [4,5,6];", text, count=1)
    text = text.replace("Fuxian formal-dataset exports for TRAIN and VALIDATION dates only.",
                        "Fuxian round-4 added TRAIN and VALIDATION exports.")
    text = text.replace("Only train/validation dates. Test dates remain sealed.",
                        "Only seven added train/validation dates. Final blind test remains sealed.")
    text = text.replace("Fuxian_formal_v1", "Fuxian_round4_trainval")
    text = text.replace("Prepare wave 1: 9 export tasks", "Prepare wave 1: 12 export tasks")
    text = text.replace("Wave 1 prepared: 3 dates, 9 Drive tasks.", "Wave 1 prepared: 4 dates, 12 Drive tasks.")
    text = text.replace("Prepare wave 2: 12 export tasks", "Prepare wave 2: 9 export tasks")
    text = text.replace("Wave 2 prepared: 4 dates, 12 Drive tasks.", "Wave 2 prepared: 3 dates, 9 Drive tasks.")
    text = text.replace("Exports use the verified fixed grids from 2020-01-02. No test task is created.",
                        "Exports use the fixed grids. No final-test image task is created.")
    GEE_OUT.write_text(text, encoding="utf-8")
    print(json.dumps({
        "status": protocol["status"],
        "new_train": protocol["training_dates_added"],
        "new_validation": protocol["validation_dates_added"],
        "total_train_dates": len(protocol["training_dates_total"]),
        "total_validation_dates": len(protocol["validation_dates_total"]),
        "gee_script": str(GEE_OUT),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
