"""Validate 2024-04-18 replacement and freeze final six-date input manifest."""
from __future__ import annotations
import hashlib, json, shutil
from datetime import datetime
from pathlib import Path
import rasterio

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'drive-download-20260921T163613Z-1-001'
BASE=ROOT/'preexperiment/data/edge_confirmatory_post2019'
DATA=BASE/'analysis_ready'
OLD=BASE/'selection_manifest.json'
NEW=BASE/'selection_manifest_v2.json'

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def sig(p):
    with rasterio.open(p) as d:
        return {'bands':d.count,'width':d.width,'height':d.height,'crs':str(d.crs),
                'transform':list(tuple(d.transform)[:6]),'dtypes':list(d.dtypes),'nodata':d.nodata}

def main():
    if NEW.exists(): raise RuntimeError('Final input manifest already exists; refusing to overwrite')
    names={
      'l8':'Fuxian_edgeconfirm_post2019_L8_native_20240418.tif',
      's2':'Fuxian_edgeconfirm_post2019_S2_20240420_for_20240418.tif',
      'mask':'Fuxian_edgeconfirm_post2019_masks_native_20240418.tif'}
    paths={k:SRC/v for k,v in names.items()}
    for p in paths.values():
        if not p.exists(): raise FileNotFoundError(p)
    ss={k:sig(p) for k,p in paths.items()}
    assert (ss['l8']['bands'],ss['l8']['width'],ss['l8']['height'],ss['l8']['crs'])==(7,542,1095,'EPSG:32648')
    assert (ss['s2']['bands'],ss['s2']['width'],ss['s2']['height'],ss['s2']['crs'])==(8,1623,3281,'EPSG:32648')
    assert (ss['mask']['bands'],ss['mask']['width'],ss['mask']['height'],ss['mask']['crs'])==(5,542,1095,'EPSG:32648')
    copied={}
    for k,p in paths.items():
        q=DATA/p.name; shutil.copy2(p,q); copied[k]=str(q.relative_to(ROOT)).replace('\\','/')
    old=json.loads(OLD.read_text(encoding='utf-8'))
    kept=[r for r in old['records'] if r['l8_date']!='2024-01-29']
    kept.append({'l8_date':'2024-04-18','s2_date':'2024-04-20','calendar_gap_days':2,
      'window':'W5_2024_replacement','l8_clear_shore':None,'s2_clear_shore':None,
      'quality_score':None,'replacement_reason':'2024-01-29 had 28.3% valid shoreline and all 46 segments were low-confidence',
      'files':copied,'sha256':{k:sha256(DATA/Path(v).name) for k,v in copied.items()},'raster_signature':ss})
    kept=sorted(kept,key=lambda r:r['l8_date'])
    payload={
      'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
      'status':'POST2019_FINAL_SIX_INPUTS_VALIDATED_AND_FROZEN',
      'selection_rule':'Quality-only date selection; unusable 2024-01-29 replaced before predictions by pre-screened 2024-04-18',
      'rejected_before_predictions':[{'l8_date':'2024-01-29','reason':'No normal-priority reference segments after prediction-blind quality screening'}],
      'date_count':6,'analysis_file_count':18,'allow_training':False,'allow_model_selection':False,
      'allow_threshold_tuning':False,'model_predictions_opened':False,'records':kept}
    NEW.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':payload['status'],'dates':[r['l8_date'] for r in kept]},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
