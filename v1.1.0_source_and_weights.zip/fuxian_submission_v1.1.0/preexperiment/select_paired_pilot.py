"""Select dates using observed quality and calendar coverage, never model scores."""
import json
from pathlib import Path

root=Path(__file__).resolve().parent
rows=json.loads((root/'results/s2_pair_quality_2020_2025.json').read_text(encoding='utf8'))
dates=[('2020-01-02','train'),('2020-05-09','train'),
       ('2021-02-05','train'),('2021-05-12','train'),
       ('2022-03-12','train'),('2022-08-19','train'),
       ('2023-01-26','validation'),('2023-03-31','validation'),
       ('2024-02-14','test'),('2024-05-04','test'),
       ('2025-05-07','test'),('2025-12-01','test')]
selected=[]
for date,split in dates:
    eligible=[r for r in rows if r['l8_date']==date and r['joint_shore_valid']>=.8]
    if not eligible:
        raise ValueError('No pair passes the preregistered 80% initial screen: '+date)
    # Among pairs passing 90%, choose closest date, then best common coverage.
    # If none pass 90%, retain a partial pair with maximal common coverage.
    core=[r for r in eligible if r['joint_shore_valid']>=.9]
    choice=sorted(core,key=lambda r:(r['calendar_gap_days'],-r['joint_shore_valid']))[0] if core else max(eligible,key=lambda r:r['joint_shore_valid'])
    choice=dict(choice)
    choice.update(split=split,qa_group='core' if choice['joint_shore_valid']>=.9 else 'partial',
                  status='AUTOMATED_PAIR_QA_PASSED_VISUAL_REVIEW_PENDING',
                  temporal_consistency='NOT_VERIFIED',registration='NOT_VERIFIED',
                  label_status='NOT_CREATED',allow_training=False)
    selected.append(choice)
result={'purpose':'12-date preparation pilot, not final paper dataset',
        'source':'results/s2_pair_quality_2020_2025.json',
        'selection_note':'Calendar spread and QA only; no model predictions used. A close date is not evidence of unchanged water level.',
        'records':selected}
(root/'results/pilot_manifest_paired.json').write_text(json.dumps(result,indent=2),encoding='utf8')
summary=[]
for year in range(2020,2026):
    yy=[r for r in rows if r['year']==year]
    summary.append({'year':year,'pairs':len(yy),
                    'unique_l8_joint90':len({r['l8_date'] for r in yy if r['joint_shore_valid']>=.9}),
                    'unique_l8_joint80':len({r['l8_date'] for r in yy if r['joint_shore_valid']>=.8})})
(root/'results/paired_qa_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps({'summary':summary,'pilot':[{'l8':r['l8_date'],'s2':r['s2_date'],'split':r['split'],'joint':round(r['joint_shore_valid']*100,2)} for r in selected]},indent=2))
