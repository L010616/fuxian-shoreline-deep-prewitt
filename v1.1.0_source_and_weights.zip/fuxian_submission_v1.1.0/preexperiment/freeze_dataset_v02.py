"""Freeze corrected prior-anchored train/validation draft labels as dataset v0.2."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from freeze_dataset_v01 import item


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "preexperiment/results/pilot_manifest_paired.json"
OUT = ROOT / "preexperiment/results/dataset_v0.2"
DRAFTS = ROOT / "preexperiment/results/formal_trainval_drafts_v02"


def main() -> None:
    records = json.loads(SOURCE.read_text(encoding="utf-8"))["records"]
    selected = [record for record in records if record["split"] in {"train", "validation"}]
    frozen = []
    for record in selected:
        l8tag = record["l8_date"].replace("-", "")
        s2tag = record["s2_date"].replace("-", "")
        limitations = []
        if record["calendar_gap_days"]:
            limitations.append(f"L8_S2_GAP_{record['calendar_gap_days']}_DAY")
        if record["qa_group"] == "partial":
            limitations.append("PARTIAL_VALID_COVERAGE_USE_JOINT_VALID_MASK")
        if record["l8_date"] == "2020-01-02":
            limitations.append("USE_EXISTING_GOOGLE_EARTH_EXCLUSION_MASK")
        frozen.append({
            "l8_date": record["l8_date"], "s2_date": record["s2_date"],
            "split": record["split"], "qa_group": record["qa_group"],
            "label_status": "PRIOR_ANCHORED_AUTOMATIC_S2_DRAFT_V0.2",
            "allow_final_accuracy_claim": False,
            "limitations": limitations,
            "files": {
                "l8": item(ROOT / f"Fuxian_L8_native_{l8tag}.tif"),
                "s2": item(ROOT / f"Fuxian_S2_{s2tag}.tif"),
                "masks": item(ROOT / f"Fuxian_masks_native_{l8tag}.tif"),
                "draft_label": item(DRAFTS / l8tag / "S2_water_DRAFT.tif"),
            },
        })
    manifest = {
        "version": "0.2",
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "purpose": "corrected reproducible method-development experiments",
        "reference_status": "PRIOR_ANCHORED_AUTOMATIC_DRAFT_NOT_FINAL_TRUTH",
        "test_inputs_opened_after_v0.1_model_freeze": True,
        "test_accuracy_opened": False,
        "correction": (
            "Stable prior interior is forced as the connected lake core; S2 NDWI decisions are restricted "
            "to the fixed shore band to prevent within-lake spectral fronts from becoming shorelines."
        ),
        "split": {"train_dates": 6, "validation_dates": 2, "test_dates": 4},
        "rules": [
            "All loss and metrics use the joint valid observation mask.",
            "The 2019 geometry supplies only the stable interior and search band, never the target shoreline.",
            "Version 0.2 labels still require manual review and cannot support final paper accuracy.",
            "Test accuracy remains unopened until corrected development experiments and reference review finish.",
        ],
        "records": frozen,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "dataset_manifest_v0.2.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
