"""Prepare transparent AI triage and a locked completion gate for core-six review.

This script does not claim or replace human shoreline review.  It only records
where a reviewer should look first and writes the exact file/status contract
used by evaluate_q2_manual_core6.py.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"

ROWS = [
    ("HR01", "MODIFICATION_LIKELY", "S04-S11", "urban/constructed shore; jagged draft segments and short spurs"),
    ("HR02", "INVALID_SECTORS_NEED_CHECK", "S01,S04,S08,S09", "cloud or invalid areas; never interpolate a shoreline through unreadable pixels"),
    ("HR03", "MINOR_CHECK", "S01,S05-S07,S11", "complex bays and built shoreline; verify the visible water-land interface"),
    ("HR04", "MINOR_CHECK", "S02,S04,S05,S10-S12", "peninsulas and small closed contours; retain only the named lake outer shoreline"),
    ("HR05", "MODIFICATION_LIKELY", "S01-S04,S07,S11-S12", "short offshoots and locally jagged draft segments"),
    ("HR06", "MINOR_CHECK", "S02-S05,S07-S10", "constructed and locally jagged shore segments"),
]


def main() -> None:
    fields = ["scene_id", "ai_precheck_priority", "focus_sectors", "reason", "human_decision"]
    with (PACK / "ai_precheck_sectors.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for scene_id, priority, sectors, reason in ROWS:
            writer.writerow({
                "scene_id": scene_id,
                "ai_precheck_priority": priority,
                "focus_sectors": sectors,
                "reason": reason,
                "human_decision": "PENDING",
            })
    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "AI_PRECHECK_ONLY_NOT_HUMAN_REVIEW",
        "may_be_reported_as_human_review": False,
        "purpose": "navigation aid only; reviewers must inspect all shoreline sectors",
        "completion_gate": {
            "required_consensus_status": ["ACCEPTED", "MODIFIED", "INVALID_SECTOR_ONLY"],
            "required_file_per_scene": "shoreline_REVIEWED.geojson",
            "geometry_rule": "one closed outer shoreline LineString for the named lake; islands and internal holes excluded",
            "independent_reviewers_recommended": 2,
            "model_outputs_visible_during_review": False,
        },
    }
    (PACK / "manual_review_completion_contract.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(PACK / "ai_precheck_sectors.csv")
    print(PACK / "manual_review_completion_contract.json")


if __name__ == "__main__":
    main()
