"""Build compact review sites for the remaining train/validation dates."""
from pathlib import Path

import build_wave1_compact_review as review


ROOT = Path(__file__).resolve().parents[1]
review.BASE = ROOT / "preexperiment/results/formal_trainval_drafts"
review.DATES = ["20200102", "20210512", "20220819", "20230126", "20230331"]


if __name__ == "__main__":
    review.main()
