"""Insert the frozen cross-lake experiment into manuscript version 20."""
from __future__ import annotations

import copy
import shutil
from pathlib import Path

from PIL import Image
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt
from docx.table import Table


ROOT = Path(r"D:\Document\ChatGPT\水色")
SOURCE = ROOT / "论文/revision_round13/19_第十九版_普通模型敏感性与引文顺序修订.docx"
OUT_DIR = ROOT / "论文/revision_round14"
OUTPUT = OUT_DIR / "20_第二十版_跨湖零样本外推.docx"
RESULT_DIR = ROOT / "preexperiment/results/q2_cross_lake_zero_shot_v04_waihai_target"
SUMMARY_FIG = RESULT_DIR / "cross_lake_formal_summary.png"
QUAL_FIG = RESULT_DIR / "cross_lake_qualitative_audit_doc.png"


def set_east_asia(run, name: str = "宋体") -> None:
    run.font.name = "Times New Roman"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)


def add_text_before(anchor, text: str, style: str = "Normal", *, bold: bool = False):
    paragraph = anchor.insert_paragraph_before(style=style)
    run = paragraph.add_run(text)
    set_east_asia(run)
    run.bold = bold
    return paragraph


def paragraph_by_exact(doc: Document, text: str):
    for paragraph in doc.paragraphs:
        if paragraph.text.strip() == text:
            return paragraph
    raise KeyError(text)


def append_sentence(paragraph, text: str) -> None:
    run = paragraph.add_run(text)
    set_east_asia(run)


def set_cell(cell, text: str, size: float = 8.0) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    set_east_asia(run)
    run.font.size = Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def clone_result_table(doc: Document, anchor) -> Table:
    # Table 2 is the 14th OOXML table because equations are stored as two-cell tables.
    table_xml = copy.deepcopy(doc.tables[13]._tbl)
    anchor._p.addprevious(table_xml)
    table = Table(table_xml, doc._body)
    table._tbl.remove(table.rows[-1]._tr)
    rows = [
        ["模型", "Precision", "Recall", "F1", "IoU", "BF1 30 m", "ASD/m"],
        ["Spatial prior", "0.9862 ± 0.0067", "0.9976 ± 0.0021", "0.9918 ± 0.0038", "0.9838 ± 0.0073", "0.8446 ± 0.0548", "26.85 ± 5.37"],
        ["Deep Prewitt", "0.9871 ± 0.0062", "0.9977 ± 0.0025", "0.9924 ± 0.0034", "0.9848 ± 0.0067", "0.8658 ± 0.0542", "25.29 ± 5.38"],
        ["Matched conv.", "0.9871 ± 0.0062", "0.9975 ± 0.0023", "0.9923 ± 0.0036", "0.9847 ± 0.0070", "0.8597 ± 0.0534", "25.84 ± 5.79"],
    ]
    for r_index, values in enumerate(rows):
        for c_index, value in enumerate(values):
            set_cell(table.cell(r_index, c_index), value, 8.0 if r_index else 8.5)
            if r_index == 0:
                for run in table.cell(r_index, c_index).paragraphs[0].runs:
                    run.bold = True
    return table


def insert_picture_before(anchor, path: Path, width: float):
    paragraph = anchor.insert_paragraph_before()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.keep_with_next = True
    paragraph.add_run().add_picture(str(path), width=Inches(width))
    return paragraph


def optimize_qualitative() -> None:
    with Image.open(RESULT_DIR / "cross_lake_qualitative_audit.png") as image:
        target_width = 2600
        target_height = round(image.height * target_width / image.width)
        resized = image.convert("RGB").resize((target_width, target_height), Image.Resampling.LANCZOS)
        resized.save(QUAL_FIG, format="PNG", optimize=True, compress_level=9)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    optimize_qualitative()
    shutil.copy2(SOURCE, OUTPUT)
    doc = Document(OUTPUT)

    # Abstracts and contribution list.
    append_sentence(doc.paragraphs[2], " 此外，将抚仙湖冻结检查点零样本外推至滇池外海、洱海和星云湖的18期独立影像，深层Prewitt模型取得0.8658的30 m Boundary F1和25.29 m的平均对称岸线距离；相对空间先验，18期Boundary F1均提高且岸线距离均降低。")
    append_sentence(doc.paragraphs[5], " In an additional zero-shot transfer to 18 independent dates from Dianchi Waihai, Erhai, and Xingyun Lake, the frozen deep Prewitt model achieved a 30 m Boundary F1 of 0.8658 and an average symmetric shoreline distance of 25.29 m; it improved Boundary F1 and reduced shoreline distance relative to the spatial-prior model on all 18 dates.")
    append_sentence(doc.paragraphs[11], " ⑤将冻结模型零样本外推至三个未见湖泊的18期干湿季影像，并在预测盲法冻结的Sentinel-2岸线代理上评价跨湖边缘泛化。")

    # Methods subsection before Results.
    results_anchor = paragraph_by_exact(doc, "3 结果")
    add_text_before(results_anchor, "2.7 跨湖零样本外推协议", "Heading 2")
    add_text_before(results_anchor,
        "为检验空间外推能力，将仅在抚仙湖训练并冻结的空间先验、深层Prewitt和参数量匹配普通卷积检查点直接应用于滇池外海、洱海和星云湖。每湖选取6期未参与训练、验证、阈值确定或检查点选择的Landsat 8影像，干季和湿季各3期，共18期；每期使用近同期Sentinel-2影像生成预测盲法岸线代理。参考代理在查看模型输出前生成，随后仅依据无模型叠加的影像质量图独立复核，18期全部保留并冻结。三个模型使用相同的训练集归一化参数、0.5阈值、共同有效域和固定空间约束。目标定义为命名湖泊的外岸线；由于JRC水体先验中的滇池外海与草海经狭窄水道连通，使用EPSG:32648投影坐标系中北坐标2763300 m的固定边界分离草海，并保留包含外海湖心种子的连通分量。该规则不随日期、模型或误差调整。统计仍以日期为独立单位，先在日期内平均三个种子，再报告18期均值、日期间样本标准差、日期配对自助95%置信区间和双侧Wilcoxon检验。")

    # Main Results subsection before Discussion.
    discussion_anchor = paragraph_by_exact(doc, "4 讨论")
    add_text_before(discussion_anchor, "3.9 跨湖零样本外推", "Heading 2")
    add_text_before(discussion_anchor,
        "冻结模型在三个未见湖泊18期影像上的总体结果见表8，逐湖边界指标和深层Prewitt相对空间先验的日期级增益见图14。所有日期均进入汇总，未依据模型误差或改善方向删除样本。")
    add_text_before(discussion_anchor, "表 8 三个未见湖泊18期零样本外推结果（均值 ± 日期间标准差，n=18）")
    add_text_before(discussion_anchor, "Table 8 Zero-shot transfer to 18 dates from three unseen lakes (mean ± SD across dates, n = 18).")
    clone_result_table(doc, discussion_anchor)
    add_text_before(discussion_anchor,
        "深层Prewitt模型的Precision、Recall、F1和IoU分别为0.9871、0.9977、0.9924和0.9848，30 m Boundary F1为0.8658 ± 0.0542，ASD为25.29 ± 5.38 m。相对空间先验，其Boundary F1在18/18期提高，平均增益为0.0212（日期自助95% CI：0.0161—0.0272；双侧Wilcoxon p=0.000196），ASD也在18/18期降低，平均减少1.57 m（95% CI：1.03—2.21 m；p=0.000196）。相对参数量匹配普通卷积，Boundary F1平均提高0.0061，ASD平均减少0.55 m，但两个置信区间均跨零，日期配对检验分别为p=0.267和p=0.157。因此，跨湖结果强化了深层Prewitt相对空间先验的边缘细化证据，但尚不能证明其普遍优于同容量普通卷积。")
    insert_picture_before(discussion_anchor, SUMMARY_FIG, 6.55)
    add_text_before(discussion_anchor,
        "图 14 三个未见湖泊的零样本外推结果。（a）30 m Boundary F1；（b）平均对称岸线距离；（c）深层Prewitt相对空间先验的日期级Boundary F1增益。柱和误差线表示6期日期均值与样本标准差，散点表示单期增益，粉色横线表示逐湖平均增益。")
    add_text_before(discussion_anchor,
        "Fig. 14. Zero-shot transfer to three unseen lakes. (a) Boundary F1 at 30 m; (b) average symmetric shoreline distance; and (c) date-wise Boundary F1 gain of deep Prewitt over the spatial-prior model. Bars and error bars denote the mean and sample standard deviation across six dates per lake; dots denote individual dates and pink segments denote lake-wise mean gains.")

    # Discussion: replace the superseded single-lake limitation and add an interpretation paragraph.
    limitation = paragraph_by_exact(doc, "4.3 参考岸线与泛化限制")
    next_heading = paragraph_by_exact(doc, "4.4 制图示例的解释边界")
    for paragraph in doc.paragraphs:
        if "研究仅覆盖一个湖盆" in paragraph.text:
            old = paragraph.text
            new = old.replace(
                "研究仅覆盖一个湖盆，空间先验和参考生成共享固定湖盆知识，未来仍需同步RTK/GNSS岸线、多湖泊外部测试和完全不使用候选岸带生成的全景参考。尽管训练集含806个窗口，真正的独立训练单位仍为12个日期；该数据量适用于本文的单湖任务，但尚不足以证明跨湖迁移或极端水位条件下的稳定性。",
                "模型训练仍只覆盖抚仙湖一个湖盆，但新增的滇池外海、洱海和星云湖18期零样本实验提供了多湖泊外部证据。三个目标湖仍集中于云南高原，参考生成也使用相同的遥感代理流程，因此尚不能外推到不同气候区、浑浊度类型或极端水位条件；未来仍需同步RTK/GNSS岸线、跨区域湖泊和不依赖候选岸带生成的全景参考。尽管训练集含806个窗口，真正的独立训练单位仍为12个日期，跨湖结果应解释为冻结模型在相近区域湖泊上的零样本迁移证据，而非普适水体分割能力。")
            paragraph.text = new
            for run in paragraph.runs:
                set_east_asia(run)
            break
    add_text_before(next_heading,
        "跨湖外推中，深层Prewitt相对空间先验在18期均提高Boundary F1并降低ASD，且干季和湿季分组方向一致，说明局部梯度细化并非只依赖抚仙湖的单一岸线形态。另一方面，其相对参数量匹配普通卷积的优势仍未达到显著水平，表明现阶段第二项创新的稳健结论应限定为“显式Prewitt分支稳定改善空间先验基线”，而不能扩展为“显著优于所有同容量可学习卷积”。外部参考为Sentinel-2遥感岸线代理，跨湖高区域F1主要受大面积易分类湖心像元影响，因此图14和表8的解释仍以Boundary F1与ASD为主。")

    # Conclusion and availability statement.
    conclusion_anchor = paragraph_by_exact(doc, "数据与代码可用性")
    conclusion_paragraphs = [p for p in doc.paragraphs if p.text.startswith("结果支持空间先验与显式梯度信息")]
    if conclusion_paragraphs:
        append_sentence(conclusion_paragraphs[0], " 在滇池外海、洱海和星云湖18期零样本外推中，深层Prewitt相对空间先验的Boundary F1和ASD分别在18/18期改善，表明这一局部边缘收益能够迁移至未见湖泊；相对参数量匹配普通卷积的差异仍不显著。")
    availability = next(p for p in doc.paragraphs if p.text.startswith("原始Landsat 8、Sentinel-2和JRC"))
    append_sentence(availability, " 跨湖冻结参考清单、命名湖泊目标掩膜规则、18期逐日期结果、三模型三种子输出和协议修正审计文件也将一并归档。")

    # Supplementary qualitative audit.
    heading = doc.add_paragraph("S7 跨湖零样本外推的逐日期定性核查", style="Heading 2")
    heading.paragraph_format.page_break_before = True
    p = doc.add_paragraph("图S3展示三个未见湖泊各6期的冻结Sentinel-2岸线代理与深层Prewitt预测岸线。参考代理在模型输出之前生成，独立影像质量复核后18期全部保留；多云日期仅在Landsat 8与Sentinel-2共同有效域内评价。粉色表示冻结参考岸线，紫色表示深层Prewitt预测岸线。")
    for run in p.runs:
        set_east_asia(run)
    pic = doc.add_paragraph()
    pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.add_run().add_picture(str(QUAL_FIG), width=Inches(6.55))
    cn = doc.add_paragraph("图 S3 三个未见湖泊18期零样本外推的定性核查。每行对应一个湖泊，每列对应一个独立日期；粉色和紫色分别表示冻结Sentinel-2岸线代理与深层Prewitt预测岸线。")
    en = doc.add_paragraph("Fig. S3. Qualitative audit of zero-shot transfer on 18 dates from three unseen lakes. Rows denote lakes and columns denote independent dates; pink and purple lines indicate the frozen Sentinel-2 shoreline proxy and the deep Prewitt prediction, respectively.")
    for paragraph in (heading, cn, en):
        for run in paragraph.runs:
            set_east_asia(run)

    # Refresh the Word field-update flag without changing visible content.
    settings = doc.settings._element
    update = settings.find(qn("w:updateFields"))
    if update is None:
        update = OxmlElement("w:updateFields")
        settings.append(update)
    update.set(qn("w:val"), "true")
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    main()
