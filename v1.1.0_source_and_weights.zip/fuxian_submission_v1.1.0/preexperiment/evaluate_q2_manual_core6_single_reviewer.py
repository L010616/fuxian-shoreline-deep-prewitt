"""Run a clearly labelled single-reviewer provisional core-six evaluation.

The locked two-reviewer evaluator and its original review form remain
unchanged.  This wrapper exists so useful analysis can proceed before an
independent second reviewer and consensus decision are available.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import evaluate_q2_manual_core6 as locked


PACK = locked.PACK
OUT = locked.ROOT / "preexperiment/results/q2_manual_core6_evaluation_single_reviewer_provisional"
FORM = PACK / "manual_review_form_single_reviewer.csv"


def single_review_rows() -> list[dict]:
    with FORM.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    errors = []
    if len(rows) != 6:
        errors.append(f"expected six rows, found {len(rows)}")
    for row in rows:
        scene_id = row.get("scene_id", "UNKNOWN")
        if not row.get("reviewer_A", "").strip() or row.get("reviewer_A_status") not in locked.ALLOWED:
            errors.append(f"{scene_id}: reviewer A status incomplete")
        candidate = PACK / scene_id / "shoreline_REVIEWED.geojson"
        row["reviewed_path"] = candidate
        if not candidate.exists():
            errors.append(f"{scene_id}: missing {candidate}")
        row["consensus_status"] = "SINGLE_REVIEWER_PROVISIONAL"
    if errors:
        raise RuntimeError("SINGLE REVIEW GATE CLOSED:\n- " + "\n- ".join(errors))
    return rows


def main() -> None:
    locked.OUT = OUT
    locked.review_rows = single_review_rows
    locked.main()
    result = OUT / "manual_core6_results.json"
    payload = json.loads(result.read_text(encoding="utf-8"))
    payload["status"] = "MANUAL_CORE6_SINGLE_REVIEWER_PROVISIONAL_COMPLETE"
    payload["review_stage"] = "single_reviewer_provisional"
    payload["independent_second_review_complete"] = False
    payload["consensus_complete"] = False
    payload["formal_two_reviewer_gate_preserved"] = True
    payload["review_form"] = str(FORM)
    result.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
