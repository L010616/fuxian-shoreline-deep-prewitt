"""Build topology-safe, prediction-blind shoreline candidates for review.

The former implementation retained the longest open contour fragment and
closed it by joining its endpoints. For scenes with masked shoreline pixels,
that operation created an artificial chord across the lake. This version
reconstructs the named lake from the binary review raster, polygonizes its main
connected component, and exports the polygon exterior. No open fragment is
ever force-closed.

Outputs remain annotation aids, not reference truth.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import shapes
from rasterio.warp import transform
from scipy import ndimage as ndi
from skimage.measure import approximate_polygon


ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"

NOTES = {
    "HR01": ("FULL_REVIEW_REQUIRED", "S04-S07,S10-S11", "复核浅水植被、港池和狭窄支汊。"),
    "HR02": ("FULL_REVIEW_REQUIRED", "S01,S04,S08,S09", "复核云影与不可判读岸段，不跨越缺测区补画。"),
    "HR03": ("FULL_REVIEW_REQUIRED", "S01,S05-S07,S11", "复核城市岸段、复杂湾顶和半岛根部。"),
    "HR04": ("FULL_REVIEW_REQUIRED", "S02,S04-S05,S10-S12", "复核复杂半岛，仅保留命名湖泊外岸线。"),
    "HR05": ("FULL_REVIEW_REQUIRED", "S01-S04,S07,S10-S12", "复核入湖沟渠、短小尖刺和主湖外岸线。"),
    "HR06": ("FULL_REVIEW_REQUIRED", "S02-S05,S07-S10", "复核入湖沟渠、人工岸段和局部凹湾。"),
}


def ring_length(xy: np.ndarray) -> float:
    return float(np.linalg.norm(np.diff(xy, axis=0), axis=1).sum())


def signed_area(xy: np.ndarray) -> float:
    x, y = xy[:, 0], xy[:, 1]
    return float(0.5 * np.sum(x[:-1] * y[1:] - x[1:] * y[:-1]))


def topology_safe_exterior(mask_path: Path) -> tuple[list[list[float]], dict]:
    """Return the closed exterior of the largest 8-connected water component."""
    with rasterio.open(mask_path) as ds:
        water = ds.read(1) == 1
        labels, count = ndi.label(water, structure=np.ones((3, 3), dtype=np.uint8))
        if count == 0:
            raise RuntimeError(f"No water component in {mask_path}")
        sizes = np.bincount(labels.ravel())
        sizes[0] = 0
        main = labels == int(sizes.argmax())

        polygons = [geom for geom, value in shapes(
            main.astype(np.uint8), mask=main, transform=ds.transform,
            connectivity=8
        ) if int(value) == 1]
        if not polygons:
            raise RuntimeError(f"Polygonization failed: {mask_path}")
        polygon = max(polygons, key=lambda g: abs(signed_area(np.asarray(g["coordinates"][0]))))
        exterior = np.asarray(polygon["coordinates"][0], dtype=float)
        if not np.array_equal(exterior[0], exterior[-1]):
            raise RuntimeError("Raster polygon exterior is unexpectedly open")

        simplified = approximate_polygon(exterior, tolerance=7.5)
        if not np.array_equal(simplified[0], simplified[-1]):
            raise RuntimeError("Simplification opened a closed raster exterior")
        if len(simplified) < 4:
            raise RuntimeError("Simplified exterior has fewer than four vertices")

        segments = np.linalg.norm(np.diff(simplified, axis=0), axis=1)
        length_m = ring_length(simplified)
        max_segment_m = float(segments.max())
        if max_segment_m > 500 or max_segment_m / max(length_m, 1.0) > 0.01:
            raise RuntimeError(
                f"Suspicious segment remains: {max_segment_m:.1f} m of {length_m:.1f} m"
            )

        lon, lat = transform(ds.crs, "EPSG:4326",
                             simplified[:, 0].tolist(), simplified[:, 1].tolist())
        coords = [[float(x), float(y)] for x, y in zip(lon, lat)]
        qc = {
            "source_water_components": int(count),
            "main_component_pixels": int(main.sum()),
            "candidate_vertices": len(coords),
            "closed": coords[0] == coords[-1],
            "length_m": round(length_m, 2),
            "max_segment_m": round(max_segment_m, 2),
            "max_segment_fraction": round(max_segment_m / length_m, 6),
            "construction": "largest_8_connected_water_component_polygon_exterior",
            "forced_endpoint_closure": False,
        }
        return coords, qc


def main() -> None:
    records = []
    for scene_id, (precheck, sectors, note) in NOTES.items():
        scene_dir = PACK / scene_id
        source = scene_dir / "S2_water_FOR_REVIEW_10m.tif"
        coordinates, qc = topology_safe_exterior(source)
        feature = {
            "type": "Feature",
            "properties": {
                "scene_id": scene_id,
                "status": "CORRECTED_INITIAL_CANDIDATE_NOT_HUMAN_REVIEWED",
                "manual_edit_required": True,
                "review_focus_sectors": sectors,
                "source": source.name,
                "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                **qc,
            },
            "geometry": {"type": "LineString", "coordinates": coordinates},
        }
        target = scene_dir / "shoreline_CORRECTED_INITIAL.geojson"
        target.write_text(json.dumps(
            {"type": "FeatureCollection", "features": [feature]}, ensure_ascii=False
        ), encoding="utf-8")
        record = {
            "scene_id": scene_id,
            "review_status": precheck,
            "focus_sectors": sectors,
            "review_notes": note,
            "candidate_file": str(target.relative_to(PACK)).replace("\\", "/"),
            "human_reviewer_decision": "PENDING_R2",
            **qc,
        }
        records.append(record)
        print(json.dumps(record, ensure_ascii=False))

    with (PACK / "corrected_initial_candidate_qc.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    (PACK / "corrected_initial_candidate_qc.json").write_text(
        json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
