"""Render fixed-seed full-lake qualitative comparisons for two test dates."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi

from run_locked_test_model_comparison import load_scenes, normalize_and_exclude
from run_multidate_ablation_pilot import predict
from run_standard_model_comparison_pilot import build_models


ROOT = Path(__file__).resolve().parents[1]
MODEL_DIR = ROOT / "preexperiment/results/fair_comparison_3seed_corrected_labels_v03"
OUT = ROOT / "preexperiment/manuscript_ready/figures"
SEED = 20260913
TARGETS = {"2025-12-01", "2026-02-03"}
NAMES = {"proposed_parallel": "Proposed", "unet_resnet18": "U-Net", "deeplabv3plus_resnet18": "DeepLabV3+", "segformer_mit_b0": "SegFormer-B0"}


def edge(mask):
    return mask & ~ndi.binary_erosion(mask)


def rgb(scene):
    arr = scene["x_raw"][[2, 1, 0]].transpose(1, 2, 0).astype("float32")
    out = np.empty_like(arr)
    for b in range(3):
        values = arr[:, :, b][scene["roi"] & np.isfinite(arr[:, :, b])]
        lo, hi = np.percentile(values, [2, 98])
        out[:, :, b] = np.clip((arr[:, :, b] - lo) / max(hi - lo, 1e-6), 0, 1)
    return (out ** 0.75 * 255).astype("uint8")


def overlay(base, truth, prediction, valid):
    image = base.copy()
    ref = ndi.binary_dilation(edge(truth) & valid, iterations=1)
    pred = ndi.binary_dilation(edge(prediction) & valid, iterations=1)
    image[ref] = [0, 235, 255]
    image[pred] = [255, 50, 160]
    image[ref & pred] = [255, 245, 60]
    image[~valid & ndi.binary_dilation(edge(truth), iterations=2)] = [110, 110, 110]
    return image


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    config = json.loads((MODEL_DIR / "config.json").read_text(encoding="utf-8"))
    scenes = [s for s in load_scenes() if s["record"]["l8_date"] in TARGETS]
    normalize_and_exclude(scenes, config["normalization"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    factories = build_models()
    predictions = {s["record"]["l8_date"]: {} for s in scenes}
    for name in NAMES:
        model = factories[name]().to(device).eval()
        ckpt = torch.load(MODEL_DIR / f"{name}_seed{SEED}_best.pt", map_location=device, weights_only=False)
        model.load_state_dict(ckpt["model"])
        for scene in scenes:
            predictions[scene["record"]["l8_date"]][name] = predict(model, scene, device) >= 0.5
        del model
        if device.type == "cuda": torch.cuda.empty_cache()
    title_font = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 34)
    legend_font = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 26)
    for scene in scenes:
        date = scene["record"]["l8_date"]; base = rgb(scene); h, w = base.shape[:2]
        canvas = Image.new("RGB", (w * 4, h + 110), "white"); draw = ImageDraw.Draw(canvas)
        for i, (name, label) in enumerate(NAMES.items()):
            panel = Image.fromarray(overlay(base, scene["y"].astype(bool), predictions[date][name], scene["valid"]))
            canvas.paste(panel, (i * w, 54)); box = draw.textbbox((0,0),label,font=title_font)
            draw.text((i*w+(w-(box[2]-box[0]))/2,8),label,font=title_font,fill="#111111")
        legend = f"{date} | cyan: reference  magenta: prediction  yellow: overlap  gray: excluded"
        draw.text((20, h+68), legend, font=legend_font, fill="#111111")
        canvas.save(OUT / f"figure_qualitative_{date.replace('-', '')}.png", dpi=(600,600), optimize=True)
        canvas.save(OUT / f"figure_qualitative_{date.replace('-', '')}.pdf", "PDF", resolution=600)
    print(json.dumps({"dates": sorted(TARGETS), "files": 4, "seed": SEED}, ensure_ascii=False))


if __name__ == "__main__": main()
