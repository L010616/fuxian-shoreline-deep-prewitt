from pathlib import Path
import json
import build_wave1_reference_drafts as builder
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'preexperiment/data/edge_confirmatory_post2019'
OUT=ROOT/'preexperiment/results/edge_confirmatory_post2019/reference_drafts'
builder.DATA_ROOT=BASE/'analysis_ready'; builder.OUT=OUT
builder.L8_TEMPLATE='Fuxian_edgeconfirm_post2019_L8_native_{l8_tag}.tif'
builder.S2_TEMPLATE='Fuxian_edgeconfirm_post2019_S2_{s2_tag}_for_{l8_tag}.tif'
builder.MASK_TEMPLATE='Fuxian_edgeconfirm_post2019_masks_native_{l8_tag}.tif'
rec={'l8_date':'2024-04-18','s2_date':'2024-04-20','calendar_gap_days':2,'split':'post2019_edge_confirmatory_test'}
result=builder.build_one(rec)
print(json.dumps(result,ensure_ascii=False,indent=2))

