"""Validate the six additional-test GeoTIFFs on the frozen export grids."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from validate_formal_downloads import discover, inspect_tif


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "preexperiment/results/additional_test_pairs_v01.json"
OUT = ROOT / "preexperiment/results/additional_test_download_qc_v01.json"


def main() -> int:
    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["selected"]
    found = discover(ROOT)
    rows = []
    for record in records:
        lt = record["l8_date"].replace("-", "")
        st = record["s2_date"].replace("-", "")
        expected = {
            "l8": f"Fuxian_L8_native_{lt}.tif",
            "s2": f"Fuxian_S2_{st}.tif",
            "masks": f"Fuxian_masks_native_{lt}.tif",
        }
        files = {}
        for kind, name in expected.items():
            matches = found.get(name.lower(), [])
            if len(matches) == 1:
                files[kind] = inspect_tif(matches[0], kind)
            else:
                files[kind] = {
                    "expected_name": name,
                    "status": "MISSING" if not matches else "DUPLICATE",
                    "paths": [str(path) for path in matches],
                }
        rows.append({
            "l8_date": record["l8_date"],
            "s2_date": record["s2_date"],
            "files": files,
            "status": "PASS" if all(item["status"] == "PASS" for item in files.values()) else "INCOMPLETE_OR_FAILED",
        })
    report = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "PASS" if all(row["status"] == "PASS" for row in rows) else "WAITING_OR_FAILED",
        "expected_dates": len(rows),
        "passed_dates": sum(row["status"] == "PASS" for row in rows),
        "records": rows,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": report["status"], "passed_dates": report["passed_dates"], "expected_dates": len(rows)}, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
