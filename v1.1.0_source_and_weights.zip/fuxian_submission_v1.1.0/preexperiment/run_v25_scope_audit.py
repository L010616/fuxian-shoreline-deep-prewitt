"""Post-review scope audit; fixed models, dates, thresholds, and original results.

This is an exploratory sensitivity analysis, not a newly blinded confirmation.
The expanded S2 masks are unsurveyed spectral proxies. No model is selected here.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio
import torch
from rasterio.enums import Resampling
from rasterio.warp import reproject, transform
from scipy import ndimage as ndi
from skimage.measure import find_contours

import run_q2_cross_lake_zero_shot as base
import evaluate_q2_manual_core6 as manual
import evaluate_q2_manual_core6_r2 as manual_r2
from run_deep_edge_component_ablation import DeepSingleOperatorDFANet
from run_parameter_matched_conv_control import ParameterMatchedConvDFANet
from run_multidate_ablation_pilot import predict

ROOT = base.ROOT
OUT = ROOT / "preexperiment/results/v25_supplementary_20261001"
AUDIT = OUT / "scope_audit"
WIDE_M = 1000.0


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def warp(source, src, scene, resampling=Resampling.average):
    arr = np.full(scene["y"].shape, np.nan, dtype="float32")
    reproject(source.astype("float32"), arr, src_transform=src.transform,
              src_crs=src.crs, dst_transform=scene["profile"]["transform"],
              dst_crs=scene["profile"]["crs"], src_nodata=None,
              dst_nodata=np.nan, resampling=resampling)
    return arr


def upsample(mask, scene, src):
    arr = np.zeros((src.height, src.width), dtype="uint8")
    reproject(mask.astype("uint8"), arr,
              src_transform=scene["profile"]["transform"], src_crs=scene["profile"]["crs"],
              dst_transform=src.transform, dst_crs=src.crs, resampling=Resampling.nearest)
    return arr > 0


def contour_coverage(water, valid, belt, src, metadata):
    contours = find_contours(water.astype("uint8"), .5)
    if not contours:
        raise RuntimeError(f"Empty contour: {metadata}")
    # Exactly one outer target; internal holes were filled before contouring.
    c = max(contours, key=lambda a: len(a))
    mid = (c[:-1] + c[1:]) / 2
    rr = np.clip(np.rint(mid[:, 0]).astype(int), 0, valid.shape[0]-1)
    cc = np.clip(np.rint(mid[:, 1]).astype(int), 0, valid.shape[1]-1)
    lengths = np.sqrt((np.diff(c[:, 0])*abs(src.transform.e))**2 +
                      (np.diff(c[:, 1])*abs(src.transform.a))**2)
    safe = ndi.binary_erosion(valid, iterations=2)
    good = safe[rr, cc]
    in_belt = belt[rr, cc]
    total = float(lengths.sum())
    retained = float(lengths[good].sum())
    inside = float(lengths[good & in_belt].sum())
    if retained == 0:
        raise RuntimeError(f"No valid independent shoreline: {metadata}")
    outside = good & ~in_belt
    dist = ndi.distance_transform_edt(~belt, sampling=(abs(src.transform.e), abs(src.transform.a)))
    values = dist[rr[outside], cc[outside]]
    row = {**metadata, "full_outer_ring_km": total/1000,
           "joint_valid_outer_ring_km": retained/1000,
           "joint_valid_fraction_of_ring": retained/total,
           "inside_original_band_km": inside/1000,
           "outside_original_band_km": (retained-inside)/1000,
           "coverage_fraction_on_joint_valid_ring": inside/retained,
           "outside_max_distance_m": float(values.max()) if len(values) else 0.0}
    return row


def prepare():
    AUDIT.mkdir(parents=True, exist_ok=False)
    (AUDIT / "references").mkdir()
    frozen = json.loads((base.OUT / "frozen_evaluation_manifest.json").read_text(encoding="utf-8"))
    records = base.selected_records()
    by_key = {(r["lake"], r["l8_date"]): r for r in frozen["records"]}
    human = {(r["lake"], r["l8_date"]): r for r in manual_r2.r2_rows()}
    human_old = json.loads((manual_r2.OUT / "manual_core6_results.json").read_text(encoding="utf-8"))
    human_hash = {Path(r["path"]).name+Path(r["path"]).parent.name: r["sha256"] for r in human_old["reviewed_files"]}
    coverage, metadata = [], []
    for r in records:
        tag = f"{r['lake']}_{r['l8_date']}"
        for name, p in r["paths"].items():
            if base.sha256(p) != by_key[(r["lake"], r["l8_date"])]["files"][name]["sha256"]:
                raise RuntimeError(f"Input changed since frozen evaluation: {p}")
        s = base.read_scene(r)
        lake = s["interior"] | (s["shore"] & ndi.binary_fill_holes(s["interior"]))
        # Recover the exact JRC lake used in the formal v04 run, not a prediction.
        with rasterio.open(r["paths"]["qa"]) as qa:
            masks = qa.read()
            lake = base.external.main_component(masks[0]>=2, qa, r["lake"])
            if r["lake"] == "Dianchi_Waihai":
                north = qa.transform.f + (np.arange(qa.height)+.5)*qa.transform.e
                lake &= north[:, None] <= 2763300
                lake = base.external.main_component(lake, qa, r["lake"])
            lake = ndi.binary_fill_holes(lake)
        wide = ndi.distance_transform_edt(~lake, sampling=30) <= WIDE_M
        if r["lake"] == "Dianchi_Waihai":
            wide &= north[:, None] <= 2763300
        finite = np.all(np.isfinite(s["x_raw"]) & (s["x_raw"]>-9000), axis=0)
        threshold_path = r["paths"]["draft"].parent / "draft_manifest.json"
        threshold = float(json.loads(threshold_path.read_text(encoding="utf-8"))["threshold_ndwi"])
        with rasterio.open(r["paths"]["s2"]) as src:
            green, nir = src.read(2).astype("float32"), src.read(4).astype("float32")
            domain = upsample(wide, s, src)
            belt = upsample(s["shore"], s, src)
            prior10 = upsample(lake, s, src)
            joint10 = upsample(masks[3]>0, s, src)
            good = (src.read(8)>0) & (green+nir>0) & joint10 & domain
            ndwi = np.zeros(green.shape, dtype="float32")
            np.divide(green-nir, green+nir, out=ndwi, where=green+nir>0)
            # Invalid prior water bridges clouds only; observed water is spectral.
            candidate = ((good & (ndwi>threshold)) | (~good & prior10)) & domain
            labels, count = ndi.label(candidate, structure=np.ones((3,3), dtype="uint8"))
            xs, ys = transform("EPSG:4326", src.crs, [base.external.SEEDS[r['lake']][0]], [base.external.SEEDS[r['lake']][1]])
            col, row = (~src.transform)*(xs[0], ys[0])
            lab = int(labels[int(row), int(col)])
            fallback = False
            if lab == 0:
                anchor = upsample(s["interior"], s, src)
                votes = np.bincount(labels[anchor].ravel(), minlength=count+1); votes[0]=0
                lab = int(votes.argmax()); fallback = True
            if lab == 0:
                raise RuntimeError(f"No target component: {tag}")
            water = ndi.binary_fill_holes(labels==lab)
            full_truth = warp(water, src, s) >= .5
            wide_valid = wide & finite & (masks[3]>0) & (warp(good, src, s)>=.999)
            row_meta = {"reference": "expanded_S2_spectral_proxy", "lake": r["lake"],
                        "l8_date": r["l8_date"], "s2_date": r["s2_date"], "season": r["season"]}
            coverage.append(contour_coverage(water, good, belt, src, row_meta))
            arrays = {"old_truth": s["y"], "old_valid": s["valid"], "shore": s["shore"],
                      "wide": wide, "wide_truth": full_truth, "wide_valid": wide_valid}
            if (r["lake"], r["l8_date"]) in human:
                h = human[(r["lake"], r["l8_date"])]
                hp = h["reviewed_path"]
                if base.sha256(hp) != human_hash[hp.name+hp.parent.name]:
                    raise RuntimeError(f"Human reference hash changed: {hp}")
                hwater = manual.reviewed_mask(hp, r["paths"]["draft"])
                arrays["manual_truth"] = warp(hwater, src, s)>=.5
                coverage.append(contour_coverage(hwater, good, belt, src,
                                  {**row_meta, "reference":"manual_R2_outer_ring"}))
            rp = AUDIT / "references" / f"{tag}.npz"
            np.savez_compressed(rp, **arrays)
            meta = {"tag":tag, "lake":r["lake"], "l8_date":r["l8_date"], "s2_date":r["s2_date"],
                    "season":r["season"], "threshold_ndwi":threshold,
                    "threshold_manifest_sha256":base.sha256(threshold_path),
                    "reference_cache_sha256":base.sha256(rp),
                    "component_seed_fallback_to_prior_overlap":fallback}
            metadata.append(meta)
        print(f"PREPARED {tag}", flush=True)
    write_csv(AUDIT / "reference_band_coverage.csv", coverage)
    write_json(AUDIT / "protocol_before_inference.json", {
        "created_at":datetime.now().astimezone().isoformat(timespec="seconds"),
        "status":"POST_REVIEW_SENSITIVITY_REFERENCES_FIXED_BEFORE_NEW_INFERENCE",
        "original_results_modified":False, "model_selection":False,
        "expanded_domain":"fixed 1000 m Euclidean buffer of original JRC named-lake footprint; fixed Waihai north boundary retained",
        "automatic_reference":"same previously recorded NDWI Otsu threshold; observed pixels classified throughout expanded domain; invalid JRC water bridges missing cloud pixels only; centre component retained and holes filled",
        "limitation":"Expanded references remain automatic S2 spectral proxies, not new human or survey ground truth. Invalid segments and crop edges are excluded. Reference threshold and component identity still use prior information.",
        "boundary_support":"legacy queries: erosion(original valid & original band,3); full queries: erosion(expanded joint-valid domain,3); nearest targets: erosion(corresponding valid,1)",
        "aggregation":"Both per-seed metric means and metrics of mean-probability ensemble are reported separately. Original cross-lake tables used the latter.",
        "checkpoints":frozen["checkpoints"], "records":metadata})


def support(truth, valid, query):
    safe = ndi.binary_erosion(valid, iterations=1)
    core = ndi.binary_erosion(valid & query, iterations=3)
    tb = (truth ^ ndi.binary_erosion(truth)) & safe
    tq = tb & core
    if not tb.any() or not tq.any():
        raise RuntimeError("Empty reference boundary in diagnostic support")
    dt = ndi.distance_transform_edt(~tb)*30
    return safe, core, tb, tq, dt


def measure(prob, truth, valid, cache):
    safe, core, tb, tq, dt = cache
    pred = prob>=.5
    p, t = pred[valid], truth[valid]
    tp, fp, fn = int((p&t).sum()), int((p&~t).sum()), int((~p&t).sum())
    prec, rec = tp/max(tp+fp,1), tp/max(tp+fn,1)
    pb = (pred ^ ndi.binary_erosion(pred)) & safe
    pq = pb & core
    if not pb.any() or not pq.any():
        raise RuntimeError("Empty predicted boundary")
    dp = ndi.distance_transform_edt(~pb)*30
    a, b = dt[pq], dp[tq]
    out = {"precision":prec, "recall":rec, "f1":2*prec*rec/max(prec+rec,1e-12),
           "iou":tp/max(tp+fp+fn,1), "mean_symmetric_boundary_distance_m":float((a.mean()+b.mean())/2),
           "hd95_m":float(max(np.percentile(a,95),np.percentile(b,95))),
           "prediction_query_count":int(pq.sum()), "reference_query_count":int(tq.sum()),
           "valid_pixels":int(valid.sum())}
    for tol in (30,60):
        bp, br = float((a<=tol).mean()), float((b<=tol).mean())
        out[f"boundary_f1_{tol}m"] = 2*bp*br/(bp+br+1e-12)
    return out


def infer():
    protocol = json.loads((AUDIT / "protocol_before_inference.json").read_text(encoding="utf-8"))
    configs = {"spatial_prior":base.fusion.CONFIGS["prior"][0],
               "deep_prewitt":lambda:DeepSingleOperatorDFANet("prewitt"),
               "parameter_matched_ordinary_conv":ParameterMatchedConvDFANet}
    checkpoints = {m:{int(seed):ROOT / row["path"] for seed,row in seeds.items()}
                   for m,seeds in protocol["checkpoints"].items()}
    stats = json.loads((base.COMPONENT / "deep_edge_component_ablation_results.json").read_text(encoding="utf-8"))["normalization"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.set_num_threads(4)
    models = {}
    for name in base.MODELS:
        for seed in base.SEEDS:
            p = checkpoints[name][seed]
            if base.sha256(p) != protocol["checkpoints"][name][str(seed)]["sha256"]:
                raise RuntimeError(f"Checkpoint changed: {p}")
            model = configs[name]().to(device)
            state = torch.load(p, map_location=device, weights_only=False)
            model.load_state_dict(state["model"]); model.eval()
            models[(name,seed)] = model
    pd = AUDIT / "raw_probability_cache"; pd.mkdir(exist_ok=True)
    md = AUDIT / "per_scene_metrics"; md.mkdir(exist_ok=True)
    old = json.loads((base.OUT / "cross_lake_zero_shot_results.json").read_text(encoding="utf-8"))
    rows, checks = [], []
    for r, meta in zip(base.selected_records(), protocol["records"]):
        tag = meta["tag"]
        metric_file = md / f"{tag}.json"
        if metric_file.exists():
            saved = json.loads(metric_file.read_text(encoding="utf-8"))
            rows.extend(saved["rows"]); checks.extend(saved["checks"])
            print(f"RESUME {tag}", flush=True); continue
        rp = AUDIT / "references" / f"{tag}.npz"
        if base.sha256(rp) != meta["reference_cache_sha256"]:
            raise RuntimeError(f"Reference changed: {rp}")
        arrays = dict(np.load(rp))
        s = base.read_scene(r); base.normalize([s], stats)
        definitions = {
            "legacy_belt":(arrays["old_truth"],arrays["old_valid"],arrays["shore"]),
            "expanded_proxy_full":(arrays["wide_truth"],arrays["wide_valid"],arrays["wide"]),
            "expanded_proxy_belt":(arrays["wide_truth"],arrays["wide_valid"],arrays["shore"]),
        }
        if "manual_truth" in arrays:
            definitions["manual_full"]=(arrays["manual_truth"],arrays["wide_valid"],arrays["wide"])
            definitions["manual_legacy_belt"]=(arrays["manual_truth"],arrays["old_valid"],arrays["shore"])
        caches={name:support(*items) for name,items in definitions.items()}
        local, local_checks = [], []
        for name in base.MODELS:
            probs=[]
            for seed in base.SEEDS:
                pp=pd / f"{tag}_{name}_seed{seed}.npz"
                if pp.exists():
                    prob=np.load(pp)["probability"]
                else:
                    with torch.inference_mode():
                        prob=predict(models[(name,seed)],s,device)
                    np.savez_compressed(pp, probability=prob)
                probs.append(prob)
                for scheme,(truth,valid,query) in definitions.items():
                    met=measure(prob,truth,valid,caches[scheme])
                    local.append({"model":name,"aggregation":"single_seed","seed":seed,
                                  "scope":scheme,"prediction":"raw", **{k:meta[k] for k in ("lake","l8_date","s2_date","season")}, **met})
            ensemble=np.mean(probs,axis=0).astype("float32")
            for constrained in (False,True):
                prob=base.apply_frozen_spatial_constraint(ensemble,s) if constrained else ensemble
                for scheme,(truth,valid,query) in definitions.items():
                    met=measure(prob,truth,valid,caches[scheme])
                    local.append({"model":name,"aggregation":"probability_ensemble","seed":"ensemble",
                                  "scope":scheme,"prediction":"constrained" if constrained else "raw",
                                  **{k:meta[k] for k in ("lake","l8_date","s2_date","season")}, **met})
                    if constrained and scheme=="legacy_belt":
                        previous=old["three_seed_ensemble_per_date"][name][tag]
                        diffs={k:abs(met[k]-previous[k]) for k in base.KEYS}
                        maxdiff=max(diffs.values())
                        local_checks.append({"tag":tag,"model":name,"max_absolute_metric_difference":maxdiff})
                        if maxdiff>1e-5:
                            raise RuntimeError(f"Original result reproduction failed: {tag} {name} {diffs}")
            print(f"INFERRED {tag} {name}",flush=True)
        write_json(metric_file,{"rows":local,"checks":local_checks})
        rows.extend(local); checks.extend(local_checks)
    write_csv(AUDIT / "all_scope_per_date_seed_metrics.csv",rows)
    write_csv(AUDIT / "original_result_reproduction_checks.csv",checks)
    write_json(AUDIT / "completion.json",{"status":"COMPLETE", "created_at":datetime.now().astimezone().isoformat(timespec="seconds"),
        "n_dates":18,"n_models":3,"n_seeds":3,"n_metric_rows":len(rows),"original_results_reproduced":True,
        "max_original_result_difference":max(r["max_absolute_metric_difference"] for r in checks),
        "protocol_sha256":base.sha256(AUDIT / "protocol_before_inference.json")})


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("stage",choices=("prepare","infer"))
    args=parser.parse_args()
    os.environ.setdefault("MPLCONFIGDIR", str(OUT / "matplotlib_cache"))
    prepare() if args.stage=="prepare" else infer()
