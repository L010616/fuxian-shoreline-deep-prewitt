"""Write conservative AI triage for the 24 compact test-review sites.

This file never edits labels and never authorizes test evaluation.
"""
from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/formal_test_drafts_v02"

TRIAGE = {
    "20240214_R01": ("PASS_CANDIDATE", "high", "Cyan segment coincides with the visible outer water-land edge."),
    "20240214_R02": ("PASS_CANDIDATE", "high", "Cyan segment follows the visible beach/water edge."),
    "20240214_R03": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies inland from the visible lake edge."),
    "20240214_R04": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies inland; S2 view is also obscured by haze/cloud."),
    "20240214_R05": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies in open water and does not trace the visible island or outer shore."),
    "20240214_R06": ("EXCLUDE_CANDIDATE", "high", "Reference view is cloud-obscured and the segment does not reliably trace the visible shore."),
    "20240504_R01": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies on land and the reference view is cloud-obscured."),
    "20240504_R02": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies in open water away from the visible shore."),
    "20240504_R03": ("PASS_CANDIDATE", "medium", "Segment aligns with a short visible headland edge; nearby cloud requires confirmation."),
    "20240504_R04": ("EXCLUDE_CANDIDATE", "high", "Cloud covers the reference edge, so its position cannot be verified reliably."),
    "20240504_R05": ("PASS_CANDIDATE", "high", "Long cyan segment follows the visible engineered outer shore."),
    "20240504_R06": ("PASS_CANDIDATE", "high", "Cyan segment follows the visible curved water-land edge."),
    "20250507_R01": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies in water and the two-day reference view is heavily cloud-obscured."),
    "20250507_R02": ("EXCLUDE_CANDIDATE", "high", "Cloud/shadow obscures the edge and the segment is displaced lakeward."),
    "20250507_R03": ("REDRAW_CANDIDATE", "high", "Part follows an artificial shore, but a loop and lakeward spur require redraw."),
    "20250507_R04": ("EXCLUDE_CANDIDATE", "high", "Cloud and shadow obscure the two-day reference edge."),
    "20250507_R05": ("PASS_CANDIDATE", "medium", "Segment generally follows the beach edge; two-day date gap still requires confirmation."),
    "20250507_R06": ("EXCLUDE_CANDIDATE", "medium", "Segment is near the shore, but cloud/shadow and the two-day gap prevent reliable approval."),
    "20251201_R01": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies in open water away from the visible headland."),
    "20251201_R02": ("EXCLUDE_CANDIDATE", "high", "Cyan segment lies in open water away from the visible shore."),
    "20251201_R03": ("EXCLUDE_CANDIDATE", "high", "Complex cyan segment lies in open water rather than on the visible shoreline."),
    "20251201_R04": ("REDRAW_CANDIDATE", "high", "Only part approaches the shore; the loop and long lakeward spur require redraw."),
    "20251201_R05": ("PASS_CANDIDATE", "high", "Cyan segment consistently follows the visible natural shore."),
    "20251201_R06": ("REDRAW_CANDIDATE", "medium", "Artificial harbor edge is visible, but the line mixes structures and the outer shore."),
}


def main() -> None:
    manifest = json.loads((BASE / "compact_review_manifest.json").read_text(encoding="utf-8"))
    rows = []
    for site in manifest["sites"]:
        decision, confidence, reason = TRIAGE[site["site_id"]]
        rows.append({
            "site_id": site["site_id"],
            "source_segment": site["source_segment"],
            "center_utm_x": site["center_utm"][0],
            "center_utm_y": site["center_utm"][1],
            "ai_triage": decision,
            "confidence": confidence,
            "reason": reason,
            "human_review_status": "PENDING",
            "allow_label_edit": False,
            "allow_test_evaluation": False,
        })

    csv_path = BASE / "ai_triage_24_sites.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    counts = Counter(row["ai_triage"] for row in rows)
    payload = {
        "status": "AI_TRIAGE_ONLY_HUMAN_CONFIRMATION_REQUIRED",
        "source": "visual inspection of paired L8/S2 compact panels",
        "site_count": len(rows),
        "counts": dict(counts),
        "human_review_complete": False,
        "labels_modified": False,
        "test_accuracy_opened": False,
        "rules": [
            "PASS_CANDIDATE still requires a human click/record before acceptance.",
            "REDRAW_CANDIDATE requires a human-edited shoreline.",
            "EXCLUDE_CANDIDATE should enter the invalid-observation mask unless another clear same-date source resolves it.",
            "No triage outcome may be used to inspect model test accuracy."
        ],
        "records": rows,
    }
    (BASE / "ai_triage_24_sites.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# 测试集 24 个高风险岸段机器辅助分流", "",
        "本表仅用于减少人工复核量，不修改参考标签，也不允许开启测试精度。", "",
        f"- 可确认候选：{counts['PASS_CANDIDATE']} 处",
        f"- 重绘候选：{counts['REDRAW_CANDIDATE']} 处",
        f"- 排除候选：{counts['EXCLUDE_CANDIDATE']} 处", "",
        "高风险抽样中大量问题来自云/云影、湖内光谱边界和复杂人工岸。该比例不能外推到整湖岸线，因为这 24 处是按风险主动挑选的。", "",
        f"人工下一步只需先检查 {counts['PASS_CANDIDATE']} 个 PASS_CANDIDATE；确认后再处理 {counts['REDRAW_CANDIDATE']} 个 REDRAW_CANDIDATE。{counts['EXCLUDE_CANDIDATE']} 个 EXCLUDE_CANDIDATE 可优先进入排除掩膜复核。"
    ]
    (BASE / "ai_triage_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(payload | {"records": "written to JSON/CSV"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
