"""Validate and freeze the newly downloaded 2024-2025 test expansion."""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path

from validate_formal_downloads import inspect_tif


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "preexperiment/data/unseen_test_round3/raw"
OUT = ROOT / "preexperiment/results/unseen_test_round3"
CSV_PATH = RAW / "Fuxian_unseen_test_manifest_2024_2025_v2.csv"

# Dates already used in training, validation, model selection, reference review,
# or earlier held-out testing. They cannot be counted as newly unseen evidence.
PREVIOUSLY_OPENED = {
    "2020-01-02", "2020-05-09", "2021-02-05", "2021-05-12",
    "2022-03-12", "2022-08-19", "2023-01-26", "2023-03-31",
    "2024-02-14", "2024-05-04", "2025-05-07", "2025-12-01",
    "2026-01-18", "2026-02-03",
}


def file_set(row: dict[str, str]) -> dict[str, Path]:
    ld = row["l8_date"].replace("-", "")
    sd = row["s2_date"].replace("-", "")
    return {
        "l8": RAW / f"Fuxian_unseen_v2_L8_{ld}.tif",
        "s2": RAW / f"Fuxian_unseen_v2_S2_{sd}_for_{ld}.tif",
        "masks": RAW / f"Fuxian_unseen_v2_masks_{ld}.tif",
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    with CSV_PATH.open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    audited = []
    for row in rows:
        paths = file_set(row)
        files = {}
        for kind, path in paths.items():
            files[kind] = inspect_tif(path, kind) if path.exists() else {
                "path": str(path), "status": "MISSING"
            }
        l8_clear = float(row["l8_clear_shore"])
        s2_clear = float(row["s2_clear_shore"])
        complete = all(v["status"] == "PASS" for v in files.values())
        opened = row["l8_date"] in PREVIOUSLY_OPENED
        audited.append({
            "l8_date": row["l8_date"],
            "s2_date": row["s2_date"],
            "season_window": row["season_window"],
            "l8_clear_shore": l8_clear,
            "s2_clear_shore": s2_clear,
            "day_gap": int(float(row["day_gap"])),
            "quality_score": float(row["quality_score"]),
            "download_complete": complete,
            "previously_opened": opened,
            "new_independent_test_eligible": complete and not opened,
            "quality_class": (
                "CORE" if min(l8_clear, s2_clear) >= 0.85
                else "PARTIAL" if min(l8_clear, s2_clear) >= 0.55
                else "REJECT"
            ),
            "files": files,
        })

    independent = [r for r in audited if r["new_independent_test_eligible"]]
    report = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "source_manifest": str(CSV_PATH),
        "downloaded_dates": len(audited),
        "complete_dates": sum(r["download_complete"] for r in audited),
        "new_independent_dates": len(independent),
        "previously_opened_dates": [r["l8_date"] for r in audited if r["previously_opened"]],
        "status": "PASS_WITH_DUPLICATE_DATE_EXCLUDED" if len(independent) >= 5 else "FAILED",
        "records": audited,
    }
    (OUT / "intake_qc.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    frozen = {
        "dataset": "Fuxian unseen-date expansion round 3",
        "status": "FROZEN_BEFORE_REFERENCE_CREATION",
        "selection_used_model_outputs": False,
        "previously_opened_dates_excluded": report["previously_opened_dates"],
        "selected": [{k: r[k] for k in (
            "l8_date", "s2_date", "season_window", "l8_clear_shore",
            "s2_clear_shore", "day_gap", "quality_score", "quality_class"
        )} for r in independent],
        "allow_training": False,
        "allow_model_selection": False,
        "allow_evaluation": False,
    }
    (OUT / "selection_manifest.json").write_text(
        json.dumps(frozen, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "status": report["status"],
        "downloaded": len(audited),
        "complete": report["complete_dates"],
        "new_independent": len(independent),
        "excluded": report["previously_opened_dates"],
        "quality": {r["l8_date"]: r["quality_class"] for r in independent},
    }, ensure_ascii=False, indent=2))
    return 0 if report["status"].startswith("PASS") else 2


if __name__ == "__main__":
    raise SystemExit(main())
