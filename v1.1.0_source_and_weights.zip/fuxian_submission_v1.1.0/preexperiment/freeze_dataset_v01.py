"""Freeze the current train/validation inputs and draft labels by SHA-256."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "preexperiment/results/pilot_manifest_paired.json"
OUT = ROOT / "preexperiment/results/dataset_v0.1"
DRAFTS = ROOT / "preexperiment/results/formal_trainval_drafts"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def item(path: Path) -> dict:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}


def main():
    records = json.loads(SOURCE.read_text(encoding="utf-8"))["records"]
    selected = [r for r in records if r["split"] in {"train", "validation"}]
    frozen = []
    for record in selected:
        l8tag = record["l8_date"].replace("-", "")
        s2tag = record["s2_date"].replace("-", "")
        files = {
            "l8": item(ROOT / f"Fuxian_L8_native_{l8tag}.tif"),
            "s2": item(ROOT / f"Fuxian_S2_{s2tag}.tif"),
            "masks": item(ROOT / f"Fuxian_masks_native_{l8tag}.tif"),
            "draft_label": item(DRAFTS / l8tag / "S2_water_DRAFT.tif"),
        }
        limitations = []
        if record["calendar_gap_days"]:
            limitations.append(f"L8_S2_GAP_{record['calendar_gap_days']}_DAY")
        if record["qa_group"] == "partial":
            limitations.append("PARTIAL_VALID_COVERAGE_USE_JOINT_VALID_MASK")
        if record["l8_date"] == "2020-01-02":
            limitations.append("USE_EXISTING_GOOGLE_EARTH_EXCLUSION_MASK")
        frozen.append({
            "l8_date": record["l8_date"], "s2_date": record["s2_date"],
            "split": record["split"], "qa_group": record["qa_group"],
            "label_status": "AUTOMATIC_S2_DRAFT_V0.1",
            "allow_final_accuracy_claim": False,
            "limitations": limitations, "files": files,
        })
    manifest = {
        "version": "0.1", "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "purpose": "reproducible three-seed method-development experiments",
        "reference_status": "AI_SCREENED_AUTOMATIC_DRAFT_NOT_FINAL_TRUTH",
        "test_dates_opened": False,
        "split": {"train_dates": 6, "validation_dates": 2, "test_dates": 4},
        "rules": [
            "No test date may be opened before model and hyperparameters are fixed.",
            "All loss and metrics must use the joint valid observation mask.",
            "The 2019 water geometry is a spatial prior, never a target label.",
            "Version 0.1 results cannot be reported as final paper accuracy.",
        ],
        "records": frozen,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "dataset_manifest_v0.1.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
