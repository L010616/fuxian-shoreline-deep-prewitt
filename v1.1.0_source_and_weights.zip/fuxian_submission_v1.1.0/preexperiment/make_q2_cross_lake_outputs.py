"""Create compact audit figures and a report for cross-lake transfer."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import rasterio
from matplotlib.lines import Line2D
from rasterio.enums import Resampling
from rasterio.warp import reproject
from scipy import ndimage as ndi

import q2_external_reference_drafts as external
import run_q2_cross_lake_zero_shot as experiment


ROOT = Path(__file__).resolve().parents[1]
RESULT_VERSION = os.environ.get("Q2_RESULT_VERSION", "q2_cross_lake_zero_shot_v01")
OUT = ROOT / "preexperiment/results" / RESULT_VERSION
RESULT = OUT / "cross_lake_zero_shot_results.json"
COLORS = {
    "spatial_prior": "#8FA2D6",
    "deep_prewitt": "#6A5C95",
    "parameter_matched_ordinary_conv": "#E7A889",
    "reference": "#D99AAE",
}
LABELS = {
    "spatial_prior": "Spatial prior",
    "deep_prewitt": "Deep Prewitt",
    "parameter_matched_ordinary_conv": "Matched convolution",
}
LAKES = ("Dianchi_Waihai", "Erhai", "Xingyun")
LAKE_LABELS = {"Dianchi_Waihai": "Dianchi Waihai", "Erhai": "Erhai", "Xingyun": "Xingyun"}


def style() -> None:
    plt.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.titlesize": 10,
        "axes.labelsize": 9, "axes.spines.top": False,
        "axes.spines.right": False, "axes.linewidth": 0.8,
        "xtick.major.width": 0.8, "ytick.major.width": 0.8,
        "figure.facecolor": "white", "axes.facecolor": "white",
    })


def summary_figure(data: dict) -> None:
    style()
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.15), constrained_layout=True)
    x = np.arange(3)
    width = 0.24
    for index, model in enumerate(LABELS):
        bf1 = [data["summary"][model][f"lake:{lake}"]["boundary_f1_30m"]["mean"] for lake in LAKES]
        bf1_sd = [data["summary"][model][f"lake:{lake}"]["boundary_f1_30m"]["date_sd"] for lake in LAKES]
        axes[0].bar(x + (index - 1) * width, bf1, width, color=COLORS[model], label=LABELS[model],
                    yerr=bf1_sd, capsize=2, error_kw={"lw": 0.8})
        asd = [data["summary"][model][f"lake:{lake}"]["mean_symmetric_boundary_distance_m"]["mean"] for lake in LAKES]
        asd_sd = [data["summary"][model][f"lake:{lake}"]["mean_symmetric_boundary_distance_m"]["date_sd"] for lake in LAKES]
        axes[1].bar(x + (index - 1) * width, asd, width, color=COLORS[model],
                    yerr=asd_sd, capsize=2, error_kw={"lw": 0.8})
    for axis in axes[:2]:
        axis.set_xticks(x, [LAKE_LABELS[lake] for lake in LAKES], rotation=18, ha="right")
        axis.grid(axis="y", color="#E6E8EC", lw=0.7)
        axis.set_axisbelow(True)
    axes[0].set_ylabel("Boundary F1 at 30 m")
    axes[0].set_ylim(0.60, 1.00)
    axes[0].legend(frameon=False, loc="upper left", bbox_to_anchor=(-0.02, 1.02), fontsize=8)
    axes[1].set_ylabel("ASD (m)")
    axes[1].set_ylim(0, 45)
    deep = data["three_seed_ensemble_per_date"]["deep_prewitt"]
    prior = data["three_seed_ensemble_per_date"]["spatial_prior"]
    for index, lake in enumerate(LAKES):
        ids = sorted(key for key, row in deep.items() if row["lake"] == lake)
        improvements = [deep[key]["boundary_f1_30m"] - prior[key]["boundary_f1_30m"] for key in ids]
        jitter = np.linspace(-0.08, 0.08, len(improvements))
        axes[2].scatter(np.full(len(improvements), index) + jitter, improvements,
                        color=COLORS["deep_prewitt"], edgecolor="white", linewidth=0.5, s=30)
        axes[2].plot([index - 0.16, index + 0.16], [np.mean(improvements)] * 2,
                     color=COLORS["reference"], lw=2.2)
    axes[2].axhline(0, color="#7B7D83", lw=0.8, ls="--")
    axes[2].set_xticks(x, [LAKE_LABELS[lake] for lake in LAKES], rotation=18, ha="right")
    axes[2].set_ylabel("Deep Prewitt BF1 gain")
    axes[2].grid(axis="y", color="#E6E8EC", lw=0.7)
    axes[2].set_axisbelow(True)
    for label, axis in zip(("(a)", "(b)", "(c)"), axes):
        axis.text(-0.13, 1.04, label, transform=axis.transAxes, fontweight="bold")
    fig.savefig(OUT / "cross_lake_formal_summary.png", dpi=350, bbox_inches="tight")
    plt.close(fig)


def rgb_l8(path: Path) -> tuple[np.ndarray, dict]:
    with rasterio.open(path) as src:
        raw = src.read([3, 2, 1]).astype("float32")
        profile = src.profile.copy()
    valid = np.all(np.isfinite(raw) & (raw > -9000), axis=0)
    channels = []
    for band in raw:
        lo, hi = np.percentile(band[valid], [2, 98])
        channels.append(np.clip((band - lo) / max(hi - lo, 1e-6), 0, 1) ** 0.82)
    return np.moveaxis(np.stack(channels), 0, -1), profile


def reference_on_l8(record: dict, profile: dict) -> np.ndarray:
    draft = record["paths"]["draft"]
    with rasterio.open(draft) as src:
        source = src.read(1)
        source = np.where(source == 255, np.nan, source).astype("float32")
        target = np.full((profile["height"], profile["width"]), np.nan, dtype="float32")
        reproject(source, target, src_transform=src.transform, src_crs=src.crs,
                  src_nodata=np.nan, dst_transform=profile["transform"], dst_crs=profile["crs"],
                  dst_nodata=np.nan, resampling=Resampling.average)
    return target >= 0.5


def qualitative_figure(records: list[dict]) -> None:
    style()
    by_lake = {lake: sorted((row for row in records if row["lake"] == lake),
                            key=lambda row: row["l8_date"]) for lake in LAKES}
    fig, axes = plt.subplots(3, 6, figsize=(13.2, 6.7))
    fig.subplots_adjust(left=0.065, right=0.995, bottom=0.035, top=0.91,
                        wspace=0.055, hspace=0.13)
    for row_index, lake in enumerate(LAKES):
        for col_index, record in enumerate(by_lake[lake]):
            axis = axes[row_index, col_index]
            rgb, profile = rgb_l8(record["paths"]["l8"])
            truth = reference_on_l8(record, profile)
            pred_path = OUT / "deep_prewitt_predictions" / f"{lake}_{record['l8_date']}_probability.tif"
            with rasterio.open(pred_path) as src:
                probability = src.read(1)
                valid = probability > -9000
            pred = probability >= 0.5
            ref_edge = truth ^ ndi.binary_erosion(truth)
            pred_edge = pred ^ ndi.binary_erosion(pred)
            ref_edge = ndi.binary_dilation(ref_edge & valid, iterations=1)
            pred_edge = ndi.binary_dilation(pred_edge & valid, iterations=1)
            overlay = rgb.copy()
            overlay[ref_edge] = np.array([217, 154, 174]) / 255
            overlay[pred_edge] = np.array([143, 162, 214]) / 255
            axis.imshow(overlay)
            axis.set_title(f"{record['l8_date']}  [{record['season']}]", fontsize=8, pad=2)
            axis.set_xticks([]); axis.set_yticks([])
            for spine in axis.spines.values():
                spine.set_visible(True); spine.set_linewidth(0.55); spine.set_color("#8B8D92")
        axes[row_index, 0].set_ylabel(LAKE_LABELS[lake], fontsize=9, fontweight="bold")
    handles = [Line2D([0], [0], color=COLORS["reference"], lw=2, label="Frozen S2 shoreline proxy"),
               Line2D([0], [0], color=COLORS["deep_prewitt"], lw=2, label="Deep Prewitt shoreline")]
    fig.legend(handles=handles, loc="upper center", ncol=2, frameon=False,
               bbox_to_anchor=(0.5, 0.992), borderaxespad=0)
    fig.savefig(OUT / "cross_lake_qualitative_audit.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def report(data: dict) -> None:
    lines = [
        "# 跨湖零样本外推：冻结参考集正式结果", "",
        "本轮直接使用抚仙湖冻结检查点，在滇池外海、洱海和星云湖开展零样本外推。每湖6期，包含3期干季与3期湿季；目标湖数据未参与训练、阈值选择、阈值调整或检查点选择。Sentinel-2岸线代理在查看模型预测前生成；其后仅依据无模型叠加的影像质量图独立复核，18期全部保留并冻结。所有模型使用相同的命名湖泊外岸线目标与固定空间约束。数值反映相对于遥感岸线代理的跨传感器一致性，不等同于相对于实测岸线的绝对精度。", "",
        "## 逐湖结果（18期日期均值）", "",
        "|模型|湖泊|IoU|Boundary F1 30 m|ASD/m|", "|---|---|---:|---:|---:|",
    ]
    for model in experiment.MODELS:
        for lake in LAKES:
            group = data["summary"][model][f"lake:{lake}"]
            lines.append(f"|{LABELS[model]}|{LAKE_LABELS[lake]}|{group['iou']['mean']:.4f} ± {group['iou']['date_sd']:.4f}|{group['boundary_f1_30m']['mean']:.4f} ± {group['boundary_f1_30m']['date_sd']:.4f}|{group['mean_symmetric_boundary_distance_m']['mean']:.2f} ± {group['mean_symmetric_boundary_distance_m']['date_sd']:.2f}|")
    comparison = data["paired_date_effects"]["deep_prewitt_vs_spatial_prior"]
    matched = data["paired_date_effects"]["deep_prewitt_vs_parameter_matched_ordinary_conv"]
    lines += ["", "## 结果判断", "",
              f"- 深层 Prewitt 相对空间先验的30 m Boundary F1在18/18期提高，平均提高 {comparison['boundary_f1_30m']['mean_improvement']:.4f}，日期自助法95%区间为 {comparison['boundary_f1_30m']['bootstrap_95_ci'][0]:.4f}—{comparison['boundary_f1_30m']['bootstrap_95_ci'][1]:.4f}。",
              f"- 深层 Prewitt 相对空间先验的 ASD 在18/18期降低，平均减少 {comparison['asd_reduction_m']['mean_improvement']:.2f} m，95%区间为 {comparison['asd_reduction_m']['bootstrap_95_ci'][0]:.2f}—{comparison['asd_reduction_m']['bootstrap_95_ci'][1]:.2f} m。",
              f"- 相对参数量匹配普通卷积分支，Boundary F1平均提高 {matched['boundary_f1_30m']['mean_improvement']:.4f}，但95%区间跨0（p={matched['boundary_f1_30m']['wilcoxon_two_sided_p']:.3f}）；该比较支持方向性趋势，尚不能声称统计显著优于普通卷积。",
              "- 滇池目标严格限定为外海（Waihai）；JRC水体先验中与外海经狭窄水道相连的草海被固定地理边界剔除。该规则由命名目标定义决定，对所有日期和模型一致应用。",
              "- 所有18期均纳入统计，未按模型误差或改进方向删除日期。", "",
              "## 产物", "",
              "- `cross_lake_zero_shot_results.json`：完整三模型、三随机种子与日期级结果。",
              "- `per_date_three_seed_ensemble.csv`：日期级六项区域/边界指标。",
              "- `group_summary.csv`：总体、逐湖和干湿季均值及日期标准差。",
              "- `cross_lake_qualitative_audit.png`：18期冻结岸线代理与深层 Prewitt 岸线叠加质检图。",
              "- `cross_lake_formal_summary.png`：逐湖指标和 Boundary F1 增益图。", ""]
    (OUT / "跨湖零样本正式报告.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    data = json.loads(RESULT.read_text(encoding="utf-8"))
    records = experiment.selected_records()
    summary_figure(data)
    qualitative_figure(records)
    report(data)
    print("Q2 cross-lake outputs complete")


if __name__ == "__main__":
    main()
