"""Import six Google Earth Pro KML shoreline reviews with geometry QC.

This creates model-readable GeoJSON files and a single-reviewer provisional
form.  It intentionally leaves the original two-reviewer consensus form
untouched.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

import numpy as np
from rasterio.warp import transform
from scipy.spatial import cKDTree


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "人工审核"
PACK = ROOT / "preexperiment/results/q2_external/manual_review_core6"
FORM = PACK / "manual_review_form.csv"
OUT_FORM = PACK / "manual_review_form_single_reviewer.csv"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_kml_line(path: Path) -> list[list[float]]:
    root = ET.parse(path).getroot()
    ns = {"k": "http://www.opengis.net/kml/2.2"}
    lines = root.findall(".//k:LineString", ns)
    if len(lines) != 1:
        raise RuntimeError(f"{path.name}: expected one LineString, found {len(lines)}")
    text = lines[0].findtext("k:coordinates", default="", namespaces=ns)
    coords = []
    for token in text.split():
        values = token.split(",")
        if len(values) < 2:
            continue
        coords.append([float(values[0]), float(values[1])])
    if len(coords) < 4:
        raise RuntimeError(f"{path.name}: too few coordinates")
    return coords


def read_geojson_line(path: Path) -> list[list[float]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    lines = [f["geometry"]["coordinates"] for f in payload.get("features", [])
             if (f.get("geometry") or {}).get("type") == "LineString"]
    if len(lines) != 1:
        raise RuntimeError(f"{path}: expected one candidate LineString, found {len(lines)}")
    return [[float(p[0]), float(p[1])] for p in lines[0]]


def local_epsg(coords: list[list[float]]) -> str:
    lon = float(np.mean([p[0] for p in coords]))
    lat = float(np.mean([p[1] for p in coords]))
    zone = int((lon + 180) // 6) + 1
    return f"EPSG:{32600 + zone if lat >= 0 else 32700 + zone}"


def projected(coords: list[list[float]], crs: str) -> np.ndarray:
    xs, ys = transform("EPSG:4326", crs,
                       [p[0] for p in coords], [p[1] for p in coords])
    return np.column_stack([xs, ys])


def line_length(points: np.ndarray) -> float:
    return float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())


def main() -> None:
    with FORM.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
        fieldnames = list(rows[0])
    if len(rows) != 6:
        raise RuntimeError(f"Expected six review rows, found {len(rows)}")

    qc_rows = []
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    for row in rows:
        scene_id = row["scene_id"]
        source = SOURCE / f"{scene_id}_shoreline_REVIEWED.kml"
        candidate_path = PACK / scene_id / "shoreline_AI_ASSISTED_CANDIDATE.geojson"
        if not source.exists():
            raise FileNotFoundError(source)
        reviewed = read_kml_line(source)
        candidate = read_geojson_line(candidate_path)
        crs = local_epsg(reviewed)
        rev_xy = projected(reviewed, crs)
        cand_xy = projected(candidate, crs)
        closure_m = float(np.linalg.norm(rev_xy[0] - rev_xy[-1]))
        if closure_m > 0.05:
            raise RuntimeError(f"{scene_id}: reviewed shoreline is not closed ({closure_m:.3f} m)")

        # Symmetric vertex-to-polyline-sampling proxy; dense source contours
        # make this suitable for detecting and describing manual edits.
        d_rev, _ = cKDTree(cand_xy).query(rev_xy, k=1)
        d_cand, _ = cKDTree(rev_xy).query(cand_xy, k=1)
        symmetric = np.concatenate([d_rev, d_cand])
        exact_same = len(reviewed) == len(candidate) and np.allclose(reviewed, candidate, atol=1e-10)
        changed = not exact_same
        out_path = PACK / scene_id / "shoreline_REVIEWED.geojson"
        feature = {
            "type": "Feature",
            "properties": {
                "scene_id": scene_id,
                "lake": row["lake"],
                "season": row["season"],
                "l8_date": row["l8_date"],
                "s2_date": row["s2_date"],
                "status": "SINGLE_REVIEWER_PROVISIONAL_MODIFIED" if changed else "SINGLE_REVIEWER_PROVISIONAL_ACCEPTED",
                "source_kml": str(source),
                "source_kml_sha256": sha256(source),
                "length_m": round(line_length(rev_xy), 3),
                "created_at": now,
                "consensus_review_complete": False,
            },
            "geometry": {"type": "LineString", "coordinates": reviewed},
        }
        out_path.write_text(json.dumps({"type": "FeatureCollection", "features": [feature]},
                                       ensure_ascii=False, indent=2), encoding="utf-8")

        row["reviewer_A"] = "USER_REVIEWER_NAME_PENDING"
        row["reviewer_A_status"] = "MODIFIED" if changed else "ACCEPTED"
        row["reviewer_A_notes"] = "Google Earth Pro manual review; reviewer name pending"
        row["reviewer_B"] = ""
        row["reviewer_B_status"] = "UNREVIEWED"
        row["reviewer_B_notes"] = "Independent second review pending"
        row["consensus_status"] = "UNREVIEWED"
        row["reviewed_file"] = str(out_path.relative_to(PACK)).replace("\\", "/")

        qc_rows.append({
            "scene_id": scene_id,
            "lake": row["lake"],
            "season": row["season"],
            "reviewed_vertices": len(reviewed),
            "candidate_vertices": len(candidate),
            "closed": closure_m <= 0.05,
            "closure_m": closure_m,
            "reviewed_length_m": line_length(rev_xy),
            "candidate_length_m": line_length(cand_xy),
            "geometry_changed": changed,
            "symmetric_nn_median_m": float(np.median(symmetric)),
            "symmetric_nn_p95_m": float(np.percentile(symmetric, 95)),
            "symmetric_nn_max_m": float(np.max(symmetric)),
            "reviewed_geojson": str(out_path),
            "reviewed_geojson_sha256": sha256(out_path),
        })

    with OUT_FORM.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    qc_csv = PACK / "manual_review_geometry_qc.csv"
    with qc_csv.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(qc_rows[0]))
        writer.writeheader()
        writer.writerows(qc_rows)
    (PACK / "manual_review_geometry_qc.json").write_text(
        json.dumps({"created_at": now, "review_stage": "single_reviewer_provisional",
                    "consensus_complete": False, "records": qc_rows},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(qc_rows, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
