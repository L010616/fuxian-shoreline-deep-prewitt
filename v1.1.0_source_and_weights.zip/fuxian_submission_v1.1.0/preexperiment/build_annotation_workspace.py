"""Build an explicitly unreviewed S2 training-date draft and native-pixel review assets."""
import json
from pathlib import Path
import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling, transform
from rasterio.windows import Window, bounds as window_bounds, from_bounds
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu
from skimage.measure import find_contours, approximate_polygon
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'preexperiment/results/native_20200102'
OUT=BASE/'annotation_workspace'


def save_rgb(data, indices, path):
    rgb=np.clip(data[list(indices)].transpose(1,2,0)/.20,0,1)**.65
    Image.fromarray((rgb*255).astype('uint8')).save(path)


def split_valid(points, good):
    # Treat contours as paths; do not bridge invalid observations or close gaps.
    start=None
    for i,ok in enumerate(np.r_[good,False]):
        if ok and start is None: start=i
        if not ok and start is not None:
            if i-start>=8: yield points[start:i]
            start=None


def review_chunks(coords,limit=750):
    """Split long paths into inspectable sections without changing their geometry."""
    piece=[coords[0].tolist()];distance=0
    for endpoint in coords[1:]:
        start=np.array(piece[-1]);length=float(np.linalg.norm(endpoint-start))
        while distance+length>limit:
            cut=start+(endpoint-start)*(limit-distance)/length
            piece.append(cut.tolist());yield np.array(piece)
            piece=[cut.tolist()];start=cut;distance=0;length=float(np.linalg.norm(endpoint-start))
        piece.append(endpoint.tolist());distance+=length
    if distance>1e-6:yield np.array(piece)


def main():
    OUT.mkdir(parents=True,exist_ok=True); (OUT/'assets').mkdir(exist_ok=True)
    with rasterio.open(ROOT/'Fuxian_S2_20200102.tif') as s:
        s2=s.read(); st=s.transform; crs=s.crs; sp=s.profile.copy()
    with rasterio.open(BASE/'observation_support.tif') as s:
        support=s.read(); lt=s.transform
    zone=np.zeros(s2.shape[1:],'uint8'); joint=np.zeros_like(zone)
    for source,dst in [(support[3],zone),(support[2],joint)]:
        reproject(source,dst,src_transform=lt,src_crs=crs,dst_transform=st,dst_crs=crs,resampling=Resampling.nearest)
    green=s2[1].astype('float32');nir=s2[3].astype('float32')
    valid=(s2[7]==1)&(green+nir>0)
    index=np.full(green.shape,np.nan,'float32')
    np.divide(green-nir,green+nir,out=index,where=valid)
    sample=index[valid&(zone==1)]; threshold=float(threshold_otsu(sample))
    labels,n=ndi.label(valid&(index>threshold),structure=np.ones((3,3)))
    xs,ys=transform('EPSG:4326',crs,[102.8889],[24.5022]);col,row=(~st)*(xs[0],ys[0])
    lake_id=int(labels[int(row),int(col)])
    if not lake_id: raise ValueError('Lake seed is not classified as water; inspect observations before continuing.')
    water=labels==lake_id
    # Two 10 m pixels provide a conservative cloud/invalid margin for drafts.
    usable=ndi.binary_erosion(valid&(joint==1),iterations=2)&(zone==1)
    features=[]; segments=[]
    for contour in find_contours(water.astype('uint8'),.5):
        r0=np.floor(contour[:,0]).astype(int); c0=np.floor(contour[:,1]).astype(int)
        r1=np.minimum(r0+1,usable.shape[0]-1); c1=np.minimum(c0+1,usable.shape[1]-1)
        good=usable[r0,c0]&usable[r0,c1]&usable[r1,c0]&usable[r1,c1]
        for part in split_valid(contour,good):
            part=approximate_polygon(part,tolerance=.3)
            coords=np.column_stack([st.c+(part[:,1]+.5)*10,st.f-(part[:,0]+.5)*10])
            length=float(np.linalg.norm(np.diff(coords,axis=0),axis=1).sum())
            if length<60: continue
            for chunk in review_chunks(coords):
                sid=f'S2_DRAFT_{len(segments)+1:03d}'
                props=dict(segment_id=sid,scene_date='2020-01-02',reference_date='2020-01-02',
                    review_status='DRAFT',origin='S2_NDWI_OTSU_AUTOMATIC',annotator=None,reviewer=None,
                    scene_type='UNREVIEWED',uncertainty_reason='AUTOMATIC_DRAFT_REQUIRES_VISUAL_REVIEW',
                    reference_source='Fuxian_S2_20200102.tif',approx_length_m=float(np.linalg.norm(np.diff(chunk,axis=0),axis=1).sum()))
                segments.append(dict(id=sid,kind='shoreline',coordinates=chunk.tolist(),properties=props))
                lon,lat=transform(crs,'EPSG:4326',chunk[:,0].tolist(),chunk[:,1].tolist())
                features.append(dict(type='Feature',properties=props,geometry=dict(type='LineString',coordinates=list(map(list,zip(lon,lat))))))
    draft=dict(schema_version=1,crs='EPSG:32648',scene_date='2020-01-02',review_status='DRAFT',
               author='',segments=segments,control_points=[],allow_training=False)
    (OUT/'initial_draft.json').write_text(json.dumps(draft,ensure_ascii=False),encoding='utf8')
    (OUT/'S2_shoreline_DRAFT.geojson').write_text(json.dumps(dict(type='FeatureCollection',features=features),ensure_ascii=False),encoding='utf8')
    profile=sp.copy();profile.update(count=1,dtype='float32',nodata=np.nan,compress='deflate')
    with rasterio.open(OUT/'S2_NDWI_diagnostic.tif','w',**profile) as s:s.write(index,1);s.descriptions=('S2_NDWI_DIAGNOSTIC_NOT_LABEL',)
    windows=json.loads((BASE/'annotation_window_manifest.json').read_text())
    lands=json.loads((BASE/'registration_screen.json').read_text())['records']
    for r in lands:
        bounds=window_bounds(Window(r['col'],r['row'],64,64),lt)
        windows.append(dict(id=f'LAND_{r["id"]}',bounds_utm=list(bounds),purpose='CONTROL_POINT_CANDIDATE_LAND_NOT_VERIFIED'))
    manifest=[]
    with rasterio.open(ROOT/'Fuxian_L8_native_20200102.tif') as lsrc, rasterio.open(ROOT/'Fuxian_S2_20200102.tif') as ssrc:
        for item in windows:
            entry=dict(id=item['id'],view_bounds=item['bounds_utm'],purpose=item.get('purpose','SHORELINE_REVIEW'))
            for sensor,src,scale in [('s2',ssrc,.0001),('l8',lsrc,1)]:
                w=from_bounds(*item['bounds_utm'],src.transform)
                c=int(np.floor(w.col_off));r=int(np.floor(w.row_off))
                ce=int(np.ceil(w.col_off+w.width));re=int(np.ceil(w.row_off+w.height))
                w=Window(c,r,ce-c,re-r)
                data=src.read(window=w).astype('float32')*scale
                # Crop native pixels without resampling; each image retains its own exact bounds.
                bounds=window_bounds(w,src.transform)
                prefix=f'assets/{item["id"]}_{sensor}'
                save_rgb(data,(2,1,0),OUT/(prefix+'_rgb.png'))
                save_rgb(data,(3,2,1),OUT/(prefix+'_nir.png'))
                entry[sensor]=dict(bounds=list(bounds),rgb=prefix+'_rgb.png',nir=prefix+'_nir.png',width=data.shape[2],height=data.shape[1])
            lw=from_bounds(*item['bounds_utm'],lt).round_offsets().round_lengths()
            mask=support[2,int(lw.row_off):int(lw.row_off+lw.height),int(lw.col_off):int(lw.col_off+lw.width)]
            rgba=np.zeros((*mask.shape,4),'uint8');rgba[:,:,:3]=[242,79,87];rgba[:,:,3]=np.where(mask==1,0,110)
            maskfile=f'assets/{item["id"]}_invalid.png';Image.fromarray(rgba).save(OUT/maskfile)
            entry['invalid']=dict(file=maskfile,bounds=list(window_bounds(lw,lt)))
            manifest.append(entry)
    info=dict(scene_date='2020-01-02',crs='EPSG:32648',windows=manifest,
              draft_method=dict(index='NDWI = (S2 B3 - B8)/(B3 + B8)',otsu_threshold=threshold,
              threshold_sample_count=int(sample.size),segment_count=len(segments),
              draft_total_length_m=sum(s['properties']['approx_length_m'] for s in segments),
              contour_simplification_tolerance_m=3,minimum_segment_length_m=60,
              quality_margin_m=20,maximum_review_segment_length_m=750,
              note='Training-date draft only; length is algorithm output, not validated shoreline length.'))
    (OUT/'manifest.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(info['draft_method'],indent=2))


if __name__=='__main__':main()
