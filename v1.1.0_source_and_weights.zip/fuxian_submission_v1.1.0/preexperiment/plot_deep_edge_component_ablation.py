"""Plot the validation-only deep edge component ablation in the paper palette."""
from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/deep_edge_component_ablation"
SOURCE = BASE / "deep_edge_component_ablation_summary.csv"

ORDER = [
    "spatial_prior", "parameter_matched_ordinary_conv", "deep_log_only",
    "deep_prewitt_only", "shallow_parallel", "deep_parallel",
]
LABELS = {
    "spatial_prior": "Spatial prior",
    "parameter_matched_ordinary_conv": "Matched conv.",
    "deep_log_only": "Deep LoG",
    "deep_prewitt_only": "Deep Prewitt",
    "shallow_parallel": "Shallow parallel",
    "deep_parallel": "Deep parallel",
}
COLORS = ["#8FA2D6", "#E7A889", "#D99AAE", "#6A5C95", "#A9C8B8", "#5B608C"]


def main() -> None:
    with SOURCE.open(encoding="utf-8-sig") as stream:
        source = {row["configuration"]: row for row in csv.DictReader(stream)}
    rows = [source[name] for name in ORDER]
    labels = [LABELS[name] for name in ORDER]
    bf1 = np.asarray([float(row["BF1_30m_mean"]) for row in rows]) * 100
    bf1_sd = np.asarray([float(row["BF1_30m_sd"]) for row in rows]) * 100
    asd = np.asarray([float(row["ASD_m_mean"]) for row in rows])
    asd_sd = np.asarray([float(row["ASD_m_sd"]) for row in rows])

    plt.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 10,
        "xtick.labelsize": 8, "ytick.labelsize": 9, "axes.linewidth": 0.8,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.2), constrained_layout=True)
    y = np.arange(len(rows))[::-1]
    for ax, values, errors, xlabel, formatter, gap in (
        (axes[0], bf1, bf1_sd, "Boundary F1 at 30 m (%)", lambda x: f"{x:.2f}", 0.025),
        (axes[1], asd, asd_sd, "ASD (m)", lambda x: f"{x:.2f}", 0.08),
    ):
        for yi, value, error, color in zip(y, values, errors, COLORS):
            ax.errorbar(value, yi, xerr=error, fmt="o", markersize=6.5, color=color,
                        ecolor="#3E3142", elinewidth=1.2, capsize=3, capthick=1.1)
            ax.text(value + error + gap, yi, formatter(value), va="center", fontsize=8,
                    color="#3E3142", bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.5})
        ax.set_xlabel(xlabel)
        ax.set_yticks(y, labels if ax is axes[0] else [])
        ax.grid(axis="x", color="#E8E8EC", linewidth=0.7)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_axisbelow(True)
    axes[0].set_xlim(min(bf1 - bf1_sd) - 0.15, max(bf1 + bf1_sd) + 0.25)
    axes[1].set_xlim(max(0, min(asd - asd_sd) - 0.35), max(asd + asd_sd) + 0.6)
    axes[0].text(-0.20, 1.03, "(a)", transform=axes[0].transAxes, fontweight="bold", fontsize=11)
    axes[1].text(-0.08, 1.03, "(b)", transform=axes[1].transAxes, fontweight="bold", fontsize=11)
    fig.savefig(BASE / "deep_edge_component_ablation.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(BASE / "deep_edge_component_ablation.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(BASE)


if __name__ == "__main__":
    main()
