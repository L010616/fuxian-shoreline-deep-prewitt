"""Post-review date/temporal-episode sensitivity of the six final dates.

These intervals are descriptive with only three episodes. Model weights,
reference masks, metrics, and all six dates are preserved.
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"preexperiment/results/v25_supplementary_20261001/temporal_blocks"
SOURCE=ROOT/"preexperiment/results/prewitt_confirmation_set3/locked_evaluation/per_date_seed_averaged.csv"
METRICS=("precision","recall","f1","iou","boundary_f1_30m","boundary_f1_60m",
         "mean_symmetric_boundary_distance_m","hd95_m")
B=100000


def exact_cluster_signflip(means):
    means=np.asarray(means,dtype=float)
    observed=abs(means.mean())
    null=np.asarray([np.mean(means*np.asarray(signs)) for signs in itertools.product((-1,1),repeat=len(means))])
    return float((np.abs(null)>=observed-1e-12).mean())


def main():
    OUT.mkdir(parents=True,exist_ok=False)
    rows=list(csv.DictReader(SOURCE.open(encoding="utf-8-sig",newline="")))
    dates=sorted({r["date"] for r in rows})
    lookup={(r["model"],r["date"]):r for r in rows}
    episodes={year:[d for d in dates if d.startswith(year)] for year in sorted({d[:4] for d in dates})}
    assert len(dates)==6 and [len(x) for x in episodes.values()]==[3,2,1]
    protocol={"status":"POST_REVIEW_TEMPORAL_BLOCK_REANALYSIS", "input_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              "episodes":episodes,"unit":"year-specific acquisition episode: early 2020, late 2022, late 2024",
              "n_bootstrap":B,"random_seed":20261001,
              "limitation":"Only three temporal episodes of one lake; no population-wide significance. Resampling intervals do not create additional independent observations."}
    (OUT/"protocol.json").write_text(json.dumps(protocol,indent=2),encoding="utf-8")
    results,per_date,per_episode=[],[],[]
    rng=np.random.default_rng(20261001)
    for baseline in ("prior_only","parameter_matched_ordinary_conv"):
        for metric in METRICS:
            sign=-1 if metric in ("mean_symmetric_boundary_distance_m","hd95_m") else 1
            effects={d:sign*(float(lookup[("fixed_prewitt_deep",d)][metric])-float(lookup[(baseline,d)][metric])) for d in dates}
            arrays=[np.asarray([effects[d] for d in ds]) for ds in episodes.values()]
            means=np.asarray([a.mean() for a in arrays])
            values=np.asarray(list(effects.values()))
            date_draw=values[rng.integers(0,6,size=(B,6))].mean(1)
            sampled=rng.integers(0,3,size=(B,3))
            hierarchy=np.empty((B,3))
            for position in range(3):
                for index,a in enumerate(arrays):
                    mask=sampled[:,position]==index
                    hierarchy[mask,position]=a[rng.integers(0,len(a),size=(int(mask.sum()),len(a)))].mean(1)
            hmean=hierarchy.mean(1)
            # Preserve date weighting as a separate whole-block bootstrap estimator.
            sizes=np.asarray([len(a) for a in arrays])
            weighted=(means[sampled]*sizes[sampled]).sum(1)/sizes[sampled].sum(1)
            row={"baseline":baseline,"metric":metric,"n_dates":6,"n_episodes":3,
                 "date_mean_improvement":float(values.mean()),"date_sd":float(values.std(ddof=1)),
                 "dates_improved":int((values>0).sum()),"date_bootstrap_low":float(np.quantile(date_draw,.025)),
                 "date_bootstrap_high":float(np.quantile(date_draw,.975)),
                 "date_exact_wilcoxon_p":float(wilcoxon(values,method="exact").pvalue),
                 "equal_episode_mean_improvement":float(means.mean()),"episodes_improved":int((means>0).sum()),
                 "episode_date_hierarchical_low":float(np.quantile(hmean,.025)),
                 "episode_date_hierarchical_high":float(np.quantile(hmean,.975)),
                 "whole_episode_date_weighted_low":float(np.quantile(weighted,.025)),
                 "whole_episode_date_weighted_high":float(np.quantile(weighted,.975)),
                 "episode_exact_signflip_p":exact_cluster_signflip(means)}
            for (year,ds),mean in zip(episodes.items(),means):
                others=[effects[d] for d in dates if d not in ds]
                row[f"leave_out_{year}_date_mean"]=float(np.mean(others))
                per_episode.append({"baseline":baseline,"metric":metric,"episode":year,"n_dates":len(ds),"mean_improvement":float(mean)})
            for d,value in effects.items():
                per_date.append({"baseline":baseline,"metric":metric,"date":d,"episode":d[:4],"improvement":value})
            results.append(row)
    for name,data in (("temporal_statistics.csv",results),("per_date_effects.csv",per_date),("per_episode_effects.csv",per_episode)):
        with (OUT/name).open("w",encoding="utf-8-sig",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    (OUT/"temporal_statistics.json").write_text(json.dumps({"protocol":protocol,"results":results},indent=2),encoding="utf-8")
    for r in results:
        if r["metric"] in ("boundary_f1_30m","mean_symmetric_boundary_distance_m"):
            print(json.dumps(r,ensure_ascii=False),flush=True)


if __name__=="__main__":main()
