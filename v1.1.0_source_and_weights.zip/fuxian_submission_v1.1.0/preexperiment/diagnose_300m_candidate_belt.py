# -*- coding: utf-8 -*-
"""Prediction-independent geometry check for the fixed 300 m shoreline belt.

The Sentinel-2 lake component is delineated over the complete valid ROI.  The
2019 interior is used only as the component seed; spectral decisions are not
restricted to the candidate belt.  The resulting outer boundary is then
compared with the exported belt.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.warp import reproject, transform
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu

import build_wave1_reference_drafts as ref

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/candidate_belt_geometry"


def resample(a, src_transform, crs, shape, dst_transform):
    out = np.zeros(shape, dtype="uint8")
    reproject(a.astype("uint8"), out, src_transform=src_transform, src_crs=crs,
              dst_transform=dst_transform, dst_crs=crs,
              resampling=Resampling.nearest)
    return out.astype(bool)


def one(l8_date, s2_date, l8_path, s2_path, mask_path, dataset):
    with rasterio.open(l8_path) as src:
        l8_transform, crs = src.transform, src.crs
    with rasterio.open(mask_path) as src:
        masks = src.read()
    with rasterio.open(s2_path) as src:
        s2, s2_transform = src.read(), src.transform

    shape = s2.shape[1:]
    shore = resample(masks[0] == 1, l8_transform, crs, shape, s2_transform)
    roi = resample(masks[4] == 1, l8_transform, crs, shape, s2_transform)
    interior_l8 = ref.recover_prior_interior(masks[0] == 1, l8_transform, crs)
    interior = resample(interior_l8, l8_transform, crs, shape, s2_transform)
    green, nir = s2[1].astype("float32"), s2[3].astype("float32")
    valid = (s2[7] == 1) & (green + nir > 0) & roi
    ndwi = np.full(shape, np.nan, dtype="float32")
    np.divide(green - nir, green + nir, out=ndwi, where=valid)
    threshold = float(threshold_otsu(ndwi[valid & shore & np.isfinite(ndwi)]))

    # Crucially, the spectral water candidate is permitted across the full ROI.
    candidate = interior | (valid & (ndwi > threshold))
    labels, _ = ndi.label(candidate, structure=np.ones((3, 3)))
    xs, ys = transform("EPSG:4326", crs, [ref.SEED_LON_LAT[0]], [ref.SEED_LON_LAT[1]])
    col, row = (~s2_transform) * (xs[0], ys[0])
    lab = int(labels[int(row), int(col)])
    water = ndi.binary_fill_holes(labels == lab)
    boundary = water & ~ndi.binary_erosion(water, structure=np.ones((3, 3)))
    boundary &= ndi.binary_erosion(valid, iterations=2)
    n = int(boundary.sum())
    inside = int((boundary & shore).sum())
    px = abs(float(s2_transform.a))
    distance_to_belt = ndi.distance_transform_edt(~shore) * px
    outside_dist = distance_to_belt[boundary & ~shore]
    return {
        "dataset": dataset, "l8_date": l8_date, "s2_date": s2_date,
        "threshold": threshold, "boundary_pixels": n,
        "inside_300m_belt_pixels": inside,
        "coverage_fraction": float(inside / n) if n else None,
        "outside_max_distance_m": float(outside_dist.max()) if outside_dist.size else 0.0,
        "outside_p95_distance_m": float(np.quantile(outside_dist, .95)) if outside_dist.size else 0.0,
        "pixel_size_m": px,
    }


def main():
    rows = []
    # Primary blind dates.
    base = ROOT / "preexperiment/data/round4_final_blind/raw"
    pairs = json.loads((ROOT / "preexperiment/results/round4_final_blind/evaluation_pairs.json").read_text(encoding="utf-8"))["selected"]
    for r in pairs:
        lt, st = r["l8_date"].replace("-", ""), r["s2_date"].replace("-", "")
        rows.append(one(r["l8_date"], r["s2_date"],
            base / f"Fuxian_final_L8_native_{lt}.tif",
            base / f"Fuxian_final_S2_{st}_for_{lt}.tif",
            base / f"Fuxian_final_masks_native_{lt}.tif", "primary_blind"))
    # Post-2019 confirmation dates.
    base = ROOT / "preexperiment/data/edge_confirmatory_post2019/analysis_ready"
    pairs = json.loads((ROOT / "preexperiment/results/edge_confirmatory_post2019/evaluation_pairs.json").read_text(encoding="utf-8"))["selected"]
    for r in pairs:
        lt, st = r["l8_date"].replace("-", ""), r["s2_date"].replace("-", "")
        rows.append(one(r["l8_date"], r["s2_date"],
            base / f"Fuxian_edgeconfirm_post2019_L8_native_{lt}.tif",
            base / f"Fuxian_edgeconfirm_post2019_S2_{st}_for_{lt}.tif",
            base / f"Fuxian_edgeconfirm_post2019_masks_native_{lt}.tif", "post2019_confirmation"))
    cov = np.asarray([r["coverage_fraction"] for r in rows])
    summary = {
        "method": "full-valid-ROI S2 NDWI lake component; 2019 interior used only as component seed",
        "n_dates": len(rows), "coverage_mean": float(cov.mean()),
        "coverage_min": float(cov.min()), "coverage_median": float(np.median(cov)),
        "dates_at_least_99pct": int((cov >= .99).sum()),
        "dates_at_least_95pct": int((cov >= .95).sum()),
        "rows": rows,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "candidate_belt_geometry_12_independent_dates.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
