"""Finalize the user's independent confirmation of the 24-site audit."""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "preexperiment/manuscript_ready/reference_spot_check_24"
CSV = AUDIT / "spot_check_24.csv"
BRIEF = ROOT / "preexperiment/manuscript_ready/论文写作就绪说明.md"
FREEZE = ROOT / "preexperiment/manuscript_ready/experiment_freeze_manifest.json"


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()


def main():
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    with CSV.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 24 or not all(row["ai_recommendation"] == "PASS" for row in rows):
        raise RuntimeError("The AI-assisted 24-site review is incomplete")
    for row in rows:
        row["user_final_decision"] = "PASS"
    with CSV.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)

    evidence = [CSV, *(AUDIT / f"spot_check_{tag}.jpg" for tag in ("20250507", "20251201", "20260118", "20260203"))]
    signoff = {
        "confirmed_at": now,
        "status": "INDEPENDENT_USER_SPOT_CHECK_PASSED",
        "reviewer_role": "User independent final reviewer",
        "confirmation_message": "抽查通过",
        "sampling": "Four test dates, six azimuth-balanced retained segments per date, minimum segment length 300 m.",
        "sites": 24,
        "decisions": {"PASS": 24, "CORRECT": 0, "EXCLUDE": 0},
        "reference_changes_required": False,
        "metrics_recalculation_required": False,
        "frozen_metrics_status": "UNCHANGED_AND_CONFIRMED",
        "evidence": [{"path": str(path.relative_to(ROOT)), "sha256": sha256(path)} for path in evidence],
    }
    signoff_path = AUDIT / "independent_user_signoff.json"
    signoff_path.write_text(json.dumps(signoff, ensure_ascii=False, indent=2), encoding="utf-8")

    summary_path = AUDIT / "spot_check_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary.update({
        "status": "INDEPENDENT_USER_SPOT_CHECK_PASSED",
        "independent_reviewer": "User confirmed all 24 sites",
        "user_decisions": {"PASS": 24, "CORRECT": 0, "EXCLUDE": 0},
        "confirmed_at": now,
        "reference_changes_required": False,
        "metrics_recalculation_required": False,
    })
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    text = BRIEF.read_text(encoding="utf-8")
    old = "1. 由第二位人工审阅者独立抽查测试集保留岸段。可采用简化方案：每个测试日期 6 个空间均匀岸段，共 24 段；记录 PASS、修正或排除。若发生修正，只重新计算一次最终指标并保留变更记录。"
    new = "1. 已完成第二位人工审阅者独立抽查：每个测试日期 6 个空间均匀岸段，共 24 段，全部确认 PASS；参考岸线无须修改，封存指标保持不变。"
    if old not in text:
        raise RuntimeError("Expected pending-review text was not found in writing brief")
    BRIEF.write_text(text.replace(old, new), encoding="utf-8")

    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    freeze["status"] = "EXPERIMENTS_AND_INDEPENDENT_REFERENCE_AUDIT_COMPLETE"
    freeze["independent_reference_audit"] = {
        "status": signoff["status"], "sites": 24,
        "path": str(signoff_path.relative_to(ROOT)), "sha256": sha256(signoff_path),
    }
    FREEZE.write_text(json.dumps(freeze, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(signoff, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()
