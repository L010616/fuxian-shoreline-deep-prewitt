"""One-time evaluation of all frozen extended checkpoints on five unseen dates."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
import torch

import run_extended_training_round3 as ext
import run_multidate_ablation_pilot as ablation
from evaluate_extended_boundary_support import metric as boundary_metric
from run_multidate_ablation_pilot import predict
from run_quick_model_pilot import metrics as area_metrics


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/unseen_test_round3"
MODEL_DIR = ROOT / "preexperiment/results/extended_training_round3"
DRAFTS = BASE / "reference_drafts"
REF = BASE / "screened_reference"
SELECTION = BASE / "selection_manifest.json"
OUT = BASE / "locked_evaluation"
SEEDS = ext.SEEDS


def normalize_and_exclude(scenes: list[dict], normalization: list[dict]) -> None:
    for scene in scenes:
        scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
        for band, stat in enumerate(normalization):
            scene["x"][band] = (
                np.clip(scene["x_raw"][band], stat["p01"], stat["p99"]) - stat["mean"]
            ) / stat["std"]
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        exclusion = REF / scene["tag"] / "exclusion_mask_L8_30m.tif"
        with rasterio.open(exclusion) as src:
            scene["valid"] &= ~src.read(1).astype(bool)


def evaluate_probability(prob: np.ndarray, scene: dict) -> dict:
    valid = scene["valid"]
    shore = valid & scene["shore"]
    conventional = area_metrics(prob, scene["y"], valid, shore)
    boundary = boundary_metric(prob, scene["y"], valid, scene["shore"])
    return {**conventional, **boundary,
            "valid_pixels": int(valid.sum()), "valid_shore_pixels": int(shore.sum())}


def constrained_probability(prob: np.ndarray, scene: dict) -> np.ndarray:
    result = prob.copy()
    result[scene["interior"]] = 1.0
    result[scene["roi"] & ~scene["shore"] & ~scene["interior"]] = 0.0
    result[~scene["roi"]] = 0.0
    return result


def macro(per_date: dict[str, dict], mode: str, keys: list[str]) -> dict[str, float]:
    return {key: float(np.mean([row[mode][key] for row in per_date.values()])) for key in keys}


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    result_path = OUT / "unseen_test_results.json"
    if result_path.exists():
        raise RuntimeError("Locked unseen-date evaluation already exists; refusing to rerun")

    selection = json.loads(SELECTION.read_text(encoding="utf-8"))
    ref_manifest = json.loads((REF / "screened_reference_manifest.json").read_text(encoding="utf-8"))
    if selection["allow_evaluation"] or ref_manifest["status"] != "FROZEN_FOR_ONE_TIME_UNSEEN_EVALUATION":
        raise RuntimeError("Selection/reference state is inconsistent with one-time evaluation")

    dates = [{"l8_date": r["l8_date"], "s2_date": r["s2_date"], "split": "unseen_test"}
             for r in selection["selected"]]
    ablation.DRAFTS = DRAFTS
    scenes = [ablation.read_scene(record) for record in dates]
    protocol = json.loads((MODEL_DIR / "protocol.json").read_text(encoding="utf-8"))
    normalize_and_exclude(scenes, protocol["normalization"])

    keys = ["precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m",
            "mean_symmetric_boundary_distance_m", "hd95_m"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    results: dict[str, dict] = {}
    for model_name, factory in ext.factories().items():
        results[model_name] = {}
        for seed in SEEDS:
            model = factory().to(device)
            checkpoint = torch.load(
                MODEL_DIR / f"{model_name}_seed{seed}_best.pt",
                map_location=device, weights_only=False,
            )
            model.load_state_dict(checkpoint["model"])
            per_date = {}
            for scene in scenes:
                probability = predict(model, scene, device)
                per_date[scene["record"]["l8_date"]] = {
                    "raw": evaluate_probability(probability, scene),
                    "common_constraint": evaluate_probability(
                        constrained_probability(probability, scene), scene
                    ),
                }
            results[model_name][str(seed)] = {
                "checkpoint_epoch": int(checkpoint["epoch"]),
                "per_date": per_date,
                "raw_macro": macro(per_date, "raw", keys),
                "common_constraint_macro": macro(per_date, "common_constraint", keys),
            }
            print(f"completed {model_name} seed {seed}", flush=True)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    summary = {}
    for model_name in results:
        summary[model_name] = {}
        for mode in ("raw_macro", "common_constraint_macro"):
            summary[model_name][mode] = {}
            for key in keys:
                values = np.asarray([results[model_name][str(seed)][mode][key] for seed in SEEDS])
                summary[model_name][mode][key] = {
                    "mean": float(values.mean()),
                    "std": float(values.std(ddof=1)),
                    "values": values.tolist(),
                }

    payload = {
        "status": "LOCKED_UNSEEN_DATE_EVALUATION_OPENED_ONCE",
        "models": list(results),
        "seeds": SEEDS,
        "dates": [r["l8_date"] for r in dates],
        "excluded_previously_opened_date": selection["previously_opened_dates_excluded"],
        "decision_threshold": 0.5,
        "selection_used_model_outputs": False,
        "training_or_model_selection_after_test": False,
        "reference_status": "Conservatively screened Sentinel-2 references; not surveyed ground truth",
        "device": str(device),
        "results": results,
        "summary": summary,
    }
    result_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({name: {
        "BF1_30m": round(row["raw_macro"]["boundary_f1_30m"]["mean"], 4),
        "ASD_m": round(row["raw_macro"]["mean_symmetric_boundary_distance_m"]["mean"], 2),
        "IoU": round(row["raw_macro"]["iou"]["mean"], 4),
    } for name, row in summary.items()}, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
