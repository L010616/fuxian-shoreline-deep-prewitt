import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/multidate_ablation_pilot"
data = json.loads((OUT / "metrics.json").read_text(encoding="utf-8"))
order = ["dfanet", "prior", "log", "prewitt", "parallel"]
labels = ["DFANet", "Prior", "+LoG", "+Prewitt", "Parallel"]
colors = ["#778899", "#3b82a0", "#6f9e4f", "#d49a35", "#b14d55"]
metrics = [
    ("IoU", [data[k]["macro"]["iou"] for k in order], True),
    ("Boundary F1 (30 m)", [data[k]["macro"]["boundary_f1_30m"] for k in order], True),
    ("Mean boundary distance (m)", [data[k]["macro"]["mean_symmetric_boundary_distance_m"] for k in order], False),
]

canvas = Image.new("RGB", (1800, 650), "white")
draw = ImageDraw.Draw(canvas)
title_font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 30)
font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 22)
small = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 17)
draw.text((900, 20), "Fuxian Lake multi-date ablation pilot (draft labels)", fill="#172738", font=title_font, anchor="ma")
for panel, (title, vals, high_zoom) in enumerate(metrics):
    x0 = panel * 600 + 58; y0 = 100; width = 500; height = 430
    draw.text((x0 + width / 2, 66), title, fill="#172738", font=font, anchor="ma")
    floor = min(vals) - 0.002 if high_zoom else 0
    ceiling = max(vals) + 0.001 if high_zoom else max(vals) * 1.15
    for tick in range(5):
        y = y0 + height - tick * height / 4
        value = floor + tick * (ceiling - floor) / 4
        draw.line((x0, y, x0 + width, y), fill="#d9e0e5", width=1)
        draw.text((x0 - 8, y), f"{value:.3f}" if high_zoom else f"{value:.1f}", fill="#52616b", font=small, anchor="rm")
    bar_w = 66; gap = 31
    for i, (label, value, color) in enumerate(zip(labels, vals, colors)):
        left = x0 + 14 + i * (bar_w + gap)
        top = y0 + height - (value - floor) / (ceiling - floor) * height
        draw.rectangle((left, top, left + bar_w, y0 + height), fill=color)
        draw.text((left + bar_w / 2, top - 8), f"{value:.4f}" if high_zoom else f"{value:.2f}", fill="#172738", font=small, anchor="mb")
        draw.text((left + bar_w / 2, y0 + height + 14), label, fill="#172738", font=small, anchor="ma")
draw.text((900, 625), "Six training dates; two independent validation dates; one seed", fill="#52616b", font=small, anchor="ms")
canvas.save(OUT / "multidate_ablation_metrics.png")
