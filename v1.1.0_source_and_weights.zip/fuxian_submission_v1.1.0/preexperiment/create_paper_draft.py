from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "论文"
DOCX = OUT / "抚仙湖湖界精细提取论文初稿_v0.1.docx"
PILOT = ROOT / "preexperiment/results/quick_model_pilot_20200102/east_test_comparison.png"


def set_font(run, east_asia="宋体", latin="Times New Roman", size=10.5, bold=None):
    run.font.name = latin
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east_asia)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor(0, 0, 0)
    if bold is not None:
        run.bold = bold


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=100, bottom=90, end=100):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_cell_text(cell, text, bold=False, color="000000", align=WD_ALIGN_PARAGRAPH.CENTER, size=8.5):
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.05
    run = p.add_run(str(text))
    set_font(run, size=size, bold=bold)
    run.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    set_cell_margins(cell)


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.style = "Table Grid"
    for i, header in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], header, bold=True, color="FFFFFF")
        set_cell_shading(table.rows[0].cells[i], "1F4E78")
        if widths:
            table.rows[0].cells[i].width = Cm(widths[i])
    set_repeat_header(table.rows[0])
    for ridx, row in enumerate(rows):
        cells = table.add_row().cells
        for i, value in enumerate(row):
            align = WD_ALIGN_PARAGRAPH.LEFT if isinstance(value, str) and len(value) > 18 else WD_ALIGN_PARAGRAPH.CENTER
            set_cell_text(cells[i], value, align=align)
            if widths:
                cells[i].width = Cm(widths[i])
            if ridx % 2 == 1:
                set_cell_shading(cells[i], "EAF2F8")
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def add_body(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0.74)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_after = Pt(5)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if bold_lead:
        r = p.add_run(bold_lead)
        set_font(r, bold=True)
    r = p.add_run(text)
    set_font(r)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    p.paragraph_format.space_before = Pt(10 if level == 1 else 7)
    p.paragraph_format.space_after = Pt(5)
    for run in p.runs:
        set_font(run, east_asia="黑体", size=14 if level == 1 else 12, bold=True)
    p.paragraph_format.keep_with_next = True
    return p


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_font(r, size=9)


def add_page_number(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = " PAGE "
    fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_begin, instr, fld_end])
    set_font(run, size=9)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Cm(21.0); sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.4); sec.bottom_margin = Cm(2.3)
    sec.left_margin = Cm(2.6); sec.right_margin = Cm(2.4)
    add_page_number(sec)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:e-fill"), "宋体") if False else None
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(10.5)
    for name in ("Title", "Heading 1", "Heading 2", "Heading 3"):
        style = styles[name]
        style.font.color.rgb = RGBColor(0, 0, 0)
    title_style_ppr = styles["Title"]._element.get_or_add_pPr()
    title_style_border = title_style_ppr.find(qn("w:pBdr"))
    if title_style_border is not None:
        title_style_ppr.remove(title_style_border)

    title = doc.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = Pt(18)
    title.paragraph_format.space_after = Pt(12)
    run = title.add_run("面向抚仙湖精细湖界提取的空间约束")
    run.add_break()
    run.add_text("与并联边缘增强方法")
    set_font(run, east_asia="黑体", size=17, bold=True)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.paragraph_format.space_after = Pt(18)
    run = subtitle.add_run("A Boundary Constrained Dual Edge Feature Aggregation Network for Fine Shoreline Extraction of Fuxian Lake")
    set_font(run, size=11, bold=False)

    add_heading(doc, "摘要", 1)
    add_body(doc, "湖岸带山体阴影、浅水底质、岸边植被和建设用地在光谱上具有较强混淆性，容易造成水体边界破碎、偏移和局部伪检。本文以抚仙湖为研究区，构建一种结合空间先验约束和并联边缘特征增强的湖界提取方法。该方法以DFANet为语义分割骨干，利用历史水域范围及岸带缓冲区限定有效搜索空间，并通过LoG和Prewitt算子分别表征多尺度二阶边缘响应与方向梯度信息。边缘特征经独立分支编码后与语义特征进行多级融合，以提高复杂岸段的定位能力。实验采用按日期隔离的数据划分，设置空间约束、单一边缘算子和完整模型等消融，并与传统水体指数、U-Net、DeepLabV3+和SegFormer进行对比。评价同时考虑区域重叠精度、边界匹配精度和岸线距离误差，从而检验模型是否真正改善湖界位置。")
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run("关键词：抚仙湖；湖界提取；DFANet；空间先验；边缘增强；Landsat 8")
    set_font(r, bold=True)

    add_heading(doc, "1 引言", 1)
    add_body(doc, "湖泊水域边界是刻画湖泊面积、岸线形态和水陆相互作用的重要空间要素。Landsat系列影像具有长期连续、覆盖稳定和空间分辨率适中的优势，已广泛用于地表水制图。基于全球Landsat档案构建的JRC Global Surface Water数据进一步表明，长时序30 m影像能够支持大尺度水体变化监测[1]。然而，对单一大型湖泊开展精细湖界定位时，一个像元的偏移即可形成约30 m的岸线误差，区域面积指标较高并不意味着岸线位置准确。")
    add_body(doc, "传统水体提取通常利用绿光、近红外和短波红外波段构建光谱指数。NDWI用于增强开放水体[2]，MNDWI通过短波红外波段抑制建设用地噪声[3]，AWEI则针对阴影和暗地物混淆进行了组合设计[4]。这些方法计算简单，但阈值容易受成像条件、浑浊度、浅水底质和岸带背景影响。抚仙湖周边同时存在山地阴影、岸边植被、裸地、道路、码头及浅水色带，固定阈值难以稳定区分真实陆水交界与水体内部的光谱梯度。")
    add_body(doc, "深度语义分割能够联合利用光谱、纹理和上下文信息。U-Net通过编码器与对称解码器之间的跳跃连接恢复空间细节[5]；DeepLabV3+结合空洞空间金字塔池化和解码结构增强多尺度上下文及边界恢复能力[6]；SegFormer采用分层Transformer编码器和轻量MLP解码器聚合多尺度特征[7]。DFANet通过子网络与子阶段级联聚合特征，在较低计算量下保持较大的感受野[8]，适合面向长时序遥感影像的轻量处理。现有语义分割网络仍主要优化区域分类损失，对湖岸线这类细长目标的几何偏移不够敏感。")
    add_body(doc, "本文从空间约束和边缘表征两个方面改进DFANet。空间约束利用历史最大水域及其岸带缓冲限制模型搜索区域，降低远离湖岸的阴影和暗地物伪检。边缘增强部分并联引入LoG和Prewitt算子，将尺度敏感的二阶响应与具有方向性的梯度响应共同编码，并在多个语义层级融合。研究重点回答三个问题：空间先验能否减少复杂背景误检；两类边缘算子是否具有互补作用；区域精度的改善能否同步转化为Boundary F1和岸线距离误差的改善。")

    add_heading(doc, "2 研究区与数据", 1)
    add_heading(doc, "2.1 研究区", 2)
    add_body(doc, "抚仙湖位于云南高原中部，湖体南北狭长，岸带地形和土地覆盖差异明显。西岸和南岸山地靠近湖滨，阴影与深色植被易与水体混淆；北岸和东岸分布较多农田、道路、居民地及旅游设施，局部存在码头、栈道和浅水滩地。不同岸段同时包含自然陡岸、浅水岸、植被岸和建设岸，为检验湖界模型在复杂背景下的稳定性提供了代表性场景。")
    add_heading(doc, "2.2 遥感数据", 2)
    add_body(doc, "主影像采用Google Earth Engine中的Landsat 8 Collection 2 Tier 1 Level 2地表反射率产品，参考影像采用Sentinel-2 SR Harmonized产品。2020—2025年共检索到102景覆盖湖心点的Landsat 8影像，其中87景在整景云量不高于80%的条件下进入岸带质量检查。以JRC 2019年水域轮廓内外各300 m构建临时岸带后，28景的Landsat岸带有效比例达到90%。对有效场景检索前后3 d内Sentinel-2影像，最终获得19个共同有效岸带不低于90%的独立日期和27个不低于80%的独立日期。")
    add_caption(doc, "表1 主要数据及用途")
    add_table(doc, ["数据", "空间分辨率", "主要内容", "用途"], [
        ["Landsat 8 OLI L2", "30 m", "B2—B7地表反射率及QA", "模型输入与主时间序列"],
        ["Sentinel-2 SR", "10—20 m", "可见光、近红外、短波红外及SCL", "近同期参考岸线与配准检查"],
        ["JRC Global Surface Water", "30 m", "年度水体历史", "构建历史空间先验"],
        ["Google Earth历史影像", "不固定", "岸带高分辨率影像", "固定地物和人工设施辅助核查"],
    ], [3.5, 2.5, 5.1, 5.2])

    add_heading(doc, "2.3 影像质量控制与数据划分", 2)
    add_body(doc, "云、云影、卷云和无效观测依据传感器质量波段进行掩膜。Landsat与Sentinel-2按照各自原生网格保存，并通过地理变换进行空间对应，避免直接按数组行列对齐。仅在两种影像均有效的共同岸带生成参考标签。训练、验证和测试按独立日期划分，同一日期切出的图块只能进入一个数据子集。测试日期在模型结构、阈值、损失权重和后处理规则固定前保持封存。")
    add_caption(doc, "表2 首批日期划分方案")
    add_table(doc, ["用途", "Landsat日期", "Sentinel-2日期", "共同有效岸带"], [
        ["训练", "2020-01-02", "2020-01-02", "96.65%"], ["训练", "2020-05-09", "2020-05-11", "99.86%"],
        ["训练", "2021-02-05", "2021-02-05", "99.99%"], ["训练", "2021-05-12", "2021-05-11", "86.61%"],
        ["训练", "2022-03-12", "2022-03-12", "99.99%"], ["训练", "2022-08-19", "2022-08-19", "96.91%"],
        ["验证", "2023-01-26", "2023-01-26", "99.99%"], ["验证", "2023-03-31", "2023-04-01", "89.82%"],
        ["测试", "2024-02-14", "2024-02-15", "93.75%"], ["测试", "2024-05-04", "2024-05-05", "91.73%"],
        ["测试", "2025-05-07", "2025-05-05", "95.18%"], ["测试", "2025-12-01", "2025-12-01", "99.73%"],
    ], [2.2, 4.1, 4.1, 4.0])

    add_heading(doc, "3 方法", 1)
    add_heading(doc, "3.1 总体框架", 2)
    add_body(doc, "方法由影像预处理、空间先验构建、DFANet语义主干、并联边缘分支、多级特征融合和湖界后处理六部分组成。首先对Landsat反射率和质量掩膜进行统一处理；随后利用历史水域确定固定湖内区、待判定岸带和固定外部背景。语义主干提取多尺度水陆特征，边缘分支计算并编码LoG与Prewitt响应。融合后的特征生成水体概率图，最终在空间约束内获得水体掩膜并矢量化为湖界。")
    add_heading(doc, "3.2 空间先验约束", 2)
    add_body(doc, "空间先验仅使用目标日期以前或预先固定的基准期资料构建。历史最大水域向陆侧和湖心侧分别扩展一定距离，形成包含潜在水位变化的待判定岸带。岸带内由模型预测水陆类别，稳定湖内区固定为水体，先验外部固定为非水体。该设计把模型注意范围集中在真实湖岸附近，同时保留异常水位变化的空间余量。缓冲距离只根据训练集和验证集确定，测试日期不得参与选择。")
    add_heading(doc, "3.3 DFANet语义主干", 2)
    add_body(doc, "DFANet以轻量骨干为基础，通过多个子网络级联和同尺度子阶段聚合传播高层语义信息[8]。本文保留其深度可分离卷积和跨阶段特征聚合结构，并将Landsat可见光、近红外和短波红外波段作为输入。正式实验将统一输入波段、图块尺寸和数据增强条件，使DFANet及各对比网络在相同信息条件下训练。")
    add_heading(doc, "3.4 LoG与Prewitt并联边缘分支", 2)
    add_body(doc, "Prewitt算子分别计算水平和垂直方向梯度，突出具有明确方向的局部反射率跃迁；LoG算子先在给定尺度进行高斯平滑，再计算拉普拉斯响应，对岸线弯曲、宽窄变化及多尺度边缘更敏感。本文分别对绿光、近红外或其组合特征计算两类响应。固定算子不参与参数更新，其输出经过独立卷积编码后，在浅层、中层和深层与语义特征连接。浅层融合保留精细位置，中层融合抑制局部纹理噪声，深层融合利用湖泊整体上下文判断候选边缘是否为真实陆水交界。")
    add_heading(doc, "3.5 模型训练与湖界生成", 2)
    add_body(doc, "训练损失以像元级二元交叉熵和Dice损失为主体，并在验证集上评估是否需要加入边缘辅助监督。训练图块优先覆盖岸带，同时保留一定比例的稳定湖内区和外部背景。推理阶段将水体概率阈值固定为0.5或由验证集统一确定，并在空间先验内保留与湖心连通的主要水体。栅格边界转换为矢量岸线时记录简化容差，避免后处理产生超过半个像元的额外位移。")

    add_heading(doc, "4 实验设计", 1)
    add_heading(doc, "4.1 对比与消融", 2)
    add_body(doc, "传统方法设置MNDWI自适应阈值和AWEI零阈值基线。深度模型包括U-Net、DeepLabV3+、SegFormer-B0和原始DFANet。消融实验依次设置原始DFANet、空间约束DFANet、单一LoG增强、单一Prewitt增强和完整并联模型。所有深度模型采用相同日期划分、输入波段、有效掩膜和数据增强。最终配置运行3个随机种子，报告均值和标准差。")
    add_caption(doc, "表3 正式实验模型矩阵")
    add_table(doc, ["类别", "模型", "目的"], [
        ["传统基线", "MNDWI Otsu", "检验自适应指数阈值"], ["传统基线", "AWEI", "检验阴影抑制能力"],
        ["深度对比", "U-Net", "编码器解码器基线"], ["深度对比", "DeepLabV3+", "多尺度空洞卷积基线"],
        ["深度对比", "SegFormer-B0", "轻量Transformer基线"], ["消融", "DFANet", "原始骨干"],
        ["消融", "DFANet + prior", "空间约束贡献"], ["消融", "DFANet + LoG", "二阶多尺度边缘贡献"],
        ["消融", "DFANet + Prewitt", "方向梯度贡献"], ["完整模型", "DFANet + prior + LoG + Prewitt", "联合贡献"],
    ], [2.8, 6.4, 7.0])
    add_heading(doc, "4.2 评价指标", 2)
    add_body(doc, "区域精度采用Precision、Recall、F1和IoU。边界精度采用30 m和60 m容差下的Boundary F1，并计算预测岸线到参考岸线的平均绝对距离、中位距离和95%分位距离。距离评价只在共同有效岸带内进行。为避免像元数量较大的日期主导总体结果，除汇总指标外还报告逐日期和逐岸线类型结果，并按日期或岸段进行bootstrap获得95%置信区间。模型效率报告参数量和统一硬件上的推理时间。")
    add_heading(doc, "4.3 岸线类型与稳定性分析", 2)
    add_body(doc, "测试岸段划分为自然陡岸、浅水岸、植被岸和建设岸或码头四类。每个测试日期设置20—30条分层检查断面，用于独立核查岸线距离。Google Earth历史影像仅辅助判断固定地物、码头和浮动设施，不替代目标日期参考岸线。稳定性分析比较不同日期、岸段类型、有效观测比例和岸线复杂度下的误差变化。")

    add_heading(doc, "5 技术可行性预实验", 1)
    add_body(doc, "在2020-01-02同日Landsat 8与Sentinel-2影像上开展单日期技术预实验。北岸和南岸用于训练，西岸用于验证，东岸用于测试；五处经Google Earth辅助筛查的疑点区域从训练和评价中排除。该实验采用紧凑DFANet风格网络，目的仅是验证数据、模型、空间先验、边缘融合和边界评价链路。")
    add_caption(doc, "表4 单日期技术预实验结果")
    add_table(doc, ["模型", "IoU", "F1", "BF1 30 m", "BF1 60 m", "边界距离/m"], [
        ["技术基线", "0.9804", "0.9901", "0.8459", "0.9158", "19.26"],
        ["空间先验与双边缘分支", "0.9923", "0.9962", "0.9060", "0.9484", "15.07"],
    ], [5.0, 2.1, 2.1, 2.5, 2.5, 2.8])
    add_body(doc, "增强模型在单日期东岸测试区的30 m Boundary F1提高0.0600，平均对称边界距离减少4.19 m。可视化显示空间先验能够明显抑制建设用地中的远岸伪检，边缘分支有助于维持岸线连续性。由于参考标签来自同日Sentinel-2 NDWI、训练与测试仍属于同一日期且只有一个随机种子，本节结果只支持技术路线选择，不作为论文最终精度或统计结论。")
    if PILOT.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(str(PILOT), width=Cm(16.0))
        add_caption(doc, "图1 东岸空间留出区预实验对比  左为参考岸线  中为技术基线  右为增强模型")

    add_heading(doc, "6 正式结果组织", 1)
    add_body(doc, "正式结果将依次报告总体模型对比、消融实验、逐日期稳定性、逐岸线类型误差和效率分析。主结论以独立测试日期的3次重复结果为依据。单日期预实验表将在正式结果完成后删除或移至补充材料，正文只保留完整多日期实验。")
    add_heading(doc, "7 讨论", 1)
    add_body(doc, "讨论重点包括空间先验对山体阴影和建设用地伪检的抑制作用、LoG与Prewitt在不同岸线类型中的互补性、30 m混合像元对参考岸线和距离指标的限制，以及固定历史范围在异常高水位条件下可能造成的截断风险。还将分析模型参数增加与边界精度收益之间的关系，并说明方法推广到其他高原湖泊时需要重新确定的先验缓冲距离和影像质量条件。")
    add_heading(doc, "8 结论", 1)
    add_body(doc, "本文构建了一个面向复杂湖岸背景的空间约束与并联边缘增强框架。正式结论将在多日期独立测试完成后，根据区域指标、边界指标、岸线距离误差及稳定性分析进行归纳。结论只陈述实验直接支持的改进幅度和适用条件。")

    doc.add_page_break()
    add_heading(doc, "参考文献", 1)
    refs = [
        "[1] Pekel J F, Cottam A, Gorelick N, et al. High-resolution mapping of global surface water and its long-term changes. Nature, 2016, 540: 418-422. https://doi.org/10.1038/nature20584.",
        "[2] McFeeters S K. The use of the Normalized Difference Water Index in the delineation of open water features. International Journal of Remote Sensing, 1996, 17(7): 1425-1432. https://doi.org/10.1080/01431169608948714.",
        "[3] Xu H. Modification of normalised difference water index to enhance open water features in remotely sensed imagery. International Journal of Remote Sensing, 2006, 27(14): 3025-3033. https://doi.org/10.1080/01431160600589179.",
        "[4] Feyisa G L, Meilby H, Fensholt R, et al. Automated Water Extraction Index: a new technique for surface water mapping using Landsat imagery. Remote Sensing of Environment, 2014, 140: 23-35. https://doi.org/10.1016/j.rse.2013.08.029.",
        "[5] Ronneberger O, Fischer P, Brox T. U-Net: Convolutional Networks for Biomedical Image Segmentation. MICCAI, 2015: 234-241. https://doi.org/10.1007/978-3-319-24574-4_28.",
        "[6] Chen L C, Zhu Y, Papandreou G, et al. Encoder-Decoder with Atrous Separable Convolution for Semantic Image Segmentation. ECCV, 2018: 801-818. https://doi.org/10.1007/978-3-030-01234-2_49.",
        "[7] Xie E, Wang W, Yu Z, et al. SegFormer: Simple and Efficient Design for Semantic Segmentation with Transformers. Advances in Neural Information Processing Systems, 2021, 34: 12077-12090.",
        "[8] Li H, Xiong P, Fan H, et al. DFANet: Deep Feature Aggregation for Real-Time Semantic Segmentation. Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2019: 9522-9531.",
    ]
    for ref in refs:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.74)
        p.paragraph_format.first_line_indent = Cm(-0.74)
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(3)
        r = p.add_run(ref); set_font(r, size=9)

    doc.core_properties.title = "面向抚仙湖精细湖界提取的空间约束与并联边缘增强方法"
    doc.core_properties.subject = "SCI论文初稿"
    doc.core_properties.author = ""
    doc.save(DOCX)
    print(DOCX)


if __name__ == "__main__":
    main()
