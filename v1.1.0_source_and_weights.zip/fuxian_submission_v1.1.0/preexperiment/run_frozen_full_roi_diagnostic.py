"""Post-hoc frozen diagnostic of false positives outside the candidate shoreline belt.
No training, threshold tuning, or model selection is performed.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
import rasterio
import torch
from scipy.ndimage import label
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'preexperiment'))
import run_multidate_ablation_pilot as ablation
import run_round4_fusion_confirmation as fusion
import run_round4_remaining_models as remaining
from run_multidate_ablation_pilot import predict
BASE=ROOT/'preexperiment/results/round4_final_blind'
DRAFTS=BASE/'reference_drafts'; REF=BASE/'screened_reference'; PAIRS=BASE/'evaluation_pairs.json'
CONF=ROOT/'preexperiment/results/round4_fusion_confirmation'; REM=ROOT/'preexperiment/results/round4_remaining_models'
OUT=ROOT/'preexperiment/results/frozen_full_roi_diagnostic'; OUT.mkdir(parents=True,exist_ok=True)
SEEDS=(20260913,20260929,20261017)

def normalize_and_exclude(scenes,norm):
 for s in scenes:
  s['x']=np.empty_like(s['x_raw'],dtype='float32')
  for b,st in enumerate(norm): s['x'][b]=(np.clip(s['x_raw'][b],st['p01'],st['p99'])-st['mean'])/st['std']
  s['x'][~np.isfinite(s['x'])]=0
  s['priors']=np.stack([s['interior'],s['shore']]).astype('float32')
  with rasterio.open(REF/s['tag']/'exclusion_mask_L8_30m.tif') as src: s['valid'] &= ~src.read(1).astype(bool)

def comp_max_area(mask):
 lab,n=label(mask)
 if n==0:return 0.0
 c=np.bincount(lab.ravel()); c[0]=0
 return float(c.max()*0.0009) # 30 m pixel -> 0.0009 km2

def main():
 dates=[{'l8_date':r['l8_date'],'s2_date':r['s2_date'],'split':'final_blind_test'} for r in json.loads(PAIRS.read_text(encoding='utf-8'))['selected']]
 ablation.DRAFTS=DRAFTS
 scenes=[ablation.read_scene(r) for r in dates]
 norm=json.loads((CONF/'fusion_confirmation_results.json').read_text(encoding='utf-8'))['normalization']
 normalize_and_exclude(scenes,norm)
 factories={'dfanet':remaining.model_factories()['dfanet'],'prior':fusion.CONFIGS['prior'][0]}
 device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
 rows=[]
 for name,factory in factories.items():
  mdir=CONF if name=='prior' else REM
  for seed in SEEDS:
   model=factory().to(device)
   ck=torch.load(mdir/f'{name}_seed{seed}_best.pt',map_location=device,weights_only=False); model.load_state_dict(ck['model']); model.eval()
   for s in scenes:
    prob=predict(model,s,device); pred=prob>=0.5; truth=s['y']; valid=s['valid']&s['roi']
    outside=valid&~s['shore']&~s['interior']; land=outside&~truth; fp=pred&land
    all_land=valid&~truth; all_fp=pred&all_land
    rows.append({'model':name,'seed':seed,'date':s['record']['l8_date'],'checkpoint_epoch':int(ck['epoch']),
      'outside_land_pixels':int(land.sum()),'outside_fp_pixels':int(fp.sum()),'outside_fp_rate':float(fp.sum()/max(land.sum(),1)),
      'outside_fp_area_km2':float(fp.sum()*0.0009),'outside_largest_fp_patch_km2':comp_max_area(fp),
      'roi_land_pixels':int(all_land.sum()),'roi_fp_pixels':int(all_fp.sum()),'roi_fp_rate':float(all_fp.sum()/max(all_land.sum(),1))})
    print(name,seed,s['record']['l8_date'],rows[-1]['outside_fp_pixels'],flush=True)
   del model
   if torch.cuda.is_available():torch.cuda.empty_cache()
 import csv
 fields=list(rows[0])
 with (OUT/'full_roi_diagnostic_by_seed_date.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
 date_rows=[]
 for name in factories:
  for dt in [r['l8_date'] for r in dates]:
   g=[r for r in rows if r['model']==name and r['date']==dt]
   row={'model':name,'date':dt}
   for k in fields:
    if k in {'model','date','seed'}: continue
    row[k]=float(np.mean([x[k] for x in g]))
   date_rows.append(row)
 with (OUT/'full_roi_diagnostic_date_mean.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(date_rows[0])); w.writeheader(); w.writerows(date_rows)
 summ=[]
 for name in factories:
  g=[r for r in date_rows if r['model']==name]
  summ.append({'model':name,'n_dates':len(g),'outside_fp_rate_mean':float(np.mean([x['outside_fp_rate'] for x in g])),'outside_fp_area_km2_mean':float(np.mean([x['outside_fp_area_km2'] for x in g])),
   'outside_largest_fp_patch_km2_mean':float(np.mean([x['outside_largest_fp_patch_km2'] for x in g])),'roi_fp_rate_mean':float(np.mean([x['roi_fp_rate'] for x in g]))})
 (OUT/'full_roi_diagnostic_summary.json').write_text(json.dumps(summ,indent=2),encoding='utf-8')
 print(json.dumps({'device':str(device),'summary':summ},indent=2))
if __name__=='__main__':main()

