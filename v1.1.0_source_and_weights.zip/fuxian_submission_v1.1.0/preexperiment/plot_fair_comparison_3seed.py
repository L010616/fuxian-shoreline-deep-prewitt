import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"preexperiment/results/fair_comparison_3seed_corrected_labels_v03"
d=json.loads((OUT/"summary_mean_std.json").read_text(encoding="utf-8"))
order=["proposed_parallel","unet_resnet18","deeplabv3plus_resnet18","segformer_mit_b0"]
labels=["Proposed","U-Net","DeepLabV3+","SegFormer"]
colors=["#b14d55","#3b82a0","#6f9e4f","#d49a35"]
items=[("Raw IoU","iou",True),("Raw Boundary F1 (30 m)","boundary_f1_30m",True),("Raw mean boundary distance (m)","mean_symmetric_boundary_distance_m",False)]
im=Image.new("RGB",(1800,680),"white");draw=ImageDraw.Draw(im)
tf=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",30);f=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",22);sm=ImageFont.truetype("C:/Windows/Fonts/arial.ttf",17)
draw.text((900,20),"Three-seed fair comparison on independent validation dates",fill="#172738",font=tf,anchor="ma")
for pi,(title,key,zoom) in enumerate(items):
    values=[d[n]["raw"][key]["mean"] for n in order];stds=[d[n]["raw"][key]["std"] for n in order]
    x0=pi*600+62;y0=105;w=490;h=430;draw.text((x0+w/2,70),title,fill="#172738",font=f,anchor="ma")
    lo=min(v-s for v,s in zip(values,stds))-.006 if zoom else 0;hi=max(v+s for v,s in zip(values,stds))+.002 if zoom else max(v+s for v,s in zip(values,stds))*1.12
    for t in range(5):
        y=y0+h-t*h/4;v=lo+t*(hi-lo)/4;draw.line((x0,y,x0+w,y),fill="#d9e0e5");draw.text((x0-8,y),f"{v:.3f}" if zoom else f"{v:.1f}",fill="#52616b",font=sm,anchor="rm")
    bw=82;gap=35
    for i,(lab,v,s,c) in enumerate(zip(labels,values,stds,colors)):
        left=x0+12+i*(bw+gap);top=y0+h-(v-lo)/(hi-lo)*h;draw.rectangle((left,top,left+bw,y0+h),fill=c)
        cx=left+bw/2;yt=y0+h-(v+s-lo)/(hi-lo)*h;yb=y0+h-(v-s-lo)/(hi-lo)*h;draw.line((cx,yt,cx,yb),fill="#172738",width=3);draw.line((cx-9,yt,cx+9,yt),fill="#172738",width=3);draw.line((cx-9,yb,cx+9,yb),fill="#172738",width=3)
        draw.text((cx,top-17),f"{v:.4f}" if zoom else f"{v:.2f}",fill="#172738",font=sm,anchor="mb");draw.text((cx,y0+h+14),lab,fill="#172738",font=sm,anchor="ma")
draw.text((900,650),"Bars: mean; error bars: sample standard deviation; n=3 seeds",fill="#52616b",font=sm,anchor="ms")
im.save(OUT/"fair_comparison_3seed.png")
