"""Compare export grids and prepare conservative observation support for annotation."""
import json
from pathlib import Path
import numpy as np
import rasterio
from rasterio.enums import ColorInterp, Resampling
from rasterio.warp import reproject
from scipy import ndimage as ndi
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'preexperiment/results/baselines_20200102'
OUT=ROOT/'preexperiment/results/native_20200102'


def main():
    with rasterio.open(ROOT/'Fuxian_L8_native_20200102.tif') as src:
        l8=src.read(); profile=src.profile.copy(); trans=src.transform; crs=src.crs
    with rasterio.open(ROOT/'Fuxian_masks_native_20200102.tif') as src:
        masks=src.read(); assert ColorInterp.alpha not in src.colorinterp
    with rasterio.open(ROOT/'Fuxian_S2_20200102.tif') as src:
        sv=src.read(8).astype('float32'); st=src.transform; sb=src.bounds
    metadata=json.loads((OLD/'native_grid_source_metadata.json').read_text())
    expected=metadata['projection']['transform']
    assert crs.to_string()==metadata['projection']['crs']
    assert trans.a==expected[0] and trans.e==expected[4]
    assert abs((trans.c-expected[2])/30-round((trans.c-expected[2])/30))<1e-8
    assert abs((trans.f-expected[5])/30-round((trans.f-expected[5])/30))<1e-8
    assert np.array_equal(l8[6]==1,masks[1]==1)
    shape=masks.shape[1:]; fraction=np.zeros(shape,'float32'); nearest=np.zeros(shape,'uint8')
    # Zero is a meaningful invalid observation, not nodata, during area averaging.
    reproject(sv,fraction,src_transform=st,src_crs=crs,dst_transform=trans,dst_crs=crs,resampling=Resampling.average)
    reproject(sv,nearest,src_transform=st,src_crs=crs,dst_transform=trans,dst_crs=crs,resampling=Resampling.nearest)
    rr,cc=np.indices(shape)
    left=trans.c+cc*30; top=trans.f-rr*30
    footprint=(left>=sb.left)&(left+30<=sb.right)&(top<=sb.top)&(top-30>=sb.bottom)
    # Require agreement with the GEE QA layer and complete valid support of the
    # exported S2 observations intersecting the L8 cell. No arbitrary spatial dilation.
    conservative=(masks[3]==1)&(fraction>=1-1e-6)&footprint
    zone=masks[0]==1
    ambiguous=(nearest.astype(bool)!=(masks[2]==1))&zone
    border=ndi.binary_dilation(sv==0,iterations=2)&ndi.binary_dilation(sv==1,iterations=2)
    border30=np.zeros(shape,'uint8')
    reproject(border.astype('uint8'),border30,src_transform=st,src_crs=crs,
              dst_transform=trans,dst_crs=crs,resampling=Resampling.max)
    support=np.stack([masks[1],fraction,conservative.astype('float32'),masks[0]]).astype('float32')
    profile.update(count=4,dtype='float32',nodata=None,photometric='MINISBLACK',compress='deflate')
    with rasterio.open(OUT/'observation_support.tif','w',**profile) as dst:
        dst.write(support)
        dst.descriptions=('l8_valid','s2_valid_area_fraction','joint_conservative','shore_zone')
        dst.colorinterp=(ColorInterp.gray,)+(ColorInterp.undefined,)*3
    old=json.loads((OLD/'registration_screen.json').read_text())
    new=json.loads((OUT/'registration_screen.json').read_text())
    rows=[]
    for a,b in zip(old['records'],new['records']):
        assert a['id']==b['id']
        x=dict(id=a['id'])
        for name,record in [('old',a),('native',b)]:
            values=list(record['bands'].values())
            shift=np.mean([v['shift_row_col_pixels'] for v in values],axis=0)
            x[name+'_mean_shift_m']=float(np.linalg.norm(shift)*30)
            x[name+'_mean_unshifted_ncc']=float(np.mean([v['ncc_before'] for v in values]))
        rows.append(x)
    result=dict(status='NATIVE_GRID_VERIFIED_AUTOMATIC_REGISTRATION_SCREEN_ONLY',
                native_grid_matches_source=True,source_masks_alpha=False,matched_windows=rows,
                old_median_vector_m=old['median_fitted_translation_magnitude_m'],
                native_median_vector_m=new['median_fitted_translation_magnitude_m'],
                old_median_unshifted_ncc=float(np.median([r['old_mean_unshifted_ncc'] for r in rows])),
                native_median_unshifted_ncc=float(np.median([r['native_mean_unshifted_ncc'] for r in rows])),
                qa=dict(shore_pixels=int(zone.sum()),gee_joint_pixels=int(((masks[3]==1)&zone).sum()),
                        conservative_joint_pixels=int((conservative&zone).sum()),
                        conservative_joint_fraction=float(conservative[zone].mean()),
                        nearest_disagreements_on_shore=int(ambiguous.sum()),
                        disagreements_near_s2_qa_transition=int((ambiguous&(border30==1)).sum())),
                reference_status='NOT_CREATED',independent_landmark_registration='PENDING',
                limitation='Same geographic neighborhoods; nearest native-grid window centers differ by <=15 m per axis. Fitted texture shifts are not shoreline errors or surveyed ground control accuracy.')
    (OUT/'grid_repair_comparison.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    # Data figure: parallel per-window values, no independent accuracy claim.
    canvas=Image.new('RGB',(1120,740),'white'); d=ImageDraw.Draw(canvas)
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',22); small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17)
    d.text((32,22),'Export-grid repair: matched land-texture windows',font=font,fill='black')
    d.text((32,57),'Fitted translation magnitude (m); mean NIR/SWIR1 vector per window',font=small,fill='black')
    for j,row in enumerate(rows):
        y=107+j*65;d.text((30,y+10),f'Land {row["id"]}',font=small,fill='black')
        for k,(key,color) in enumerate([('old_mean_shift_m','#c86944'),('native_mean_shift_m','#167b8b')]):
            value=row[key]; x=150+value*20
            d.rectangle((150,y+k*24,x,y+k*24+17),fill=color)
            d.text((x+8,y+k*24-2),f'{value:.1f}',font=small,fill='black')
    d.rectangle((30,650,49,667),fill='#c86944');d.text((58,646),'Old zero-origin grid',font=small,fill='black')
    d.rectangle((330,650,349,667),fill='#167b8b');d.text((358,646),'Source native grid',font=small,fill='black')
    d.text((30,695),'Exploratory screening only. No fitted shift applied; no shoreline accuracy measured.',font=small,fill='black')
    canvas.save(OUT/'grid_repair_comparison.png')
    records=json.loads((OUT/'review_windows.json').read_text())
    for rec in records:
        r,c=rec['row'],rec['col']; sub=np.s_[r:r+128,c:c+128]
        local_zone=zone[sub]
        rec.update(conservative_window_qa_fraction=float(conservative[sub].mean()),
                   conservative_shore_qa_fraction=float(conservative[sub][local_zone].mean()) if local_zone.any() else None,
                   review_status='RAW_OBSERVATION_REVIEW_REQUIRED',label_status='NOT_CREATED')
    (OUT/'annotation_window_manifest.json').write_text(json.dumps(records,indent=2),encoding='utf8')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
