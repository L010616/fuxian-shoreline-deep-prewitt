"""Freeze the 18 external-lake reference drafts after model-independent review.

All dates are retained. Review uses the pre-existing Sentinel-2 draft overview
and image-quality metadata only; no date is removed or edited in response to
model accuracy. Joint-valid and draft-nodata masks remain the only exclusions.
"""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

import run_q2_cross_lake_zero_shot as experiment


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/q2_external/screened_reference_freeze"
QC = ROOT / "preexperiment/results/q2_external/candidate_qc.csv"

REVIEW = {
    ("Dianchi_Waihai", "20200118"): ("RETAIN_CLEAR", "Clear shoreline; small invalid patches are away from the evaluated lake boundary."),
    ("Dianchi_Waihai", "20200728"): ("RETAIN_WITH_JOINT_VALID_MASK", "Extensive cloud and shadow; retain all independently valid shoreline sectors and exclude invalid pixels only."),
    ("Dianchi_Waihai", "20220312"): ("RETAIN_CLEAR", "Clear shoreline with continuous model-independent S2 draft."),
    ("Dianchi_Waihai", "20220819"): ("RETAIN_WITH_JOINT_VALID_MASK", "Extensive cloud and shadow; visible shoreline remains adequate within the joint-valid mask."),
    ("Dianchi_Waihai", "20230126"): ("RETAIN_CLEAR", "Clear shoreline with continuous S2 draft."),
    ("Dianchi_Waihai", "20240824"): ("RETAIN_WITH_JOINT_VALID_MASK", "Invalid surroundings are extensive, but retained shoreline sectors remain visually interpretable."),
    ("Erhai", "20200827"): ("RETAIN_CLEAR", "Lake shoreline is clear; invalid patches are mainly outside the target boundary."),
    ("Erhai", "20210102"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Erhai", "20221121"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Erhai", "20230601"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Erhai", "20251028"): ("RETAIN_WITH_JOINT_VALID_MASK", "Cloud patches occur outside or away from most evaluated shoreline sectors."),
    ("Erhai", "20251129"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Xingyun", "20200118"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Xingyun", "20200728"): ("RETAIN_WITH_JOINT_VALID_MASK", "Cloud and shadow are extensive; only jointly valid shoreline sectors are retained."),
    ("Xingyun", "20220312"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Xingyun", "20220819"): ("RETAIN_WITH_JOINT_VALID_MASK", "Cloud affects the northeastern vicinity; invalid pixels are excluded without deleting the date."),
    ("Xingyun", "20230126"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
    ("Xingyun", "20241027"): ("RETAIN_CLEAR", "Clear shoreline and continuous S2 draft."),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=False)
    with QC.open(newline="", encoding="utf-8-sig") as stream:
        quality = {(row["lake"], row["l8_date"]): row for row in csv.DictReader(stream)}
    records = []
    selected = experiment.selected_records()
    if set(REVIEW) != {(row["lake"], row["l8_date"]) for row in selected}:
        raise RuntimeError("Review inventory does not match the frozen 18-date set")
    for row in selected:
        key = row["lake"], row["l8_date"]
        status, note = REVIEW[key]
        overview = row["paths"]["draft"].parent / "review_overview.png"
        q = quality[key]
        records.append({
            "lake": row["lake"], "l8_date": row["l8_date"],
            "s2_date": row["s2_date"], "season": row["season"],
            "decision": "retain", "review_status": status, "review_note": note,
            "review_source": "prediction-blind S2 draft overview generated before model inference",
            "exclusion_rule": "joint L8-S2 valid mask AND S2 draft finite support; no metric-based date or sector deletion",
            "quality": {
                "joint_valid_shore": float(q["joint_valid_shore"]),
                "approx_usable_shoreline_km": float(q["approx_usable_shoreline_km"]),
                "sectors_50pct_joint_valid_of_12": int(q["sectors_50pct_joint_valid_of_12"]),
            },
            "files": {
                name: {"path": str(path.relative_to(ROOT)).replace("\\", "/"),
                       "sha256": sha256(path)}
                for name, path in {**row["paths"], "review_overview": overview}.items()
            },
        })
    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "EXTERNAL_REFERENCE_SET_FROZEN_ALL_18_DATES_RETAINED",
        "purpose": "model-independent reference review before corrected hard-constraint evaluation",
        "review_scope": "pre-existing S2 imagery, automatic draft shoreline and sensor-validity masks",
        "model_overlay_used_for_retention_or_exclusion": False,
        "metric_based_exclusion": False,
        "all_dates_retained": True,
        "date_count": len(records),
        "lake_counts": {lake: sum(row["lake"] == lake for row in records)
                        for lake in ("Dianchi_Waihai", "Erhai", "Xingyun")},
        "season_counts_per_lake": {
            lake: {season: sum(row["lake"] == lake and row["season"] == season for row in records)
                   for season in ("dry", "wet")}
            for lake in ("Dianchi_Waihai", "Erhai", "Xingyun")
        },
        "records": records,
    }
    manifest = OUT / "external_reference_freeze_manifest.json"
    manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    with (OUT / "reference_review.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(["lake", "l8_date", "s2_date", "season", "decision", "review_status",
                         "joint_valid_shore", "usable_shoreline_km", "valid_sectors_of_12", "review_note"])
        for row in records:
            writer.writerow([row["lake"], row["l8_date"], row["s2_date"], row["season"],
                             row["decision"], row["review_status"], row["quality"]["joint_valid_shore"],
                             row["quality"]["approx_usable_shoreline_km"],
                             row["quality"]["sectors_50pct_joint_valid_of_12"], row["review_note"]])
    print(json.dumps({"manifest": str(manifest), "dates": len(records),
                      "all_retained": True}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
