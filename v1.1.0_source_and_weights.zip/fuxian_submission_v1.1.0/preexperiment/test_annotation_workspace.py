"""Verify coordinate preservation and versioned annotation persistence using temporary data."""
import copy
import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path
import numpy as np
import annotation_server as server
from build_annotation_workspace import review_chunks


class AnnotationChecks(unittest.TestCase):
    def sample(self):
        return dict(crs='EPSG:32648',scene_date='2020-01-02',author='TEST_ONLY',segments=[
            dict(id='TEST_LINE',kind='shoreline',coordinates=[[290000,2713000],[290020,2713020]],
                 properties=dict(review_status='DRAFT'))],control_points=[])

    def test_review_chunks_preserve_length_and_shared_endpoints(self):
        points=np.array([[280000.,2700000.],[281003.,2700200.],[282014.,2700600.]])
        chunks=list(review_chunks(points));length=lambda p:np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
        self.assertAlmostEqual(sum(length(c) for c in chunks),length(points),places=7)
        self.assertTrue(all(length(c)<=750+1e-6 for c in chunks))
        for a,b in zip(chunks,chunks[1:]):np.testing.assert_allclose(a[-1],b[0])

    def test_reject_bad_coordinates_and_unattributed_review(self):
        data=self.sample();data['segments'][0]['coordinates'][0][0]=float('nan')
        with self.assertRaises(ValueError):server.validate(data)
        data=self.sample();data['segments'][0]['properties']['review_status']='REVIEWED'
        with self.assertRaises(ValueError):server.validate(data)

    def test_http_saves_versions_and_wgs84_in_temporary_directory(self):
        original=server.ROOT
        with tempfile.TemporaryDirectory() as temp:
            server.ROOT=Path(temp)
            http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
            thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
            try:
                url=f'http://127.0.0.1:{http.server_port}/save'
                for _ in range(2):
                    request=urllib.request.Request(url,data=json.dumps(self.sample()).encode(),headers={'Content-Type':'application/json'})
                    with urllib.request.urlopen(request) as response:self.assertEqual(response.status,200)
                files=list((Path(temp)/'saves').glob('draft_*.geojson'));self.assertEqual(len(files),2)
                geo=json.loads(files[0].read_text('utf8'));lon,lat=geo['features'][0]['geometry']['coordinates'][0]
                self.assertTrue(102<lon<104 and 24<lat<25)
                latest=json.loads((Path(temp)/'saves/latest.json').read_text('utf8'))
                self.assertFalse(latest['allow_training']);self.assertEqual(latest['review_status'],'DRAFT_DATASET')
                self.assertEqual(latest['segments'][0]['coordinates'],self.sample()['segments'][0]['coordinates'])
            finally:
                http.shutdown();http.server_close();thread.join();server.ROOT=original


if __name__=='__main__':unittest.main()
