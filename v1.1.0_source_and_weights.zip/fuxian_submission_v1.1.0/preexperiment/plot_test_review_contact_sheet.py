"""Create a contact sheet for rapid QA of the 24 frozen-test review panels."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/formal_test_drafts_v02"
OUTPUT = BASE / "compact_review_contact_sheet.jpg"


def main() -> None:
    paths = sorted(BASE.glob("*/compact_review/*.jpg"))
    if len(paths) != 24:
        raise RuntimeError(f"Expected 24 panels, found {len(paths)}")
    thumb_w, thumb_h = 500, 291
    header = 54
    sheet = Image.new("RGB", (thumb_w * 3, (thumb_h + header) * 8), "white")
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 20)
    for index, path in enumerate(paths):
        image = Image.open(path).convert("RGB")
        image.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
        x = index % 3 * thumb_w
        y = index // 3 * (thumb_h + header)
        draw = ImageDraw.Draw(sheet)
        draw.text((x + 12, y + 12), path.stem, fill="#172738", font=font)
        sheet.paste(image, (x, y + header))
    sheet.save(OUTPUT, quality=92, dpi=(200, 200))
    print(OUTPUT)


if __name__ == "__main__":
    main()
