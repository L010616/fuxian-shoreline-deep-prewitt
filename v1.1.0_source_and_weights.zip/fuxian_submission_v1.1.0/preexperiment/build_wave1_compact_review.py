"""Build an 18-site compact review pack from wave-1 shoreline drafts."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw, ImageFont
from rasterio.warp import transform
from rasterio.windows import Window, from_bounds


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment/results/formal_wave1"
DATES = ["20200509", "20210205", "20220312"]
SITE_COUNT = 6
MIN_SPACING_M = 2200.0
HALF_SIZE_M = 750.0
REPORT_TITLE = "第一批岸线简化复核"
REPORT_INTRO = ("每期选取 6 个空间分散且光谱风险最高的岸段，共 18 处。左为 Landsat 8，右为 Sentinel-2；"
                "青色为自动岸线草稿。该页面用于预实验筛查，不能替代最终参考岸线质量记录。")
TEST_DATES_OPENED = False


def utm_coords(feature):
    coordinates = feature["geometry"]["coordinates"]
    lon, lat = zip(*coordinates)
    x, y = transform("EPSG:4326", "EPSG:32648", list(lon), list(lat))
    return np.column_stack([x, y])


def select_sites(features):
    candidates = []
    for f in features:
        p = f["properties"]
        xy = utm_coords(f)
        center = xy.mean(axis=0)
        score = p["low_margin_vertex_fraction"] + max(0, 0.08 - p["median_abs_ndwi_margin"]) * 5
        candidates.append((score, center, f, xy))
    candidates.sort(key=lambda x: x[0], reverse=True)
    selected = []
    for item in candidates:
        if all(np.linalg.norm(item[1] - old[1]) >= MIN_SPACING_M for old in selected):
            selected.append(item)
        if len(selected) == SITE_COUNT:
            break
    # Relax spacing only if a scene has too few distinct high-risk regions.
    if len(selected) < SITE_COUNT:
        used = {id(x[2]) for x in selected}
        selected.extend(x for x in candidates if id(x[2]) not in used) 
        selected = selected[:SITE_COUNT]
    return selected


def read_rgb(src, bounds, bands, scale, stretch):
    win = from_bounds(*bounds, src.transform).round_offsets().round_lengths()
    win = Window(max(0, win.col_off), max(0, win.row_off), win.width, win.height)
    data = src.read(bands, window=win, boundless=True, fill_value=0).astype("float32") * scale
    rgb = np.clip(data.transpose(1, 2, 0) / stretch, 0, 1) ** 0.7
    return (rgb * 255).astype("uint8"), win


def draw_line(image, xy, src, win, color=(0, 255, 255), width=3):
    inv = ~src.transform
    pixels = [inv * tuple(p) for p in xy]
    points = [(round(c - win.col_off), round(r - win.row_off)) for c, r in pixels]
    draw = ImageDraw.Draw(image)
    if len(points) >= 2:
        draw.line(points, fill=color, width=width)


def main():
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 19)
    small = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 15)
    all_sites = []
    html_sections = []
    for date in DATES:
        scene = BASE / date
        data = json.loads((scene / "shoreline_DRAFT.geojson").read_text(encoding="utf-8"))
        high = [f for f in data["features"] if f["properties"]["review_priority"] == "HIGH"]
        if len(high) < SITE_COUNT:
            high = data["features"]
        selected = select_sites(high)
        assets = scene / "compact_review"
        assets.mkdir(exist_ok=True)
        manifest = json.loads((scene / "draft_manifest.json").read_text(encoding="utf-8"))
        s2tag = manifest["s2_date"].replace("-", "")
        with rasterio.open(ROOT / f"Fuxian_S2_{s2tag}.tif") as s2src, \
             rasterio.open(ROOT / f"Fuxian_L8_native_{date}.tif") as l8src:
            for number, (score, center, feature, xy) in enumerate(selected, 1):
                site_id = f"{date}_R{number:02d}"
                bounds = [center[0] - HALF_SIZE_M, center[1] - HALF_SIZE_M,
                          center[0] + HALF_SIZE_M, center[1] + HALF_SIZE_M]
                s2rgb, s2win = read_rgb(s2src, bounds, (3, 2, 1), 1.0, 2600)
                l8rgb, l8win = read_rgb(l8src, bounds, (3, 2, 1), 1.0, 0.24)
                sim = Image.fromarray(s2rgb)
                lim = Image.fromarray(l8rgb)
                draw_line(sim, xy, s2src, s2win, width=2)
                draw_line(lim, xy, l8src, l8win, width=1)
                size = 500
                sim = sim.resize((size, size), Image.Resampling.NEAREST)
                lim = lim.resize((size, size), Image.Resampling.NEAREST)
                canvas = Image.new("RGB", (size * 2, size + 82), "white")
                canvas.paste(lim, (0, 42)); canvas.paste(sim, (size, 42))
                draw = ImageDraw.Draw(canvas)
                draw.text((12, 10), f"{site_id} | L8 30 m", fill="black", font=font)
                draw.text((size + 12, 10), f"S2 10 m + cyan draft", fill="black", font=font)
                p = feature["properties"]
                draw.text((12, size + 52),
                          f"source {p['segment_id']} | low-margin fraction {p['low_margin_vertex_fraction']:.0%}",
                          fill="black", font=small)
                filename = f"{site_id}.jpg"
                canvas.save(assets / filename, quality=92)
                site = {
                    "site_id": site_id, "date": manifest["l8_date"],
                    "source_segment": p["segment_id"], "score": float(score),
                    "center_utm": center.tolist(), "bounds_utm": bounds,
                    "status": "PENDING_COMPACT_REVIEW", "image": str(assets / filename),
                }
                all_sites.append(site)
                html_sections.append(
                    f'<section><h2>{site_id}</h2><img src="{date}/compact_review/{filename}">'
                    f'<p>来源岸段 {p["segment_id"]}；低光谱间隔顶点 {p["low_margin_vertex_fraction"]:.0%}。'
                    '检查青色线是否沿可见水陆交界；若明显偏离则记录重绘。</p></section>'
                )
    report = {
        "status": "PENDING_COMPACT_REVIEW", "strategy": "6 spatially separated highest-risk sites per date",
        "site_count": len(all_sites), "test_dates_opened": TEST_DATES_OPENED, "sites": all_sites,
    }
    (BASE / "compact_review_manifest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    html = ('''<!doctype html><html lang="zh"><meta charset="utf-8"><title>''' + REPORT_TITLE + '''</title>
<style>body{max-width:1080px;margin:30px auto;background:#eef2f5;color:#172738;font:17px system-ui}
section{background:white;padding:18px;margin:22px 0;box-shadow:0 2px 8px #ccd}img{width:100%;height:auto}p{line-height:1.7}</style>
<h1>抚仙湖''' + REPORT_TITLE + "</h1><p>" + REPORT_INTRO + "</p>" + "".join(html_sections) + "</html>")
    (BASE / "compact_review.html").write_text(html, encoding="utf-8")
    print(json.dumps({"sites": len(all_sites), "html": str(BASE / "compact_review.html")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
