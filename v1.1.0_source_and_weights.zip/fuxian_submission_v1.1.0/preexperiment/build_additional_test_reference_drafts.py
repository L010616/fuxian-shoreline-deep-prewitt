"""Build automatic review drafts for the two additional 2026 test dates."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "preexperiment/results/additional_test_pairs_v01.json"
OUT = ROOT / "preexperiment/results/formal_test_drafts_v03_additional"


def main() -> int:
    qc_path = ROOT / "preexperiment/results/additional_test_download_qc_v01.json"
    if not qc_path.exists() or json.loads(qc_path.read_text(encoding="utf-8"))["status"] != "PASS":
        raise RuntimeError("Additional-test download QC has not passed")
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    records = []
    for source in data["selected"]:
        records.append({
            "l8_date": source["l8_date"],
            "s2_date": source["s2_date"],
            "calendar_gap_days": source["calendar_gap_days"],
            "split": "test",
        })
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    results = [builder.build_one(record) for record in records]
    summary = {
        "dataset": "Fuxian additional formal test reference drafts v0.3",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_DATE_LEVEL_REVIEW",
        "test_accuracy_opened": False,
        "allow_evaluation": False,
        "records": results,
        "totals": {
            "dates": len(results),
            "segments": sum(row["segment_count"] for row in results),
            "high_priority_segments": sum(row["high_priority_segments"] for row in results),
        },
    }
    (OUT / "additional_test_draft_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
