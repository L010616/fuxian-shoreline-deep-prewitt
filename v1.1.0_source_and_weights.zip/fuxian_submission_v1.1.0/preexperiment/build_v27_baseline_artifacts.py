"""Create matching scientific plots and compact numerical-verification caches."""
from pathlib import Path
import csv,json,os
import numpy as np
from scipy import ndimage as ndi
import rasterio
from rasterio.warp import transform
import run_v25_scope_audit as audit
import run_v27_index_jrc_baselines as new
os.environ.setdefault('MPLCONFIGDIR',str(new.OUT/'matplotlib_cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=audit.ROOT;OUT=new.OUT;FIG=ROOT/'论文/revision_round21/figures';FIG.mkdir(parents=True,exist_ok=True)
NAMES={'ndwi_zero':'NDWI, zero','ndwi_otsu':'NDWI, Otsu','mndwi_zero':'MNDWI, zero','mndwi_otsu':'MNDWI, Otsu','jrc_2019':'JRC 2019','spatial_prior':'Spatial prior','parameter_matched_ordinary_conv':'Matched conv.','deep_prewitt':'Deep Prewitt'}
ORDER=list(NAMES)
def main():
    summary=new.csvread(OUT/'summary_mean_date_sd.csv');lookup={r['model']:r for r in summary if r['scope']=='manual_full'}
    colors=['#b8c6e5','#92a6d1','#e8b99e','#e2a07f','#91b6a7','#a3acd8','#879bd0','#6c5c9b']
    plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.8,'savefig.facecolor':'white'})
    fig,axes=plt.subplots(1,3,figsize=(11.4,3.55),sharey=True,gridspec_kw={'width_ratios':[1,1,1.15]})
    ys=np.arange(len(ORDER))[::-1]
    for ax,key,label in zip(axes,('f1','boundary_f1_30m','mean_symmetric_boundary_distance_m'),('Region F1','Boundary F1 (30 m)','ASD (m)')):
        for y,m,c in zip(ys,ORDER,colors):
            r=lookup[m];mean=float(r[key+'_mean']);sd=float(r[key+'_date_sd'])
            ax.errorbar(mean,y,xerr=sd,fmt='o',color=c,markersize=5,capsize=3,elinewidth=1.25)
        ax.set_xlabel(label);ax.set_yticks(ys);ax.grid(axis='x',color='#e5e7eb',lw=.7);ax.set_axisbelow(True)
    axes[0].set_yticklabels([NAMES[m] for m in ORDER]);axes[0].set_xlim(.972,1.002);axes[1].set_xlim(.50,.94);axes[2].set_xlim(-2,138)
    for i,ax in enumerate(axes):ax.text(-.06,1.035,f'({chr(97+i)})',transform=ax.transAxes,fontweight='bold',fontsize=12)
    fig.subplots_adjust(left=.14,right=.992,bottom=.18,top=.90,wspace=.22)
    fig.savefig(FIG/'index_JRC_manual_comparison.png',dpi=450);fig.savefig(FIG/'index_JRC_manual_comparison.svg');plt.close(fig)
    cache=OUT/'verification_cache';cache.mkdir(exist_ok=True)
    thresholds={(r['tag'],r['method']):float(r['threshold']) for r in new.csvread(OUT/'index_thresholds.csv')}
    records=[]
    for r in audit.base.selected_records():
        tag=f"{r['lake']}_{r['l8_date']}";a=dict(np.load(audit.AUDIT/'references'/f'{tag}.npz'));s=audit.base.read_scene(r);v=a['wide_valid'];x=s['x_raw']
        data={'valid':v,'wide':a['wide'],'proxy_truth':a['wide_truth']}
        if 'manual_truth' in a:data['manual_truth']=a['manual_truth']
        for name,b in (('ndwi',3),('mndwi',4)):
            den=x[1]+x[b];idx=np.full(v.shape,np.nan,dtype='float32');np.divide(x[1]-x[b],den,out=idx,where=np.isfinite(den)&(np.abs(den)>1e-8));idx[~v]=np.nan;data[name]=idx
        with rasterio.open(r['paths']['qa']) as qa:
            lake=audit.base.external.main_component(qa.read(1)>=2,qa,r['lake'])
            if r['lake']=='Dianchi_Waihai':
                lake&=(qa.transform.f+(np.arange(qa.height)+.5)*qa.transform.e)[:,None]<=2763300.
                labels,_=ndi.label(lake,structure=np.ones((3,3),dtype='uint8'));sx,sy=transform('EPSG:4326',qa.crs,[102.7049],[24.8379]);c,rr=(~qa.transform)*(sx[0],sy[0]);lake=labels==labels[round(rr),round(c)]
            data['jrc_2019']=ndi.binary_fill_holes(lake)&v
        for m in audit.base.MODELS:
            probs=[np.load(audit.AUDIT/'raw_probability_cache'/f'{tag}_{m}_seed{seed}.npz')['probability'] for seed in audit.base.SEEDS]
            data[m]=(np.mean(probs,axis=0).astype('float32')>=.5)&v
        p=cache/f'{tag}.npz';np.savez_compressed(p,**data)
        records.append({'tag':tag,'lake':r['lake'],'l8_date':r['l8_date'],'sha256':new.sha(p),'thresholds':{m:thresholds[(tag,m)] for m in new.METHODS if m!='jrc_2019'}})
        print('CACHED',tag,flush=True)
    new.dump(cache/'manifest.json',{'pixel_size_m':30,'scope':'Same frozen expanded common-valid mask; values outside common validity are omitted because eroded query/target support excludes those edges.','records':records})
if __name__=='__main__':main()
