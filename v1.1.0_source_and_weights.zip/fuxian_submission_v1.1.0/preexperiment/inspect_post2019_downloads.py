from pathlib import Path
import rasterio, re, json, csv
src=Path(r"D:\Document\ChatGPT\水色\drive-download-20260921T161217Z-1-001")
rows=[]
for p in sorted(src.glob("*.tif")):
    with rasterio.open(p) as ds:
        rows.append({"name":p.name,"bands":ds.count,"width":ds.width,"height":ds.height,"crs":str(ds.crs),"transform":tuple(ds.transform)[:6],"dtypes":list(ds.dtypes),"nodata":ds.nodata})
print(json.dumps(rows,indent=2,ensure_ascii=False))
print((src/"Fuxian_edgeconfirm_post2019_selection_manifest.csv").read_text(encoding="utf-8-sig"))

