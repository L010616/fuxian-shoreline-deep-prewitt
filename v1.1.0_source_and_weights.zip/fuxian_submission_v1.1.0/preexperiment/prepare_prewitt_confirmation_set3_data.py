"""Validate and freeze the downloaded final Prewitt confirmation image triplets."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path

import rasterio


ROOT = Path(__file__).resolve().parents[1]
def find_source() -> Path:
    candidates = [
        path.parent for path in ROOT.glob("drive-download-*/Fuxian_prewitt_confirm_set3_selection_manifest.csv")
    ]
    if not candidates:
        raise FileNotFoundError(
            "No downloaded set-3 folder contains Fuxian_prewitt_confirm_set3_selection_manifest.csv"
        )
    return max(candidates, key=lambda path: path.stat().st_mtime)


SOURCE = find_source()
DATA = ROOT / "preexperiment" / "data" / "prewitt_confirmation_set3"
RAW = DATA / "analysis_ready"
MANIFEST = DATA / "selection_manifest.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def raster_signature(path: Path) -> dict:
    with rasterio.open(path) as dataset:
        return {
            "bands": dataset.count,
            "width": dataset.width,
            "height": dataset.height,
            "crs": str(dataset.crs),
            "transform": list(tuple(dataset.transform)[:6]),
            "dtypes": list(dataset.dtypes),
            "nodata": dataset.nodata,
        }


def main() -> None:
    if MANIFEST.exists():
        raise RuntimeError("Set-3 manifest already exists; refusing to overwrite")

    csv_path = SOURCE / "Fuxian_prewitt_confirm_set3_selection_manifest.csv"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 6:
        raise RuntimeError(f"Expected six selected pairs, found {len(rows)}")
    if len({row["l8_date"] for row in rows}) != 6:
        raise RuntimeError("The six Landsat dates are not unique")

    RAW.mkdir(parents=True, exist_ok=True)
    records = []
    for row in rows:
        l8_tag = row["l8_date"].replace("-", "")
        s2_tag = row["s2_date"].replace("-", "")
        names = {
            "l8": f"Fuxian_prewitt_confirm_set3_L8_native_{l8_tag}.tif",
            "s2": f"Fuxian_prewitt_confirm_set3_S2_{s2_tag}_for_{l8_tag}.tif",
            "mask": f"Fuxian_prewitt_confirm_set3_masks_native_{l8_tag}.tif",
        }
        source_paths = {key: SOURCE / name for key, name in names.items()}
        missing = [str(path) for path in source_paths.values() if not path.exists()]
        if missing:
            raise FileNotFoundError(missing)

        signatures = {key: raster_signature(path) for key, path in source_paths.items()}
        expected = {
            "l8": (7, 542, 1095, "EPSG:32648"),
            "s2": (8, 1623, 3281, "EPSG:32648"),
            "mask": (5, 542, 1095, "EPSG:32648"),
        }
        for key, wanted in expected.items():
            signature = signatures[key]
            actual = (signature["bands"], signature["width"], signature["height"], signature["crs"])
            if actual != wanted:
                raise RuntimeError(f"Unexpected {key} grid for {l8_tag}: {signature}")

        copied = {}
        hashes = {}
        for key, source_path in source_paths.items():
            destination = RAW / source_path.name
            shutil.copy2(source_path, destination)
            copied[key] = str(destination.relative_to(ROOT)).replace("\\", "/")
            hashes[key] = sha256(destination)

        records.append({
            "l8_date": row["l8_date"],
            "s2_date": row["s2_date"],
            "calendar_gap_days": int(float(row["day_gap"])),
            "window": row["window"],
            "season": row["season"],
            "l8_clear_shore": float(row["l8_clear_shore"]),
            "s2_clear_shore": float(row["s2_clear_shore"]),
            "quality_score": float(row["quality_score"]),
            "files": copied,
            "sha256": hashes,
            "raster_signature": signatures,
        })

    payload = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "PREWITT_CONFIRMATION_SET3_INPUTS_VALIDATED_BEFORE_REFERENCE_SCREENING",
        "selection_rule": "One quality-ranked unused pair per calendar year from 2020 through 2025; no model output used",
        "date_count": 6,
        "analysis_file_count": 18,
        "allow_training": False,
        "allow_model_selection": False,
        "allow_threshold_tuning": False,
        "allow_model_predictions_before_reference_freeze": False,
        "records": records,
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": payload["status"],
        "dates": [record["l8_date"] for record in records],
        "minimum_l8_clear_shore": min(record["l8_clear_shore"] for record in records),
        "minimum_s2_clear_shore": min(record["s2_clear_shore"] for record in records),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

