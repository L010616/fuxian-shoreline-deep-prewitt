"""Ingest and validate the six frozen round-4 final blind-test dates."""
from __future__ import annotations
import json, os, shutil, hashlib
from datetime import datetime
from pathlib import Path
from validate_formal_downloads import inspect_tif

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'drive-download-20260915T180854Z-1-001'
RAW=ROOT/'preexperiment/data/round4_final_blind/raw'
OUT=ROOT/'preexperiment/results/round4_final_blind'
DATES=[
 ('2024-01-13','2024-01-11'),('2024-08-24','2024-08-23'),('2025-03-04','2025-03-01'),
 ('2026-04-24','2026-04-25'),('2026-08-14','2026-08-13'),('2026-05-26','2026-05-25')]

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def copy_or_link(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():
  if sha(dst)!=sha(src): raise RuntimeError(f'Existing file differs: {dst}')
  return
 try: os.link(src,dst)
 except OSError: shutil.copy2(src,dst)

def main():
 RAW.mkdir(parents=True,exist_ok=True); OUT.mkdir(parents=True,exist_ok=True)
 records=[]
 for ld,sd in DATES:
  lt=ld.replace('-',''); st=sd.replace('-','')
  source_paths={
   'l8':SOURCE/f'Fuxian_final_L8_native_{lt}.tif',
   's2':SOURCE/f'Fuxian_final_S2_{st}_for_{lt}.tif',
   'masks':SOURCE/f'Fuxian_final_masks_native_{lt}.tif'}
  raw_paths={k:RAW/p.name for k,p in source_paths.items()}
  for k,p in source_paths.items():
   if not p.exists(): raise FileNotFoundError(p)
   copy_or_link(p,raw_paths[k])
  # Compatibility hardlinks used by the existing reference/evaluation pipeline.
  compat={'l8':ROOT/f'Fuxian_L8_native_{lt}.tif','s2':ROOT/f'Fuxian_S2_{st}.tif','masks':ROOT/f'Fuxian_masks_native_{lt}.tif'}
  for k,p in compat.items(): copy_or_link(raw_paths[k],p)
  files={k:inspect_tif(p,k) for k,p in raw_paths.items()}
  records.append({'l8_date':ld,'s2_date':sd,'split':'final_blind_test',
    'download_complete':all(v['status']=='PASS' for v in files.values()),'files':files})
 status='PASS' if len(records)==6 and all(r['download_complete'] for r in records) else 'FAILED'
 payload={'created_at':datetime.now().astimezone().isoformat(timespec='seconds'),
  'status':status,'dates':6,'files':18,'training_allowed':False,'model_selection_allowed':False,
  'threshold_tuning_allowed':False,'records':records}
 (OUT/'intake_qc.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
 (OUT/'evaluation_pairs.json').write_text(json.dumps({'selected':[
  {'l8_date':ld,'s2_date':sd,'calendar_gap_days':abs((datetime.fromisoformat(ld)-datetime.fromisoformat(sd)).days),
   'quality_class':'FINAL_BLIND'} for ld,sd in DATES]},ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'status':status,'dates':len(records),'complete':sum(r['download_complete'] for r in records)},indent=2))
 return 0 if status=='PASS' else 2
if __name__=='__main__': raise SystemExit(main())
