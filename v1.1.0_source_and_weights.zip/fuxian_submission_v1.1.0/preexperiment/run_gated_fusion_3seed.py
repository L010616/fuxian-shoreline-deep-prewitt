"""Compare prior-only, concatenated edges, and gated edge fusion."""
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

import run_fair_comparison_3seed as protocol
from run_multidate_ablation_pilot import AblationDFANet, DSConv, Encoder, FixedEdgeMode


ROOT = Path(__file__).resolve().parents[1]
protocol.OUT = ROOT / "preexperiment/results/gated_fusion_3seed_v01"


class EdgeGate(nn.Module):
    def __init__(self, semantic_channels, edge_channels):
        super().__init__()
        self.edge_project = nn.Sequential(
            nn.Conv2d(edge_channels, semantic_channels, 1, bias=False),
            nn.BatchNorm2d(semantic_channels),
        )
        self.gate = nn.Conv2d(semantic_channels * 2, semantic_channels, 1)
        nn.init.zeros_(self.gate.weight)
        nn.init.constant_(self.gate.bias, -1.0)

    def forward(self, semantic, edge):
        projected = self.edge_project(edge)
        weight = torch.sigmoid(self.gate(torch.cat([semantic, projected], dim=1)))
        return semantic + weight * projected


class GatedParallelDFANet(nn.Module):
    """Parallel fixed-edge encoder with conservative, spatially varying gates."""
    def __init__(self):
        super().__init__()
        semantic_widths = (24, 48, 96, 128)
        edge_widths = (12, 20, 32, 48)
        self.semantic = Encoder(8, semantic_widths)
        self.edges = FixedEdgeMode("parallel")
        self.edge_encoder = Encoder(4, edge_widths)
        self.gates = nn.ModuleList([
            EdgeGate(s, e) for s, e in zip(semantic_widths, edge_widths)
        ])
        self.d2 = DSConv(128 + 96, 96)
        self.d1 = DSConv(96 + 48, 64)
        self.d0 = DSConv(64 + 24, 48)
        self.head = nn.Conv2d(48, 1, 1)

    def forward(self, x, priors):
        semantic = self.semantic(torch.cat([x, priors], dim=1))
        edge = self.edge_encoder(self.edges(x))
        s0, s1, s2, s3 = [gate(s, e) for gate, s, e in zip(self.gates, semantic, edge)]
        z = F.interpolate(s3, size=s2.shape[-2:], mode="bilinear", align_corners=False)
        z = self.d2(torch.cat([z, s2], dim=1))
        z = F.interpolate(z, size=s1.shape[-2:], mode="bilinear", align_corners=False)
        z = self.d1(torch.cat([z, s1], dim=1))
        z = F.interpolate(z, size=s0.shape[-2:], mode="bilinear", align_corners=False)
        z = self.d0(torch.cat([z, s0], dim=1))
        return F.interpolate(self.head(z), size=x.shape[-2:], mode="bilinear", align_corners=False)


def candidate_models():
    return {
        "prior": lambda: AblationDFANet(True, None),
        "parallel": lambda: AblationDFANet(True, "parallel"),
        "gated_parallel": GatedParallelDFANet,
    }


protocol.build_models = candidate_models

if __name__ == "__main__":
    protocol.main()
