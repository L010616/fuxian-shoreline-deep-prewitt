from pathlib import Path
import re, json
root=Path(r"D:\Document\ChatGPT\水色")
pat=re.compile(r'20(?:1[3-9]|2[0-6])[-_]?(?:0[1-9]|1[0-2])[-_]?(?:0[1-9]|[12]\d|3[01])')
hits={}
for base in [root/"preexperiment"/"results", root/"preexperiment"/"data", root]:
    if not base.exists(): continue
    for p in base.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".json",".csv",".txt",".js",".py"} and p.stat().st_size<2_000_000:
            try: s=p.read_text(encoding="utf-8",errors="ignore")
            except: continue
            ds={m.group(0).replace("_","-") for m in pat.finditer(s)}
            if ds: hits[str(p.relative_to(root))]=sorted(ds)
all_dates=sorted({d for v in hits.values() for d in v})
print("\n".join(all_dates))
print("COUNT",len(all_dates))

