"""Freeze conservative pilot-test shoreline references for the two usable dates.

This script does not claim independent ground truth. It retains normal-priority
draft segments plus compact-review PASS segments, and masks every other
high-priority segment with a 30 m buffer. The outputs are suitable only for the
locked pilot evaluation documented in the accompanying manifest.
"""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform, transform_geom
from scipy import ndimage as ndi


ROOT = Path(__file__).resolve().parents[1]
DRAFT_ROOT = ROOT / "preexperiment/results/formal_test_drafts_v02"
REVIEW_ROOT = DRAFT_ROOT / "manual_review_v01"
OUT = REVIEW_ROOT / "pilot_test_reference_v01"
DATES = {
    "20250507": {"s2": "20250505", "gap_days": 2},
    "20251201": {"s2": "20251201", "gap_days": 0},
}
BUFFER_M = 30.0


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def read_manual_decisions() -> dict[str, str]:
    path = REVIEW_ROOT / "manual_review_decisions_24.csv"
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {row["source_segment"]: row["decision"] for row in csv.DictReader(stream)}


def rasterize_exclusions(lines_wgs84: list[dict], reference: Path, output: Path) -> dict:
    with rasterio.open(reference) as src:
        profile = src.profile.copy()
        projected = [transform_geom("EPSG:4326", src.crs, geom) for geom in lines_wgs84]
        line_mask = rasterize(
            [(geom, 1) for geom in projected],
            out_shape=(src.height, src.width),
            transform=src.transform,
            fill=0,
            dtype="uint8",
            all_touched=True,
        )
        iterations = max(1, int(np.ceil(BUFFER_M / abs(src.transform.a))))
        mask = ndi.binary_dilation(line_mask.astype(bool), iterations=iterations).astype("uint8")
    profile.update(count=1, dtype="uint8", nodata=255, compress="deflate")
    with rasterio.open(output, "w", **profile) as dst:
        dst.write(mask, 1)
        dst.set_band_description(1, "pilot_reference_exclusion_mask_1_excluded")
    return {
        "path": str(output.relative_to(ROOT)),
        "reference_raster": reference.name,
        "shape": [int(mask.shape[0]), int(mask.shape[1])],
        "excluded_pixels": int(mask.sum()),
        "sha256": sha256(output),
    }


def sector_coverage(features: list[dict], target_crs) -> dict:
    points = []
    for feature in features:
        coords = np.asarray(feature["geometry"]["coordinates"], dtype="float64")
        xs, ys = transform("EPSG:4326", target_crs, coords[:, 0].tolist(), coords[:, 1].tolist())
        points.append(np.column_stack([xs, ys]))
    if not points:
        return {"occupied_12_sectors": 0, "sector_ids": []}
    coords = np.vstack(points)
    center = coords.mean(axis=0)
    angle = (np.degrees(np.arctan2(coords[:, 1] - center[1], coords[:, 0] - center[0])) + 360) % 360
    sectors = sorted(set((angle // 30).astype(int).tolist()))
    return {"occupied_12_sectors": len(sectors), "sector_ids": sectors}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    decisions = read_manual_decisions()
    records = []
    for l8_tag, info in DATES.items():
        date_out = OUT / l8_tag
        date_out.mkdir(exist_ok=True)
        draft_path = DRAFT_ROOT / l8_tag / "shoreline_DRAFT.geojson"
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        with rasterio.open(ROOT / f"Fuxian_S2_{info['s2']}.tif") as src:
            target_crs = src.crs
        retained, excluded, excluded_lines = [], [], []
        for feature in draft["features"]:
            props = feature["properties"]
            sid = props["segment_id"]
            manual = decisions.get(sid)
            keep = manual == "PASS" or (manual is None and props["review_priority"] == "NORMAL")
            copied = json.loads(json.dumps(feature))
            copied["properties"].update({
                "pilot_review_decision": "RETAIN" if keep else "EXCLUDE",
                "pilot_review_basis": (
                    "COMPACT_VISUAL_PASS" if manual == "PASS"
                    else "COMPACT_VISUAL_EXCLUDE" if manual == "EXCLUDE"
                    else "AUTOMATIC_HIGH_PRIORITY_CONSERVATIVE_EXCLUDE" if not keep
                    else "DATE_OVERVIEW_PLUS_NORMAL_PRIORITY"
                ),
                "reference_status": "PILOT_SCREENED_NOT_INDEPENDENT_GROUND_TRUTH",
                "allow_training": False,
            })
            if keep:
                retained.append(copied)
            else:
                excluded.append(copied)
                excluded_lines.append(feature["geometry"])

        retained_path = date_out / "shoreline_reference_PILOT_SCREENED.geojson"
        excluded_path = date_out / "excluded_segments.geojson"
        write_json(retained_path, {"type": "FeatureCollection", "features": retained})
        write_json(excluded_path, {"type": "FeatureCollection", "features": excluded})
        s2_mask = rasterize_exclusions(
            excluded_lines,
            ROOT / f"Fuxian_S2_{info['s2']}.tif",
            date_out / "pilot_exclusion_mask_S2_10m.tif",
        )
        l8_mask = rasterize_exclusions(
            excluded_lines,
            ROOT / f"Fuxian_L8_native_{l8_tag}.tif",
            date_out / "pilot_exclusion_mask_L8_30m.tif",
        )

        retained_length = sum(float(f["properties"]["length_m"]) for f in retained)
        total_length = retained_length + sum(float(f["properties"]["length_m"]) for f in excluded)
        records.append({
            "l8_date": f"{l8_tag[:4]}-{l8_tag[4:6]}-{l8_tag[6:]}",
            "s2_date": f"{info['s2'][:4]}-{info['s2'][4:6]}-{info['s2'][6:]}",
            "calendar_gap_days": info["gap_days"],
            "retained_segments": len(retained),
            "excluded_segments": len(excluded),
            "retained_length_km": retained_length / 1000,
            "total_draft_length_km": total_length / 1000,
            "retained_length_fraction": retained_length / total_length,
            "spatial_coverage": sector_coverage(retained, target_crs),
            "retained_reference": {
                "path": str(retained_path.relative_to(ROOT)),
                "sha256": sha256(retained_path),
            },
            "excluded_reference": {
                "path": str(excluded_path.relative_to(ROOT)),
                "sha256": sha256(excluded_path),
            },
            "masks": [s2_mask, l8_mask],
        })

    manifest = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "dataset": "Fuxian Lake conservative pilot test shoreline reference v0.1",
        "status": "FROZEN_FOR_ONE_TIME_PILOT_EVALUATION",
        "scope": "Two conditionally accepted 2025 dates only",
        "reviewer": "Codex-assisted visual interpretation",
        "independent_second_reviewer": False,
        "ground_truth_claim": False,
        "allow_training": False,
        "allow_model_selection": False,
        "allow_one_time_pilot_test_evaluation": True,
        "exclusion_policy": "Exclude every high-priority segment unless explicitly passed in the 24-site compact review; buffer excluded lines by 30 m on each native grid.",
        "limitations": [
            "The references are automatic Sentinel-2 drafts screened by visual review, not independent ground truth.",
            "The 2025-05-07 Landsat scene uses a Sentinel-2 reference acquired two days earlier.",
            "Only two dates qualify; final SCI testing requires at least two additional clear independent dates.",
            "Metrics must report retained shoreline coverage and must not be used for further tuning or model selection.",
        ],
        "records": records,
    }
    manifest_path = OUT / "pilot_test_reference_manifest.json"
    write_json(manifest_path, manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
