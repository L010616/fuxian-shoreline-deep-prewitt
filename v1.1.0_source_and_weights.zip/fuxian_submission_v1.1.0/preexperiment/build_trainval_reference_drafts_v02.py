"""Generate corrected prior-anchored reference drafts for train/validation dates."""
from __future__ import annotations

import json
from pathlib import Path

import build_wave1_reference_drafts as builder


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/formal_trainval_drafts_v02"
MANIFEST = ROOT / "preexperiment/results/pilot_manifest_paired.json"


def main() -> None:
    builder.OUT = OUT
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads(MANIFEST.read_text(encoding="utf-8"))["records"]
    selected = [record for record in records if record["split"] in {"train", "validation"}]
    results = [builder.build_one(record) for record in selected]
    summary = {
        "dataset": "Fuxian train-validation automatic shoreline drafts v0.2",
        "method": "fixed prior interior plus S2 NDWI decisions restricted to the shore band",
        "status": "AUTOMATIC_DRAFTS_REQUIRE_FINAL_REFERENCE_REVIEW",
        "purpose": "corrected development labels; not final paper accuracy",
        "allow_final_paper_claims": False,
        "test_inputs_opened_after_model_freeze_v01": True,
        "split_counts": {
            "train": sum(record["split"] == "train" for record in results),
            "validation": sum(record["split"] == "validation" for record in results),
        },
        "records": results,
    }
    (OUT / "trainval_draft_summary_v02.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"dates": len(results), "output": str(OUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
