"""Make prediction-blind RGB contact sheets for external-lake image review."""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw, ImageFont, ImageOps
from rasterio.enums import Resampling


ROOT = Path(__file__).resolve().parent.parent
SOURCES = [ROOT / "跨湖测试",
           ROOT / "drive-download-20260923T094631Z-1-001",
           ROOT / "drive-download-20260923T095357Z-1-001",
           ROOT / "drive-download-20260923T110142Z-1-001",
           ROOT / "drive-download-20260923T112403Z-1-001",
           ROOT / "drive-download-20260923T124126Z-1-001"]
OUT = ROOT / "preexperiment" / "results" / "q2_external"


def find(lake: str, l8_day: str, s2_day: str, kind: str) -> Path:
    name = f"Q2_FAST_{lake}_{l8_day}_{s2_day}_{kind}.tif"
    matches = [p for source in SOURCES for p in source.rglob(name)]
    if not matches and kind == "L8":
        matches = [p for source in SOURCES for p in source.rglob(
            f"Q2_FAST_{lake}_{l8_day}_*_L8.tif")]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one {name}, found {len(matches)}")
    return matches[0]


def rgb(path: Path, kind: str, size=(340, 300)) -> Image.Image:
    with rasterio.open(path) as ds:
        scale = min(size[0] / ds.width, size[1] / ds.height)
        width, height = max(1, round(ds.width * scale)), max(1, round(ds.height * scale))
        a = ds.read([3, 2, 1], out_shape=(3, height, width),
                    resampling=Resampling.bilinear).astype("float32")
        m = ds.read_masks(1, out_shape=(height, width),
                          resampling=Resampling.nearest) > 0
    if kind == "L8":
        a = np.clip((a - 0.01) / 0.20, 0, 1) ** 0.8
    else:
        a = np.clip((a - 100) / 3200, 0, 1) ** 0.8
    out = (np.nan_to_num(a.transpose(1, 2, 0)) * 255).astype("uint8")
    out[~m] = (232, 221, 230)
    im = Image.fromarray(out)
    return ImageOps.pad(im, size, color=(248, 248, 248))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "candidate_qc.csv").open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)
    small = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 15)
    for lake in sorted({r["lake"] for r in rows}):
        subset = [r for r in rows if r["lake"] == lake]
        canvas = Image.new("RGB", (720, 375 * len(subset) + 55), "white")
        draw = ImageDraw.Draw(canvas)
        draw.text((12, 14), lake + " | prediction-blind image QC", font=font,
                  fill=(35, 35, 45))
        for i, row in enumerate(subset):
            top = 55 + i * 375
            l8 = rgb(find(lake, row["l8_date"], row["s2_date"], "L8"), "L8")
            s2 = rgb(find(lake, row["l8_date"], row["s2_date"], "S2"), "S2")
            canvas.paste(l8, (10, top + 36))
            canvas.paste(s2, (370, top + 36))
            status = "PASS" if row["preliminary_quality_pass"] == "True" else "REJECT"
            color = (40, 115, 75) if status == "PASS" else (180, 70, 65)
            draw.text((12, top + 5),
                      f"L8 {row['l8_date']} | S2 {row['s2_date']} | {status}",
                      font=small, fill=color)
            draw.text((15, top + 343),
                      f"L8 RGB | shore valid {float(row['l8_valid_shore']):.0%}",
                      font=small, fill=(40, 40, 50))
            draw.text((375, top + 343),
                      f"S2 RGB | lake coverage {float(row['s2_foot_lake']):.0%}",
                      font=small, fill=(40, 40, 50))
        canvas.save(OUT / f"{lake}_rgb_contact_sheet.png")
        print(OUT / f"{lake}_rgb_contact_sheet.png")


if __name__ == "__main__":
    main()
