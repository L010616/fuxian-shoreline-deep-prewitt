"""Sensitivity test using the unreviewed S2 drafts on all six blind dates.

The experiment keeps sensor preprocessing and joint-valid masks, but removes
the manually screened shoreline exclusion masks. Frozen checkpoints and the
0.5 threshold are reused without tuning. Results are sensitivity diagnostics,
not accuracy against surveyed ground truth.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
import torch

import run_multidate_ablation_pilot as ablation
import run_round4_fusion_confirmation as fusion
import run_round4_remaining_models as remaining
from evaluate_extended_boundary_support import metric as boundary_metric
from run_multidate_ablation_pilot import predict
from run_quick_model_pilot import metrics as area_metrics


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "results" / "round4_final_blind"
CONF = ROOT / "preexperiment" / "results" / "round4_fusion_confirmation"
REM = ROOT / "preexperiment" / "results" / "round4_remaining_models"
OUT = ROOT / "preexperiment" / "results" / "unscreened_reference_sensitivity"
SEEDS = (20260913, 20260929, 20261017)
MODELS = (
    "unet_resnet18",
    "deeplabv3plus_resnet18",
    "segformer_mit_b0",
    "dfanet",
    "prior",
)
LABELS = {
    "unet_resnet18": "U-Net",
    "deeplabv3plus_resnet18": "DeepLabV3+",
    "segformer_mit_b0": "SegFormer-B0",
    "dfanet": "Compact DFANet",
    "prior": "Spatial prior",
}
KEYS = (
    "precision", "recall", "f1", "iou", "boundary_f1_30m",
    "boundary_f1_60m", "mean_symmetric_boundary_distance_m", "hd95_m",
)


def prepare(scenes, normalization):
    for scene in scenes:
        scene["x"] = np.empty_like(scene["x_raw"], dtype="float32")
        for band, stat in enumerate(normalization):
            scene["x"][band] = (
                np.clip(scene["x_raw"][band], stat["p01"], stat["p99"])
                - stat["mean"]
            ) / stat["std"]
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        # Deliberately do not apply screened_reference/*/exclusion_mask_L8_30m.tif.


def evaluate(probability, scene):
    valid = scene["valid"]
    shore = valid & scene["shore"]
    return {
        **area_metrics(probability, scene["y"], valid, shore),
        **boundary_metric(probability, scene["y"], valid, scene["shore"]),
        "valid_pixels": int(valid.sum()),
        "valid_shore_pixels": int(shore.sum()),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    dates = [
        {"l8_date": row["l8_date"], "s2_date": row["s2_date"], "split": "final_blind_test"}
        for row in json.loads((BASE / "evaluation_pairs.json").read_text(encoding="utf-8"))["selected"]
    ]
    ablation.DRAFTS = BASE / "reference_drafts"
    scenes = [ablation.read_scene(record) for record in dates]
    normalization = json.loads((CONF / "fusion_confirmation_results.json").read_text(
        encoding="utf-8"))["normalization"]
    prepare(scenes, normalization)
    ordinary = remaining.model_factories()
    factories = {
        "unet_resnet18": ordinary["unet_resnet18"],
        "deeplabv3plus_resnet18": ordinary["deeplabv3plus_resnet18"],
        "segformer_mit_b0": ordinary["segformer_mit_b0"],
        "dfanet": ordinary["dfanet"],
        "prior": fusion.CONFIGS["prior"][0],
    }
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    raw = {}
    rows = []
    for name in MODELS:
        raw[name] = {}
        model_dir = CONF if name == "prior" else REM
        for seed in SEEDS:
            model = factories[name]().to(device)
            checkpoint = torch.load(model_dir / f"{name}_seed{seed}_best.pt",
                                    map_location=device, weights_only=False)
            model.load_state_dict(checkpoint["model"])
            per_date = {}
            for scene in scenes:
                day = scene["record"]["l8_date"]
                values = evaluate(predict(model, scene, device), scene)
                per_date[day] = values
                rows.append({"model": LABELS[name], "config_key": name,
                             "seed": seed, "date": day, **{key: values[key] for key in KEYS},
                             "valid_pixels": values["valid_pixels"],
                             "valid_shore_pixels": values["valid_shore_pixels"]})
            raw[name][str(seed)] = {"checkpoint_epoch": int(checkpoint["epoch"]),
                                    "per_date": per_date}
            print("completed", name, seed, flush=True)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    date_means = []
    for name in MODELS:
        for day in [record["l8_date"] for record in dates]:
            group = [row for row in rows if row["config_key"] == name and row["date"] == day]
            date_means.append({"model": LABELS[name], "config_key": name, "date": day,
                               **{key: float(np.mean([row[key] for row in group])) for key in KEYS}})
    summary = []
    for name in MODELS:
        group = [row for row in date_means if row["config_key"] == name]
        summary.append({
            "model": LABELS[name], "config_key": name, "n_dates": len(group),
            **{f"{key}_mean": float(np.mean([row[key] for row in group])) for key in KEYS},
            **{f"{key}_date_sd": float(np.std([row[key] for row in group], ddof=1)) for key in KEYS},
        })

    for filename, data in (("per_seed_date.csv", rows),
                           ("per_date_seed_mean.csv", date_means),
                           ("unscreened_summary.csv", summary)):
        with (OUT / filename).open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    payload = {
        "status": "POST_HOC_UNSCREENED_REFERENCE_SENSITIVITY_NOT_SURVEYED_ACCURACY",
        "dates": [record["l8_date"] for record in dates],
        "models": list(MODELS), "seeds": list(SEEDS), "decision_threshold": 0.5,
        "sensor_preprocessing_retained": True,
        "joint_valid_mask_retained": True,
        "manual_low_confidence_segment_exclusion_applied": False,
        "reference": "Unreviewed Sentinel-2 NDWI connected-water draft",
        "training_or_model_selection_after_test": False,
        "device": str(device), "results": raw, "summary": summary,
    }
    (OUT / "results.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
