"""Generate conservative morphology-based redraw candidates for 104 and 107.

Candidates preserve each draft segment's endpoints, remove narrow non-water
intrusions with a 20 m closing operation, and remain explicitly unapproved.
"""

from __future__ import annotations

import json
import hashlib
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image, ImageDraw
from rasterio.warp import transform_geom
from rasterio.windows import from_bounds
from scipy.spatial.distance import cdist
from skimage.measure import find_contours
from skimage.morphology import closing, disk


ROOT = Path(__file__).resolve().parents[1]
ANN = ROOT / "preexperiment/results/native_20200102/annotation_workspace"
OUT = ANN / "ge_corrections"
RASTER = ANN / "S2_NDWI_diagnostic.tif"
IDS = ("S2_DRAFT_104", "S2_DRAFT_107")
THRESHOLD = 0.13653606176376343


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rdp(points: np.ndarray, epsilon: float) -> np.ndarray:
    if len(points) < 3:
        return points
    start, end = points[0], points[-1]
    chord = end - start
    denom = np.dot(chord, chord)
    if denom == 0:
        distances = np.linalg.norm(points - start, axis=1)
    else:
        t = np.clip(((points - start) @ chord) / denom, 0, 1)
        proj = start + t[:, None] * chord
        distances = np.linalg.norm(points - proj, axis=1)
    idx = int(np.argmax(distances))
    if distances[idx] <= epsilon:
        return np.vstack([start, end])
    return np.vstack([rdp(points[: idx + 1], epsilon)[:-1], rdp(points[idx:], epsilon)])


def contour_xy(contour: np.ndarray, transform) -> np.ndarray:
    rows, cols = contour[:, 0], contour[:, 1]
    xs = transform.c + (cols + 0.5) * transform.a + (rows + 0.5) * transform.b
    ys = transform.f + (cols + 0.5) * transform.d + (rows + 0.5) * transform.e
    return np.column_stack([xs, ys])


def choose_path(contours: list[np.ndarray], original: np.ndarray) -> np.ndarray:
    candidates = []
    for line in contours:
        if len(line) < 5:
            continue
        d0 = np.linalg.norm(line - original[0], axis=1)
        d1 = np.linalg.norm(line - original[-1], axis=1)
        i, j = int(np.argmin(d0)), int(np.argmin(d1))
        endpoint_error = float(d0[i] + d1[j])
        if endpoint_error > 100:
            continue
        lo, hi = sorted((i, j))
        direct = line[lo : hi + 1]
        if i > j:
            direct = direct[::-1]
        paths = [direct]
        closed = np.linalg.norm(line[0] - line[-1]) <= 15
        if closed:
            wrap = np.vstack([line[hi:], line[: lo + 1]])
            if i < j:
                wrap = wrap[::-1]
            paths.append(wrap)
        for path in paths:
            if len(path) < 2:
                continue
            length = float(np.linalg.norm(np.diff(path, axis=0), axis=1).sum())
            proximity = float(cdist(path, original).min(axis=1).mean())
            # Shorter endpoint-to-endpoint route is favoured; proximity prevents
            # selection of an unrelated crop-edge contour.
            score = endpoint_error * 4 + proximity + length * 0.02
            candidates.append((score, path))
    if not candidates:
        raise RuntimeError("No main-water contour connects both segment endpoints")
    return min(candidates, key=lambda item: item[0])[1]


def draw_overlay(ndwi: np.ndarray, original: np.ndarray, candidate: np.ndarray, transform, path: Path) -> None:
    norm = np.nan_to_num(np.clip((ndwi + 0.5) / 1.0, 0, 1), nan=0.0)
    rgb = np.dstack([160 * (1 - norm) + 30, 110 + 100 * norm, 60 + 180 * norm]).astype(np.uint8)
    scale = 6
    image = Image.fromarray(rgb).resize((rgb.shape[1] * scale, rgb.shape[0] * scale), Image.Resampling.NEAREST)
    draw = ImageDraw.Draw(image)

    def pixel_points(coords):
        inv = ~transform
        return [tuple(float(v) * scale for v in inv * (float(x), float(y))) for x, y in coords]

    draw.line(pixel_points(original), fill=(0, 255, 255), width=3)
    draw.line(pixel_points(candidate), fill=(255, 255, 0), width=4)
    image.save(path)


def main() -> None:
    draft = json.loads((ANN / "initial_draft.json").read_text(encoding="utf-8"))
    segments = {s["id"]: s for s in draft["segments"]}
    features = []
    records = []
    candidates_utm = {}

    with rasterio.open(RASTER) as src:
        for sid in IDS:
            original = np.asarray(segments[sid]["coordinates"], dtype=float)
            minx, miny = original.min(axis=0) - 120
            maxx, maxy = original.max(axis=0) + 120
            window = from_bounds(minx, miny, maxx, maxy, src.transform).round_offsets().round_lengths()
            ndwi = src.read(1, window=window)
            transform = src.window_transform(window)
            water = np.isfinite(ndwi) & (ndwi > THRESHOLD)
            water_simplified = closing(water, disk(2))
            contours = [contour_xy(c, transform) for c in find_contours(water_simplified.astype(np.uint8), 0.5)]
            candidate = choose_path(contours, original)
            candidate[0] = original[0]
            candidate[-1] = original[-1]
            candidates_utm[sid] = candidate.tolist()
            candidate = rdp(candidate, 4.0)
            candidate[0] = original[0]
            candidate[-1] = original[-1]

            original_length = float(np.linalg.norm(np.diff(original, axis=0), axis=1).sum())
            candidate_length = float(np.linalg.norm(np.diff(candidate, axis=0), axis=1).sum())
            geom = {"type": "LineString", "coordinates": candidate.tolist()}
            features.append(
                {
                    "type": "Feature",
                    "geometry": transform_geom("EPSG:32648", "EPSG:4326", geom, precision=8),
                    "properties": {
                        "segment_id": sid,
                        "status": "AI_ASSISTED_REDRAW_CANDIDATE_UNAPPROVED",
                        "allow_training": False,
                        "method": "S2_NDWI_OTSU_PLUS_20M_WATER_CLOSING",
                        "otsu_threshold": THRESHOLD,
                        "morphology_radius_m": 20,
                        "endpoints_preserved": True,
                        "original_length_m": original_length,
                        "candidate_length_m": candidate_length,
                    },
                }
            )
            panel = OUT / "redraw_panels" / f"{sid}_candidate_overlay.png"
            draw_overlay(ndwi, original, candidate, transform, panel)
            records.append(
                {
                    "segment_id": sid,
                    "original_vertices": len(original),
                    "candidate_vertices": len(candidate),
                    "original_length_m": original_length,
                    "candidate_length_m": candidate_length,
                    "overlay": str(panel.relative_to(OUT)),
                }
            )

    collection = {
        "type": "FeatureCollection",
        "name": "redraw_candidates_104_107_UNAPPROVED",
        "status": "AI_ASSISTED_REDRAW_CANDIDATE_UNAPPROVED",
        "allow_training": False,
        "features": features,
    }
    candidate_path = OUT / "redraw_candidates_104_107_UNAPPROVED.geojson"
    candidate_path.write_text(
        json.dumps(collection, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    corrected_features = []
    for segment in draft["segments"]:
        sid = segment["id"]
        if sid in {"S2_DRAFT_185", "S2_DRAFT_186", "S2_DRAFT_187"}:
            continue
        coords = candidates_utm.get(sid, segment["coordinates"])
        geom = {"type": "LineString", "coordinates": coords}
        props = dict(segment.get("properties", {}))
        props.update({"segment_id": sid, "dataset_status": "DRAFT", "allow_training": False})
        if sid in candidates_utm:
            props.update(
                {
                    "review_status": "AI_REVIEWED_PILOT_REDRAW_UNAPPROVED",
                    "redraw_method": "S2_NDWI_OTSU_PLUS_20M_WATER_CLOSING",
                    "google_earth_role": "AUXILIARY_OBJECT_SCREENING_ONLY",
                }
            )
        corrected_features.append(
            {
                "type": "Feature",
                "geometry": transform_geom("EPSG:32648", "EPSG:4326", geom, precision=8),
                "properties": props,
            }
        )
    corrected = {
        "type": "FeatureCollection",
        "name": "shoreline_ge_corrected_DRAFT",
        "scene_date": "2020-01-02",
        "status": "DRAFT",
        "allow_training": False,
        "correction_summary": "Segments 185-187 removed; 104 and 107 replaced by morphology-assisted candidates.",
        "features": corrected_features,
    }
    corrected_path = OUT / "shoreline_ge_corrected_DRAFT.geojson"
    corrected_path.write_text(
        json.dumps(corrected, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    metrics_path = OUT / "redraw_candidates_104_107_metrics.json"
    metrics_path.write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    manifest_path = OUT / "ge_correction_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["outputs"]["redraw_candidates"] = {
        "path": candidate_path.name,
        "feature_count": len(features),
        "status": "UNAPPROVED",
        "sha256": sha256(candidate_path),
    }
    manifest["outputs"]["corrected_pilot_draft"] = {
        "path": corrected_path.name,
        "feature_count": len(corrected_features),
        "status": "DRAFT",
        "allow_training": False,
        "sha256": sha256(corrected_path),
    }
    manifest["outputs"]["redraw_metrics"] = {
        "path": metrics_path.name,
        "sha256": sha256(metrics_path),
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
