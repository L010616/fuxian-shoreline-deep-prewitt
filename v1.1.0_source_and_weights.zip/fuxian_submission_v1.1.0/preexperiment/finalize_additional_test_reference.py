"""Freeze conservative references for the two additional test dates.

Every high-priority automatic segment is excluded. Normal-priority segments
are retained only after each full-date overview is marked PASS in the review
record. These labels are screened pilot references, not independent truth.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import transform, transform_geom
from scipy import ndimage as ndi


ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT
DRAFT_ROOT = ROOT / "preexperiment/results/formal_test_drafts_v03_additional"
REVIEW = DRAFT_ROOT / "additional_date_level_review.json"
OUT = DRAFT_ROOT / "screened_reference_v01"
MANIFEST = ROOT / "preexperiment/results/additional_test_pairs_v01.json"
BUFFER_M = 30.0
L8_TEMPLATE = "Fuxian_L8_native_{l8_tag}.tif"
S2_TEMPLATE = "Fuxian_S2_{s2_tag}.tif"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def rasterize_exclusions(lines, reference: Path, output: Path) -> dict:
    with rasterio.open(reference) as src:
        profile = src.profile.copy()
        projected = [transform_geom("EPSG:4326", src.crs, geom) for geom in lines]
        line_mask = rasterize(
            [(geom, 1) for geom in projected], out_shape=(src.height, src.width),
            transform=src.transform, fill=0, dtype="uint8", all_touched=True,
        ) if projected else np.zeros((src.height, src.width), dtype="uint8")
        iterations = max(1, int(np.ceil(BUFFER_M / abs(src.transform.a))))
        mask = ndi.binary_dilation(line_mask.astype(bool), iterations=iterations).astype("uint8")
    profile.update(count=1, dtype="uint8", nodata=255, compress="deflate")
    with rasterio.open(output, "w", **profile) as dst:
        dst.write(mask, 1)
        dst.set_band_description(1, "screened_reference_exclusion_mask_1_excluded")
    return {"path": str(output.relative_to(ROOT)), "excluded_pixels": int(mask.sum()), "sha256": sha256(output)}


def sector_coverage(features, target_crs) -> dict:
    points = []
    for feature in features:
        coords = np.asarray(feature["geometry"]["coordinates"], dtype="float64")
        xs, ys = transform("EPSG:4326", target_crs, coords[:, 0].tolist(), coords[:, 1].tolist())
        points.append(np.column_stack([xs, ys]))
    if not points:
        return {"occupied_12_sectors": 0, "sector_ids": []}
    coords = np.vstack(points)
    center = coords.mean(axis=0)
    angles = (np.degrees(np.arctan2(coords[:, 1] - center[1], coords[:, 0] - center[0])) + 360) % 360
    sectors = sorted(set((angles // 30).astype(int).tolist()))
    return {"occupied_12_sectors": len(sectors), "sector_ids": sectors}


def main() -> None:
    reviews = json.loads(REVIEW.read_text(encoding="utf-8"))
    if reviews.get("status") != "DATE_OVERVIEWS_REVIEWED":
        raise RuntimeError("Date-level overview review has not been completed")
    decisions = {row["l8_date"]: row for row in reviews["records"]}
    selected = json.loads(MANIFEST.read_text(encoding="utf-8"))["selected"]
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    for source in selected:
        if not decisions.get(source["l8_date"], {}).get("accept", False):
            raise RuntimeError(f"Date not accepted by overview review: {source['l8_date']}")
        l8_tag = source["l8_date"].replace("-", "")
        s2_tag = source["s2_date"].replace("-", "")
        date_out = OUT / l8_tag
        date_out.mkdir(exist_ok=True)
        draft = json.loads((DRAFT_ROOT / l8_tag / "shoreline_DRAFT.geojson").read_text(encoding="utf-8"))
        retained, excluded, excluded_lines = [], [], []
        for feature in draft["features"]:
            keep = feature["properties"]["review_priority"] == "NORMAL"
            copied = json.loads(json.dumps(feature))
            copied["properties"].update({
                "screened_decision": "RETAIN" if keep else "EXCLUDE",
                "screened_basis": "DATE_OVERVIEW_PLUS_NORMAL_PRIORITY" if keep else "AUTOMATIC_HIGH_PRIORITY_CONSERVATIVE_EXCLUDE",
                "reference_status": "SCREENED_NOT_INDEPENDENT_GROUND_TRUTH",
                "allow_training": False,
            })
            (retained if keep else excluded).append(copied)
            if not keep:
                excluded_lines.append(feature["geometry"])
        retained_path = date_out / "shoreline_reference_SCREENED.geojson"
        excluded_path = date_out / "excluded_segments.geojson"
        write_json(retained_path, {"type": "FeatureCollection", "features": retained})
        write_json(excluded_path, {"type": "FeatureCollection", "features": excluded})
        s2_path = DATA_ROOT / S2_TEMPLATE.format(l8_tag=l8_tag, s2_tag=s2_tag)
        l8_path = DATA_ROOT / L8_TEMPLATE.format(l8_tag=l8_tag, s2_tag=s2_tag)
        with rasterio.open(s2_path) as src:
            target_crs = src.crs
        masks = [
            rasterize_exclusions(excluded_lines, s2_path, date_out / "exclusion_mask_S2_10m.tif"),
            rasterize_exclusions(excluded_lines, l8_path, date_out / "exclusion_mask_L8_30m.tif"),
        ]
        retained_length = sum(float(f["properties"]["length_m"]) for f in retained)
        total_length = retained_length + sum(float(f["properties"]["length_m"]) for f in excluded)
        records.append({
            "l8_date": source["l8_date"], "s2_date": source["s2_date"],
            "calendar_gap_days": source["calendar_gap_days"],
            "retained_segments": len(retained), "excluded_segments": len(excluded),
            "retained_length_km": retained_length / 1000,
            "total_draft_length_km": total_length / 1000,
            "retained_length_fraction": retained_length / total_length,
            "spatial_coverage": sector_coverage(retained, target_crs),
            "retained_reference": {"path": str(retained_path.relative_to(ROOT)), "sha256": sha256(retained_path)},
            "excluded_reference": {"path": str(excluded_path.relative_to(ROOT)), "sha256": sha256(excluded_path)},
            "masks": masks,
        })
    output = {
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "dataset": "Fuxian Lake additional conservative screened test reference v0.1",
        "status": "FROZEN_FOR_ONE_TIME_ADDITIONAL_EVALUATION",
        "ground_truth_claim": False, "allow_training": False, "allow_model_selection": False,
        "allow_one_time_evaluation": True,
        "reviewer": "Codex-assisted full-date visual screening",
        "independent_second_reviewer": False,
        "exclusion_policy": "Exclude every high-priority segment and buffer excluded lines by 30 m on both native grids.",
        "records": records,
    }
    write_json(OUT / "screened_reference_manifest.json", output)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
