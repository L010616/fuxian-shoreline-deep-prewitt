"""Combine the two locked test waves into manuscript-ready four-date outputs."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "preexperiment/results/locked_pilot_test_v01/pilot_test_results.json"
NEW = ROOT / "preexperiment/results/locked_additional_test_v01/additional_test_results.json"
OUT = ROOT / "preexperiment/manuscript_ready/final_test"
METRICS = ["precision", "recall", "f1", "iou", "boundary_f1_30m", "boundary_f1_60m", "mean_symmetric_boundary_distance_m"]


def stats(values):
    arr = np.asarray(values, dtype=float)
    return {"mean": float(arr.mean()), "std": float(arr.std(ddof=1)), "values": arr.tolist()}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    old = json.loads(OLD.read_text(encoding="utf-8"))
    new = json.loads(NEW.read_text(encoding="utf-8"))
    seeds = old["seeds"]
    if seeds != new["seeds"]:
        raise RuntimeError("Seed sets differ between locked test waves")
    waves = [old["results_by_seed"], new["results_by_seed"]]
    per_seed = {}
    all_dates = []
    for seed in seeds:
        combined = {}
        for wave in waves:
            overlap = set(combined) & set(wave[str(seed)]["per_date"])
            if overlap:
                raise RuntimeError(f"Duplicate dates: {sorted(overlap)}")
            combined.update(wave[str(seed)]["per_date"])
        if not all_dates:
            all_dates = sorted(combined)
        per_seed[str(seed)] = {
            "per_date": combined,
            "raw_macro": {m: float(np.mean([combined[d]["raw"][m] for d in all_dates])) for m in METRICS},
            "common_constraint_macro": {m: float(np.mean([combined[d]["common_constraint"][m] for d in all_dates])) for m in METRICS},
        }
    summary = {}
    for mode in ("raw_macro", "common_constraint_macro"):
        summary[mode] = {m: stats([per_seed[str(seed)][mode][m] for seed in seeds]) for m in METRICS}
    per_date_summary = {}
    for date in all_dates:
        per_date_summary[date] = {}
        for mode in ("raw", "common_constraint"):
            per_date_summary[date][mode] = {
                m: stats([per_seed[str(seed)]["per_date"][date][mode][m] for seed in seeds]) for m in METRICS
            }
    package = {
        "status": "FOUR_DATE_LOCKED_TEST_COMBINED_WITHOUT_RERUNNING_MODELS",
        "model": "frozen parallel LoG-Prewitt DFANet v0.2",
        "dates": all_dates, "seeds": seeds, "date_count": len(all_dates),
        "combination_rule": "Macro-average the four per-date metrics within each seed, then report mean and sample SD across the three frozen seeds.",
        "summary": summary, "per_date_summary": per_date_summary,
        "reference_status": "Conservatively screened Sentinel-2 references; not independent surveyed ground truth",
    }
    (OUT / "four_date_test_results.json").write_text(json.dumps(package, ensure_ascii=False, indent=2), encoding="utf-8")

    with (OUT / "table_four_date_overall.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["mode", "metric", "mean", "std", "n_dates", "n_seeds"])
        for mode, cells in summary.items():
            for metric, cell in cells.items():
                writer.writerow([mode, metric, cell["mean"], cell["std"], len(all_dates), len(seeds)])
    with (OUT / "table_four_date_per_date.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["date", "mode", "metric", "mean", "std", "n_seeds"])
        for date in all_dates:
            for mode, cells in per_date_summary[date].items():
                for metric, cell in cells.items():
                    writer.writerow([date, mode, metric, cell["mean"], cell["std"], len(seeds)])

    render_per_date(per_date_summary, all_dates)
    report = make_report(package)
    (OUT / "四期封存测试结果说明.md").write_text(report, encoding="utf-8")
    print(json.dumps({"output": str(OUT), "dates": all_dates, "raw_macro": summary["raw_macro"]}, ensure_ascii=False, indent=2))


def render_per_date(data, dates):
    width, height = 1800, 820
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    regular = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 34)
    small = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 29)
    bold = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 38)
    panels = [("boundary_f1_30m", "Boundary F1 (30 m)", 0.88, 1.0),
              ("mean_symmetric_boundary_distance_m", "Mean boundary distance (m)", 0, 95)]
    colors = ["#377eb8", "#e41a1c", "#4daf4a", "#984ea3"]
    for p, (metric, title, ymin, ymax) in enumerate(panels):
        left = 110 + p * 875; right = left + 735; top = 85; bottom = 600
        for tick in range(6):
            frac = tick / 5; y = bottom - frac * (bottom - top); val = ymin + frac * (ymax - ymin)
            draw.line((left, y, right, y), fill="#dddddd", width=2)
            label = f"{val:.3f}" if ymax == 1 else f"{val:.0f}"
            box = draw.textbbox((0, 0), label, font=small); draw.text((left - 15 - (box[2]-box[0]), y-16), label, fill="#222222", font=small)
        draw.line((left, top, left, bottom), fill="#111111", width=3); draw.line((left, bottom, right, bottom), fill="#111111", width=3)
        slot = (right-left)/len(dates)
        for i, date in enumerate(dates):
            cell = data[date]["raw"][metric]; mean, std = cell["mean"], cell["std"]
            cx = left + slot*(i+0.5); y = bottom-(mean-ymin)/(ymax-ymin)*(bottom-top)
            draw.rectangle((cx-slot*.28, y, cx+slot*.28, bottom), fill=colors[i], outline="#111111", width=2)
            y1 = bottom-(mean+std-ymin)/(ymax-ymin)*(bottom-top); y2 = bottom-(mean-std-ymin)/(ymax-ymin)*(bottom-top)
            draw.line((cx,y1,cx,y2), fill="#111111", width=3); draw.line((cx-12,y1,cx+12,y1), fill="#111111", width=3); draw.line((cx-12,y2,cx+12,y2), fill="#111111", width=3)
            val = f"{mean:.3f}" if ymax == 1 else f"{mean:.1f}"; box=draw.textbbox((0,0),val,font=small); draw.text((cx-(box[2]-box[0])/2,max(top,y1-38)),val,fill="#111111",font=small)
            box=draw.textbbox((0,0),date,font=small); draw.text((cx-(box[2]-box[0])/2,bottom+24),date,fill="#111111",font=small)
        box=draw.textbbox((0,0),title,font=bold); draw.text(((left+right)/2-(box[2]-box[0])/2,18),title,fill="#111111",font=bold)
        draw.text((left,bottom+96),"Mean ± SD across three frozen seeds",fill="#333333",font=regular)
    image.save(OUT / "figure_four_date_boundary_performance.png", dpi=(600,600), optimize=True)
    image.save(OUT / "figure_four_date_boundary_performance.pdf", "PDF", resolution=600)


def make_report(package):
    s = package["summary"]["raw_macro"]
    def pm(name, digits=4):
        return f"{s[name]['mean']:.{digits}f} ± {s[name]['std']:.{digits}f}"
    rows = []
    for date, modes in package["per_date_summary"].items():
        raw=modes["raw"]
        rows.append(f"| {date} | {raw['iou']['mean']:.4f} ± {raw['iou']['std']:.4f} | {raw['boundary_f1_30m']['mean']:.4f} ± {raw['boundary_f1_30m']['std']:.4f} | {raw['mean_symmetric_boundary_distance_m']['mean']:.2f} ± {raw['mean_symmetric_boundary_distance_m']['std']:.2f} |")
    return "\n".join([
        "# 四期封存测试结果说明", "", f"测试日期：{', '.join(package['dates'])}。三个随机种子均使用训练阶段已冻结的并联 LoG-Prewitt DFANet 权重，未重新训练或调参。", "",
        f"四期宏平均原始输出为：IoU {pm('iou')}，Boundary F1（30 m）{pm('boundary_f1_30m')}，Boundary F1（60 m）{pm('boundary_f1_60m')}，平均对称岸线距离 {pm('mean_symmetric_boundary_distance_m',2)} m。", "",
        "| 日期 | IoU | Boundary F1 (30 m) | 平均岸线距离 (m) |", "|---|---:|---:|---:|", *rows, "",
        "统计口径：先在每个随机种子内对四个日期作宏平均，再对三个种子报告均值和样本标准差。参考岸线来自 Sentinel-2 自动草稿和保守筛查，低置信度岸段已从评价中排除。", "",
        "论文表述限制：这些结果可作为当前实验稿的封存测试结果，但参考岸线不能写成独立测量真值。投稿前建议由第二位人工审阅者对保留岸段抽查并签字确认。", ""
    ])


if __name__ == "__main__": main()
