"""Plot deterministic three-seed ablation results with sample-SD error bars."""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "preexperiment/results/ablation_3seed_v02_corrected_labels"
SUMMARY = OUT / "summary_mean_std.json"
FIGURE = OUT / "deterministic_ablation_3seed_corrected_labels.png"


def main() -> None:
    data = json.loads(SUMMARY.read_text(encoding="utf-8"))
    order = ["dfanet", "prior", "log", "prewitt", "parallel"]
    labels = ["DFANet", "Prior", "Prior+LoG", "Prior+Prewitt", "Parallel"]
    colors = ["#718096", "#3182A0", "#7A9E45", "#D69E2E", "#B54755"]
    panels = [
        ("Raw IoU", "iou", True, 4),
        ("Boundary F1 (30 m)", "boundary_f1_30m", True, 4),
        ("Mean boundary distance (m)", "mean_symmetric_boundary_distance_m", False, 2),
    ]

    canvas = Image.new("RGB", (2040, 760), "white")
    draw = ImageDraw.Draw(canvas)
    title_font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 34)
    panel_font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 25)
    text_font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 17)
    small_font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 15)
    draw.text((1020, 24), "Deterministic three-seed ablation on independent validation dates",
              fill="#172738", font=title_font, anchor="ma")

    for panel_index, (title, key, zoom, decimals) in enumerate(panels):
        values = [data[name]["raw"][key]["mean"] for name in order]
        stds = [data[name]["raw"][key]["std"] for name in order]
        x0, y0, width, height = panel_index * 680 + 72, 118, 550, 475
        draw.text((x0 + width / 2, 78), title, fill="#172738", font=panel_font, anchor="ma")
        if zoom:
            spread = max(values) - min(values)
            padding = max(0.0015, spread * 0.35)
            low = min(v - s for v, s in zip(values, stds)) - padding
            high = max(v + s for v, s in zip(values, stds)) + padding * 0.55
        else:
            low = 0.0
            high = max(v + s for v, s in zip(values, stds)) * 1.12

        for tick in range(5):
            y = y0 + height - tick * height / 4
            value = low + tick * (high - low) / 4
            draw.line((x0, y, x0 + width, y), fill="#D9E0E5", width=1)
            tick_label = f"{value:.3f}" if zoom else f"{value:.1f}"
            draw.text((x0 - 8, y), tick_label, fill="#52616B", font=text_font, anchor="rm")

        bar_width, gap, start = 78, 28, x0 + 15
        for index, (label, value, std, color) in enumerate(zip(labels, values, stds, colors)):
            left = start + index * (bar_width + gap)
            top = y0 + height - (value - low) / (high - low) * height
            draw.rectangle((left, top, left + bar_width, y0 + height), fill=color)
            center = left + bar_width / 2
            error_top = y0 + height - (value + std - low) / (high - low) * height
            error_bottom = y0 + height - (value - std - low) / (high - low) * height
            draw.line((center, error_top, center, error_bottom), fill="#172738", width=3)
            draw.line((center - 8, error_top, center + 8, error_top), fill="#172738", width=3)
            draw.line((center - 8, error_bottom, center + 8, error_bottom), fill="#172738", width=3)
            draw.text((center, top - 14), f"{value:.{decimals}f}", fill="#172738",
                      font=small_font, anchor="mb")
            draw.text((center, y0 + height + 14), label, fill="#172738", font=small_font, anchor="ma")

    draw.text((1020, 724), "Bars show means; error bars show sample standard deviations; n = 3 seeds",
              fill="#52616B", font=text_font, anchor="ms")
    canvas.save(FIGURE, dpi=(300, 300))
    print(FIGURE)


if __name__ == "__main__":
    main()
