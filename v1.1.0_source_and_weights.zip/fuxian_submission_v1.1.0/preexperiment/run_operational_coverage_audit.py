"""Prediction-only deployment audit on all six frozen primary blind dates.

This does not score pixels lacking a trustworthy reference. It quantifies how
much of each map is observable and how many predictions a user would unknowingly
accept if the Landsat QA mask were ignored. Models and threshold remain frozen.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import rasterio
import torch

import run_multidate_ablation_pilot as ablation
import run_round4_fusion_confirmation as fusion
from run_multidate_ablation_pilot import predict


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "preexperiment" / "results" / "round4_final_blind"
RAW = ROOT / "preexperiment" / "data" / "round4_final_blind" / "raw"
CHECKPOINTS = ROOT / "preexperiment" / "results" / "round4_fusion_confirmation"
OUT = ROOT / "preexperiment" / "results" / "operational_coverage_audit"
SEEDS = (20260913, 20260929, 20261017)
PIXEL_KM2 = 0.0009


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fraction(part: np.ndarray, whole: np.ndarray) -> float:
    return float(part.sum() / max(int(whole.sum()), 1))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pairs = json.loads((BASE / "evaluation_pairs.json").read_text(encoding="utf-8"))["selected"]
    assert len(pairs) == 6
    ablation.DRAFTS = BASE / "reference_drafts"
    scenes = [ablation.read_scene({"l8_date": r["l8_date"],
                                   "s2_date": r["s2_date"],
                                   "split": "final_blind_test"}) for r in pairs]
    norm = json.loads((CHECKPOINTS / "fusion_confirmation_results.json").read_text(
        encoding="utf-8"))["normalization"]
    records = []
    for scene in scenes:
        day = scene["tag"]
        with rasterio.open(RAW / f"Fuxian_final_masks_native_{day}.tif") as src:
            masks = src.read().astype(bool)
        roi = masks[4]
        shore = masks[0] & roi
        finite = np.all(np.isfinite(scene["x_raw"]) & (scene["x_raw"] > -9000), axis=0)
        l8_ok = finite & masks[1] & roi
        s2_ok = masks[2] & roi
        joint_ok = finite & masks[3] & roi
        scene["x"] = np.stack([
            (np.clip(scene["x_raw"][b], st["p01"], st["p99"]) - st["mean"]) / st["std"]
            for b, st in enumerate(norm)
        ]).astype("float32")
        scene["x"][~np.isfinite(scene["x"])] = 0
        scene["priors"] = np.stack([scene["interior"], scene["shore"]]).astype("float32")
        with rasterio.open(BASE / "screened_reference" / day / "exclusion_mask_L8_30m.tif") as src:
            screened = scene["valid"] & ~src.read(1).astype(bool)
        record = {
            "date": scene["record"]["l8_date"],
            "roi_km2": int(roi.sum()) * PIXEL_KM2,
            "l8_observable_roi_fraction": fraction(l8_ok, roi),
            "l8_observable_shore_fraction": fraction(l8_ok & shore, shore),
            "s2_observable_shore_fraction": fraction(s2_ok & shore, shore),
            "joint_observable_shore_fraction": fraction(joint_ok & shore, shore),
            "screened_reference_roi_fraction": fraction(screened, roi),
            "screened_reference_shore_fraction": fraction(screened & shore, shore),
            "l8_unobservable_roi_km2": int((roi & ~l8_ok).sum()) * PIXEL_KM2,
            "l8_unobservable_shore_km2": int((shore & ~l8_ok).sum()) * PIXEL_KM2,
        }
        scene["operational_masks"] = (roi, l8_ok, shore)
        scene["operational_record"] = record
        records.append(record)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_rows = []
    checksums = {}
    for seed in SEEDS:
        cp = CHECKPOINTS / f"prior_seed{seed}_best.pt"
        checksums[str(seed)] = sha256(cp)
        model = fusion.CONFIGS["prior"][0]().to(device)
        model.load_state_dict(torch.load(cp, map_location=device, weights_only=False)["model"])
        model.eval()
        for scene in scenes:
            prob = predict(model, scene, device)
            pred = prob >= 0.5
            roi, l8_ok, shore = scene["operational_masks"]
            unknown = roi & ~l8_ok
            row = {
                "date": scene["record"]["l8_date"], "seed": seed,
                "water_area_qa_masked_km2": int((pred & l8_ok).sum()) * PIXEL_KM2,
                "water_area_if_qa_ignored_km2": int((pred & roi).sum()) * PIXEL_KM2,
                "untrustworthy_predicted_water_km2": int((pred & unknown).sum()) * PIXEL_KM2,
                "untrustworthy_predicted_water_fraction_of_unknown": fraction(pred & unknown, unknown),
                "unknown_roi_km2": int(unknown.sum()) * PIXEL_KM2,
                "unknown_shore_km2": int((shore & unknown).sum()) * PIXEL_KM2,
            }
            model_rows.append(row)
            print(seed, row["date"], row["untrustworthy_predicted_water_km2"], flush=True)
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    with (OUT / "coverage_by_date.csv").open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    with (OUT / "prediction_by_seed_date.csv").open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(model_rows[0]))
        writer.writeheader()
        writer.writerows(model_rows)
    summary = {
        "status": "DESCRIPTIVE_DEPLOYMENT_AUDIT_NOT_ACCURACY_ON_CLOUDS",
        "dates": [r["date"] for r in records],
        "n_dates": len(records), "n_seeds": len(SEEDS), "decision_threshold": 0.5,
        "model": "frozen spatial-prior model, unmodified probability output",
        "checkpoint_sha256": checksums,
        "mean_l8_observable_roi_fraction": float(np.mean([r["l8_observable_roi_fraction"] for r in records])),
        "mean_l8_observable_shore_fraction": float(np.mean([r["l8_observable_shore_fraction"] for r in records])),
        "mean_screened_reference_shore_fraction": float(np.mean([r["screened_reference_shore_fraction"] for r in records])),
        "mean_untrustworthy_predicted_water_km2": float(np.mean([r["untrustworthy_predicted_water_km2"] for r in model_rows])),
        "device": str(device),
        "interpretation": "No accuracy is assigned where Landsat QA fails or a screened reference is absent.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
