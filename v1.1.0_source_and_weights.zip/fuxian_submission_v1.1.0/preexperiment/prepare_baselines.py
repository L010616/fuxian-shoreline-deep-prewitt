"""Create reproducible baseline maps; this script does NOT create ground truth.

Input: seven-band GeoTIFF, B2 B3 B4 B5 B6 B7 (surface reflectance), valid (0/1).
The valid band must describe original observations, not a water mask.
Otsu calibration zone: aligned single-band 0/1 GeoTIFF supplied with --shore.
Output: diagnostic indices, threshold predictions and unnormalized edge responses.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu


def calculate(bands, valid, calibration_zone):
    blue, green, red, nir, swir1, swir2 = bands
    valid = valid & np.isfinite(bands).all(axis=0)
    denominator = green + swir1
    index_valid = valid & (np.abs(denominator) > 1e-6)
    mndwi = np.full(green.shape, np.nan, dtype=np.float32)
    np.divide(green - swir1, denominator, out=mndwi, where=index_valid)
    awei = blue + 2.5 * green - 1.5 * (nir + swir1) - 0.25 * swir2
    sample = mndwi[index_valid & calibration_zone]
    if sample.size < 100 or np.ptp(sample) <= 1e-6:
        raise ValueError('Insufficient variation or valid pixels for shore-zone Otsu.')
    threshold = float(threshold_otsu(sample))
    # Eight pixels cover the 4*sigma support of the largest (sigma=2) LoG.
    # A square erosion also excludes invalid pixels at kernel corners.
    edge_valid = ndi.binary_erosion(valid, structure=np.ones((17, 17)), border_value=0)
    edge_arrays, edge_names = [], []
    for band_name, band in [('nir', nir), ('swir1', swir1)]:
        safe = np.where(valid, band, 0).astype(np.float32)
        for axis, direction in [(1, 'x'), (0, 'y')]:
            edge_arrays.append(ndi.prewitt(safe, axis=axis, mode='reflect') / 6.0)
            edge_names.append(f'prewitt_{band_name}_{direction}')
        for sigma in [1.0, 2.0]:
            edge_arrays.append(sigma**2 * ndi.gaussian_laplace(safe, sigma=sigma, truncate=4))
            edge_names.append(f'log_{band_name}_sigma{int(sigma)}')
    return {
        'mndwi': mndwi, 'awei_sh': np.where(valid, awei, np.nan),
        'mndwi_prediction': np.where(index_valid, mndwi > threshold, 255).astype('uint8'),
        'awei_prediction': np.where(valid, awei > 0, 255).astype('uint8'),
        'edges': np.where(edge_valid, np.stack(edge_arrays), np.nan),
        'edge_names': edge_names, 'mndwi_threshold': threshold,
        'calibration_pixels': int(sample.size), 'valid_pixels': int(valid.sum()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('image', type=Path)
    parser.add_argument('--shore', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    with rasterio.open(args.image) as source:
        if source.count != 7:
            raise ValueError('Expected B2-B7 reflectance plus a seventh valid band.')
        data = source.read().astype('float32')
        valid = (data[6] == 1) & (source.read_masks()[:6] > 0).all(axis=0)
        profile = source.profile.copy()
        with rasterio.open(args.shore) as shore:
            if source.crs != shore.crs or source.transform != shore.transform or source.shape != shore.shape:
                raise ValueError('Shore mask must have exactly the same CRS, transform and shape.')
            # Four-band byte exports may be tagged RGBA: read_masks(1) would
            # silently use joint_valid as alpha and change the L8-only calibration.
            # The explicit binary shore band defines this zone, including valid zeros.
            if shore.nodata == 1:
                raise ValueError('Binary shore value 1 cannot also represent nodata.')
            zone = shore.read(1) == 1
    results = calculate(data[:6], valid, zone)
    args.output.mkdir(parents=True, exist_ok=True)

    def write(name, array, descriptions, nodata):
        if array.ndim == 2:
            array = array[None]
        target = profile.copy()
        target.update(driver='GTiff', count=array.shape[0], dtype=str(array.dtype),
                      nodata=nodata, compress='deflate')
        with rasterio.open(args.output / name, 'w', **target) as dst:
            dst.write(array)
            dst.descriptions = tuple(descriptions)

    write('indices.tif', np.stack([results['mndwi'], results['awei_sh']]), ['MNDWI', 'AWEI_sh'], np.nan)
    write('mndwi_otsu.tif', results['mndwi_prediction'], ['water_prediction'], 255)
    write('awei_zero.tif', results['awei_prediction'], ['water_prediction'], 255)
    write('edge_responses.tif', results['edges'], results['edge_names'], np.nan)
    info = {k: results[k] for k in ['mndwi_threshold','calibration_pixels','valid_pixels','edge_names']}
    info.update(input=str(args.image.resolve()), calibration_zone=str(args.shore.resolve()),
                awei_threshold=0, status='UNVALIDATED_PREDICTIONS_NOT_REFERENCE_LABELS')
    (args.output / 'processing.json').write_text(json.dumps(info, indent=2), encoding='utf8')
    print(json.dumps(info, indent=2))


if __name__ == '__main__':
    main()
