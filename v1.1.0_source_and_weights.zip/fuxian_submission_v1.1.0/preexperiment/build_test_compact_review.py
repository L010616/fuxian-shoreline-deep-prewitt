"""Create a 24-site compact manual-review pack for frozen test-label drafts."""
from __future__ import annotations

from pathlib import Path

import build_wave1_compact_review as review


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    review.BASE = ROOT / "preexperiment/results/formal_test_drafts_v02"
    review.DATES = ["20240214", "20240504", "20250507", "20251201"]
    review.REPORT_TITLE = "测试日期岸线简化复核"
    review.REPORT_INTRO = (
        "每个测试日期选取 6 个空间分散且风险最高的岸段，共 24 处。"
        "左图为 Landsat 8，右图为 Sentinel-2，青色线为自动参考岸线草稿。"
        "需要确认青色线沿目标日期可见水陆交界；云、云影和无法判断区域应保留为排除区。"
        "2025-05-07 与参考影像相差 2 天，必须额外检查短期水边变化。"
    )
    review.TEST_DATES_OPENED = True
    review.main()


if __name__ == "__main__":
    main()
