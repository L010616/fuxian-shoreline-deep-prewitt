SOURCE AND WEIGHTS ARCHIVE: compact numerical caches are supplied in the complete Zenodo DOI archive. Download that archive to run immediate metric verification.

# Fuxian Lake shoreline extraction: reproduction package 1.1.0

This package contains the original public source and numerical results plus the complete post-review supplement: nine frozen neural checkpoints, six prediction-blind manually delineated reference geometries, scope/temporal sensitivity records, and NDWI, MNDWI and fixed-2019-JRC controls.

## Immediate numerical reproduction

Install numpy, scipy and scikit-image in the recorded environment, then from this directory run:

```
python reproduce_reported_metrics.py
```

Expected: PASS, 192 rows and eight metrics per row, maximum absolute difference below 1e-9. The cache stores physical-reflectance index values on the common valid domain, fixed JRC masks and binary raw neural probability-ensemble predictions. Otsu thresholds are re-estimated without reference water labels. All 18 proxy-reference dates and six manual-reference dates are retained.

This check reproduces thresholding and metric calculation. It does not reproduce neural training or inference. To do those, obtain the original Landsat, Sentinel-2 and QA/JRC inputs using the supplied GEE programs, filenames and frozen date manifests, install the recorded PyTorch environment, and use the nine supplied weights with source normalization. Satellite scenes are not bundled. The new evaluators resolve their workspace from their own file location. Original immutable screening records retain historical paths; resolve these to equivalent downloaded files rather than changing labels, thresholds or hashes. Completed outputs are read-only evidence; use a separate output workspace for reruns.

## Layout

- src/, gee/, manifests/, environment/, results/: original public release.
- preexperiment/: complete research evaluator/model source; results/ contains frozen confirmation, manual, cross-lake, expanded-scope and temporal evidence.
- preexperiment/results/v27_index_jrc_20261001/: pre-evaluation rule freeze, all per-date metrics, thresholds, mean +/- sample SD, paired lake/date effects and compact verification cache.
- provenance/buffer_protocol.json: separate validation-only prior-width retraining. Its raster EDT approximation differs from the formal exported prior; Fig. S1 is not another estimate of Table 4.
- CITATION.cff, SHA256SUMS.txt, RELEASE_INVENTORY.json: citation and integrity records.

## Interpretation

The new comparisons are post-review descriptive analyses. Indices use zero thresholds or per-image Otsu thresholds (256 bins); they have no component cleanup, hole filling or imposed stable-interior assignment. JRC is a fixed 2019 annual named-lake footprint, not a contemporaneous observation or ground truth. All methods share expanded 1-km, cloud-screened evaluation support. This is not an all-weather or unprocessed-scene experiment. Manual references represent six interpretable dates in three lakes. Automatic Sentinel-2 masks are spectral diagnostic references, including one questionable Xingyun 2022-03-12 contour retained in analysis. Three lake clusters do not justify population-wide significance.

Deep Prewitt improves Boundary F1 over the fixed JRC footprint, but has no observed average ASD advantage over JRC. All outcomes, including unfavourable comparisons, are supplied. Dates nested within lakes use descriptive two-stage resampling; between-date SD must not be called standard error.

Archive DOI: https://doi.org/10.5281/zenodo.23083486
Repository: https://github.com/L010616/fuxian-shoreline-deep-prewitt

Public release status is established by the archive landing page, not by this local README.
